using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Clipxel.Models;
using Clipxel.Windows;

namespace Clipxel;
public partial class App
{
    private ReferenceBoardWindow? _referenceBoard;
    private bool _referenceMode;
    private readonly HashSet<PinWindow> _boardHiddenPins = new();

    public void ToggleReferenceMode()
    {
        if (_shuttingDown) return;
        if (_preferences is not null) { _preferences.Activate(); return; }
        if (_capturePending || SelectionWindow.IsCaptureActive)
        { _trayService?.ShowNotice("請先完成或取消截圖，再切換模式。"); return; }
        try
        {
            if (_referenceMode)
            {
                _referenceMode = false; _referenceBoard?.Hide();
                foreach (var pin in _boardHiddenPins.ToArray()) if (_pins.Contains(pin)) pin.Show();
                _boardHiddenPins.Clear();
            }
            else
            {
                bool first = _referenceBoard is null;
                if (_referenceBoard is null)
                {
                    _referenceBoard = new ReferenceBoardWindow();
                    _referenceBoard.ReturnRequested += ToggleReferenceMode;
                    _referenceBoard.PasteRequested += () => HandleCommand("paste");
                    _referenceBoard.CaptureRequested += () => BeginCapture();
                    _referenceBoard.ImportRequested += () =>
                    {
                        var dialog = new OpenFileDialog { Multiselect = true, Filter = "圖片|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff", Title = "加入參考圖片" };
                        if (dialog.ShowDialog(_referenceBoard) == true) ImportReferenceFiles(dialog.FileNames);
                    };
                }
                // Snapshot before hiding: the original annotation models remain editable.
                _referenceBoard.SyncPins(_pins);
                foreach (var pin in _pins.Where(pin => pin.IsVisible).ToArray())
                { _boardHiddenPins.Add(pin); pin.HideFromTray(); }
                _referenceMode = true;
                _referenceBoard.Show(); _referenceBoard.Activate();
                if (first) _referenceBoard.Dispatcher.BeginInvoke(new Action(_referenceBoard.FitAll));
            }
            UpdateState();
        }
        catch (Exception ex)
        {
            // A failed transition must never strand the user's images out of sight.
            _referenceMode = false; _referenceBoard?.Hide();
            foreach (var pin in _boardHiddenPins.ToArray()) if (_pins.Contains(pin)) pin.Show();
            _boardHiddenPins.Clear(); LogError("Switch reference mode", ex);
            _trayService?.ShowNotice("切換模式失敗：" + ex.Message);
        }
    }

    internal void RegisterProjectPin(PinWindow pin)
    {
        _pins.Add(pin); _boardHiddenPins.Add(pin);
        pin.Closed += (_, _) => { _pins.Remove(pin); _hidden.Remove(pin); _boardHiddenPins.Remove(pin); _referenceBoard?.RemovePin(pin); UpdateState(); };
        UpdateState();
    }
    private bool _openingProject;
    internal void OpenBoardProject(string path)
    {
        if (_openingProject || _capturePending || SelectionWindow.IsCaptureActive) { _trayService?.ShowNotice("請先完成目前操作，再開啟專案。"); return; }
        if (!File.Exists(path)) { _trayService?.ShowNotice("找不到專案檔。"); return; }
        if (!_referenceMode) ToggleReferenceMode();
        if (!_referenceMode || _referenceBoard is null) return;
        _openingProject=true;
        try { _referenceBoard.Show(); _referenceBoard.Activate(); _referenceBoard.OpenProject(path); }
        finally { _openingProject=false; }
    }
    public void ImportReferenceFiles(IEnumerable<string> paths)
    {
        var inputs=paths.ToArray();
        var projects=inputs.Where(path => Services.ProjectAssociation.IsProjectPath(path)).ToArray();
        if(projects.Length > 0)
        {
            if(inputs.Length != 1) { _trayService?.ShowNotice("請一次拖入一個專案，圖片請另外加入。"); return; }
            OpenBoardProject(projects[0]); return;
        }
        paths=inputs;
        var errors = new List<string>();
        foreach (string path in paths)
        {
            try
            {
                using var stream = File.OpenRead(path);
                var bitmap = new BitmapImage(); bitmap.BeginInit(); bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = stream; bitmap.EndInit(); bitmap.Freeze();
                if ((long)bitmap.PixelWidth * bitmap.PixelHeight > 64_000_000) throw new InvalidOperationException("圖片超過 6400 萬像素。");
                AddPin(bitmap, Array.Empty<Annotation>());
            }
            catch (Exception ex) { LogError("Import reference image", ex); errors.Add(Path.GetFileName(path)); }
        }
        if (_referenceMode) _referenceBoard?.FitAll();
        if (errors.Count > 0) _trayService?.ShowNotice("無法讀取：" + string.Join("、", errors.Take(5)));
    }
}
