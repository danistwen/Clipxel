using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Clipxel.Models;
using Clipxel.Services;
using Clipxel.Windows;
namespace Clipxel;
public partial class App : Application
{
    public static Preferences Settings { get; private set; } = new();
    private HotkeyHost? _hotkeyHost;
    private TrayService? _trayService;
    private Mutex? _instanceMutex;
    private bool _ownsMutex, _capturePending, _shuttingDown;
    private readonly List<PinWindow> _pins = new();
    private readonly HashSet<PinWindow> _hidden = new();
    private DispatcherTimer? _timer;
    private DateTimeOffset? _pauseUntil;
    private bool _manualPause, _suspended = true;
    private PreferencesWindow? _preferences;
    private CancellationTokenSource? _countdown;
    private PixelRect? _lastRegion, _lastDesktop;
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        SliderScrub.Register();MistBackdrop.Register();DialogChrome.Register();
        DispatcherUnhandledException += (_, error) => { LogError("Unhandled UI error", error.Exception); error.Handled = true; AppDialogWindow.ShowMessage("Clipxel 遇到錯誤，請重新啟動。\n" + LogPath); ShutdownSafely(1); };
        if (e.Args.Length > 0 && e.Args[0] == "--self-test") { ShutdownSafely(Tests.SelfTests.Run(e.Args.Length > 1 ? e.Args[1] : Path.Combine(Path.GetTempPath(), "Clipxel-self-test.txt"))); return; }
        _instanceMutex = new Mutex(true, @"Local\PinShot.Desktop.Singleton", out _ownsMutex);
        if (!_ownsMutex) { var project = e.Args.FirstOrDefault(a => ProjectAssociation.IsProjectPath(a)); if (project is not null && ProjectAssociation.Send(project)) { ShutdownSafely(); return; } if (!e.Args.Contains("--startup")) AppDialogWindow.ShowMessage("Clipxel 已在執行中，請從右下角通知區域開啟。"); ShutdownSafely(); return; }
        Settings = PreferenceStore.Load();ThemeService.Apply();
        try { ProjectAssociation.Register(); } catch (Exception ex) { LogError("Register project icon",ex); }
        _ = ProjectAssociation.Listen(path => Dispatcher.BeginInvoke(new Action(() => OpenBoardProject(path))));
        _trayService = new TrayService(); _trayService.Command += HandleCommand;
        _hotkeyHost = new HotkeyHost(); _hotkeyHost.RegistrationWarning += message => _trayService.ShowNotice(message);
        _hotkeyHost.ActionRequested += id => {if(!System.Windows.Interop.ComponentDispatcher.IsThreadModal)HandleCommand(id switch { 3 => "paste", 4 => "pins", 5 => "board", _ => "capture" });};
        _hotkeyHost.Show();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) }; _timer.Tick += (_, _) => UpdateState(); _timer.Start(); UpdateState();
        var openPath=e.Args.FirstOrDefault(a => ProjectAssociation.IsProjectPath(a));
        if(openPath is not null) Dispatcher.BeginInvoke(new Action(() => OpenBoardProject(openPath)));
        if (!e.Args.Contains("--startup")) _trayService.ShowNotice("Clipxel 0.4.37 已啟動。右鍵圖示可設定快捷鍵與開機啟動。");
    }
    private void UpdateState()
    {
        if (_shuttingDown) return;
        if (_manualPause && _pauseUntil.HasValue && DateTimeOffset.Now >= _pauseUntil.Value) { _manualPause = false; _pauseUntil = null; }
        string reason = System.Windows.Interop.ComponentDispatcher.IsThreadModal ? "對話視窗開啟中" : _preferences is not null ? "設定中" : _manualPause ? (_pauseUntil.HasValue ? "至 " + _pauseUntil.Value.LocalDateTime.ToString("HH:mm") : "手動暫停") : ForegroundProgram.ShouldPause(Settings) ? "前景程式" : "";
        bool suspend = reason.Length > 0;
        if (suspend != _suspended) { _suspended = suspend; if (suspend) _hotkeyHost?.Suspend(); else _hotkeyHost?.Register(Settings); }
        _trayService?.Update(reason, _manualPause, _hidden.Count > 0, _pins.Count, _lastRegion.HasValue, _countdown is not null, Settings.CaptureKey);
    }
    private async void HandleCommand(string command)
    {
        try
        {
            if (command.StartsWith("pause:")) { int minutes = int.Parse(command[6..]); _manualPause = true; _pauseUntil = minutes == 0 ? null : DateTimeOffset.Now.AddMinutes(minutes); UpdateState(); return; }
            if (command.StartsWith("delay:")) { BeginCapture(int.Parse(command[6..])); return; }
            switch (command)
            {
                case "board": ToggleReferenceMode(); break;
                case "capture": BeginCapture(); break;
                case "cancel": _countdown?.Cancel(); break;
                case "resume": _manualPause = false; _pauseUntil = null; UpdateState(); break;
                case "pins":
                    if (_referenceMode && _referenceBoard is not null)
                    {
                        if (_referenceBoard.IsVisible) _referenceBoard.Hide(); else { _referenceBoard.Show(); _referenceBoard.Activate(); }
                        break;
                    }
                    if (_hidden.Count > 0) { foreach (var pin in _hidden.ToArray()) pin.Show(); _hidden.Clear(); }
                    else foreach (var pin in _pins.Where(x => x.IsVisible).ToArray()) { pin.HideFromTray(); _hidden.Add(pin); }
                    UpdateState(); break;
                case "paste":
                    var bitmap = await ClipboardService.GetImageAsync();
                    if (bitmap is null) _trayService?.ShowNotice("剪貼簿中沒有圖片。"); else AddPin(bitmap, Array.Empty<Annotation>());
                    break;
                case "last": BeginCapture(last: true); break;
                case "settings": ShowPreferences(); break;
                case "shortcuts": ShowShortcutPreferences(); break;
                case "startup": StartupService.Set(!StartupService.Enabled); break;
                case "folder": Directory.CreateDirectory(Settings.SaveFolder); Process.Start(new ProcessStartInfo(Settings.SaveFolder) { UseShellExecute = true }); break;
                case "about": AppDialogWindow.ShowMessage("Clipxel 0.4.37\n作者：danistwen", "關於 Clipxel"); break;
                case "exit": ShutdownSafely(); break;
            }
        }
        catch (Exception ex) { LogError(command, ex); _trayService?.ShowNotice("操作失敗：" + ex.Message); }
    }
    public void ShowCanvasPreferences() => ShowPreferences();
    public void ShowShortcutPreferences() { ShowPreferences(); _preferences?.SelectShortcuts(); }
    private void ShowPreferences()
    {
        if (_preferences is not null) { if(_referenceMode && _referenceBoard?.IsVisible==true)CanvasTheme.Apply(_preferences,_referenceBoard.CanvasBackground); _preferences.Activate(); return; }
        if (SelectionWindow.IsCaptureActive) { _trayService?.ShowNotice("請先完成或取消目前的截圖。"); return; }
        _countdown?.Cancel();
        _preferences = new PreferencesWindow(Settings, (next, startup) =>
        {
            next.Validate(); string? failure = _hotkeyHost?.Register(next, probe: true); if (failure is not null) return failure;
            object? previousStartup = StartupService.Read();
            try { StartupService.Set(startup); PreferenceStore.Save(next); Settings = next; ThemeService.Apply();return null; }
            catch (Exception ex)
            {
                try { StartupService.Restore(previousStartup); } catch (Exception restore) { LogError("Restore startup", restore); return ex.Message + "\n開機啟動設定無法還原，請重新確認。"; }
                return ex.Message;
            }
        });
        _preferences.Closed += (_, _) => { _preferences = null; UpdateState(); };
        if (_referenceMode && _referenceBoard?.IsVisible == true) { _preferences.Owner = _referenceBoard; CanvasTheme.Apply(_preferences,_referenceBoard.CanvasBackground); }
        UpdateState(); DialogOwner.Prepare(_preferences); _preferences.Show(); _preferences.Activate();
    }
    public void RememberRegion(PixelRect region, PixelRect desktop) { _lastRegion = region; _lastDesktop = desktop; UpdateState(); }
    private void AddPin(BitmapSource bitmap, IEnumerable<Annotation> annotations)
    {
        var pin = new PinWindow(bitmap, annotations); _pins.Add(pin);
        pin.Closed += (_, _) => { _pins.Remove(pin); _hidden.Remove(pin); _boardHiddenPins.Remove(pin); _referenceBoard?.RemovePin(pin); UpdateState(); };
        if (_referenceMode)
        {
            _boardHiddenPins.Add(pin);
            _referenceBoard?.SyncPins(_pins);
            _referenceBoard?.Show();
            if (_referenceBoard is not null) _referenceBoard.Dispatcher.BeginInvoke(new Action(_referenceBoard.FitAll));
        }
        else pin.Show();
        UpdateState();
    }
    private async void BeginCapture(int seconds = 0, bool last = false)
    {
        if (_capturePending || _shuttingDown || SelectionWindow.IsCaptureActive || _preferences is not null) return;
        if (last && (!_lastRegion.HasValue || !_lastDesktop.HasValue)) return;
        _capturePending = true; var cancellation = new CancellationTokenSource(); _countdown = cancellation; UpdateState();
        SelectionWindow? selector = null;
        try
        {
            // No toast during countdown: it could otherwise be included in the screenshot.
            await Task.Delay(seconds == 0 ? 180 : seconds * 1000, cancellation.Token);
            if (_shuttingDown) return;
            DesktopCapture source;
            var temporarilyHidden = last ? _pins.Where(pin => pin.IsVisible).ToArray() : Array.Empty<PinWindow>();
            bool restoreBoard = _referenceMode && _referenceBoard?.IsVisible == true;
            try
            {
                foreach (var pin in temporarilyHidden) pin.HideFromTray();
                if (restoreBoard) _referenceBoard?.Hide();
                if (temporarilyHidden.Length > 0 || restoreBoard) await Task.Delay(150, cancellation.Token);
                source = ScreenCaptureService.CaptureVirtualScreen();
            }
            finally
            {
                if (!_shuttingDown)
                {
                    foreach (var pin in temporarilyHidden) if (_pins.Contains(pin)) pin.Show();
                    if (restoreBoard) _referenceBoard?.Show();
                }
            }
            if (last)
            {
                if (source.Bounds != _lastDesktop!.Value) throw new InvalidOperationException("螢幕範圍已變更，請重新選取區域。");
                var r = _lastRegion!.Value;
                var bitmap = ScreenCaptureService.CropDetached(source.Bitmap, new Int32Rect(r.X, r.Y, r.Width, r.Height));
                AddPin(bitmap, Array.Empty<Annotation>()); await CaptureStorage.AutoSaveAsync(bitmap); return;
            }
            selector = new SelectionWindow(source);
            selector.RegionCaptured += async (_, result) =>
            {
                try
                {
                    AddPin(result.Bitmap, result.Annotations);
                    if (Settings.AutoSave) await CaptureStorage.AutoSaveAsync(ImageExportService.Compose(result.Bitmap, result.Annotations.Select(Clipxel.Rendering.AnnotationRenderer.Build).ToArray()));
                }
                catch (Exception ex) { LogError("Create pin", ex); _trayService?.ShowNotice("建立釘圖失敗：" + ex.Message); }
            };
            selector.Show(); selector.Activate();
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { selector?.Close(); LogError("Begin capture", ex); _trayService?.ShowNotice("截圖失敗：" + ex.Message); }
        finally { if (ReferenceEquals(_countdown, cancellation)) _countdown = null; cancellation.Dispose(); _capturePending = false; UpdateState(); }
    }
    public static string LogPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "Clipxel", "error.log");

    public static void LogError(string operation, Exception error)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
            if (File.Exists(LogPath) && new FileInfo(LogPath).Length > 1_000_000)
                File.Move(LogPath, LogPath + ".previous", overwrite: true);
            File.AppendAllText(LogPath, $"{DateTimeOffset.Now:O} {operation}\n{error}\n\n");
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }


    private void ShutdownSafely(int code = 0)
    {
        _shuttingDown = true;
        if (_referenceBoard is not null) _referenceBoard.AllowClose = true;
        Shutdown(code);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _shuttingDown = true;
        if (_referenceBoard is not null) _referenceBoard.AllowClose = true;
        _timer?.Stop(); _countdown?.Cancel(); _hotkeyHost?.Close(); _trayService?.Dispose();
        if (_ownsMutex) _instanceMutex?.ReleaseMutex(); _instanceMutex?.Dispose(); base.OnExit(e);
    }
}
