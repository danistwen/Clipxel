# Clipxel 品牌來源

此資料夾保留品牌色票、三種字標 SVG 原稿及現用圖示的來源紀錄，供維護設計時使用。
程式實際使用的圖示、PNG 與 WPF 字標資源位於 ../Assets。

- Clipxel_Color_Palette.json / .txt：品牌色票。
- clipxel-logotype-dark.svg / color.svg / black.svg：字標原稿。
- asset-origins.json：仍保留之應用資產的來源與既有雜湊紀錄。

完整品牌展示圖及未使用之圖檔不包含在本原始碼精簡包；請使用原有品牌包取得。
