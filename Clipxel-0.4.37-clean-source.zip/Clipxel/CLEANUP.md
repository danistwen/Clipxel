# 0.4.37 原始碼封裝清理

不修改程式功能、版本與建置／簽章流程。完整原包保留，這是獨立精簡副本。

整理 README、驗證文件與品牌說明；資產來源清單同步移除已刪圖檔項目。

移除清單：

- History/README-PinShot-0.4.24.md
- History/toolbar-preview.png
- History/toolbar-preview.svg
- legacy-version-notes/RELEASE-0.4.32.md
- legacy-version-notes/RELEASE-0.4.31.md
- legacy-version-notes/RELEASE-0.4.32.1.md
- legacy-version-notes/RELEASE-0.4.32.2.md
- RELEASE-0.4.36.md
- RELEASE-0.4.32.md
- RELEASE-0.4.22.md
- RELEASE-0.4.33.md
- RELEASE-0.4.23.md
- RELEASE-0.4.30.md
- RELEASE-0.4.4.md
- RELEASE-0.4.12.md
- RELEASE-0.4.31.md
- RELEASE-0.4.18.md
- RELEASE-0.4.13.md
- RELEASE-0.4.32.1.md
- RELEASE-0.4.19.md
- RELEASE-0.4.9.md
- RELEASE-0.4.16.md
- RELEASE-0.4.32.2.md
- RELEASE-0.4.18.1.md
- RELEASE-0.4.17.md
- RELEASE-0.4.24.md
- RELEASE-0.4.8.md
- RELEASE-0.4.25.md
- RELEASE-0.4.14.md
- RELEASE-0.4.26.md
- RELEASE-0.4.20.md
- RELEASE-0.4.15.md
- RELEASE-0.4.5.md
- RELEASE-0.4.6.md
- RELEASE-0.4.34.md
- RELEASE-0.4.10.md
- RELEASE-0.4.21.md
- RELEASE-0.4.29.md
- RELEASE-0.4.35.md
- RELEASE-0.4.11.md
- RELEASE-0.4.28.md
- RELEASE-0.4.7.md
- RELEASE-0.4.27.md
- Brand/Clipxel_Brand_Asset_Sheet.png
- source-checks.txt
- Assets/Clipxel-caption-light.png
- Assets/Clipxel-caption-dark.png
- Assets/Clipxel-white-32.png
- Assets/Clipxel-20.png
- Assets/Clipxel-256.png
- Assets/Clipxel-dark-32.png
- Assets/Clipxel-16.png
- Assets/Clipxel-128.png
- Assets/Clipxel-40.png
- Assets/Clipxel-thumbnail.png
- Assets/Clipxel-white-64.png
- Assets/Clipxel-dark-64.png
- Assets/Clipxel-logotype-white.png
- Assets/Clipxel-32.png
- Assets/Clipxel-24.png
- Assets/Clipxel-48.png
