using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Services;
using Clipxel.Windows;
namespace Clipxel.Controls;

// Kept as the public HSV helper used by older self-tests and integrations.
public static class ColorWheel
{
    public static Color FromHsv(double h,double s,double v,byte a)
    {
        h=(h%360+360)%360;s=Math.Clamp(s,0,1);v=Math.Clamp(v,0,1);
        double c=v*s,x=c*(1-Math.Abs(h/60%2-1)),m=v-c;
        var rgb=(h/60) switch {<1=>(c,x,0d),<2=>(x,c,0d),<3=>(0d,c,x),<4=>(0d,x,c),<5=>(x,0d,c),_=>(c,0d,x)};
        return Color.FromArgb(a,(byte)Math.Round((rgb.Item1+m)*255),(byte)Math.Round((rgb.Item2+m)*255),(byte)Math.Round((rgb.Item3+m)*255));
    }
}

public sealed class ColorSpectrum : FrameworkElement
{
    private static readonly BitmapSource Texture=CreateTexture();
    private Point _position=new(.5,0);
    private Color _selected=Colors.Red;
    public event Action<Color>? Changed;
    public ColorSpectrum()
    {
        Height=236;Cursor=Cursors.Cross;Focusable=true;
        MouseLeftButtonDown+=(_,e)=>{Focus();CaptureMouse();Pick(e.GetPosition(this));e.Handled=true;};
        MouseMove+=(_,e)=>{if(IsMouseCaptured&&e.LeftButton==MouseButtonState.Pressed)Pick(e.GetPosition(this));};
        MouseLeftButtonUp+=(_,e)=>{if(IsMouseCaptured){Pick(e.GetPosition(this));ReleaseMouseCapture();e.Handled=true;}};
        Unloaded+=(_,_)=>{if(IsMouseCaptured)ReleaseMouseCapture();};
        KeyDown+=(_,e)=>{double dx=e.Key==Key.Left?-.01:e.Key==Key.Right?.01:0,dy=e.Key==Key.Up?-.01:e.Key==Key.Down?.01:0;if(dx!=0||dy!=0){Pick(new Point((_position.X+dx)*ActualWidth,(_position.Y+dy)*ActualHeight));e.Handled=true;}};
    }
    public static Color At(double x,double y)=>ColorWheel.FromHsv(Math.Clamp(y,0,1)*360,Math.Min(1,Math.Clamp(x,0,1)*2),Math.Min(1,(1-Math.Clamp(x,0,1))*2),255);
    private static BitmapSource CreateTexture()
    {
        const int w=320,h=256;var pixels=new byte[w*h*4];
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){var c=At(x/(w-1d),y/(h-1d));int i=(y*w+x)*4;pixels[i]=c.B;pixels[i+1]=c.G;pixels[i+2]=c.R;pixels[i+3]=255;}
        var image=BitmapSource.Create(w,h,96,96,PixelFormats.Bgra32,null,pixels,w*4);image.Freeze();return image;
    }
    public void SetColor(Color c)
    {
        _selected=c;double r=c.R/255d,g=c.G/255d,b=c.B/255d,max=Math.Max(r,Math.Max(g,b)),min=Math.Min(r,Math.Min(g,b)),d=max-min;
        double hue=d==0?_position.Y*360:max==r?60*((g-b)/d%6):max==g?60*((b-r)/d+2):60*((r-g)/d+4);
        if(hue<0)hue+=360;
        // Arbitrary HEX/swatches retain their exact RGB; the ring is a projection.
        _position=new Point(1-(max+min)/2,hue/360);InvalidateVisual();
    }
    private void Pick(Point p)
    {
        if(ActualWidth<=0||ActualHeight<=0)return;
        _position=new Point(Math.Clamp(p.X/ActualWidth,0,1),Math.Clamp(p.Y/ActualHeight,0,1));_selected=At(_position.X,_position.Y);InvalidateVisual();Changed?.Invoke(_selected);
    }
    protected override void OnRender(DrawingContext dc)
    {
        var clip=new RectangleGeometry(new Rect(RenderSize),9,9);dc.PushClip(clip);dc.DrawImage(Texture,new Rect(RenderSize));dc.Pop();
        var p=new Point(Math.Clamp(_position.X*ActualWidth,12,Math.Max(12,ActualWidth-12)),Math.Clamp(_position.Y*ActualHeight,12,Math.Max(12,ActualHeight-12)));
        dc.DrawEllipse(new SolidColorBrush(Color.FromRgb(_selected.R,_selected.G,_selected.B)),new Pen(new SolidColorBrush(Color.FromArgb(80,0,0,0)),5),p,10,10);
        dc.DrawEllipse(null,new Pen(Brushes.White,2.5),p,10,10);
    }
}

public sealed class OpacityStrip : FrameworkElement
{
    private Color _color=Colors.White;private double _value=100;
    public event Action<double>? Changed;
    public OpacityStrip()
    {
        Height=34;MinWidth=80;Cursor=Cursors.Hand;Focusable=true;
        MouseLeftButtonDown+=(_,e)=>{Focus();CaptureMouse();Pick(e.GetPosition(this).X);e.Handled=true;};
        MouseMove+=(_,e)=>{if(IsMouseCaptured&&e.LeftButton==MouseButtonState.Pressed)Pick(e.GetPosition(this).X);};
        MouseLeftButtonUp+=(_,e)=>{if(IsMouseCaptured){Pick(e.GetPosition(this).X);ReleaseMouseCapture();e.Handled=true;}};
        Unloaded+=(_,_)=>{if(IsMouseCaptured)ReleaseMouseCapture();};
        KeyDown+=(_,e)=>{double? value=e.Key switch{Key.Left or Key.Down=>_value-1,Key.Right or Key.Up=>_value+1,Key.Home=>0,Key.End=>100,_=>null};if(value.HasValue){_value=Math.Clamp(value.Value,0,100);InvalidateVisual();Changed?.Invoke(_value);e.Handled=true;}};
    }
    public void Set(Color c){_color=c;_value=c.A/255d*100;InvalidateVisual();}
    private void Pick(double x){_value=Math.Clamp((x-16)/Math.Max(1,ActualWidth-32),0,1)*100;InvalidateVisual();Changed?.Invoke(_value);}
    protected override void OnRender(DrawingContext dc)
    {
        var rect=new Rect(1,2,Math.Max(1,ActualWidth-2),30);dc.PushClip(new RectangleGeometry(rect,15,15));
        dc.DrawRectangle(ColorPicker.Checker(),null,rect);
        dc.DrawRectangle(new LinearGradientBrush(Color.FromArgb(0,_color.R,_color.G,_color.B),Color.FromRgb(_color.R,_color.G,_color.B),0),null,rect);dc.Pop();
        var p=new Point(16+(ActualWidth-32)*_value/100,17);
        dc.DrawEllipse(new SolidColorBrush(Color.FromRgb(_color.R,_color.G,_color.B)),new Pen(new SolidColorBrush(Color.FromArgb(70,0,0,0)),5),p,13,13);
        dc.DrawEllipse(null,new Pen(Brushes.White,2.5),p,13,13);
    }
}

public sealed class ColorPicker : StackPanel
{
    private readonly ColorSpectrum _spectrum=new();
    private readonly OpacityStrip _alpha=new();
    private readonly TextBox _hex=new(){Margin=new Thickness(0,4,6,0),Padding=new Thickness(7),FontFamily=new FontFamily("Consolas")};
    private readonly TextBox _percent=new(){Style=(Style)Application.Current.FindResource("InlineNumber"),Padding=new Thickness(2),VerticalContentAlignment=VerticalAlignment.Center,HorizontalContentAlignment=HorizontalAlignment.Center,Margin=new Thickness(10,0,0,0)};
    private readonly TextBlock _error=new(){Foreground=Brushes.OrangeRed,TextWrapping=TextWrapping.Wrap,FontSize=11};
    private readonly Border _preview=new(){Width=65,Height=65,CornerRadius=new CornerRadius(9),Margin=new Thickness(0,5,12,5)};
    private readonly WrapPanel _swatches=new();
    private readonly List<(Border Ring,Color Color)> _rings=new();
    private bool _sync,_sampling,_alphaDirty;
    private Action? _commitInput;
    public Color Selected {get;private set;}=Colors.White;
    public Window? SourceOwner {get;set;}
    public event Action<Color>? ColorChanged;
    public event Action<bool>? SamplingChanged;
    private static string SwatchFile=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Clipxel","swatches.json");
    private static readonly Brush CheckerBrush=CreateChecker();
    public ColorPicker(Color initial)
    {
        Width=292;Margin=new Thickness(14);Background=Brushes.Transparent;
        MouseRightButtonDown+=(_,e)=>e.Handled=true;MouseRightButtonUp+=(_,e)=>e.Handled=true;
        Children.Add(_spectrum);
        Children.Add(new TextBlock{Text="OPACITY",FontWeight=FontWeights.SemiBold,FontSize=11,Foreground=Brushes.WhiteSmoke,Margin=new Thickness(0,14,0,5)});
        var alphaRow=new DockPanel();DockPanel.SetDock(_percent,Dock.Right);alphaRow.Children.Add(_percent);alphaRow.Children.Add(_alpha);Children.Add(alphaRow);
        Children.Add(new Border{Height=1,Background=new SolidColorBrush(Color.FromArgb(70,210,216,224)),Margin=new Thickness(0,15,0,12)});
        var swatchRow=new DockPanel();DockPanel.SetDock(_preview,Dock.Left);swatchRow.Children.Add(_preview);swatchRow.Children.Add(_swatches);Children.Add(swatchRow);
        var hexRow=new DockPanel();var eyedrop=new Button{Content=new Clipxel.Rendering.ToolGlyph{Glyph="PickColor"},Width=34,Height=34,Margin=new Thickness(0,4,0,0),ToolTip="吸取畫布色彩"};DockPanel.SetDock(eyedrop,Dock.Right);hexRow.Children.Add(eyedrop);hexRow.Children.Add(_hex);Children.Add(hexRow);Children.Add(_error);
        _hex.ToolTip="#RRGGBB 或 #AARRGGBB";_percent.ToolTip="不透明度 0–100%";
        var add=new Button{Content="＋ 儲存目前色票",Padding=new Thickness(6),Margin=new Thickness(0,8,0,0)};Children.Add(add);
        _spectrum.Changed+=c=>Publish(Color.FromArgb(Selected.A,c.R,c.G,c.B));
        _alpha.Changed+=value=>Publish(Color.FromArgb((byte)Math.Round(value/100*255),Selected.R,Selected.G,Selected.B));
        void ApplyHex()
        {
            if(_sync||_sampling)return;string text=_hex.Text.Trim();
            if((text.Length!=7&&text.Length!=9)||text[0]!='#'||!text.Skip(1).All(Uri.IsHexDigit)){_error.Text="請輸入 #RRGGBB 或 #AARRGGBB。";return;}
            try{Publish((Color)ColorConverter.ConvertFromString(text));_error.Text="";}catch(FormatException){_error.Text="色號格式不正確。";}
        }
        void ApplyAlpha(){if(_sync||_sampling||!_alphaDirty)return;if(double.TryParse(_percent.Text.Trim().TrimEnd('%'),out double value)&&double.IsFinite(value)&&value>=0&&value<=100){Publish(Color.FromArgb((byte)Math.Round(value/100*255),Selected.R,Selected.G,Selected.B));_error.Text="";}else _error.Text="不透明度請填 0–100%。";}
        _commitInput=()=>{if(_hex.IsKeyboardFocusWithin)ApplyHex();else if(_percent.IsKeyboardFocusWithin)ApplyAlpha();};
        _hex.KeyDown+=(_,e)=>{if(e.Key==Key.Enter){ApplyHex();e.Handled=true;}};_hex.LostKeyboardFocus+=(_,_)=>ApplyHex();
        _percent.TextChanged+=(_,_)=>{if(!_sync)_alphaDirty=true;};
        _percent.KeyDown+=(_,e)=>{if(e.Key==Key.Enter){ApplyAlpha();e.Handled=true;}};_percent.LostKeyboardFocus+=(_,_)=>ApplyAlpha();
        eyedrop.Click+=(_,_)=>
        {
            if(_sampling)return;var owner=SourceOwner??MistBackdrop.FindOwner(this);var source=DocumentSurface.Find(owner);
            if(owner is null||source is null){_error.Text="請從畫布或釘圖開啟色盤後取色。";return;}
            _sampling=true;
            try{SamplingChanged?.Invoke(true);var picked=CanvasSampleWindow.Pick(owner,source);if(picked.HasValue){Publish(picked.Value);_error.Text="";}}
            catch(Exception ex){App.LogError("Palette canvas sampling",ex);_error.Text="取色失敗，請再試一次。";}
            finally{_sampling=false;SamplingChanged?.Invoke(false);}
        };
        add.Click+=(_,_)=>{var colors=ReadSwatches();string value=Selected.ToString();if(!colors.Contains(value))colors.Add(value);if(colors.Count>32)colors.RemoveAt(0);WriteSwatches(colors);RenderSwatches();};
        SetColor(initial);RenderSwatches();
    }
    internal static Brush Checker()=>CheckerBrush;
    private static Brush CreateChecker()
    {
        var group=new DrawingGroup();using(var dc=group.Open()){dc.DrawRectangle(Brushes.White,null,new Rect(0,0,16,16));dc.DrawRectangle(Brushes.LightGray,null,new Rect(0,0,8,8));dc.DrawRectangle(Brushes.LightGray,null,new Rect(8,8,8,8));}
        var brush=new DrawingBrush(group){TileMode=TileMode.Tile,ViewportUnits=BrushMappingMode.Absolute,Viewport=new Rect(0,0,16,16)};brush.Freeze();return brush;
    }
    private static List<string> ReadSwatches()
    {
        try{return (JsonSerializer.Deserialize<List<string>>(File.ReadAllText(BrandStorage.ReadPath("swatches.json")))??new()).Where(s=>!string.IsNullOrWhiteSpace(s)).TakeLast(32).ToList();}
        catch{return new(){"#FF000000","#FF465CFF","#FF74BE59","#FFFFCC40","#FFD95032","#FF507AFF","#FF416EE8","#FF1910CA"};}
    }
    private void WriteSwatches(List<string> colors)
    {
        try{Directory.CreateDirectory(Path.GetDirectoryName(SwatchFile)!);string temp=SwatchFile+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(colors));File.Move(temp,SwatchFile,true);_error.Text="";}
        catch(Exception ex){_error.Text="色票未儲存："+ex.Message;}
    }
    private void RenderSwatches()
    {
        _swatches.Children.Clear();_rings.Clear();foreach(string hex in ReadSwatches())
        {
            Color color;try{color=(Color)ColorConverter.ConvertFromString(hex);}catch{continue;}
            var dot=new System.Windows.Shapes.Ellipse{Width=24,Height=24,Fill=new SolidColorBrush(color)};
            var ring=new Border{Width=34,Height=34,CornerRadius=new CornerRadius(17),BorderThickness=new Thickness(2),Child=dot};_rings.Add((ring,color));
            var button=new Button{Width=40,Height=40,Padding=new Thickness(0),Margin=new Thickness(0),Background=Brushes.Transparent,BorderThickness=new Thickness(0),Content=ring,ToolTip="色票 "+hex+"；右鍵刪除"};
            button.Click+=(_,_)=>Publish(color);
            button.PreviewMouseRightButtonDown+=(_,e)=>{var list=ReadSwatches();list.Remove(hex);WriteSwatches(list);RenderSwatches();e.Handled=true;};_swatches.Children.Add(button);
        }
        RefreshRings();
    }
    private void RefreshRings(){foreach(var (ring,color) in _rings)ring.BorderBrush=color==Selected?new SolidColorBrush(Color.FromRgb(color.R,color.G,color.B)):Brushes.Transparent;}
    public void SetColor(Color color)
    {
        _sync=true;_alphaDirty=false;
        try{Selected=color;_spectrum.SetColor(color);_alpha.Set(color);_hex.Text=color.A==255?$"#{color.R:X2}{color.G:X2}{color.B:X2}":color.ToString();_percent.Text=$"{color.A/255d*100:0}%";
            var group=new DrawingGroup();using(var dc=group.Open()){dc.DrawRectangle(Checker(),null,new Rect(0,0,65,65));dc.DrawRectangle(new SolidColorBrush(color),null,new Rect(0,0,65,65));}_preview.Background=new DrawingBrush(group);RefreshRings();}
        finally{_sync=false;}
    }
    private void Publish(Color color){if(_sync)return;bool changed=color!=Selected;SetColor(color);_error.Text="";if(changed)ColorChanged?.Invoke(color);}
    internal static double AvailableHeight(Window? owner)
    {
        if(owner is null)return Math.Max(180,SystemParameters.WorkArea.Height-40);
        var area=WindowPlacementService.WorkArea(owner);double dpi=VisualTreeHelper.GetDpi(owner).DpiScaleY;
        return Math.Max(180,area.Height/dpi-40);
    }
    private static Color PickCanvas(Window? owner,Color initial,Action<Color>? preview)
    {
        var picker=new ColorPicker(initial);
        var window=new Window{Title="選擇顏色",Owner=owner,Width=352,MaxHeight=AvailableHeight(owner),SizeToContent=SizeToContent.Height,ResizeMode=ResizeMode.NoResize,Content=picker,ShowInTaskbar=false};
        DialogOwner.Prepare(window,owner);picker.SourceOwner=window;CanvasTheme.Apply(window,CanvasTheme.BackgroundFor(owner));WindowIconHelper.ApplyAdaptiveTitleBarIcon(window);
        var frame=new System.Windows.Threading.DispatcherFrame();bool closed=false;
        void Outside(object sender,PreProcessInputEventArgs e)
        {
            if(closed || picker._sampling)return;
            if(e.StagingItem.Input is MouseButtonEventArgs mouse && mouse.ButtonState==MouseButtonState.Pressed && !window.IsMouseOver)
            {mouse.Handled=true;window.Close();}
        }
        window.Closing+=(_,_)=>picker._commitInput?.Invoke();
        window.Closed+=(_,_)=>{closed=true;frame.Continue=false;};
        window.Deactivated+=(_,_)=>{if(!closed&&!picker._sampling)window.Close();};
        window.PreviewKeyDown+=(_,e)=>{if(e.Key==Key.Escape&&!picker._sampling){e.Handled=true;window.Close();}};
        if(preview is not null)picker.ColorChanged+=preview;
        InputManager.Current.PreProcessInput+=Outside;
        try{window.Show();if(!closed)System.Windows.Threading.Dispatcher.PushFrame(frame);return picker.Selected;}
        finally{InputManager.Current.PreProcessInput-=Outside;if(preview is not null)picker.ColorChanged-=preview;if(!closed)window.Close();}
    }
    public static Color Pick(Window? owner,Color initial,Action<Color>? preview=null)
    {
        if(CanvasTheme.BackgroundFor(owner) is not null)return PickCanvas(owner,initial,preview);
        var picker=new ColorPicker(initial);var panel=new DockPanel();var buttons=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(10,0,10,10)};
        var ok=new Button{Content="套用",MinWidth=70,Margin=new Thickness(4),Padding=new Thickness(8),IsDefault=true};var cancel=new Button{Content="取消",MinWidth=70,Margin=new Thickness(4),Padding=new Thickness(8),IsCancel=true};buttons.Children.Add(ok);buttons.Children.Add(cancel);DockPanel.SetDock(buttons,Dock.Bottom);panel.Children.Add(buttons);panel.Children.Add(new ScrollViewer {Content=picker,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled});
        var window=new Window{Title="選擇顏色",Owner=owner,Width=352,MaxHeight=AvailableHeight(owner),SizeToContent=SizeToContent.Height,ResizeMode=ResizeMode.NoResize,Content=panel,ShowInTaskbar=false,WindowStartupLocation=owner is null?WindowStartupLocation.CenterScreen:WindowStartupLocation.CenterOwner};
        DialogOwner.Prepare(window,owner);picker.SourceOwner=window;CanvasTheme.Apply(window,CanvasTheme.BackgroundFor(owner));WindowIconHelper.ApplyAdaptiveTitleBarIcon(window);ok.Click+=(_,_)=>window.DialogResult=true;
        if(preview is not null)picker.ColorChanged+=preview;
        try
        {
            bool accepted=window.ShowDialog()==true;
            if(!accepted)preview?.Invoke(initial);
            return accepted?picker.Selected:initial;
        }
        finally{if(preview is not null)picker.ColorChanged-=preview;}
    }
}
