using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
namespace Clipxel.Controls;
internal static class NumericSlider
{
    internal static TextBox Editor(Slider slider)
    {
        var input=new TextBox{Style=(Style)Application.Current.FindResource("InlineNumber"),Text=slider.Value.ToString("0.##",CultureInfo.CurrentCulture)};
        void Commit()
        {
            if(double.TryParse(input.Text,NumberStyles.Float,CultureInfo.CurrentCulture,out var number)&&double.IsFinite(number))slider.Value=Math.Clamp(number,slider.Minimum,slider.Maximum);
            input.Text=slider.Value.ToString("0.##",CultureInfo.CurrentCulture);
        }
        input.LostKeyboardFocus+=(_,_)=>Commit();input.KeyDown+=(_,e)=>{if(e.Key==Key.Enter){Commit();e.Handled=true;}else if(e.Key==Key.Escape){input.Text=slider.Value.ToString("0.##",CultureInfo.CurrentCulture);e.Handled=true;}};
        slider.ValueChanged+=(_,_)=>{if(!input.IsKeyboardFocusWithin)input.Text=slider.Value.ToString("0.##",CultureInfo.CurrentCulture);};return input;
    }
    internal static FrameworkElement Wrap(Slider slider)
    {
        var row=new DockPanel();var input=Editor(slider);DockPanel.SetDock(input,Dock.Right);row.Children.Add(input);row.Children.Add(slider);return row;
    }
}
