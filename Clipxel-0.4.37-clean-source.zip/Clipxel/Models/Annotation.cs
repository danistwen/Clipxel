using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using Clipxel.Windows;

namespace Clipxel.Models;

// All geometry and widths are stored in source-image pixels, independent of zoom/DPI.
public enum LineStyle { Arrow, Plain, Dashed, RoundEndpoints }

public sealed class Annotation
{
    public LineStyle LineStyle { get; init; }
    public AnnotationTool Tool { get; init; }
    public List<Point> Points { get; } = new();
    public Point Start { get; set; }
    public Point End { get; set; }
    public string Text { get; init; } = string.Empty;
    public Color Color { get; init; }
    public double StrokeWidth { get; init; } = 3;
    public string FontFamily { get; init; } = "Segoe UI";
    public double FontSize { get; init; } = 22;
    // RectangleMode is retained for backward compatibility with annotations created
    // before the unified Shape tool. New shapes use the independent stroke/fill fields.
    public RectangleAnnotationMode RectangleMode { get; init; }
    public bool UsesIndependentShapeStyle { get; init; }
    public bool ShapeStrokeEnabled { get; init; } = true;
    public bool ShapeFillEnabled { get; init; }
    public double StrokeOpacity { get; init; } = 1.0;
    public double FillOpacity { get; init; } = 0.45;
}
