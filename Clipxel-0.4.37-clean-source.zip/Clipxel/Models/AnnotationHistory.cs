using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using Clipxel.Rendering;

namespace Clipxel.Models;

// Frozen drawings and immutable committed models are shared; snapshots copy only the lists.
public sealed class AnnotationHistory
{
    private sealed record State(DrawingGroup[] Drawings, Annotation?[] Models);
    private readonly List<State> _undo = new();
    private readonly List<State> _redo = new();
    public bool CanUndo => _undo.Count > 0;
    public bool CanRedo => _redo.Count > 0;

    private static State Capture(AnnotationLayer layer, List<Annotation?> models) =>
        new(layer.Drawings.ToArray(), models.ToArray());

    public void Record(AnnotationLayer layer, List<Annotation?> models)
    {
        _undo.Add(Capture(layer, models));
        if (_undo.Count > 100) _undo.RemoveAt(0);
        _redo.Clear();
    }

    public bool Undo(AnnotationLayer layer, List<Annotation?> models) => Move(_undo, _redo, layer, models);
    public bool Redo(AnnotationLayer layer, List<Annotation?> models) => Move(_redo, _undo, layer, models);

    private static bool Move(List<State> from, List<State> to, AnnotationLayer layer, List<Annotation?> models)
    {
        if (from.Count == 0) return false;
        to.Add(Capture(layer, models));
        var state = from[^1];
        from.RemoveAt(from.Count - 1);
        layer.ReplaceAll(state.Drawings);
        models.Clear();
        models.AddRange(state.Models);
        return true;
    }

    public void Transform(Func<DrawingGroup, DrawingGroup> drawing, Func<Annotation?, Annotation?> model)
    {
        foreach (var stack in new[] { _undo, _redo })
            for (int i = 0; i < stack.Count; i++)
                stack[i] = new State(stack[i].Drawings.Select(drawing).ToArray(), stack[i].Models.Select(model).ToArray());
    }

    public void Clear() { _undo.Clear(); _redo.Clear(); }
}
