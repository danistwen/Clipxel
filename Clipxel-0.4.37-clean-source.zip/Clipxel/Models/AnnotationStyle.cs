using System;
using System.Windows.Media;
namespace Clipxel.Models;
public static class AnnotationStyle
{
    public static Color Visible(Color c){c.A=Math.Max((byte)13,c.A);return c;}
    public static Annotation With(Annotation a,Color? color=null,double? width=null,bool? stroke=null,bool? fill=null,double? strokeOpacity=null,double? fillOpacity=null,LineStyle? line=null,double? fontSize=null,string? font=null)
    {
        var b=new Annotation{Tool=a.Tool,Start=a.Start,End=a.End,Text=a.Text,Color=color??a.Color,StrokeWidth=width??a.StrokeWidth,FontSize=fontSize??a.FontSize,FontFamily=font??a.FontFamily,LineStyle=line??a.LineStyle,RectangleMode=a.RectangleMode,UsesIndependentShapeStyle=a.UsesIndependentShapeStyle||stroke.HasValue||fill.HasValue||strokeOpacity.HasValue||fillOpacity.HasValue,ShapeStrokeEnabled=stroke??a.ShapeStrokeEnabled,ShapeFillEnabled=fill??a.ShapeFillEnabled,StrokeOpacity=strokeOpacity??a.StrokeOpacity,FillOpacity=fillOpacity??a.FillOpacity};
        b.Points.AddRange(a.Points);return b;
    }
}
