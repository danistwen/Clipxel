using System;
using System.Windows;
using System.Windows.Media;

namespace Clipxel.Models;

public static class AnnotationTransforms
{
    // Replace immutable text/style values while preserving geometry and independent shape settings.
    public static Annotation WithTextStyle(Annotation source, string? text = null,
        Color? color = null, double? fontSize = null, string? fontFamily = null)
    {
        var copy = new Annotation
        {
            Tool = source.Tool, LineStyle = source.LineStyle,
            Start = source.Start, End = source.End,
            Text = text ?? source.Text, Color = color ?? source.Color,
            FontSize = fontSize ?? source.FontSize, FontFamily = fontFamily ?? source.FontFamily,
            StrokeWidth = source.StrokeWidth, RectangleMode = source.RectangleMode,
            UsesIndependentShapeStyle = source.UsesIndependentShapeStyle,
            ShapeStrokeEnabled = source.ShapeStrokeEnabled, ShapeFillEnabled = source.ShapeFillEnabled,
            StrokeOpacity = source.StrokeOpacity, FillOpacity = source.FillOpacity
        };
        copy.Points.AddRange(source.Points);
        return copy;
    }

    public static Annotation Clone(Annotation source) => Transform(source, 1, 1, new Vector());

    public static Annotation Translate(Annotation source, Vector delta) => Transform(source, 1, 1, delta);

    public static Annotation Scale(Annotation source, double sx, double sy)
    {
        double widthScale = (Math.Abs(sx) + Math.Abs(sy)) / 2.0;
        var scaled = new Annotation
        {
            Tool = source.Tool,
            Start = new Point(source.Start.X * sx, source.Start.Y * sy),
            End = new Point(source.End.X * sx, source.End.Y * sy),
            Text = source.Text, FontFamily = source.FontFamily,
            Color = source.Color,
            StrokeWidth = source.StrokeWidth * widthScale, LineStyle = source.LineStyle,
            FontSize = source.FontSize * Math.Abs(sy),
            RectangleMode = source.RectangleMode,
            UsesIndependentShapeStyle = source.UsesIndependentShapeStyle,
            ShapeStrokeEnabled = source.ShapeStrokeEnabled,
            ShapeFillEnabled = source.ShapeFillEnabled,
            StrokeOpacity = source.StrokeOpacity,
            FillOpacity = source.FillOpacity
        };
        foreach (var point in source.Points)
            scaled.Points.Add(new Point(point.X * sx, point.Y * sy));
        return scaled;
    }

    private static Annotation Transform(Annotation source, double sx, double sy, Vector delta)
    {
        var copy = new Annotation
        {
            Tool = source.Tool,
            Start = new Point(source.Start.X * sx + delta.X, source.Start.Y * sy + delta.Y),
            End = new Point(source.End.X * sx + delta.X, source.End.Y * sy + delta.Y),
            Text = source.Text, FontFamily = source.FontFamily,
            Color = source.Color,
            StrokeWidth = source.StrokeWidth, LineStyle = source.LineStyle,
            FontSize = source.FontSize,
            RectangleMode = source.RectangleMode,
            UsesIndependentShapeStyle = source.UsesIndependentShapeStyle,
            ShapeStrokeEnabled = source.ShapeStrokeEnabled,
            ShapeFillEnabled = source.ShapeFillEnabled,
            StrokeOpacity = source.StrokeOpacity,
            FillOpacity = source.FillOpacity
        };
        foreach (var point in source.Points)
            copy.Points.Add(new Point(point.X * sx + delta.X, point.Y * sy + delta.Y));
        return copy;
    }
}
