using System;
using System.Collections.Generic;
using System.Windows.Media.Imaging;

namespace Clipxel.Models;

public sealed class CapturedRegionEventArgs : EventArgs
{
    public CapturedRegionEventArgs(BitmapSource bitmap, IReadOnlyList<Annotation> annotations)
    {
        Bitmap = bitmap;
        Annotations = annotations;
    }

    public BitmapSource Bitmap { get; }
    public IReadOnlyList<Annotation> Annotations { get; }
}
