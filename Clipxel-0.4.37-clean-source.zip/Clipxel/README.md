# Clipxel 0.4.37 — 原始碼精簡包

Windows 截圖、釘圖、標註與參考畫布工具。製作者：danistwen。

本包只整理原始碼封裝與文件，程式版本仍為 0.4.37。未包含已編譯 EXE。
最新功能變更見 [RELEASE-0.4.37.md](RELEASE-0.4.37.md)，清理項目見 [CLEANUP.md](CLEANUP.md)。

## 建置與執行

需在 Windows 安裝 .NET 10 SDK；使用 Visual Studio 時安裝「.NET 桌面開發」工作負載。

開啟 Clipxel.csproj，或在本資料夾執行：

```powershell
dotnet build .\Clipxel.csproj -c Release
powershell -NoProfile -ExecutionPolicy Bypass -File .\run-debug.ps1
```

## 發布

雙擊 build-win-x64.cmd，依序執行發布、自我測試及簽章。
成功後輸出於 publish/win-x64；搬到其他電腦時複製整個輸出資料夾。

簽章流程會使用或建立目前使用者的自簽憑證，詳見 [SIGNING.md](SIGNING.md)。
如只需發布、不執行簽章腳本：

```powershell
dotnet publish .\Clipxel.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:DebugType=None -p:DebugSymbols=false -o .\publish\win-x64
```

## 檔案配置

- App.*、Models、Services：應用程式、資料模型與服務。
- Windows、Controls、Rendering：視窗、工具控制與繪圖。
- Assets：實際使用的圖示與 WPF 字標。
- Brand：品牌色票、字標原稿及資產來源。
- Tests：Windows 內建自我測試。
- 根目錄腳本：建置、偵錯、發布及簽章。

## 驗證

目前只完成封裝與引用檢查，未在 Windows 編譯或執行。實機驗證方式見 [VALIDATION.md](VALIDATION.md)。
