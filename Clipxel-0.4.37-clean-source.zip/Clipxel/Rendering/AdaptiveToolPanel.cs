using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
namespace Clipxel.Rendering;
// Uniform cells wrap at whole-tool boundaries; popup groups remain intact.
public sealed class AdaptiveToolPanel : Panel
{
    public const double Cell=34;
    private UIElement[] VisibleItems()=>InternalChildren.Cast<UIElement>().Where(c=>c.Visibility!=Visibility.Collapsed && !(c is Border b && b.Width<=1)).ToArray();
    public int VisibleCount=>VisibleItems().Length;
    public static (int Columns,int Rows) LayoutFor(int count,double width)
    {
        if(count<=0)return (1,0);
        int cols=double.IsInfinity(width)?count:Math.Clamp((int)Math.Floor(Math.Max(Cell,width)/Cell),1,count);
        return (cols,(count+cols-1)/cols);
    }
    protected override Size MeasureOverride(Size available)
    {
        var items=VisibleItems();var grid=LayoutFor(items.Length,available.Width);
        foreach(var item in items)item.Measure(new Size(Cell,Cell));
        return new Size(grid.Columns*Cell,grid.Rows*Cell);
    }
    protected override Size ArrangeOverride(Size finalSize)
    {
        var items=VisibleItems();var grid=LayoutFor(items.Length,finalSize.Width);double cellWidth=finalSize.Width/grid.Columns;
        for(int i=0;i<items.Length;i++)items[i].Arrange(new Rect(i%grid.Columns*cellWidth,i/grid.Columns*Cell,cellWidth,Cell));
        foreach(UIElement child in InternalChildren)if(child.Visibility==Visibility.Collapsed || (child is Border b&&b.Width<=1))child.Arrange(new Rect());
        return finalSize;
    }
}
