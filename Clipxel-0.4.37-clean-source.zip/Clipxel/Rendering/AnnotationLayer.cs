using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace Clipxel.Rendering;

public sealed class AnnotationLayer : FrameworkElement
{
    private readonly VisualCollection _visuals;
    private readonly ContainerVisual _committed = new();
    private readonly DrawingVisual _draft = new();
    private readonly ScaleTransform _scale = new();
    private readonly List<DrawingGroup> _drawings = new();

    public IReadOnlyList<DrawingGroup> Drawings => _drawings;
    internal long Revision {get;private set;}

    public AnnotationLayer()
    {
        IsHitTestVisible = false;
        SnapsToDevicePixels = false;
        UseLayoutRounding = false;
        RenderOptions.SetEdgeMode(this, EdgeMode.Unspecified);
        _visuals = new VisualCollection(this) { _committed, _draft };
        _committed.Transform = _scale;
        _draft.Transform = _scale;
    }

    public void SetScale(double x, double y)
    {
        Revision++;
        _scale.ScaleX = x;
        _scale.ScaleY = y;
    }

    public void Add(DrawingGroup drawing)
    {
        Revision++;
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen()) dc.DrawDrawing(drawing);
        _drawings.Add(drawing);
        _committed.Children.Add(visual);
    }

    public DrawingGroup? RemoveLast()
    {
        Revision++;
        if (_drawings.Count == 0) return null;
        int last = _drawings.Count - 1;
        var drawing = _drawings[last];
        _drawings.RemoveAt(last);
        _committed.Children.RemoveAt(last);
        return drawing;
    }

    public void RemoveAt(int index)
    {
        Revision++;
        if ((uint)index >= (uint)_drawings.Count)
            throw new ArgumentOutOfRangeException(nameof(index));
        _drawings.RemoveAt(index);
        _committed.Children.RemoveAt(index);
    }

    public void ReplaceAt(int index, DrawingGroup drawing)
    {
        Revision++;
        if ((uint)index >= (uint)_drawings.Count)
            throw new ArgumentOutOfRangeException(nameof(index));
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen()) dc.DrawDrawing(drawing);
        _drawings[index] = drawing;
        _committed.Children.RemoveAt(index);
        _committed.Children.Insert(index, visual);
    }

    public void Clear()
    {
        Revision++;
        _drawings.Clear();
        _committed.Children.Clear();
        using var dc = _draft.RenderOpen();
    }

    public void ReplaceAll(IEnumerable<DrawingGroup> drawings)
    {
        Revision++;
        _drawings.Clear();
        _committed.Children.Clear();
        foreach (var drawing in drawings) Add(drawing);
        using var dc = _draft.RenderOpen();
    }

    public void SetDraft(DrawingGroup? drawing)
    {
        Revision++;
        using var dc = _draft.RenderOpen();
        if (drawing is not null) dc.DrawDrawing(drawing);
    }

    protected override int VisualChildrenCount => _visuals?.Count ?? 0;

    protected override Visual GetVisualChild(int index)
    {
        if (_visuals is null)
            throw new ArgumentOutOfRangeException(nameof(index));
        if ((uint)index >= (uint)_visuals.Count)
            throw new ArgumentOutOfRangeException(nameof(index));
        return _visuals[index];
    }
}
