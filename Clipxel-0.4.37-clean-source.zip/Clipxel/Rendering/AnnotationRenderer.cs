using System;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Windows;

namespace Clipxel.Rendering;

public static class AnnotationRenderer
{
    // One rendering path for the retained preview and the original-resolution PNG.
    public static DrawingGroup Build(Annotation a)
    {
        var drawing = new DrawingGroup();
        var brush = new SolidColorBrush(a.Color);
        brush.Freeze();
        var pen = new Pen(brush, a.StrokeWidth)
        {
            LineJoin = PenLineJoin.Round,
            StartLineCap = PenLineCap.Round,
            EndLineCap = PenLineCap.Round
        };
        if (a.Tool == AnnotationTool.Arrow && a.LineStyle == LineStyle.Dashed) pen.DashStyle = DashStyles.Dash;
        pen.Freeze();

        using (var dc = drawing.Open())
        {
            switch (a.Tool)
            {
                case AnnotationTool.Pen:
                    if (a.Points.Count <= 1)
                        dc.DrawEllipse(brush, null, a.Start, a.StrokeWidth / 2, a.StrokeWidth / 2);
                    else
                    {
                        var path = BuildPenGeometry(a.Points);
                        dc.DrawGeometry(null, pen, path);
                    }
                    break;

                case AnnotationTool.Rectangle:
                    DrawShape(dc, a, ellipse: false);
                    break;

                case AnnotationTool.Circle:
                    DrawShape(dc, a, ellipse: true);
                    break;

                case AnnotationTool.Arrow:
                    if ((a.End-a.Start).LengthSquared < 0.0001) break;
                    if (a.LineStyle != LineStyle.Arrow)
                    {
                        dc.DrawLine(pen, a.Start, a.End);
                        if (a.LineStyle == LineStyle.RoundEndpoints)
                        {
                            double radius = Math.Max(3, a.StrokeWidth * 1.6);
                            dc.DrawEllipse(brush, null, a.Start, radius, radius);
                            dc.DrawEllipse(brush, null, a.End, radius, radius);
                        }
                        break;
                    }
                    Vector v = a.Start - a.End;
                    double length = v.Length;
                    if (length < 0.01) break;
                    v.Normalize();
                    Vector n = new(-v.Y, v.X);
                    double head = Math.Min(length, Math.Max(8, a.StrokeWidth * 4.5));
                    dc.DrawLine(pen, a.Start, a.End + v * head * 0.45);
                    var arrow = new StreamGeometry();
                    using (var context = arrow.Open())
                    {
                        context.BeginFigure(a.End, true, true);
                        context.LineTo(a.End + v * head + n * head * 0.43, true, false);
                        context.LineTo(a.End + v * head - n * head * 0.43, true, false);
                    }
                    arrow.Freeze();
                    dc.DrawGeometry(brush, null, arrow);
                    break;

                case AnnotationTool.Text:
                    var text = new FormattedText(a.Text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                        new Typeface(new FontFamily(a.FontFamily), FontStyles.Normal, FontWeights.SemiBold,
                            FontStretches.Normal), a.FontSize, brush, 1);
                    dc.DrawText(text, a.Start);
                    break;
            }
        }
        drawing.Freeze();
        return drawing;
    }

    internal static StreamGeometry BuildPenGeometry(System.Collections.Generic.IReadOnlyList<Point> points)
    {
        var path = new StreamGeometry();
        using (var context = path.Open())
        {
            if (points.Count > 0)
            {
                context.BeginFigure(points[0], false, false);
                for (int i = 1; i < points.Count - 1; i++)
                {
                    var midpoint = new Point((points[i].X + points[i + 1].X) / 2, (points[i].Y + points[i + 1].Y) / 2);
                    context.QuadraticBezierTo(points[i], midpoint, true, true);
                }
                if (points.Count > 1) context.LineTo(points[^1], true, true);
            }
        }
        path.Freeze(); return path;
    }

    private static void DrawShape(DrawingContext dc, Annotation a, bool ellipse)
    {
        Rect rect = new(a.Start, a.End);
        if (rect.IsEmpty || rect.Width <= 0 || rect.Height <= 0) return;

        bool strokeEnabled;
        bool fillEnabled;
        double strokeOpacity;
        double fillOpacity;

        if (a.UsesIndependentShapeStyle)
        {
            strokeEnabled = a.ShapeStrokeEnabled;
            fillEnabled = a.ShapeFillEnabled;
            strokeOpacity = Math.Clamp(a.StrokeOpacity, 0.0, 1.0);
            fillOpacity = Math.Clamp(a.FillOpacity, 0.0, 1.0);
        }
        else
        {
            // Legacy 0.4.37.2 annotations used an exclusive Outline/Fill mode.
            strokeEnabled = a.RectangleMode == RectangleAnnotationMode.Outline;
            fillEnabled = a.RectangleMode == RectangleAnnotationMode.Fill;
            strokeOpacity = 1.0;
            fillOpacity = Math.Clamp(a.FillOpacity, 0.0, 1.0);
        }

        Brush? fill = null;
        Pen? stroke = null;

        if (fillEnabled && fillOpacity > 0)
        {
            var fillColor = Color.FromArgb((byte)Math.Round(a.Color.A * fillOpacity), a.Color.R, a.Color.G, a.Color.B);
            var fillBrush = new SolidColorBrush(fillColor);
            fillBrush.Freeze();
            fill = fillBrush;
        }

        if (strokeEnabled && strokeOpacity > 0 && a.StrokeWidth > 0)
        {
            var strokeColor = Color.FromArgb((byte)Math.Round(a.Color.A * strokeOpacity), a.Color.R, a.Color.G, a.Color.B);
            var strokeBrush = new SolidColorBrush(strokeColor);
            strokeBrush.Freeze();
            var shapePen = new Pen(strokeBrush, a.StrokeWidth)
            {
                LineJoin = PenLineJoin.Round,
                StartLineCap = PenLineCap.Round,
                EndLineCap = PenLineCap.Round
            };
            shapePen.Freeze();
            stroke = shapePen;
        }

        if (fill is null && stroke is null) return;

        if (ellipse)
        {
            Point center = new(rect.Left + rect.Width / 2.0, rect.Top + rect.Height / 2.0);
            dc.DrawEllipse(fill, stroke, center, rect.Width / 2.0, rect.Height / 2.0);
        }
        else
        {
            dc.DrawRectangle(fill, stroke, rect);
        }
    }
}
