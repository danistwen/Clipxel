using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;

namespace Clipxel.Rendering;

// Screen-space feedback for object marquee/group selection. It is never exported.
public sealed class AnnotationSelectionChrome : FrameworkElement
{
    private Rect _marquee = Rect.Empty;
    private Rect[] _selected = Array.Empty<Rect>();

    public AnnotationSelectionChrome() => IsHitTestVisible = false;

    public void ShowMarquee(Rect marquee)
    {
        _marquee = marquee;
        InvalidateVisual();
    }

    public void ClearMarquee()
    {
        if (_marquee.IsEmpty) return;
        _marquee = Rect.Empty;
        InvalidateVisual();
    }

    public void ShowSelected(IEnumerable<Rect> bounds)
    {
        _selected = bounds.Where(r => !r.IsEmpty && r.Width >= 0 && r.Height >= 0).ToArray();
        InvalidateVisual();
    }

    public void Clear()
    {
        _marquee = Rect.Empty;
        _selected = Array.Empty<Rect>();
        InvalidateVisual();
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var blue = new SolidColorBrush(Color.FromArgb(230, 70, 92, 255));
        blue.Freeze();
        var selectionPen = new Pen(blue, 1.4)
        {
            DashStyle = new DashStyle(new double[] { 4, 3 }, 0),
            LineJoin = PenLineJoin.Round
        };
        selectionPen.Freeze();

        foreach (var rect in _selected)
        {
            var r = rect;
            r.Inflate(2, 2);
            dc.DrawRoundedRectangle(null, selectionPen, r, 3, 3);
        }

        if (!_marquee.IsEmpty)
        {
            var fill = new SolidColorBrush(Color.FromArgb(24, 70, 92, 255));
            fill.Freeze();
            var marqueePen = new Pen(blue, 1.2)
            {
                DashStyle = new DashStyle(new double[] { 5, 3 }, 0)
            };
            marqueePen.Freeze();
            dc.DrawRectangle(fill, marqueePen, _marquee);
        }
    }
}
