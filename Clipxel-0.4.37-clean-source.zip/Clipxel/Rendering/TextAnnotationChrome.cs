using System;
using System.Windows;
using System.Windows.Media;

namespace Clipxel.Rendering;

// Screen-space feedback only. This element never enters AnnotationLayer.Drawings or export.
public sealed class TextAnnotationChrome : FrameworkElement
{
    private Rect _bounds = Rect.Empty;
    private bool _selected;

    public TextAnnotationChrome() => IsHitTestVisible = false;

    public void Show(Rect bounds, bool selected)
    {
        if (_bounds == bounds && _selected == selected) return;
        _bounds = bounds;
        _selected = selected;
        InvalidateVisual();
    }

    public void Clear() => Show(Rect.Empty, false);

    public static bool IsEditorEdge(Point point, Size size)
    {
        const double grip = 5;
        return size.Width > 0 && size.Height > 0 &&
            new Rect(size).Contains(point) &&
            (point.X <= grip || point.Y <= grip || point.X >= size.Width - grip || point.Y >= size.Height - grip);
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        if (_bounds.IsEmpty) return;
        if (_selected)
        {
            dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(150, 20, 25, 35)), 2), _bounds);
            var pen = new Pen(Brushes.White, 1) { DashStyle = new DashStyle(new double[] { 4, 3 }, 0) };
            dc.DrawRectangle(null, pen, _bounds);
        }
        else
        {
            double height = Math.Min(10, _bounds.Height);
            var glow = new LinearGradientBrush(Colors.Transparent, Color.FromArgb(60, 255, 255, 255), 90);
            dc.DrawRectangle(glow, null, new Rect(_bounds.Left, _bounds.Bottom - height, _bounds.Width, height));
            dc.DrawLine(new Pen(new SolidColorBrush(Color.FromArgb(100, 255, 255, 255)), 1),
                _bounds.BottomLeft, _bounds.BottomRight);
        }
    }
}
