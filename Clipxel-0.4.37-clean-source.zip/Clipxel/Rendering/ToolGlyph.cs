using System;
using System.Windows;
using System.Windows.Media;

namespace Clipxel.Rendering;

// Shared vector definitions: toolbar and pie menus cannot drift into font glyphs.
public sealed class ToolGlyph : FrameworkElement
{
    public static readonly DependencyProperty GlyphProperty = DependencyProperty.Register(nameof(Glyph), typeof(string), typeof(ToolGlyph), new FrameworkPropertyMetadata("Shape", FrameworkPropertyMetadataOptions.AffectsRender));
    public string Glyph { get => (string)GetValue(GlyphProperty); set => SetValue(GlyphProperty, value); }
    public static readonly DependencyProperty ForegroundProperty=System.Windows.Documents.TextElement.ForegroundProperty.AddOwner(typeof(ToolGlyph),new FrameworkPropertyMetadata(Brushes.WhiteSmoke,FrameworkPropertyMetadataOptions.Inherits|FrameworkPropertyMetadataOptions.AffectsRender));
    public Brush Foreground {get=>(Brush)GetValue(ForegroundProperty);set=>SetValue(ForegroundProperty,value);}
    private Brush Blue=>Foreground;
    private static readonly Geometry Rectangle = Geometry.Parse("M6,3 H26 Q29,3 29,6 V26 Q29,29 26,29 H6 Q3,29 3,26 V6 Q3,3 6,3 Z");
    private static readonly Geometry Shape = Geometry.Parse("M5,4 H21 Q24,4 24,7 V23 Q24,26 21,26 H5 Q2,26 2,23 V7 Q2,4 5,4 Z");
    public ToolGlyph() { Width = Height = 14; IsHitTestVisible = false; }
    protected override void OnRender(DrawingContext dc)
    {
        double size = Math.Min(ActualWidth, ActualHeight);
        if (size <= 0) return;
        var pen = new Pen(Blue, 2.7) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        dc.PushTransform(new TranslateTransform((ActualWidth - size) / 2, (ActualHeight - size) / 2));
        dc.PushTransform(new ScaleTransform(size / 32, size / 32));
        if (Glyph == "DragHandle") {for(int y=7;y<=25;y+=9)for(int x=11;x<=21;x+=10)dc.DrawEllipse(Blue,null,new Point(x,y),1.6,1.6);}
        else if (Glyph == "SwitchMode") dc.DrawGeometry(null,pen,Geometry.Parse("M3,9 H28 M22,3 L28,9 L22,15 M29,23 H4 M10,17 L4,23 L10,29"));
        else if (Glyph == "PickColor") dc.DrawGeometry(null,pen,Geometry.Parse("M4,22 L18,8 L24,14 L10,28 L3,30 L4,22 Z M15,5 L27,17 M20,7 L24,3 C28,-1 33,4 29,8 L25,12"));
        else if (Glyph == "Rectangle") dc.DrawGeometry(null, pen, Rectangle);
        else if (Glyph == "Circle") dc.DrawEllipse(null, pen, new Point(16, 16), 13, 13);
        else if (Glyph == "Shape") { dc.DrawGeometry(null, pen, Shape); dc.DrawEllipse(null, pen, new Point(19, 19), 11, 11); }
        else if (Glyph == "Opacity")
        {
            dc.PushClip(new EllipseGeometry(new Point(16, 16), 15, 15));
            for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++)
            {
                dc.PushOpacity((x + y) % 2 == 0 ? 1 : .18);
                dc.DrawRectangle(Blue, null, new Rect(x * 8, y * 8, 8, 8)); dc.Pop();
            }
            dc.Pop();
        }
        else
        {
            string path = Glyph switch
            {
                "Disconnect" => "M2,2 H10 V10 H2 Z M22,22 H30 V30 H22 Z M10,6 H22 M26,14 V22 M18,12 L28,2 M18,2 L28,12",
                "StrokeWidth" => "M3,6 H29 M3,16 H29 M3,26 H29 M12,3 V9 M20,12 V20 M9,22 V30",
                "Magnet" => "M4,3 H11 V17 A5,5 0 0 0 21,17 V3 H28 V17 A12,12 0 0 1 4,17 Z M4,10 H11 M21,10 H28",
                "Startup" => "M18,2 L5,18 H14 L12,30 L27,12 H18 Z",
                "About" => "M16,2 A14,14 0 1 0 16,30 A14,14 0 1 0 16,2 M16,8 V18 M16,23 V24",
                "Pause" => "M8,4 H12 V28 H8 Z M20,4 H24 V28 H20 Z",
                "Resume" => "M8,4 L27,16 L8,28 Z",
                "Color" => "M16,3 A13,13 0 1 0 29,16 Q29,10 24,12 Q17,15 18,9 Q20,3 16,3 M7,12 H8 M8,21 H9 M14,25 H15",
                "FillColor" => "M14,3 L28,17 L15,29 L2,16 Z M4,18 H26 M27,23 Q21,30 27,30 Q32,30 27,23",
                "StrokeColor" => "M4,4 H28 V28 H4 Z M9,16 H23 M16,9 V23",
                "TextColor" => "M6,5 H26 M16,5 V23 M10,23 H22 M4,29 H28",
                "Font" => "M3,25 L11,5 L19,25 M6,18 H16 M22,12 H29 M25,12 V26",
                "Rename" => "M3,7 H17 M3,15 H12 M3,23 H10 M15,27 L18,18 L26,10 L31,15 L23,23 Z",
                "Spacing" => "M3,4 V28 M29,4 V28 M7,16 H25 M11,12 L7,16 L11,20 M21,12 L25,16 L21,20",
                "Rows" => "M4,3 H28 M4,29 H28 M16,7 V25 M12,11 L16,7 L20,11 M12,21 L16,25 L20,21",
                "Swatches" => "M3,3 H13 V13 H3 Z M19,3 H29 V13 H19 Z M3,19 H13 V29 H3 Z M19,19 H29 V29 H19 Z",
                "Delete" => "M5,8 H27 M11,8 V3 H21 V8 M8,8 L10,29 H22 L24,8 M14,13 V24 M19,13 V24",
                "ToggleChrome" => "M3,3 H29 V29 H3 Z M3,9 H29 M3,23 H29 M11,16 H21",
                "Settings" => "M3,7 H29 M3,16 H29 M3,25 H29 M10,3 V11 M22,12 V20 M13,21 V29",
                "Pen" => "M3,29 L6,19 L23,2 L30,9 L13,26 Z M6,19 L13,26 M20,5 L27,12",
                "Text" => "M3,8 V3 H29 V8 M16,3 V29 M10,29 H22",
                "Arrow" => "M4,28 L28,4 M14,4 H28 V18",
                "Plain" => "M4,28 L28,4",
                "Dashed" => "M4,28 L9,23 M13,19 L18,14 M22,10 L28,4",
                "RoundEndpoints" => "M7,25 L25,7 M3,25 A4,4 0 1 0 11,25 A4,4 0 1 0 3,25 M21,7 A4,4 0 1 0 29,7 A4,4 0 1 0 21,7",
                "Group" => "M3,10 H29 V29 H3 Z M3,10 V3 H16 L21,10",
                "Undo" => "M12,4 L4,12 L12,20 M4,12 H21 Q29,12 29,21 Q29,29 21,29 H13",
                "Redo" => "M20,4 L28,12 L20,20 M28,12 H11 Q3,12 3,21 Q3,29 11,29 H19",
                "Import" => "M3,10 V27 H29 V10 Z M3,10 V5 H13 L17,10 M16,14 V24 M11,19 H21",
                "Paste" => "M9,6 H4 V29 H27 V6 H22 M10,3 H21 V9 H10 Z M10,16 H21 M10,22 H21",
                "Capture" => "M3,11 V3 H11 M21,3 H29 V11 M29,21 V29 H21 M11,29 H3 V21",
                "Select" => "M5,3 L26,19 L16,20 L12,29 Z",
                "Pan" => "M16,2 V30 M2,16 H30 M11,7 L16,2 L21,7 M11,25 L16,30 L21,25 M7,11 L2,16 L7,21 M25,11 L30,16 L25,21",
                "Fit" => "M3,12 V3 H12 M20,3 H29 V12 M29,20 V29 H20 M12,29 H3 V20 M10,10 H22 V22 H10 Z",
                "Arrange" => "M3,3 H13 V13 H3 Z M19,3 H29 V13 H19 Z M3,19 H13 V29 H3 Z M19,19 H29 V29 H19 Z",
                "SaveProject" => "M5,2 H24 L30,8 V27 Q30,30 27,30 H5 Q2,30 2,27 V5 Q2,2 5,2 Z M8,2 V12 H23 V2 M8,30 V20 H24 V30",
                "Export" => "M3,18 V29 H29 V18 M16,23 V3 M8,11 L16,3 L24,11",
                "OpenProject" => "M2,9 V28 H27 L31,13 H11 L6,28 M2,9 V3 H13 L18,9 H27 V13",
                "ToggleDrawing" => "M2,2 H30 V30 H2 Z M8,24 L10,17 L22,5 L27,10 L15,22 Z",
                "BoardSettings" => "M12,2 H20 L21,7 L25,5 L29,12 L25,16 L29,20 L25,27 L21,25 L20,30 H12 L11,25 L7,27 L3,20 L7,16 L3,12 L7,5 L11,7 Z M10,16 A6,6 0 1 0 22,16 A6,6 0 1 0 10,16",
                "GroupStyle" => "M3,3 H29 V29 H3 Z M9,9 H23 V23 H9 Z",
                "Connect" => "M3,3 H11 V11 H3 Z M21,21 H29 V29 H21 Z M11,7 H25 V21",
                "ZoomIn" => "M5,16 H27 M16,5 V27",
                "ZoomOut" => "M5,16 H27",
                "Topmost" => "M11,3 H24 M13,3 V13 L27,20 H7 L15,13 M17,20 V30 M22,3 V13",
                "Return" => "M3,8 H19 V27 H3 Z M7,22 L11,17 L16,22 M20,2 H29 M22,2 V10 L30,15 H18 L24,10 M24,15 V24",
                "Minimize" => "M5,24 H27",
                "Close" => "M4,4 L28,28 M28,4 L4,28",
                _ => "M3,3 H29 V29 H3 Z"
            };
            dc.DrawGeometry(null, pen, Geometry.Parse(path));
        }
        dc.Pop(); dc.Pop();
    }
}
