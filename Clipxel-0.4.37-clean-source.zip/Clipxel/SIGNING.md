# Clipxel signing

## Publisher metadata

- Product: Clipxel
- Author / Company: `danistwen`
- Authenticode subject used by the bundled self-signing setup: `CN=danistwen`

## One-click build

Double-click `build-win-x64.cmd` on Windows. It runs:

1. .NET 10 `publish` as `win-x64`, self-contained, single-file.
2. Clipxel self-tests.
3. Creates a `CN=danistwen` self-signed code-signing certificate if one does not exist yet.
4. Signs `publish\win-x64\Clipxel.exe` with SHA-256 and a timestamp.
5. Verifies the Authenticode signature.

The private key remains in the current Windows user's certificate store and is not included in the source ZIP.

## Important trust note

The included workflow creates a **self-signed** code-signing certificate. It provides tamper detection and shows `danistwen` as the signer, and the setup trusts it for the current Windows user. Other computers do not automatically trust a self-signed certificate.

For public distribution without manually trusting the certificate on each target PC, use a CA-issued Windows Code Signing certificate. The rest of the signing workflow can then be changed to select that certificate thumbprint.
