using System;
using System.IO;
namespace Clipxel.Services;
internal static class BrandStorage
{
    // Keep user-selected paths and patterns; read legacy preferences/swatches until saved in Clipxel.
    internal static string ReadPath(string name)
    {
        string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string current=Path.Combine(local,"Clipxel",name);
        return File.Exists(current)?current:Path.Combine(local,"PinShot",name);
    }
}
