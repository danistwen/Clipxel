using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clipxel.Windows;
namespace Clipxel.Services;
internal static class CanvasTheme
{
    public static Color? BackgroundFor(Window? owner)
    {
        for(var current=owner;current is not null;current=current.Owner)if(current is ReferenceBoardWindow board)return board.CanvasBackground;
        return null;
    }
    public static void Apply(FrameworkElement root,Color? background)
    {
        Brush surface=(Brush)Application.Current.FindResource("DialogSurface");
        Brush foreground=ThemeService.Foreground;
        Brush field=(Brush)Application.Current.FindResource("DialogField");
        
        root.SetValue(TextBlock.ForegroundProperty,foreground);
        if(root is Window window){window.SetResourceReference(Window.BackgroundProperty,"DialogSurface");window.Foreground=foreground;}
        if(root is Border border){border.SetResourceReference(Border.BackgroundProperty,"DialogSurface");border.BorderThickness=new Thickness(0);MistBackdrop.Attach(border);}
        foreach(var type in new[]{typeof(TextBox),typeof(ComboBox),typeof(Button),typeof(CheckBox),typeof(TabItem),typeof(TabControl),typeof(ListBox),typeof(ComboBoxItem),typeof(MenuItem)})
        {
            var style=new Style(type,Application.Current.TryFindResource(type) as Style);style.Setters.Add(new Setter(Control.ForegroundProperty,new DynamicResourceExtension("TextPrimary")));
            if(type!=typeof(CheckBox)&&type!=typeof(MenuItem))style.Setters.Add(new Setter(Control.BackgroundProperty,new DynamicResourceExtension("DialogField")));root.Resources[type]=style;
        }
        var textStyle=new Style(typeof(TextBlock),Application.Current.TryFindResource(typeof(TextBlock)) as Style);textStyle.Setters.Add(new Setter(TextBlock.ForegroundProperty,new DynamicResourceExtension("TextPrimary")));root.Resources[typeof(TextBlock)]=textStyle;
        // Existing dialogs contain a few explicit foregrounds; keep error text and icons, harmonize their ordinary labels.
        root.Loaded-=OnLoaded;root.Loaded+=OnLoaded;
        if(root.IsLoaded)TintLabels(root,foreground,surface);
    }
    private static void OnLoaded(object sender,RoutedEventArgs e)
    {if(sender is FrameworkElement root)TintLabels(root,ThemeService.Foreground,(Brush)root.FindResource("DialogSurface"));}
    private static void TintLabels(DependencyObject node,Brush foreground,Brush surface)
    {
        if(node is TextBlock label && label.Foreground is SolidColorBrush brush && brush.Color.R!=178 && brush.Color!=Colors.Firebrick && brush.Color!=Colors.OrangeRed)label.Foreground=foreground;
        // Preserve existing backdrop brushes and intentional color swatches.
        for(int i=0;i<VisualTreeHelper.GetChildrenCount(node);i++)TintLabels(VisualTreeHelper.GetChild(node,i),foreground,surface);
    }
}
