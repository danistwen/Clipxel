using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Clipxel.Services;

public static class ClipboardService
{
    public static Task SetImageAsync(BitmapSource bitmap) => RetryAsync(() => Clipboard.SetImage(bitmap));
    public static Task SetTextAsync(string value) => RetryAsync(() => Clipboard.SetText(value));

    public static async Task<BitmapSource?> GetImageAsync()
    {
        BitmapSource? result = null;
        await RetryAsync(() =>
        {
            var image = Clipboard.GetImage();
            if (image is not null) result = ScreenCaptureService.CropDetached(image, new Int32Rect(0, 0, image.PixelWidth, image.PixelHeight));
        });
        return result;
    }

    private static async Task RetryAsync(Action write)
    {
        // Called on the WPF STA thread. Await deliberately retains its dispatcher context.
        for (int attempt = 0; ; attempt++)
        {
            try { write(); return; }
            catch (COMException ex) when (ex.HResult == unchecked((int)0x800401D0) && attempt < 4)
            {
                await Task.Delay(40 * (attempt + 1));
            }
        }
    }
}
