using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shell;
namespace Clipxel.Services;
internal static class DialogChrome
{
    private static readonly DependencyProperty StyledProperty=DependencyProperty.RegisterAttached("Styled",typeof(bool),typeof(DialogChrome),new PropertyMetadata(false));
    [DllImport("dwmapi.dll")]private static extern int DwmSetWindowAttribute(IntPtr hwnd,int attribute,ref int value,int size);
    public static void Register()=>EventManager.RegisterClassHandler(typeof(Window),FrameworkElement.LoadedEvent,new RoutedEventHandler((s,e)=>
    {
        if(s is not Window window||e.OriginalSource!=window||window.WindowStyle==WindowStyle.None||(bool)window.GetValue(StyledProperty))return;
        window.SetValue(StyledProperty,true);Apply(window);
    }));
    private static void Apply(Window window)
    {
        if(window.Content is not UIElement original)return;
        window.Content=null;window.WindowStyle=WindowStyle.None;
        WindowChrome.SetWindowChrome(window,new WindowChrome{CaptionHeight=0,ResizeBorderThickness=window.ResizeMode==ResizeMode.NoResize?new Thickness(0):new Thickness(5),GlassFrameThickness=new Thickness(-1),CornerRadius=new CornerRadius(12),UseAeroCaptionButtons=false});
        var root=new DockPanel();var head=new Grid{Height=34,Background=Brushes.Transparent};DockPanel.SetDock(head,Dock.Top);root.Children.Add(head);
        head.Children.Add(new TextBlock{Text=window.Title,Margin=new Thickness(36,0,42,0),VerticalAlignment=VerticalAlignment.Center,IsHitTestVisible=false});
        var mark=new Image {Width=16,Height=16,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(12,0,0,0),IsHitTestVisible=false};mark.SetResourceReference(Image.SourceProperty,"BrandMark");head.Children.Add(mark);
        var close=new Button{Content="×",Width=30,Height=26,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,3,6,3),Background=Brushes.Transparent,BorderThickness=new Thickness(0)};head.Children.Add(close);close.Click+=(_,_)=>window.Close();ToolHints.Attach(close,()=>"關閉",()=>null);
        head.MouseLeftButtonDown+=(_,e)=>{if(e.OriginalSource is not Button&&e.LeftButton==MouseButtonState.Pressed){window.DragMove();e.Handled=true;}};
        root.Children.Add(original);
        var shell=new Border{CornerRadius=new CornerRadius(12),BorderThickness=new Thickness(0),Child=root};window.Content=shell;
        CanvasTheme.Apply(shell,CanvasTheme.BackgroundFor(window));MistBackdrop.Attach(shell,window);window.Background=Brushes.Transparent;RoundedWindow.Attach(window,shell);MistBackdrop.RefreshAll();
        // Mica uses the system theme/wallpaper, not repeated live canvas captures.
        try
        {
            var handle=new WindowInteropHelper(window).Handle;
            int dark=ThemeService.IsDark?1:0,borderNone=-2,backdrop=2;
            DwmSetWindowAttribute(handle,20,ref dark,sizeof(int));
            DwmSetWindowAttribute(handle,34,ref borderNone,sizeof(int));
            bool mica=DwmSetWindowAttribute(handle,38,ref backdrop,sizeof(int))==0;
            window.Background=mica?Brushes.Transparent:new SolidColorBrush(ThemeService.Surface);
            if(HwndSource.FromHwnd(handle)?.CompositionTarget is { } target)
                target.BackgroundColor=mica?Colors.Transparent:ThemeService.Surface;
        }catch(DllNotFoundException){}catch(EntryPointNotFoundException){}
    }
}
