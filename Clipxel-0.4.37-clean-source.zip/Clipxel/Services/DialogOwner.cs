using System;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Clipxel.Windows;
namespace Clipxel.Services;
internal static class DialogOwner
{
    private static readonly DependencyProperty PreparedProperty=DependencyProperty.RegisterAttached("Prepared",typeof(bool),typeof(DialogOwner),new PropertyMetadata(false));
    internal static Window? Resolve(Window? preferred=null,Window? exclude=null)
    {
        var windows=Application.Current.Windows.OfType<Window>()
            .Where(w=>w!=exclude&&w.IsVisible&&w.IsEnabled&&w is not ToolbarWindow&&w is not PieMenuWindow&&w is not BoardPieWindow&&w is not ToastWindow).ToArray();
        // Nested modal prompts stay with their active palette; never choose the new dialog itself.
        var active=windows.FirstOrDefault(w=>w.IsActive);
        if(active is not null&&active is not PinWindow&&active is not ReferenceBoardWindow&&active is not SelectionWindow)return active;
        for(var candidate=preferred;candidate is not null;candidate=candidate.Owner)
            if(windows.Contains(candidate))return candidate;
        return active??windows.LastOrDefault();
    }
    internal static void Prepare(Window dialog,Window? preferred=null)
    {
        if((bool)dialog.GetValue(PreparedProperty))return;
        dialog.SetValue(PreparedProperty,true);
        var owner=Resolve(preferred??dialog.Owner,dialog);
        if(owner is not null)dialog.Owner=owner;
        dialog.WindowStartupLocation=owner is null?WindowStartupLocation.CenterScreen:WindowStartupLocation.CenterOwner;
        dialog.Topmost=owner?.Topmost==true;
        foreach(var toolbar in Application.Current.Windows.OfType<ToolbarWindow>().ToArray())toolbar.ClosePopups();
        // Loaded chrome replacement changes the measured size. Position once after that layout,
        // in physical pixels so negative monitor coordinates and mixed DPI remain valid.
        EventHandler? rendered=null;
        rendered=(_,_)=>
        {
            dialog.ContentRendered-=rendered;
            dialog.Dispatcher.BeginInvoke(DispatcherPriority.Loaded,new Action(()=>
            {
                if(!dialog.IsVisible)return;
                dialog.UpdateLayout();
                var anchor=dialog.Owner?.IsVisible==true?dialog.Owner:null;
                var work=anchor is null?WindowPlacementService.WorkArea(dialog):WindowPlacementService.WorkArea(anchor);
                var bounds=anchor is null?work:WindowPlacementService.Bounds(anchor);
                var size=WindowPlacementService.Bounds(dialog);
                var at=Centered(bounds,work,size.Width,size.Height);
                WindowPlacementService.Move(dialog,(int)at.X,(int)at.Y);
                MistBackdrop.RefreshAll();dialog.Activate();dialog.Focus();
            }));
        };
        dialog.ContentRendered+=rendered;
    }
    internal static Point Centered(PixelRect owner,PixelRect work,int width,int height) => new(
        Math.Clamp(owner.X+(owner.Width-width)/2,work.X,Math.Max(work.X,work.X+work.Width-width)),
        Math.Clamp(owner.Y+(owner.Height-height)/2,work.Y,Math.Max(work.Y,work.Y+work.Height-height)));
}
