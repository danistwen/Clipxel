using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace Clipxel.Services;

// One document render per revision, not one (or two) render traversals per mouse move.
// Very large desktops use a bounded tile. Sampling and the lens share the same pixels.
internal sealed class DocumentRasterCache
{
    private long _revision=long.MinValue;
    private byte[] _pixels=Array.Empty<byte>();
    private int _x,_y,_width,_height;
    internal int RenderCount { get; private set; }
    internal void Clear() { _pixels=Array.Empty<byte>();_revision=long.MinValue; }
    private void Ensure(IDocumentSurface source,Point point)
    {
        int width=Math.Max(1,(int)Math.Ceiling(source.SamplingElement.ActualWidth));
        int height=Math.Max(1,(int)Math.Ceiling(source.SamplingElement.ActualHeight));
        int x=Math.Clamp((int)Math.Floor(point.X),0,width-1),y=Math.Clamp((int)Math.Floor(point.Y),0,height-1);
        long revision=source.DocumentRevision;
        if(_pixels.Length>0&&_revision==revision&&x>=_x+Math.Min(5,_x)&&y>=_y+Math.Min(5,_y)&&x<Math.Min(width,_x+_width-(_x+_width<width?5:0))&&y<Math.Min(height,_y+_height-(_y+_height<height?5:0)))return;
        _width=(long)width*height<=16_777_216?width:Math.Min(width,1024);
        _height=(long)width*height<=16_777_216?height:Math.Min(height,1024);
        _x=Math.Clamp(x-_width/2,0,width-_width);_y=Math.Clamp(y-_height/2,0,height-_height);
        var visual=new DrawingVisual();using(var dc=visual.RenderOpen())
        {
            dc.DrawRectangle(Brushes.Black,null,new Rect(0,0,_width,_height));
            dc.PushTransform(new TranslateTransform(-_x,-_y));dc.DrawDrawing(source.CreateDocumentDrawing());dc.Pop();
        }
        var bitmap=new RenderTargetBitmap(_width,_height,96,96,PixelFormats.Pbgra32);bitmap.Render(visual);
        int length=checked(_width*_height*4);if(_pixels.Length!=length)_pixels=new byte[length];
        bitmap.CopyPixels(_pixels,_width*4,0);_revision=revision;RenderCount++;
    }
    internal Color Sample(IDocumentSurface source,Point point,byte[]? lens=null)
    {
        Ensure(source,point);
        int x=Math.Clamp((int)Math.Floor(point.X)-_x,0,_width-1),y=Math.Clamp((int)Math.Floor(point.Y)-_y,0,_height-1);
        int center=(y*_width+x)*4;
        if(lens is not null)
        {
            if(lens.Length!=11*11*4)throw new ArgumentException("Lens must be 11 × 11 BGRA pixels",nameof(lens));
            for(int row=0;row<11;row++)for(int col=0;col<11;col++)
            {
                int src=(Math.Clamp(y+row-5,0,_height-1)*_width+Math.Clamp(x+col-5,0,_width-1))*4;
                Buffer.BlockCopy(_pixels,src,lens,(row*11+col)*4,4);
            }
        }
        return Color.FromRgb(_pixels[center+2],_pixels[center+1],_pixels[center]);
    }
}
