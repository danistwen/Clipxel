using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Clipxel.Services;

// Document pixels only. UI, selection handles and glass never feed back into sampling.
internal interface IDocumentSurface
{
    FrameworkElement SamplingElement { get; }
    long DocumentRevision { get; }
    Drawing CreateDocumentDrawing();
}

internal static class DocumentSurface
{
    internal static IDocumentSurface? Find(Window? window)
    {
        for (var current = window; current is not null; current = current.Owner)
            if (current is IDocumentSurface source) return source;
        return null;
    }

    internal static Color Sample(Drawing drawing, Point point)
    {
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            dc.DrawRectangle(Brushes.Black, null, new Rect(0, 0, 1, 1));
            dc.PushTransform(new TranslateTransform(-point.X, -point.Y));
            dc.DrawDrawing(drawing);
            dc.Pop();
        }
        var bitmap = new RenderTargetBitmap(1, 1, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        var bytes = new byte[4]; bitmap.CopyPixels(bytes, 4, 0);
        return Color.FromRgb(bytes[2], bytes[1], bytes[0]);
    }
}
