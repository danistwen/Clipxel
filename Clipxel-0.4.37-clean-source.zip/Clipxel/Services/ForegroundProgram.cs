using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
namespace Clipxel.Services;
public static class ForegroundProgram
{
    public static bool ShouldPause(Preferences p)
    {
        if (!p.AutoPause) return false;
        try
        {
            GetWindowThreadProcessId(GetForegroundWindow(), out uint pid);
            using var process = Process.GetProcessById((int)pid);
            return p.PausePrograms.Split(new[] { ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Any(n => string.Equals(Path.GetFileNameWithoutExtension(n.Trim()), process.ProcessName, StringComparison.OrdinalIgnoreCase));
        }
        catch { return false; }
    }
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
}
