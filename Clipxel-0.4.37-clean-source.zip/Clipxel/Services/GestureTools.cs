using System;
using System.Linq;
using Clipxel.Windows;
namespace Clipxel.Services;
internal static class GestureTools
{
    // Indices are persisted. Board catalog v1 removes legacy node index 20; Preferences migrates once.
    public static readonly string[] AnnotationLabels={"線條","儲存","文字","複製","取色","選取","畫筆","矩形","圓形","復原","重做"};
    public static readonly PieMenuAction[] AnnotationActions={PieMenuAction.Arrow,PieMenuAction.Save,PieMenuAction.Text,PieMenuAction.Copy,PieMenuAction.PickColor,PieMenuAction.Select,PieMenuAction.Pen,PieMenuAction.Rectangle,PieMenuAction.Circle,PieMenuAction.Undo,PieMenuAction.Redo};
    public static readonly BoardAction[] BoardActions={BoardAction.Fit,BoardAction.Arrange,BoardAction.Export,BoardAction.Paste,BoardAction.Import,BoardAction.Group,BoardAction.Select,BoardAction.Pan,BoardAction.Pen,BoardAction.Rectangle,BoardAction.Circle,BoardAction.Arrow,BoardAction.Text,BoardAction.Undo,BoardAction.Redo,BoardAction.Copy,BoardAction.Delete,BoardAction.SaveProject,BoardAction.OpenProject,BoardAction.Group,BoardAction.Capture,BoardAction.ToggleDrawing,BoardAction.ToggleChrome,BoardAction.PickColor};
    public static string[] BoardLabels=>BoardActions.Select(BoardPieWindow.Label).ToArray();
    public static int[] Defaults()=>Enumerable.Range(0,8).ToArray();
    public static int[] Normalize(int[]? map,int count)=>Enumerable.Range(0,8).Select(i=>map is not null&&i<map.Length&&map[i]>=0&&map[i]<count?map[i]:i).ToArray();
}
