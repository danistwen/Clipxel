using System;
using System.Windows;
using System.Windows.Media;
namespace Clipxel.Services;
internal static class GlassAppearance
{
    internal static void Apply(double opacity)
    {
        // Only the background brush changes; text, icons and input targets stay fully opaque.
        byte alpha=(byte)Math.Round(Math.Clamp(opacity,.2,1)*255);
        Application.Current.Resources["GlassShell"]=new SolidColorBrush(Color.FromArgb(alpha,ThemeService.Surface.R,ThemeService.Surface.G,ThemeService.Surface.B));
        MistBackdrop.RefreshAll();
    }
}
