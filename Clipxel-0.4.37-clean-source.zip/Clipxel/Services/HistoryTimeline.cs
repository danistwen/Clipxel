using System;
using System.Collections.Generic;
namespace Clipxel.Services;
internal sealed class HistoryTimeline<T>
{
    private readonly int _capacity;
    private readonly Func<T,string> _key;
    private readonly List<T> _undo=new(),_redo=new();
    private T _current=default!;
    private bool _initialized;
    public bool CanUndo=>_undo.Count>0;
    public bool CanRedo=>_redo.Count>0;
    public HistoryTimeline(Func<T,string> key,int capacity=40){_key=key;_capacity=capacity;}
    public void Reset(T state){_current=state;_initialized=true;_undo.Clear();_redo.Clear();}
    public bool Observe(T state)
    {
        if(!_initialized){Reset(state);return false;}
        if(_key(_current)==_key(state))return false;
        _undo.Add(_current);if(_undo.Count>_capacity)_undo.RemoveAt(0);_current=state;_redo.Clear();return true;
    }
    public bool TryMove(bool redo,out T state)
    {
        var from=redo?_redo:_undo;var to=redo?_undo:_redo;
        if(from.Count==0){state=_current;return false;}
        to.Add(_current);_current=from[^1];from.RemoveAt(from.Count-1);state=_current;return true;
    }
}
