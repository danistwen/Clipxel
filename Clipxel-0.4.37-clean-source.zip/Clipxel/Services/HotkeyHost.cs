using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;

namespace Clipxel.Services;

public sealed class HotkeyHost : Window
{
    private HwndSource? _source;
    private IntPtr _handle;
    private readonly HashSet<int> _registered = new();
    public event Action<int>? ActionRequested;
    public event Action<string>? RegistrationWarning;
    public HotkeyHost()
    {
        Width = Height = 1; Left = Top = -10000; Opacity = 0; ShowInTaskbar = false;
        WindowStyle = WindowStyle.None; ShowActivated = false;
        SourceInitialized += (_, _) => { _handle = new WindowInteropHelper(this).Handle; _source = HwndSource.FromHwnd(_handle); _source?.AddHook(WndProc); };
        Closed += (_, _) => { Suspend(); _source?.RemoveHook(WndProc); };
    }
    public static (uint Modifiers, uint Key) Parse(string text)
    {
        uint mods = 0; var parts = text.Split('+', StringSplitOptions.TrimEntries);
        for (int i = 0; i < parts.Length - 1; i++) mods |= parts[i].ToLowerInvariant() switch
        { "ctrl" => 2u, "alt" => 1u, "shift" => 4u, "win" => 8u, _ => throw new ArgumentException("快捷鍵修飾鍵無效：" + text) };
        if (!Enum.TryParse<Key>(parts[^1], true, out var key) || !Enum.IsDefined(key) || key == Key.None || key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin)
            throw new ArgumentException("快捷鍵無效：" + text);
        if ((mods & 11) == 0 && !(key >= Key.F1 && key <= Key.F24)) throw new ArgumentException("一般按鍵需搭配 Ctrl、Alt 或 Win；F1–F24 可單獨使用。");
        int vk = KeyInterop.VirtualKeyFromKey(key);
        if (vk <= 0) throw new ArgumentException("此按鍵無法作為全域快捷鍵。");
        return (mods | 0x4000u, (uint)vk);
    }
    public void Suspend()
    { foreach (int id in _registered) UnregisterHotKey(_handle, id); _registered.Clear(); }
    public string? Register(Preferences p, bool probe = false)
    {
        Suspend(); var failures = new List<string>();
        for (int i = 0; i < p.Keys.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(p.Keys[i])) continue;
            var gesture = Parse(p.Keys[i]);
            if (RegisterHotKey(_handle, i + 1, gesture.Modifiers, gesture.Key)) _registered.Add(i + 1);
            else failures.Add(p.Keys[i]);
        }
        if (probe) Suspend();
        string? error = failures.Count == 0 ? null : "快捷鍵已被占用或 Windows 不允許：" + string.Join("、", failures);
        if (!probe && error is not null) RegistrationWarning?.Invoke(error);
        return error;
    }
    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wp, IntPtr lp, ref bool handled)
    { if (msg == 0x312 && _registered.Contains(wp.ToInt32())) { handled = true; ActionRequested?.Invoke(wp.ToInt32()); } return IntPtr.Zero; }
    [DllImport("user32.dll", SetLastError = true)] private static extern bool RegisterHotKey(IntPtr hwnd, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr hwnd, int id);
}
