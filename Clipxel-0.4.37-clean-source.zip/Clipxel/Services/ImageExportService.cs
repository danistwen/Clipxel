using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Clipxel.Services;

public static class ImageExportService
{
    private static BitmapSource Flatten(BitmapSource source)
    {
        var converted=new FormatConvertedBitmap(source,PixelFormats.Bgra32,null,0);
        int width=source.PixelWidth,height=source.PixelHeight;
        var input=new byte[checked(width*height*4)];converted.CopyPixels(input,width*4,0);
        var output=new byte[checked(width*height*3)];
        for(int i=0,j=0;i<input.Length;i+=4,j+=3) for(int channel=0;channel<3;channel++)
            output[j+channel]=(byte)((input[i+channel]*input[i+3]+255*(255-input[i+3])+127)/255);
        var result=BitmapSource.Create(width,height,96,96,PixelFormats.Bgr24,null,output,width*3);result.Freeze();return result;
    }
    public static BitmapSource Compose(BitmapSource source, IReadOnlyList<DrawingGroup> drawings)
    {
        if (drawings.Count == 0) return source;
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            dc.DrawImage(source, new Rect(0, 0, source.PixelWidth, source.PixelHeight));
            foreach (var drawing in drawings) dc.DrawDrawing(drawing);
        }
        var result = new RenderTargetBitmap(source.PixelWidth, source.PixelHeight, 96, 96, PixelFormats.Pbgra32);
        result.Render(visual);
        result.Freeze();
        return result;
    }

    public const string ExportFilter = "PNG 圖片|*.png|JPEG 圖片|*.jpg;*.jpeg|BMP 圖片|*.bmp|TIFF 圖片|*.tif;*.tiff";
    public static Task SaveImageAsync(BitmapSource bitmap, string path) => SaveEncodedAsync(bitmap,path,false);
    public static Task SavePngAsync(BitmapSource bitmap, string path) => SaveEncodedAsync(bitmap,path,true);
    private static Task SaveEncodedAsync(BitmapSource bitmap, string path, bool forcePng)
    {
        if (!bitmap.IsFrozen) throw new ArgumentException("The image must be frozen.", nameof(bitmap));
        return Task.Run(() =>
        {
            string fullPath = Path.GetFullPath(path);
            string temporary = Path.Combine(Path.GetDirectoryName(fullPath)!, $".clipxel-{Guid.NewGuid():N}.tmp");
            try
            {
                string extension=forcePng?".png":Path.GetExtension(path).ToLowerInvariant();
                BitmapEncoder encoder=extension switch { ".png"=>new PngBitmapEncoder(), ".jpg" or ".jpeg"=>new JpegBitmapEncoder{QualityLevel=95}, ".bmp"=>new BmpBitmapEncoder(), ".tif" or ".tiff"=>new TiffBitmapEncoder(), _=>throw new ArgumentException("不支援的圖片格式："+extension) };
                if(extension is ".jpg" or ".jpeg" or ".bmp") bitmap=Flatten(bitmap);
                encoder.Frames.Add(BitmapFrame.Create(bitmap));
                using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    encoder.Save(output);
                    output.Flush(true);
                }
                // The old destination is only replaced after successful encoding.
                File.Move(temporary, fullPath, overwrite: true);
            }
            finally
            {
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        });
    }
}
