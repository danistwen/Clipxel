using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
namespace Clipxel.Services;
internal static class InputBoundary
{
    public static bool IsControlInteraction(DependencyObject? source,Visual host)
    {
        if(source is Visual visual&&PresentationSource.FromVisual(visual)!=PresentationSource.FromVisual(host))return true;
        for(var node=source;node is not null;node=node is Visual?VisualTreeHelper.GetParent(node):LogicalTreeHelper.GetParent(node))
            if(node is Clipxel.Controls.ColorPicker or Clipxel.Controls.ColorSpectrum or Clipxel.Controls.OpacityStrip or Slider or TextBoxBase or MenuItem or Popup)return true;
        return false;
    }
}
