using Clipxel.Models;
using Clipxel.Windows;
namespace Clipxel.Services;
internal static class LineGesture
{
    // Screen DIPs: identical drag requirement at every canvas zoom level.
    internal static bool CanCommit(Annotation annotation,double scaleX,double scaleY)
    {
        if(annotation.Tool!=AnnotationTool.Arrow)return true;
        var delta=annotation.End-annotation.Start;
        double x=delta.X*scaleX,y=delta.Y*scaleY;
        return double.IsFinite(x)&&double.IsFinite(y)&&x*x+y*y>=9;
    }
}
