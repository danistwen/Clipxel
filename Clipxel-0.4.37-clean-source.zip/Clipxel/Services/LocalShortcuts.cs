using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
namespace Clipxel.Services;
public static class LocalShortcuts
{
    public static Dictionary<string,string> BoardDefaults() => new()
    {
        ["PickColor"]="I", ["Pen"]="B", ["Rectangle"]="U", ["Circle"]="Shift+U", ["Arrow"]="Shift+L", ["Text"]="T", ["Group"]="Ctrl+G", ["RenameGroup"]="F2", ["Undo"]="Ctrl+Z", ["Redo"]="Ctrl+Shift+Z",
        ["Copy"]="Ctrl+C", ["Select"]="V", ["Pan"]="H", ["SelectAll"]="Ctrl+A", ["Delete"]="Delete",
        ["ToggleChrome"]="Tab", ["Import"]="Ctrl+Shift+O", ["Paste"]="Ctrl+V", ["Fit"]="Ctrl+D0",
        ["Arrange"]="Ctrl+L", ["Export"]="Ctrl+Shift+E", ["SaveProject"]="Ctrl+S", ["OpenProject"]="Ctrl+O", ["ToggleDrawing"]="F8", ["BoardSettings"]="Ctrl+OemComma", ["ZoomIn"]="Add", ["ZoomOut"]="Subtract",
        ["Topmost"]="Ctrl+Alt+T", ["Return"]="Ctrl+M", ["Settings"]="Ctrl+K"
    };
    private static Dictionary<string,string> AnnotationDispatchDefaults() => new()
    {
        ["選取"]="V", ["畫筆"]="B", ["矩形"]="R", ["圓形"]="C", ["箭頭"]="A", ["文字"]="T", ["取色"]="I",
        ["復原"]="Ctrl+Z", ["重做"]="Ctrl+Y", ["重做（備用）"]="Ctrl+Shift+Z", ["複製"]="Ctrl+C", ["儲存"]="Ctrl+S",
        ["原始比例（釘圖）"]="D1", ["原始比例（數字鍵盤）"]="NumPad1", ["工具列（釘圖）"]="Tab"
    };
    public static Dictionary<string,string> AnnotationDefaults()
    {
        var keys=AnnotationDispatchDefaults();keys["矩形"]="U";keys["圓形"]="Shift+U";keys["箭頭"]="Shift+L";
        keys["重做"]="Ctrl+Shift+Z";keys["重做（備用）"]="Ctrl+Y";return keys;
    }
    internal static Dictionary<string,string> UpgradeUnchangedDefaults(Dictionary<string,string> current,bool board)
    {
        var legacy=board?BoardDefaults():AnnotationDispatchDefaults();
        if(board)
        {
            legacy["Connect"]="L";legacy.Remove("PickColor");legacy["Rectangle"]="R";legacy["Circle"]="C";legacy["Arrow"]="A";legacy["Group"]="G";legacy["GroupStyle"]="Ctrl+G";
            legacy["Redo"]="Ctrl+Y";legacy["Import"]="Ctrl+O";legacy["OpenProject"]="Ctrl+Shift+O";legacy["Fit"]="Home";legacy["Topmost"]="Ctrl+T";
        }
        else legacy.Remove("選取");
        return current is not null&&current.Count==legacy.Count&&legacy.All(p=>current.TryGetValue(p.Key,out var value)&&value==p.Value)
            ?(board?BoardDefaults():AnnotationDefaults()):current!;
    }
    public static bool ModifierOnly(Key key) => key is Key.LeftCtrl or Key.RightCtrl or Key.LeftShift or Key.RightShift or Key.LeftAlt or Key.RightAlt or Key.LWin or Key.RWin;
    public static string Format(Key key, ModifierKeys mods) =>
        (mods.HasFlag(ModifierKeys.Control)?"Ctrl+":"")+(mods.HasFlag(ModifierKeys.Alt)?"Alt+":"")+
        (mods.HasFlag(ModifierKeys.Shift)?"Shift+":"")+(mods.HasFlag(ModifierKeys.Windows)?"Win+":"")+key;
    public static (Key Key, ModifierKeys Mods) Parse(string text)
    {
        var parts=text.Split('+', StringSplitOptions.TrimEntries); ModifierKeys mods=ModifierKeys.None;
        for(int i=0;i<parts.Length-1;i++) mods |= parts[i].ToLowerInvariant() switch
        { "ctrl"=>ModifierKeys.Control,"alt"=>ModifierKeys.Alt,"shift"=>ModifierKeys.Shift,"win"=>ModifierKeys.Windows,_=>throw new ArgumentException("無效修飾鍵："+text) };
        if(!Enum.TryParse<Key>(parts[^1],true,out var key) || !Enum.IsDefined(typeof(Key),key) || key==Key.None || ModifierOnly(key) || key is Key.System or Key.ImeProcessed or Key.DeadCharProcessed)
            throw new ArgumentException("無效快捷鍵："+text);
        return (key,mods);
    }
    public static string? Match(Dictionary<string,string> bindings, Key key, ModifierKeys mods)
    { foreach(var pair in bindings) if(!string.IsNullOrWhiteSpace(pair.Value) && Parse(pair.Value)==(key,mods)) return pair.Key; return null; }
    public static void Validate(Dictionary<string,string> bindings, Dictionary<string,string> defaults, string[] globals)
    {
        if(bindings is null) throw new ArgumentException("快捷鍵設定不可為空。");
        foreach(var pair in defaults)
        {
            if(bindings.ContainsKey(pair.Key)) continue;
            bool occupied = bindings.Values.Concat(globals).Any(v => !string.IsNullOrWhiteSpace(v) && Parse(v) == Parse(pair.Value));
            bindings.Add(pair.Key, occupied ? "" : pair.Value);
        }
        var used=new HashSet<(Key,ModifierKeys)>();
        foreach(var pair in bindings)
        {
            if(!defaults.ContainsKey(pair.Key)) throw new ArgumentException("未知快捷鍵操作："+pair.Key);
            if(string.IsNullOrWhiteSpace(pair.Value)) continue;
            var key=Parse(pair.Value);
            if(key.Key is Key.Escape or Key.Enter or Key.Space || (key.Key==Key.Delete && defaults.ContainsKey("畫筆")))
                throw new ArgumentException("Esc、Enter、Space 及標註 Delete 保留給取消、確認、平移與刪除。");
            if(!used.Add(key)) throw new ArgumentException("同一模式快捷鍵重複："+pair.Value);
            if(globals.Any(g=>!string.IsNullOrWhiteSpace(g)&&Parse(g)==key)) throw new ArgumentException("模式快捷鍵與全域快捷鍵重複："+pair.Value);
        }
    }
    // Translate configured annotation bindings to the existing commands after text input guards.
    public static (Key Key, ModifierKeys Mods) AnnotationKey(Key key, ModifierKeys mods)
    {
        if(key is Key.Escape or Key.Delete or Key.Enter) return (key,mods);
        var action=Match(App.Settings.AnnotationShortcuts,key,mods);
        return action is null ? (Key.None,ModifierKeys.None) : Parse(AnnotationDispatchDefaults()[action]);
    }
}
