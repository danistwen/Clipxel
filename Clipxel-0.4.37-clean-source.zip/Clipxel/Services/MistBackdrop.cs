using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Runtime.CompilerServices;
using System.Linq;
namespace Clipxel.Services;

// Shared, bounded document-only blur: each panel maps its actual screen position.
// The timer checks revisions/placement; unchanged documents and panels do no bitmap work.
internal static class MistBackdrop
{
    private static readonly DependencyProperty OwnerProperty = DependencyProperty.RegisterAttached("Owner", typeof(Window), typeof(MistBackdrop));
    private static readonly DependencyProperty AttachedProperty = DependencyProperty.RegisterAttached("Attached", typeof(bool), typeof(MistBackdrop), new PropertyMetadata(false));
    private static readonly DependencyProperty TintProperty=DependencyProperty.RegisterAttached("BaseTint",typeof(Brush),typeof(MistBackdrop));
    private static readonly DependencyProperty ShellProperty=DependencyProperty.RegisterAttached("IsShell",typeof(bool),typeof(MistBackdrop),new PropertyMetadata(false));
    private sealed class Sample { internal int ThemeRevision=-1; internal long Revision=long.MinValue; internal BitmapSource? Bitmap; }
    private sealed class Placement { internal BitmapSource? Bitmap; internal Rect Bounds; internal Size Size; internal byte Veil; internal int ThemeRevision=-1; }
    private static readonly ConditionalWeakTable<IDocumentSurface,Sample> Samples=new();
    private static readonly ConditionalWeakTable<FrameworkElement,Placement> Placements=new();
    private static readonly List<WeakReference<FrameworkElement>> Targets=new();
    private static System.Windows.Threading.DispatcherTimer? _timer;
    private static bool _registered;
    private static void StartTimer()
    {
        if(_timer is null)
        {
            _timer=new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background) {Interval=TimeSpan.FromMilliseconds(100)};
            _timer.Tick+=(_,_)=>RefreshAll();
        }
        _timer.Start();
    }
    internal static void RefreshAll()
    {
        Targets.RemoveAll(w=>!w.TryGetTarget(out var target)||!target.IsLoaded);
        bool visible=false;
        foreach(var weak in Targets.ToArray())if(weak.TryGetTarget(out var target)&&target.IsVisible){visible=true;Map(target);}
        if(!visible)_timer?.Stop();
    }
    private static void Map(FrameworkElement target)
    {
        try{MapCore(target);}catch(InvalidOperationException){/* The native popup can disconnect while unloading. */}
    }
    private static void MapCore(FrameworkElement target)
    {
        if(target.ActualWidth<1||target.ActualHeight<1)return;
        var source=DocumentSurface.Find(FindOwner(target));
        if(source is null)return;
        var element=source.SamplingElement;
        if(element.ActualWidth<1||element.ActualHeight<1||PresentationSource.FromVisual(element) is null||PresentationSource.FromVisual(target) is null)return;
        var sample=Samples.GetValue(source,_=>new Sample());
        if(sample.Bitmap is null||sample.Revision!=source.DocumentRevision||sample.ThemeRevision!=ThemeService.Revision)
        {
            double scale=Math.Min(1,384/Math.Max(element.ActualWidth,element.ActualHeight));
            int width=Math.Max(1,(int)Math.Ceiling(element.ActualWidth*scale)),height=Math.Max(1,(int)Math.Ceiling(element.ActualHeight*scale));
            var visual=new DrawingVisual();using(var dc=visual.RenderOpen())
            {
                dc.DrawRectangle(new SolidColorBrush(ThemeService.Background),null,new Rect(0,0,width,height));
                dc.PushTransform(new ScaleTransform(width/element.ActualWidth,height/element.ActualHeight));
                dc.DrawDrawing(source.CreateDocumentDrawing());dc.Pop();
            }
            var bitmap=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);bitmap.Render(visual);
            byte[] pixels=new byte[width*height*4];bitmap.CopyPixels(pixels,width*4,0);
            // Three separable box passes approximate a Gaussian; edge pixels are extended.
            Blur(pixels,width,height,Math.Max(1,(int)Math.Round(18*scale)));
            sample.Bitmap=BitmapSource.Create(width,height,96,96,PixelFormats.Pbgra32,null,pixels,width*4);sample.Bitmap.Freeze();
            sample.Revision=source.DocumentRevision;sample.ThemeRevision=ThemeService.Revision;
        }
        Point origin=element.PointFromScreen(target.PointToScreen(new Point()));
        Point end=element.PointFromScreen(target.PointToScreen(new Point(target.ActualWidth,target.ActualHeight)));
        var bounds=new Rect(origin,end);if(bounds.Width<.1||bounds.Height<.1)return;
        byte veil=ThemeService.IsDark?(byte)190:(byte)215;
        if((bool)target.GetValue(ShellProperty)&&Application.Current.TryFindResource("GlassShell") is SolidColorBrush shellTint)veil=(byte)Math.Clamp((int)Math.Round(shellTint.Color.A*.875),64,230);
        var placement=Placements.GetValue(target,_=>new Placement());
        if(ReferenceEquals(placement.Bitmap,sample.Bitmap)&&placement.Bounds==bounds&&placement.Size==target.RenderSize&&placement.Veil==veil&&placement.ThemeRevision==ThemeService.Revision)return;
        // Unit-square coordinates preserve the actual backdrop mapping across popup DPI changes.
        var drawing=new DrawingGroup();using(var dc=drawing.Open())
        {
            dc.PushClip(new RectangleGeometry(new Rect(0,0,1,1)));
            dc.DrawRectangle(new SolidColorBrush(ThemeService.Background),null,new Rect(0,0,1,1));
            dc.DrawImage(sample.Bitmap,new Rect(-bounds.X/bounds.Width,-bounds.Y/bounds.Height,element.ActualWidth/bounds.Width,element.ActualHeight/bounds.Height));
            // Neutral dark veil preserves white label contrast without flattening local colors.
            dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(veil,ThemeService.Surface.R,ThemeService.Surface.G,ThemeService.Surface.B)),null,new Rect(0,0,1,1));
            dc.Pop();
        }
        drawing.Freeze();var mapped=new DrawingBrush(drawing){Stretch=Stretch.Fill,Viewbox=new Rect(0,0,1,1),ViewboxUnits=BrushMappingMode.Absolute};mapped.Freeze();
        if(target is Border border)border.SetCurrentValue(Border.BackgroundProperty,mapped);
        else if(target is Panel panel)panel.SetCurrentValue(Panel.BackgroundProperty,mapped);
        placement.Bitmap=sample.Bitmap;placement.Bounds=bounds;placement.Size=target.RenderSize;placement.Veil=veil;placement.ThemeRevision=ThemeService.Revision;
    }
    internal static void Blur(byte[] pixels,int width,int height,int radius)
    {
        var temp=new byte[pixels.Length];int diameter=radius*2+1;
        for(int pass=0;pass<3;pass++)
        {
            for(int y=0;y<height;y++)for(int c=0;c<4;c++)
            {
                int sum=0;for(int k=-radius;k<=radius;k++)sum+=pixels[(y*width+Math.Clamp(k,0,width-1))*4+c];
                for(int x=0;x<width;x++)
                {
                    temp[(y*width+x)*4+c]=(byte)(sum/diameter);
                    sum-=pixels[(y*width+Math.Clamp(x-radius,0,width-1))*4+c];
                    sum+=pixels[(y*width+Math.Clamp(x+radius+1,0,width-1))*4+c];
                }
            }
            for(int x=0;x<width;x++)for(int c=0;c<4;c++)
            {
                int sum=0;for(int k=-radius;k<=radius;k++)sum+=temp[(Math.Clamp(k,0,height-1)*width+x)*4+c];
                for(int y=0;y<height;y++)
                {
                    pixels[(y*width+x)*4+c]=(byte)(sum/diameter);
                    sum-=temp[(Math.Clamp(y-radius,0,height-1)*width+x)*4+c];
                    sum+=temp[(Math.Clamp(y+radius+1,0,height-1)*width+x)*4+c];
                }
            }
        }
    }
    internal static void Register()
    {
        if (_registered) return; _registered = true;
        EventManager.RegisterClassHandler(typeof(Border), FrameworkElement.LoadedEvent, new RoutedEventHandler((s,e)=>
        {
            if(s is not Border border || !ReferenceEquals(e.OriginalSource,border))return;
            foreach(string key in new[]{"GlassShell","GlassSurface","DialogSurface","MenuSurface","WindowChromeSurface","DarkGlass"})
                if(ReferenceEquals(border.Background,border.TryFindResource(key))){Attach(border);break;}
        }));
    }
    internal static void Attach(FrameworkElement element, Window? owner = null)
    {
        if(owner is not null)element.SetValue(OwnerProperty,owner);
        if((bool)element.GetValue(AttachedProperty))return;
        element.SetValue(AttachedProperty,true);
        Brush? tint=element is Border b?b.Background:element is Panel panel?panel.Background:null;
        element.SetValue(TintProperty,tint);
        element.SetValue(ShellProperty,ReferenceEquals(tint,Application.Current.TryFindResource("GlassShell")));
        void Track()
        {
            Targets.RemoveAll(w=>!w.TryGetTarget(out var t)||ReferenceEquals(t,element));
            if(element.IsLoaded){Targets.Add(new(element));if(element.IsVisible){Map(element);StartTimer();}}
        }
        element.Loaded+=(_,_)=>Track();element.Unloaded+=(_,_)=>{Track();Placements.Remove(element);RefreshAll();};
        element.IsVisibleChanged+=(_,_)=>{if(element.IsVisible&&element.IsLoaded){Map(element);StartTimer();}};
        if(element.IsLoaded)Track();
        // Clip popup child backgrounds to the rounded material, avoiding square corner patches.
        if(element is Border border)
        {
            void Clip()
            {
                double radius=border.CornerRadius.TopLeft;
                border.Clip=radius>0?new RectangleGeometry(new Rect(0,0,Math.Max(0,border.ActualWidth),Math.Max(0,border.ActualHeight)),radius,radius):null;
            }
            border.SizeChanged+=(_,_)=>Clip();border.Loaded+=(_,_)=>Clip();
            if(border.IsLoaded)Clip();
        }
    }
    internal static Window? FindOwner(DependencyObject? element)
    {
        var pending = new Queue<DependencyObject>(); var seen = new HashSet<DependencyObject>();
        if (element is not null) pending.Enqueue(element);
        while (pending.Count > 0)
        {
            var node = pending.Dequeue(); if (!seen.Add(node)) continue;
            if (node.GetValue(OwnerProperty) is Window explicitOwner) return explicitOwner;
            if (node is Window window) return window;
            DependencyObject? placement = node switch { Popup p => p.PlacementTarget, ContextMenu m => m.PlacementTarget, ToolTip t => t.PlacementTarget, _ => null };
            if (placement is not null) pending.Enqueue(placement);
            if (node is FrameworkElement fe) { if (fe.Parent is not null) pending.Enqueue(fe.Parent); if (fe.TemplatedParent is not null) pending.Enqueue(fe.TemplatedParent); }
            if (node is Visual && VisualTreeHelper.GetParent(node) is { } parent) pending.Enqueue(parent);
        }
        return null;
    }

}
