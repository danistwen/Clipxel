using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace Clipxel.Services;

public sealed class Preferences
{
    public string CaptureKey { get; set; } = "F1";
    public string AlternateKey { get; set; } = "Ctrl+Shift+A";
    public string PasteKey { get; set; } = "";
    public string ToggleModeKey { get; set; } = "Ctrl+Alt+M";
    public string TogglePinsKey { get; set; } = "";
    public string Color { get; set; } = "#FFFFFF";
    public string Theme { get; set; } = "Dark";
    public double ToolbarOpacity { get; set; } = .78;
    public double FontSize { get; set; } = 22;
    public double StrokeWidth { get; set; } = 3;
    public bool ClosePinAfterCopy { get; set; }
    public bool CloseSelectionAfterCopy { get; set; } = true;
    public bool AutoSave { get; set; }
    public string SaveFolder { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "Clipxel");
    public string NamePattern { get; set; } = "Clipxel_{date}_{time}";
    public bool AutoPause { get; set; }
    public string PausePrograms { get; set; } = "blender.exe; Cinema 4D.exe";
    public string[] Keys => new[] { CaptureKey, AlternateKey, PasteKey, TogglePinsKey, ToggleModeKey };
    public Dictionary<string, string> BoardShortcuts { get; set; } = LocalShortcuts.BoardDefaults();
    public Dictionary<string, string> AnnotationShortcuts { get; set; } = LocalShortcuts.AnnotationDefaults();
    public int[] AnnotationDirections { get; set; } = GestureTools.Defaults();
    public int BoardDirectionCatalogVersion { get; set; }
    public int[] BoardDirections { get; set; } = GestureTools.Defaults();
    public Preferences Copy()
    {
        var copy = (Preferences)MemberwiseClone();
        copy.AnnotationDirections=(int[])AnnotationDirections.Clone();copy.BoardDirections=(int[])BoardDirections.Clone();
        copy.BoardShortcuts = new(BoardShortcuts); copy.AnnotationShortcuts = new(AnnotationShortcuts); return copy;
    }
    public System.Windows.Media.Color AnnotationColor => (System.Windows.Media.Color)ColorConverter.ConvertFromString(Color);
    public void Validate()
    {
        if(Theme != "Dark" && Theme != "Light" && Theme != "White") Theme="Dark";
        AnnotationDirections=GestureTools.Normalize(AnnotationDirections,GestureTools.AnnotationLabels.Length);
        if(BoardDirectionCatalogVersion<1 && BoardDirections is not null)
            BoardDirections=BoardDirections.Select(i=>i==20?6:i>20?i-1:i).ToArray();
        BoardDirectionCatalogVersion=1;
        BoardDirections=GestureTools.Normalize(BoardDirections,GestureTools.BoardActions.Length);
        _ = AnnotationColor;
        if(!double.IsFinite(ToolbarOpacity))ToolbarOpacity=.78;ToolbarOpacity=Math.Clamp(ToolbarOpacity,.2,1);
        BoardShortcuts=LocalShortcuts.UpgradeUnchangedDefaults(BoardShortcuts,true);AnnotationShortcuts=LocalShortcuts.UpgradeUnchangedDefaults(AnnotationShortcuts,false);
        if (BoardShortcuts is not null && !BoardShortcuts.ContainsKey("SaveProject") && BoardShortcuts.TryGetValue("Export", out var oldExport) && oldExport == "Ctrl+S") BoardShortcuts["Export"] = "Ctrl+Shift+E";
        BoardShortcuts?.Remove("GroupStyle");BoardShortcuts?.Remove("Connect");
        LocalShortcuts.Validate(BoardShortcuts!, LocalShortcuts.BoardDefaults(), Keys);
        LocalShortcuts.Validate(AnnotationShortcuts, LocalShortcuts.AnnotationDefaults(), Keys);
        if (!double.IsFinite(FontSize) || FontSize < 8 || FontSize > 120 || !double.IsFinite(StrokeWidth) || StrokeWidth < 1 || StrokeWidth > 24)
            throw new ArgumentException("字級需為 8–120，筆畫粗細需為 1–24。");
        var keys = Keys.Where(k => !string.IsNullOrWhiteSpace(k)).Select(HotkeyHost.Parse).ToArray();
        if (keys.Distinct().Count() != keys.Length) throw new ArgumentException("快捷鍵不可重複。");
        if (string.IsNullOrWhiteSpace(SaveFolder) || !Path.IsPathFullyQualified(SaveFolder)) throw new ArgumentException("請選擇完整的儲存資料夾路徑。");
        _ = Path.GetFullPath(SaveFolder);
        _ = FileName();
    }
    public string FileName()
    {
        var now = DateTime.Now;
        string name = (NamePattern ?? "").Replace("{date}", now.ToString("yyyyMMdd")).Replace("{time}", now.ToString("HHmmss_fff"));
        if (string.IsNullOrWhiteSpace(name) || name.Length > 160 || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name.Contains('{') || name.Contains('}') || name.EndsWith('.') || name.EndsWith(' '))
            throw new ArgumentException("檔名可使用 {date}、{time}，不可包含路徑或特殊字元。");
        string stem = name.Split('.')[0].ToUpperInvariant();
        if (new[] { "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9" }.Contains(stem))
            throw new ArgumentException("此檔名是 Windows 保留名稱。");
        return name + ".png";
    }
}

public static class PreferenceStore
{
    public static string FilePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Clipxel", "settings.json");
    public static Preferences Load()
    {
        try { string path=BrandStorage.ReadPath("settings.json"); if (!File.Exists(path)) return new(); var p = JsonSerializer.Deserialize<Preferences>(File.ReadAllText(path)) ?? new(); p.Validate(); return p; }
        catch (Exception ex) { App.LogError("Load preferences", ex); return new(); }
    }
    public static void Save(Preferences p)
    {
        p.Validate(); Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
        string temp = FilePath + ".tmp";
        try { File.WriteAllText(temp, JsonSerializer.Serialize(p, new JsonSerializerOptions { WriteIndented = true, IgnoreReadOnlyProperties = true })); File.Move(temp, FilePath, true); }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
}

public static class StartupService
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private sealed record Snapshot(object? Current, object? Legacy);
    public static object? Read() { using var key = Registry.CurrentUser.OpenSubKey(RunKey); return new Snapshot(key?.GetValue("Clipxel"),key?.GetValue("PinShot")); }
    public static bool Enabled => Read() is Snapshot s && ((s.Current as string)?.Length>0 || (s.Legacy as string)?.Length>0);
    public static void Restore(object? value)
    {
        using var key = Registry.CurrentUser.CreateSubKey(RunKey);
        if (value is Snapshot snapshot)
        {
            if(snapshot.Current is null)key.DeleteValue("Clipxel",false);else key.SetValue("Clipxel",snapshot.Current);
            if(snapshot.Legacy is null)key.DeleteValue("PinShot",false);else key.SetValue("PinShot",snapshot.Legacy);
        }
        else
        {
            if (value is null) key.DeleteValue("Clipxel", false); else key.SetValue("Clipxel", value);
            key.DeleteValue("PinShot",false);
        }
    }
    public static void Set(bool enabled)
    {
        if (!enabled) { Restore(null); return; }
        string exe = Environment.ProcessPath ?? "";
        if (!string.Equals(Path.GetFileName(exe), "Clipxel.exe", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("請從發佈資料夾的 Clipxel.exe 啟用開機啟動。");
        Restore("\"" + exe + "\" --startup");
    }
}

public static class CaptureStorage
{
    public static async Task AutoSaveAsync(BitmapSource bitmap)
    {
        var p = App.Settings;
        if (!p.AutoSave) return;
        try
        {
            Directory.CreateDirectory(p.SaveFolder);
            // Unique suffix prevents concurrent captures or repeated patterns overwriting images.
            string path = Path.Combine(p.SaveFolder, Path.GetFileNameWithoutExtension(p.FileName()) + "_" + Guid.NewGuid().ToString("N")[..8] + ".png");
            await ImageExportService.SavePngAsync(bitmap, path);
        }
        catch (Exception ex) { App.LogError("Auto save", ex); Clipxel.Windows.ToastWindow.ShowToast("Clipxel", "自動儲存失敗：" + ex.Message); }
    }
}
