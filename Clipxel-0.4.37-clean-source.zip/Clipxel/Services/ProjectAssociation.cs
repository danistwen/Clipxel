using System;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Win32;
namespace Clipxel.Services;
internal static class ProjectAssociation
{
    private const string PipeName="PinShot.Project.Open";
    [DllImport("shell32.dll")] private static extern void SHChangeNotify(uint eventId,uint flags,IntPtr item1,IntPtr item2);
    internal static void Register()
    {
        string exe=Environment.ProcessPath??"";
        if(!string.Equals(Path.GetFileName(exe),"Clipxel.exe",StringComparison.OrdinalIgnoreCase))return;
        foreach (string suffix in new[]{".clipxel", ".pinshot"})
        { using var extension=Registry.CurrentUser.CreateSubKey(@"Software\Classes\"+suffix);extension.SetValue("","Clipxel.Project"); }
        using var type=Registry.CurrentUser.CreateSubKey(@"Software\Classes\Clipxel.Project");type.SetValue("","Clipxel 畫布專案");
        using(var icon=type.CreateSubKey("DefaultIcon"))icon.SetValue("","\""+exe+"\",0");
        using(var command=type.CreateSubKey(@"shell\open\command"))command.SetValue("","\""+exe+"\" \"%1\"");
        SHChangeNotify(0x08000000,0,IntPtr.Zero,IntPtr.Zero);
    }
    internal static bool IsProjectPath(string path) => Path.GetExtension(path).Equals(".clipxel",StringComparison.OrdinalIgnoreCase)||Path.GetExtension(path).Equals(".pinshot",StringComparison.OrdinalIgnoreCase);
    internal static bool Send(string path)
    {
        try
        {
            using var pipe=new NamedPipeClientStream(".",PipeName,PipeDirection.Out,PipeOptions.CurrentUserOnly);
            pipe.Connect(1500);using var writer=new StreamWriter(pipe);writer.WriteLine(Path.GetFullPath(path));return true;
        }
        catch(Exception ex){App.LogError("Send project to running instance",ex);return false;}
    }
    internal static async Task Listen(Action<string> open)
    {
        while(true)
        {
            try
            {
                using var pipe=new NamedPipeServerStream(PipeName,PipeDirection.In,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous|PipeOptions.CurrentUserOnly);
                await pipe.WaitForConnectionAsync().ConfigureAwait(false);
                using var reader=new StreamReader(pipe);var buffer=new char[32768];int count=0;
                while(count<buffer.Length){int read=await reader.ReadAsync(buffer.AsMemory(count,1)).ConfigureAwait(false);if(read==0||buffer[count]=='\n')break;count++;}
                string path=new string(buffer,0,count).TrimEnd('\r');
                if(Path.IsPathFullyQualified(path)&&IsProjectPath(path)&&File.Exists(path))open(path);
            }
            catch(Exception ex){App.LogError("Project open listener",ex);return;}
        }
    }
}
