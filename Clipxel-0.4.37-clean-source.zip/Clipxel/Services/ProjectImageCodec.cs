using System.IO;
using System.IO.Compression;
using System.Windows.Media.Imaging;
namespace Clipxel.Services;
internal static class ProjectImageCodec
{
    // WIC's PNG encoder requires seeking; ZIP entry streams cannot seek.
    internal static void WritePng(ZipArchive archive, string name, BitmapSource bitmap)
    {
        using var encoded = new MemoryStream();
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        encoder.Save(encoded);
        encoded.Position = 0;
        using var destination = archive.CreateEntry(name, CompressionLevel.NoCompression).Open();
        encoded.CopyTo(destination);
    }
}
