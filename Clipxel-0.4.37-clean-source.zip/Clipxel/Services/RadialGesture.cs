using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
namespace Clipxel.Services;
// Right button gestures use the same eight directions in every annotation window.
internal static class RadialGesture
{
    internal static (Color Surface,Color Text) ThemeFor(Color color)
    {
        int max=Math.Max(color.R,Math.Max(color.G,color.B)),min=Math.Min(color.R,Math.Min(color.G,color.B));
        if(max-min>24)return (Color.FromRgb(49,53,60),Colors.WhiteSmoke);
        if(min>=220)return (Color.FromRgb(105,111,121),Colors.White);
        if(max>65)return (Color.FromRgb(238,240,244),Color.FromRgb(40,45,54));
        return (Color.FromRgb(49,53,60),Colors.WhiteSmoke);
    }
    public static void Attach(FrameworkElement host,string[] labels,Action<int> choose,Action click,Func<bool>? enabled=null,Action? starting=null,Func<int[]>? mapping=null,Func<Color>? background=null,Func<bool>? cancelTool=null)
    {
        Point start=new();bool tracking=false,cancelledTool=false;int selected=-1;int[] bindings=GestureTools.Defaults();
        var centers=RadialLayout.Centers(114,38,10,1);double radius=centers[0].X;
        var panel=new Canvas { Width=radius*2+126,Height=radius*2+50,IsHitTestVisible=false };
        var popup=new Popup { Child=panel,AllowsTransparency=true,StaysOpen=true,PlacementTarget=host,Placement=PlacementMode.Relative,IsHitTestVisible=false };
        var entries=new Border[8];
        for(int i=0;i<8;i++)
        {
            var entry=new Border { Width=114,Height=38,CornerRadius=new CornerRadius(3),Background=(Brush)Application.Current.FindResource("GlassSurface"),BorderThickness=new Thickness(1),BorderBrush=Brushes.SlateGray,Child=new TextBlock { Text=labels[i],Foreground=ThemeService.Foreground,FontSize=12,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center } };
            ((TextBlock)entry.Child).SetResourceReference(TextBlock.ForegroundProperty,"TextPrimary");
            Canvas.SetLeft(entry,panel.Width/2+centers[i].X-57);Canvas.SetTop(entry,panel.Height/2+centers[i].Y-19);panel.Children.Add(entry);entries[i]=entry;MistBackdrop.Attach(entry);
        }
        var delay=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromMilliseconds(240)};
        delay.Tick+=(_,_)=>{delay.Stop();if(tracking&&host.IsVisible)popup.IsOpen=true;};
        void End(){delay.Stop();tracking=false;popup.IsOpen=false;if(host.IsMouseCaptured)host.ReleaseMouseCapture();}
        host.PreviewMouseRightButtonDown+=(_,e)=>
        {
            if(InputBoundary.IsControlInteraction(e.OriginalSource as DependencyObject,host))return;
            if(enabled is not null&&!enabled())return;
            cancelledTool=cancelTool?.Invoke()==true;
            starting?.Invoke();
            bindings=GestureTools.Normalize(mapping?.Invoke(),labels.Length);
            for(int i=0;i<8;i++)((TextBlock)entries[i].Child).Text=labels[bindings[i]];
            foreach(var entry in entries){entry.Background=(Brush)Application.Current.FindResource("GlassSurface");((TextBlock)entry.Child).SetResourceReference(TextBlock.ForegroundProperty,"TextPrimary");}
            start=e.GetPosition(host);selected=-1;tracking=true;popup.HorizontalOffset=start.X-panel.Width/2;popup.VerticalOffset=start.Y-panel.Height/2;
            foreach(var entry in entries)entry.BorderBrush=Brushes.SlateGray;
            host.CaptureMouse();delay.Start();e.Handled=true;
        };
        host.PreviewMouseMove+=(_,e)=>
        {
            if(!tracking)return;Vector delta=e.GetPosition(host)-start;
            if(delta.Length>=25){delay.Stop();popup.IsOpen=true;}
            selected=delta.Length<25?-1:((int)Math.Round(Math.Atan2(delta.Y,delta.X)/(Math.PI/4))+8)%8;
            for(int i=0;i<8;i++)entries[i].BorderBrush=i==selected?Clipxel.Services.ThemeService.ActiveToolInk:Brushes.SlateGray;
        };
        host.PreviewMouseRightButtonUp+=(_,e)=>
        {
            if(!tracking)return;int action=selected<0?-1:bindings[selected];bool suppressClick=cancelledTool;End();e.Handled=true;
            host.Dispatcher.BeginInvoke(new Action(()=>{if(!host.IsVisible)return;if(action<0){if(!suppressClick)click();}else choose(action);}));
        };
        host.LostMouseCapture+=(_,_)=>{if(tracking)End();};host.Unloaded+=(_,_)=>End();
        host.IsVisibleChanged+=(_,_)=>{if(!host.IsVisible)End();};
    }
}
