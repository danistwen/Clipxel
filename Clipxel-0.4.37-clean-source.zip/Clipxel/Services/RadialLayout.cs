using System;
using System.Windows;
namespace Clipxel.Services;
internal static class RadialLayout
{
    // Eight true angular directions. Solve the radius against every pair's hover bounds.
    internal static Point[] Centers(double width,double height,double gap=12,double hover=1.07)
    {
        double radius=Math.Max(width,height);
        while(true)
        {
            var points=new Point[8];for(int i=0;i<8;i++)points[i]=new Point(radius*Math.Cos(i*Math.PI/4),radius*Math.Sin(i*Math.PI/4));
            bool valid=true;for(int i=0;i<8;i++)for(int j=i+1;j<8;j++)if(Math.Abs(points[i].X-points[j].X)<width*hover+gap&&Math.Abs(points[i].Y-points[j].Y)<height*hover+gap)valid=false;
            if(valid)return points;radius+=1;
        }
    }
}
