using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
namespace Clipxel.Services;
internal static class RoundedWindow
{
    [DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr window,int attribute,ref int value,int size);
    [DllImport("gdi32.dll")] private static extern IntPtr CreateRoundRectRgn(int left,int top,int right,int bottom,int width,int height);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr handle);
    [DllImport("user32.dll")] private static extern int SetWindowRgn(IntPtr window,IntPtr region,bool redraw);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window,out NativeRect bounds);
    [StructLayout(LayoutKind.Sequential)] private struct NativeRect {public int Left,Top,Right,Bottom;}
    internal static void Attach(Window window,FrameworkElement content)
    {
        bool nativeCorners=false;
        void Update()
        {
            bool maximized=window.WindowState==WindowState.Maximized;
            // Native region/DWM owns the silhouette; a second, different clip exposes corner slivers.
            content.Clip=null;
            var handle=new WindowInteropHelper(window).Handle;if(handle==IntPtr.Zero)return;
            if(nativeCorners)return;
            if(maximized){SetWindowRgn(handle,IntPtr.Zero,true);return;}
            if(!GetWindowRect(handle,out var bounds))return;
            int diameter=(int)Math.Round(28*VisualTreeHelper.GetDpi(window).DpiScaleX);
            var region=CreateRoundRectRgn(0,0,bounds.Right-bounds.Left+1,bounds.Bottom-bounds.Top+1,diameter,diameter);
            if(region!=IntPtr.Zero&&SetWindowRgn(handle,region,true)==0)DeleteObject(region);
        }
        void Initialize()
        {
            var handle=new WindowInteropHelper(window).Handle;if(handle==IntPtr.Zero)return;
            int preference=2,borderNone=-2;
            nativeCorners=!window.AllowsTransparency&&DwmSetWindowAttribute(handle,33,ref preference,sizeof(int))==0;
            DwmSetWindowAttribute(handle,34,ref borderNone,sizeof(int));Update();
        }
        window.SourceInitialized+=(_,_)=>Initialize();
        // DialogChrome attaches during Loaded, after SourceInitialized already fired.
        Initialize();
        window.SizeChanged+=(_,_)=>Update();window.StateChanged+=(_,_)=>Update();content.SizeChanged+=(_,_)=>Update();
    }
}
