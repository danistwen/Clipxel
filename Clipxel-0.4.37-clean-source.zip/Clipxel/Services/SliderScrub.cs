using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
namespace Clipxel.Services;
internal static class SliderScrub
{
    private static Slider? _active;
    public static void Register()
    {
        EventManager.RegisterClassHandler(typeof(Slider),UIElement.PreviewMouseLeftButtonDownEvent,new MouseButtonEventHandler(Down),true);
        EventManager.RegisterClassHandler(typeof(Slider),UIElement.PreviewMouseMoveEvent,new MouseEventHandler(Move),true);
        EventManager.RegisterClassHandler(typeof(Slider),UIElement.PreviewMouseLeftButtonUpEvent,new MouseButtonEventHandler(Up),true);
        EventManager.RegisterClassHandler(typeof(Slider),UIElement.LostMouseCaptureEvent,new MouseEventHandler((s,e)=>{if(ReferenceEquals(s,_active)&&!_active!.IsMouseCaptured)_active=null;}),true);
    }
    internal static void CancelWithin(FrameworkElement root)
    {
        var slider=_active;if(slider is null)return;
        if(ReferenceEquals(root,slider)||root.IsAncestorOf(slider))Cancel();
    }
    private static void Cancel()
    {
        var slider=_active;_active=null;if(slider?.IsMouseCaptured==true)slider.ReleaseMouseCapture();
    }
    private static void Set(Slider slider,MouseEventArgs e)
    {
        if(!slider.IsVisible||!slider.IsEnabled)return;
        slider.ApplyTemplate();if(slider.Template?.FindName("PART_Track",slider)is not Track track)return;
        double value=track.ValueFromPoint(e.GetPosition(track));if(!double.IsFinite(value))return;
        if(slider.IsSnapToTickEnabled)
        {
            if(slider.Ticks.Count>0){double nearest=slider.Minimum,distance=Math.Abs(value-nearest);foreach(double tick in slider.Ticks)if(Math.Abs(value-tick)<distance){nearest=tick;distance=Math.Abs(value-tick);}if(Math.Abs(value-slider.Maximum)<distance)nearest=slider.Maximum;value=nearest;}
            else if(slider.TickFrequency>0)value=slider.Minimum+Math.Round((value-slider.Minimum)/slider.TickFrequency)*slider.TickFrequency;
        }
        slider.SetCurrentValue(Slider.ValueProperty,Math.Clamp(value,slider.Minimum,slider.Maximum));
    }
    private static void Down(object sender,MouseButtonEventArgs e)
    {
        var slider=(Slider)sender;if(!slider.IsEnabled||e.ChangedButton!=MouseButton.Left)return;
        Cancel();slider.Focus();
        // Focus changes can synchronously remove the old tool panel.
        if(!slider.IsVisible||PresentationSource.FromVisual(slider)is null)return;
        if(!slider.CaptureMouse())return;
        _active=slider;Set(slider,e);e.Handled=true;
    }
    private static void Move(object sender,MouseEventArgs e)
    {
        var slider=_active;if(slider is null||!ReferenceEquals(sender,slider))return;
        if(!slider.IsVisible||!slider.IsMouseCaptured||e.LeftButton!=MouseButtonState.Pressed){Cancel();return;}
        Set(slider,e);e.Handled=true;
    }
    private static void Up(object sender,MouseButtonEventArgs e)
    {
        var slider=_active;if(slider is null||!ReferenceEquals(sender,slider))return;
        Set(slider,e);if(ReferenceEquals(_active,slider))Cancel();e.Handled=true;
    }
}
