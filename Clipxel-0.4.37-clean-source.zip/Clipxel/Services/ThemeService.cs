using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Windows;
namespace Clipxel.Services;

internal static class ThemeService
{
    private static Brush? _defaultSliderFill;
    internal static SolidColorBrush Foreground {get; private set;} = new(Color.FromRgb(243,248,254));
    internal static Brush ActiveToolInk => (Brush)Application.Current.FindResource("ActiveToolInk");
    internal static Brush ActiveToolSurface => (Brush)Application.Current.FindResource("ActiveToolSurface");
    internal static Brush ActiveSurface(string kind) => (Brush)Application.Current.FindResource("ActiveToolSurface"+kind);
    internal static Color Background {get; private set;} = Color.FromRgb(39,41,46);
    internal static Color Surface {get; private set;} = Color.FromRgb(56,62,71);
    internal static int Revision {get; private set;}
    internal static bool IsDark => App.Settings.Theme=="Dark";
    private static Color Hex(string value)=>(Color)ColorConverter.ConvertFromString(value);
    internal static void Apply()
    {
        if(App.Settings.Theme!="Dark" && App.Settings.Theme!="Light" && App.Settings.Theme!="White")App.Settings.Theme="Dark";
        Background=Hex(IsDark?"#27292E":App.Settings.Theme=="Light"?"#7E899B":"#FFFFFF");
        Surface=Hex(IsDark?"#383E47":App.Settings.Theme=="Light"?"#BDD5F5":"#F3F8FE");
        var previous=Foreground;
        Foreground=new SolidColorBrush(Hex(IsDark?"#F3F8FE":"#202637"));Foreground.Freeze();
        var resources=Application.Current.Resources;
        var previousSurfaces=new Dictionary<string,Brush>();
        if(resources["ActiveToolInk"] is Brush previousInk)previousSurfaces["ActiveToolInk"]=previousInk;
        resources["ActiveToolInk"]=new SolidColorBrush(Hex(IsDark?"#5489E8":"#005DFF"));
        _defaultSliderFill??=resources["SliderFill"] as Brush;
        resources["SliderFill"]=IsDark?ActiveToolInk:_defaultSliderFill!;
        resources["HelpBorder"]=App.Settings.Theme=="Light"?Foreground:Brushes.Gray;
        foreach(var entry in new[]{("",Color.FromArgb(50,255,255,255)),("Drawing",Color.FromArgb(34,70,92,255)),("Chrome",Color.FromArgb(90,230,235,245)),("Pie",Color.FromArgb(100,130,139,154))})
        {
            string key="ActiveToolSurface"+entry.Item1;
            if(resources[key] is Brush previousBrush)previousSurfaces[key]=previousBrush;
            resources[key]=new SolidColorBrush(App.Settings.Theme=="White"?Hex("#C8CFDA"):IsDark?Hex("#343B46"):entry.Item2);
        }
        resources["HelpSurface"]=App.Settings.Theme=="Light"?Brushes.Transparent:new SolidColorBrush(Hex(IsDark?"#27292E":"#F3F8FE"));
        resources["TextPrimary"]=Foreground;
        foreach(var key in new[]{"WindowChromeSurface","DialogSurface","MenuSurface","GlassSurface","DarkGlass"})
            resources[key]=new SolidColorBrush(Color.FromArgb(225,Surface.R,Surface.G,Surface.B));
        resources["DialogField"]=new SolidColorBrush(Hex(IsDark?"#27292E":"#F3F8FE"));
        resources["DialogSelected"]=new SolidColorBrush(Hex(IsDark?"#27292E":"#BDD5F5"));
        resources["DialogHover"]=new SolidColorBrush(Hex(IsDark?"#383E47":"#FFFFFF"));
        resources["BrandLogotype"]=Asset(IsDark?"Clipxel-logotype-dark.png":"Clipxel-logotype-color.png");
        resources["BrandMark"]=Asset(IsDark?"Clipxel-tray-white.ico":"Clipxel-tray-black.ico");
        resources["BrandCaption"]=Application.Current.FindResource("Wordmark-"+(IsDark?"dark":App.Settings.Theme=="Light"?"color":"black"));
        Revision++;
        foreach(Window window in Application.Current.Windows.Cast<Window>().ToArray())
        {
            RebindForeground(window,previous,new HashSet<DependencyObject>());
            foreach(var entry in previousSurfaces)RebindForeground(window,entry.Value,new HashSet<DependencyObject>(),entry.Key);
            if(window is ReferenceBoardWindow board)board.ApplyBrandTheme();
        }
        GlassAppearance.Apply(App.Settings.ToolbarOpacity);
    }
    // Replace frozen brushes instead of mutating a brush shared by WPF styles/drawings.
    private static void RebindForeground(DependencyObject node,Brush previous,HashSet<DependencyObject> visited,string resource="TextPrimary")
    {
        if(!visited.Add(node))return;
        if(node is FrameworkElement element)
        {
            var entries=node.GetLocalValueEnumerator();var properties=new List<DependencyProperty>();
            while(entries.MoveNext())
                if(ReferenceEquals(node.GetValue(entries.Current.Property),previous))properties.Add(entries.Current.Property);
            foreach(var property in properties)element.SetResourceReference(property,resource);
        }
        if(node is Visual)
            for(int i=0;i<VisualTreeHelper.GetChildrenCount(node);i++)RebindForeground(VisualTreeHelper.GetChild(node,i),previous,visited,resource);
        foreach(var child in LogicalTreeHelper.GetChildren(node).OfType<DependencyObject>().ToArray())RebindForeground(child,previous,visited,resource);
    }
    private static BitmapImage Asset(string name)
    {
        var image=new BitmapImage(new Uri("pack://application:,,,/Assets/"+name));image.Freeze();return image;
    }
}
