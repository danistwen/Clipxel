using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
namespace Clipxel.Services;
internal static class ToolHints
{
    internal static string Format(string label,string? shortcut)=>string.IsNullOrWhiteSpace(shortcut)?label:label+"（"+shortcut.Replace("D0","0")+"）";
    internal static void Attach(FrameworkElement button,Func<string> label,Func<string?> shortcut)
    {button.ToolTip=Format(label(),shortcut());button.ToolTipOpening+=(_,_)=>button.ToolTip=Format(label(),shortcut());}
    internal static void Board(FrameworkElement button,Clipxel.Windows.BoardAction action)=>Attach(button,()=>Clipxel.Windows.BoardPieWindow.Label(action),()=>action==Clipxel.Windows.BoardAction.Capture?App.Settings.CaptureKey:action==Clipxel.Windows.BoardAction.Return?App.Settings.ToggleModeKey:App.Settings.BoardShortcuts.GetValueOrDefault(action.ToString()));
}
