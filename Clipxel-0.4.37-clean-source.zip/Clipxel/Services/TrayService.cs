using System;
using System.Linq;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows;
using Forms = System.Windows.Forms;
using Clipxel.Windows;
namespace Clipxel.Services;
public sealed class TrayService : IDisposable
{
    private readonly Forms.NotifyIcon _icon;
    private readonly Icon _normal, _paused;
    private readonly Forms.ToolStripMenuItem _capture, _status, _resume, _pins, _last, _cancel, _startup;
    private bool _isPaused;
    public event Action<string>? Command;
    private readonly System.Collections.Generic.Dictionary<string,Bitmap> _menuImages=new();
    private Bitmap MenuImage(string glyph)
    {
        string cacheKey=glyph+"|"+App.Settings.Theme;
        if(_menuImages.TryGetValue(cacheKey,out var cached))return cached;
        if(glyph=="Clipxel")
        {
            using var resource=Application.GetResourceStream(new Uri("pack://application:,,,/Assets/Clipxel-tray.ico"))!.Stream;
            using var icon=new Icon(resource,16,16);var image=icon.ToBitmap();_menuImages[cacheKey]=image;return image;
        }
        var visual=new Clipxel.Rendering.ToolGlyph {Glyph=glyph,Width=16,Height=16,Foreground=Clipxel.Services.ThemeService.ActiveToolInk};
        visual.Measure(new System.Windows.Size(16,16));visual.Arrange(new Rect(0,0,16,16));
        var target=new System.Windows.Media.Imaging.RenderTargetBitmap(16,16,96,96,System.Windows.Media.PixelFormats.Pbgra32);target.Render(visual);
        var encoder=new System.Windows.Media.Imaging.PngBitmapEncoder();encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(target));
        using var stream=new System.IO.MemoryStream();encoder.Save(stream);stream.Position=0;using var bitmap=new Bitmap(stream);var result=new Bitmap(bitmap);_menuImages[cacheKey]=result;return result;
    }
    private Forms.ToolStripMenuItem Item(string label,string command)
    {
        string glyph=command.Split(':')[0] switch {"capture" or "last" or "delay"=>"Capture","paste"=>"Paste","pins"=>"ToggleChrome","board"=>"SwitchMode","folder"=>"OpenProject","exit"=>"CloseBoard","cancel"=>"Delete","startup"=>"Startup","about"=>"About","pause"=>"Pause","resume"=>"Resume",_=>"Settings"};
        return new Forms.ToolStripMenuItem(label,MenuImage(glyph),(_,_)=>Command?.Invoke(command));
    }
    public TrayService()
    {
        _normal = (Icon)SystemIcons.Application.Clone();
        try { using var stream = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/Clipxel-tray.ico"))!.Stream; using var supplied = new Icon(stream); _normal.Dispose(); _normal = (Icon)supplied.Clone(); } catch (Exception ex) { App.LogError("Load tray icon", ex); }
        using (var bitmap = _normal.ToBitmap())
        {
            using (var graphics = Graphics.FromImage(bitmap))
            {
                int size = bitmap.Width; graphics.FillEllipse(Brushes.DarkOrange, size / 2, size / 2, size / 2, size / 2);
                graphics.FillRectangle(Brushes.White, size * .64f, size * .63f, size * .07f, size * .24f);
                graphics.FillRectangle(Brushes.White, size * .78f, size * .63f, size * .07f, size * .24f);
            }
            IntPtr handle = bitmap.GetHicon(); try { using var icon = Icon.FromHandle(handle); _paused = (Icon)icon.Clone(); } finally { DestroyIcon(handle); }
        }
        _icon = new Forms.NotifyIcon { Text = "Clipxel 0.4.37", Icon = _normal, Visible = true };
        var menu = new Forms.ContextMenuStrip(); _icon.ContextMenuStrip = menu;
        void RefreshImages(Forms.ToolStripItemCollection items)
        {
            foreach(Forms.ToolStripItem item in items)
            {
                var key=_menuImages.FirstOrDefault(pair=>ReferenceEquals(pair.Value,item.Image)).Key;
                if(key is not null)item.Image=MenuImage(key.Split('|')[0]);
                if(item is Forms.ToolStripMenuItem submenu)RefreshImages(submenu.DropDownItems);
            }
        }
        menu.Opening+=(_,_)=>RefreshImages(menu.Items);
        _status = new Forms.ToolStripMenuItem("快捷鍵啟用中") { Enabled = false }; menu.Items.Add(_status);
        _capture = Item("截圖", "capture"); menu.Items.Add(_capture);
        var delay = new Forms.ToolStripMenuItem("延遲截圖",MenuImage("Capture")); foreach (int n in new[] { 3, 5, 10 }) delay.DropDownItems.Add(Item(n + " 秒後", "delay:" + n)); menu.Items.Add(delay);
        _cancel = Item("取消倒數截圖", "cancel"); menu.Items.Add(_cancel);
        _last = Item("再次擷取上次區域", "last"); menu.Items.Add(_last);
        menu.Items.Add(Item("剪貼簿圖片轉釘圖", "paste"));
        _pins = Item("隱藏全部釘圖", "pins"); menu.Items.Add(_pins);
        menu.Items.Add(new Forms.ToolStripSeparator());
        var pause = new Forms.ToolStripMenuItem("暫停快捷鍵",MenuImage("Pause"));
        pause.DropDownItems.Add(Item("15 分鐘", "pause:15")); pause.DropDownItems.Add(Item("1 小時", "pause:60")); pause.DropDownItems.Add(Item("直到手動恢復", "pause:0")); menu.Items.Add(pause);
        _resume = Item("恢復快捷鍵", "resume"); menu.Items.Add(_resume);
        menu.Items.Add(Item("切換釘圖／參考畫布模式", "board"));
        menu.Items.Add(Item("自訂快捷鍵…", "shortcuts")); menu.Items.Add(Item("偏好設定…", "settings")); _startup = Item("開機自動啟動", "startup"); menu.Items.Add(_startup);
        menu.Items.Add(Item("開啟儲存資料夾", "folder"));
        menu.Items.Add(new Forms.ToolStripSeparator()); menu.Items.Add(Item("關於 Clipxel 0.4.37", "about")); menu.Items.Add(Item("結束 Clipxel", "exit"));
        _icon.DoubleClick += (_, _) => Command?.Invoke("capture");
        menu.Opening += (_, _) => { try { _startup.Checked = StartupService.Enabled; } catch { _startup.Checked = false; } };
    }
    public void Update(string reason, bool manualPause, bool hidden, int pins, bool last, bool countdown, string shortcut)
    {
        bool paused = reason.Length > 0;
        if (_isPaused != paused) { _isPaused = paused; _icon.Icon = paused ? _paused : _normal; }
        string status = paused ? "快捷鍵暫停：" + reason : "快捷鍵啟用中";
        _status.Text = status; _icon.Text = "Clipxel 0.4.37 — " + status;
        _resume.Enabled = manualPause; _pins.Enabled = pins > 0; _pins.Text = (hidden ? "顯示" : "隱藏") + "全部釘圖（" + pins + "）";
        _last.Enabled = last; _cancel.Visible = countdown; _capture.Text = "截圖" + (string.IsNullOrWhiteSpace(shortcut) ? "" : "    " + shortcut);
    }
    public void ShowNotice(string text) => Application.Current.Dispatcher.InvokeAsync(() => ToastWindow.ShowToast("Clipxel", text));
    public void Dispose() { _icon.Visible = false; _icon.ContextMenuStrip?.Dispose(); _icon.Dispose(); _normal.Dispose(); _paused.Dispose(); foreach(var image in _menuImages.Values)image.Dispose();_menuImages.Clear(); }
    [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr handle);
}
