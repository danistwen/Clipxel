using System;
using System.Windows;
using System.Windows.Media.Imaging;
namespace Clipxel.Services;
public static class WindowIconHelper
{
    public static void ApplyAdaptiveTitleBarIcon(Window window)
    {
        // Native taskbar/Alt-Tab use the full multi-size app ICO. Custom dark captions use the white glyph.
        if(window is not null)window.Icon=BitmapFrame.Create(new Uri("pack://application:,,,/Assets/Clipxel.ico",UriKind.Absolute));
    }
}
