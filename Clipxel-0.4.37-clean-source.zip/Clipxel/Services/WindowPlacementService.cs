using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace Clipxel.Services;

public static class WindowPlacementService
{
    public static PixelRect DesktopBounds => new(GetSystemMetrics(76), GetSystemMetrics(77),
        GetSystemMetrics(78), GetSystemMetrics(79));

    public static (int X, int Y) CursorPosition
    {
        get { GetCursorPos(out var point); return (point.X, point.Y); }
    }

    public static PixelRect WorkArea(Window window)
    {
        var handle = new WindowInteropHelper(window).Handle;
        var monitor = MonitorFromWindow(handle, 2);
        return ReadWorkArea(monitor);
    }

    public static PixelRect WorkAreaAtCursor()
    {
        GetCursorPos(out var point);
        return ReadWorkArea(MonitorFromPoint(point, 2));
    }

    public static PixelRect MonitorBoundsAtPoint(int x, int y)
    {
        var info = new MONITORINFO { Size = Marshal.SizeOf<MONITORINFO>() };
        var monitor = MonitorFromPoint(new POINT { X = x, Y = y }, 2);
        return GetMonitorInfo(monitor, ref info) ? ToPixelRect(info.Monitor) : DesktopBounds;
    }

    private static PixelRect ReadWorkArea(IntPtr monitor)
    {
        var info = new MONITORINFO { Size = Marshal.SizeOf<MONITORINFO>() };
        return GetMonitorInfo(monitor, ref info) ? ToPixelRect(info.Work) : DesktopBounds;
    }

    public static PixelRect Bounds(Window window)
    {
        GetWindowRect(new WindowInteropHelper(window).Handle, out var rect);
        return ToPixelRect(rect);
    }

    public static void SetBounds(Window window, PixelRect bounds)
    {
        var handle = new WindowInteropHelper(window).Handle;
        if (handle != IntPtr.Zero)
            SetWindowPos(handle, IntPtr.Zero, bounds.X, bounds.Y, Math.Max(1, bounds.Width),
                Math.Max(1, bounds.Height), 0x0004 | 0x0010); // preserve z-order, do not activate
    }

    public static void Move(Window window, int x, int y) =>
        SetWindowPos(new WindowInteropHelper(window).Handle, IntPtr.Zero, x, y, 0, 0, 0x0001 | 0x0004 | 0x0010);

    private static PixelRect ToPixelRect(RECT r) => new(r.Left, r.Top, r.Right - r.Left, r.Bottom - r.Top);
    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] private struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct MONITORINFO { public int Size; public RECT Monitor, Work; public uint Flags; }
    [DllImport("user32.dll")] private static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromPoint(POINT point, uint flags);
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr window, uint flags);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool GetMonitorInfo(IntPtr monitor, ref MONITORINFO info);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out RECT rect);
    [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr insertAfter, int x, int y, int width, int height, uint flags);
}
