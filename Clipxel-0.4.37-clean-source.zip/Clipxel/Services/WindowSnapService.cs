using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace Clipxel.Services;

public readonly record struct PixelRect(int X, int Y, int Width, int Height)
{
    public int Right => X + Width;
    public int Bottom => Y + Height;
    public long Area => (long)Width * Height;
    public bool Contains(int x, int y) => x >= X && x < Right && y >= Y && y < Bottom;
}
public readonly record struct SnapCandidate(PixelRect Rect, int Score, string Kind);

public sealed class WindowSnapService
{
    private readonly PixelRect _desktop;
    private readonly List<(IntPtr Handle, PixelRect Bounds)> _windows = new();
    private readonly Dictionary<IntPtr, List<SnapCandidate>> _cache = new();
    private static readonly HashSet<string> IgnoredClasses = new(StringComparer.OrdinalIgnoreCase)
    {
        "Button", "Static", "ScrollBar", "ToolbarWindow32", "ReBarWindow32", "msctls_statusbar32",
        "tooltips_class32", "ComboBox", "ComboBoxEx32", "SysHeader32", "SysTreeView32"
    };

    public WindowSnapService(PixelRect desktop)
    {
        _desktop = desktop;
        // Snapshot z-order once, before the overlay is shown. A screenshot is immutable.
        EnumWindows((window, _) =>
        {
            if (!IsWindowVisible(window) || IsIconic(window)) return true;
            GetWindowThreadProcessId(window, out uint process);
            if (process == Environment.ProcessId) return true;
            if (DwmGetWindowAttributeInt(window, 14, out int cloaked, sizeof(int)) == 0 && cloaked != 0) return true;
            if (TryBounds(window, out var rect))
            {
                var clipped = Intersect(rect, desktop);
                if (clipped.Width > 0 && clipped.Height > 0) _windows.Add((window, clipped));
            }
            return true;
        }, IntPtr.Zero);
    }

    public List<SnapCandidate> GetCandidatesAtPoint(int screenX, int screenY)
    {
        int x = screenX - _desktop.X, y = screenY - _desktop.Y;
        var monitor = Relative(Intersect(WindowPlacementService.MonitorBoundsAtPoint(screenX, screenY), _desktop));
        var fallback = new SnapCandidate(monitor, -100, "screen");
        foreach (var window in _windows)
        {
            if (!window.Bounds.Contains(screenX, screenY)) continue;
            if (!_cache.TryGetValue(window.Handle, out var candidates))
            {
                candidates = ReadRegions(window.Handle, window.Bounds);
                _cache.Add(window.Handle, candidates);
            }
            return candidates.Where(c => c.Rect.Contains(x, y)).Append(fallback)
                .GroupBy(c => c.Rect).Select(g => g.OrderByDescending(c => c.Score).First())
                .OrderByDescending(c => c.Score).ThenBy(c => c.Rect.Area).Take(16).ToList();
        }
        return new List<SnapCandidate> { fallback };
    }

    private List<SnapCandidate> ReadRegions(IntPtr window, PixelRect bounds)
    {
        var candidates = new List<SnapCandidate> { new(Relative(bounds), 50, "window") };
        // Cache a window's child regions on first use. No provider/UI Automation calls on mouse move.
        EnumChildWindows(window, (child, _) =>
        {
            if (!IsWindowVisible(child) || !GetWindowRect(child, out var rect)) return true;
            var clipped = Intersect(ToPixels(rect), bounds);
            if (clipped.Width < 50 || clipped.Height < 35) return true;
            string name = ClassName(child);
            if (IgnoredClasses.Contains(name)) return true;
            double ratio = clipped.Area / (double)Math.Max(1L, bounds.Area);
            int score = 120;
            string kind = "region";
            if (Has(name, "SysListView32")) { score += 900; kind = "list"; }
            else if (Has(name, "SHELLDLL_DefView")) { score += 820; kind = "explorer-content"; }
            else if (Has(name, "UIItemsView")) { score += 760; kind = "explorer-content"; }
            else if (Has(name, "DirectUIHWND")) { score += 700; kind = "explorer-content"; }
            else if (Has(name, "Chrome_RenderWidgetHostHWND")) { score += 560; kind = "content"; }
            else if (Has(name, "MozillaWindowClass")) { score += 470; kind = "content"; }
            else if (Has(name, "RICHEDIT") || Has(name, "Edit")) { score += 300; kind = "editor"; }
            if (ratio >= .08 && ratio <= .90) score += 110;
            else if (ratio < .02) score -= 120;
            else if (ratio > .96) score -= 90;
            if (ratio >= .04 && ratio <= .65) score += 55;
            candidates.Add(new SnapCandidate(Relative(clipped), score, kind));
            return true;
        }, IntPtr.Zero);
        return candidates;
    }

    public static PixelRect Intersect(PixelRect a, PixelRect b)
    {
        int x = Math.Max(a.X, b.X), y = Math.Max(a.Y, b.Y);
        return new PixelRect(x, y, Math.Max(0, Math.Min(a.Right, b.Right) - x),
            Math.Max(0, Math.Min(a.Bottom, b.Bottom) - y));
    }
    private PixelRect Relative(PixelRect r) => new(r.X - _desktop.X, r.Y - _desktop.Y, r.Width, r.Height);
    private static bool Has(string name, string text) => name.Contains(text, StringComparison.OrdinalIgnoreCase);
    private static PixelRect ToPixels(RECT r) => new(r.Left, r.Top, r.Right - r.Left, r.Bottom - r.Top);
    private static bool TryBounds(IntPtr window, out PixelRect bounds)
    {
        bool found = DwmGetWindowAttributeRect(window, 9, out var rect, Marshal.SizeOf<RECT>()) == 0 ||
            GetWindowRect(window, out rect);
        bounds = ToPixels(rect);
        return found && bounds.Width > 0 && bounds.Height > 0;
    }
    private static string ClassName(IntPtr window)
    {
        var buffer = new char[256];
        int length = GetClassName(window, buffer, buffer.Length);
        return length > 0 ? new string(buffer, 0, length) : string.Empty;
    }
    [StructLayout(LayoutKind.Sequential)] private struct RECT { public int Left, Top, Right, Bottom; }
    private delegate bool EnumWindowProc(IntPtr window, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowProc callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr parent, EnumWindowProc callback, IntPtr parameter);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr window, out RECT rect);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr window, [Out] char[] name, int count);
    [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")] private static extern int DwmGetWindowAttributeRect(IntPtr window, int attribute, out RECT rect, int size);
    [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")] private static extern int DwmGetWindowAttributeInt(IntPtr window, int attribute, out int value, int size);
}
