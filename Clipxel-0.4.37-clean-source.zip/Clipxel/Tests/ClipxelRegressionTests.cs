using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clipxel.Services;
namespace Clipxel.Tests;
internal static class ClipxelRegressionTests
{
    internal static void VerifyBlur()
    {
        const int width=64,height=16;
        var pixels=new byte[width*height*4];
        for(int y=0;y<height;y++)for(int x=0;x<width;x++)
        {int i=(y*width+x)*4;pixels[i+(x<32?2:0)]=255;pixels[i+3]=255;}
        MistBackdrop.Blur(pixels,width,height,3);
        int middle=(8*width+31)*4;
        Require(pixels[2]>240&&pixels[(width-1)*4]>240,"Local red/blue colors were reduced to an average");
        Require(pixels[middle]>0&&pixels[middle+2]>0,"The color boundary was not diffused");
        for(int i=3;i<pixels.Length;i+=4)Require(pixels[i]==255,"Blur changed solid alpha");
    }
    internal static void VerifyCentering()
    {
        var work=new PixelRect(-1920,0,1920,1040);var owner=new PixelRect(-1700,80,1200,800);
        Require(DialogOwner.Centered(owner,work,400,300)==new Point(-1300,330),"Dialog not centered on negative-coordinate monitor");
        Require(DialogOwner.Centered(owner,work,2400,1200)==new Point(-1920,0),"Oversized dialog not clamped to work area");
    }
    internal static void VerifyDisabledHistory()
    {
        foreach(string key in new[]{"ToolbarButton","PieButton"})
        {
            var button=new Button {Style=(Style)Application.Current.FindResource(key),Content="Undo"};
            button.ApplyTemplate();button.Measure(new Size(140,40));button.Arrange(new Rect(0,0,140,40));
            Require(button.Opacity>.9,key+" enabled button dimmed");
            button.IsEnabled=false;button.UpdateLayout();Require(button.Opacity<.5,key+" disabled button remains bright");
            button.IsEnabled=true;Require(button.Opacity>.9,key+" enabled button did not recover");
        }
    }
    internal static void VerifyProjectSuffixes()
    {
        Require(ProjectAssociation.IsProjectPath("board.CLIPXEL"),"New project extension rejected");
        Require(ProjectAssociation.IsProjectPath("board.PinShot"),"Legacy project extension rejected");
        Require(!ProjectAssociation.IsProjectPath("photo.png"),"Image classified as project");
    }
    private static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
