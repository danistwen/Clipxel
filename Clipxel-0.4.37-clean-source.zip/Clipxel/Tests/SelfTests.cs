using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Models;
using Clipxel.Rendering;
using Clipxel.Services;
using Clipxel.Windows;

namespace Clipxel.Tests;

// Run on a Windows STA thread: Clipxel.exe --self-test <report-path>.
// These are real WPF/WIC checks. They do not claim to measure interactive frame rate.
public static class SelfTests
{
    public static int Run(string reportPath)
    {
        var log = new StringBuilder("Clipxel 0.4.37 shared glyphs / board chrome / pie menu Windows regression tests\n");
        int failures = 0;
        void Test(string name, Action test)
        {
            try { test(); log.AppendLine("PASS " + name); }
            catch (Exception error) { failures++; log.AppendLine("FAIL " + name + "\n" + error); }
        }
        Test("Repeated theme switching with frozen shared brush",ThemeTests.VerifyFrozenBrushSwitching);
        Test("Selected styles preserve source geometry and immutable history",()=>
        {
            var source=new Annotation{Tool=AnnotationTool.Pen,Start=new Point(2,3),End=new Point(9,11),Color=Colors.Red,StrokeWidth=3};source.Points.Add(new Point(4,5));
            var changed=AnnotationStyle.With(source,width:12,color:Colors.Blue);
            Require(source.StrokeWidth==3&&source.Color==Colors.Red,"Original style changed");
            Require(changed.Start==source.Start&&changed.End==source.End&&changed.Points.SequenceEqual(source.Points),"Geometry changed");
            Require(!ReferenceEquals(changed.Points,source.Points),"Point list shared with history");
            Require(AnnotationStyle.Visible(Colors.Transparent).A>=13,"Alpha below five percent");
        });
        Test("Local frosted blur diffuses boundaries and preserves regional colors",ClipxelRegressionTests.VerifyBlur);
        Test("Dialog centering handles negative monitors and large dialogs",ClipxelRegressionTests.VerifyCentering);
        Test("Disabled toolbar and pie history buttons visibly dim",ClipxelRegressionTests.VerifyDisabledHistory);
        Test("New and legacy project extensions are accepted",ClipxelRegressionTests.VerifyProjectSuffixes);
        Test("Line clicks do not commit history; drags use screen distance",ReferenceBoardWindow.VerifyLineGestures);
        Test("Canvas lens reuses document pixels and invalidates on edits",ReferenceBoardWindow.VerifyRasterCache);
        Test("Immutable text edits preserve source and annotation geometry", () =>
        {
            var original=new Annotation {Tool=AnnotationTool.Text,Text="原文",Color=Colors.White,FontFamily="Arial",FontSize=22,Start=new Point(10,20),End=new Point(30,40),StrokeWidth=6,LineStyle=LineStyle.Dashed,FillOpacity=.3};
            original.Points.Add(new Point(1,2));
            var changed=AnnotationTransforms.WithTextStyle(original,text:"新文",color:Colors.Red,fontSize:36,fontFamily:"Segoe UI");
            Require(original.Text=="原文"&&original.Color==Colors.White&&original.FontSize==22&&original.FontFamily=="Arial","Original annotation was mutated");
            Require(changed.Text=="新文"&&changed.Color==Colors.Red&&changed.FontSize==36&&changed.FontFamily=="Segoe UI","Text/style replacement failed");
            Require(changed.Start==original.Start&&changed.End==original.End&&changed.StrokeWidth==6&&changed.LineStyle==LineStyle.Dashed&&changed.FillOpacity==.3,"Geometry/settings lost");
            changed.Points.Clear();Require(original.Points.Count==1,"Points list was shared");
            Require(AnnotationTransforms.WithTextStyle(original,text:"").Text=="","Empty text must be retained");
        });
        Test("Repeated tool switching discards detached slider callbacks",ReferenceBoardWindow.VerifyToolSwitching);
        Test("Legacy node links import as independent line annotations",ReferenceBoardWindow.VerifyLegacyLinkMigration);
        Test("Resizing a member expands all group edges without shrinking",()=>
        {
            var group=new Rect(0,0,300,240);
            var expanded=ReferenceBoardWindow.ExpandedGroupBounds(group,new Rect(-30,-20,500,360),40);
            Require(expanded.Contains(group)&&expanded.Contains(new Rect(-30,-20,500,360)),"Expanded group lost old bounds or member.");
            Require(expanded.Left==-42&&expanded.Top==-60&&expanded.Right==482&&expanded.Bottom==352,"Padding or title space is incorrect.");
            Require(ReferenceBoardWindow.ExpandedGroupBounds(expanded,new Rect(10,20,40,30),40)==expanded,"Shrinking member unexpectedly shrank group.");
        });
        Test("Switch focus decoration does not change row height",()=>
        {
            var toggle=new System.Windows.Controls.CheckBox{Content="Test",Style=(Style)Application.Current.FindResource("SwitchToggle")};
            toggle.ApplyTemplate();toggle.Measure(new Size(260,double.PositiveInfinity));double height=toggle.DesiredSize.Height;
            var ring=(System.Windows.Controls.Border)toggle.Template.FindName("FocusRing",toggle);
            ring.Visibility=Visibility.Visible;toggle.Measure(new Size(260,double.PositiveInfinity));
            Require(Math.Abs(height-toggle.DesiredSize.Height)<.01,"Switch focus resized the menu row.");
        });
        Test("Node direction migration preserves later tools and runs once",()=>
        {
            var prefs=new Preferences{SaveFolder=Path.GetTempPath(),BoardDirections=new[]{20,21,22,23,24,0,6,19}};
            prefs.BoardShortcuts["Connect"]="L";prefs.Validate();
            Require(prefs.BoardDirections.SequenceEqual(new[]{6,20,21,22,23,0,6,19}),"Gesture catalog shifted to the wrong tools.");
            Require(!prefs.BoardShortcuts.ContainsKey("Connect"),"Obsolete shortcut remains.");
            var once=(int[])prefs.BoardDirections.Clone();prefs.Validate();
            Require(prefs.BoardDirections.SequenceEqual(once),"Direction migration ran twice.");
        });
        Test("Octagonal layout preserves 45-degree directions and hover separation",()=>
        {
            foreach(var size in new[]{(138d,38d),(114d,38d)})
            {
                var points=RadialLayout.Centers(size.Item1,size.Item2);double radius=points[0].X;
                for(int i=0;i<8;i++)
                {
                    Require(Math.Abs(((Vector)points[i]).Length-radius)<.001,"Menu is not circular");
                    double angle=Math.Atan2(points[i].Y,points[i].X);double expected=i*Math.PI/4;if(expected>Math.PI)expected-=Math.PI*2;
                    Require(Math.Abs(angle-expected)<.001,"Menu direction is not octagonal");
                    for(int j=i+1;j<8;j++)Require(Math.Abs(points[i].X-points[j].X)>=size.Item1*1.07+12||Math.Abs(points[i].Y-points[j].Y)>=size.Item2*1.07+12,"Hover plates overlap");
                }
            }
        });
        Test("Tool hints include only name and configured binding",()=>{Require(ToolHints.Format("畫筆","B")=="畫筆（B）","Unexpected hint");Require(ToolHints.Format("顏色",null)=="顏色","Unset shortcut should be omitted");});
        Test("Canvas marquee moves every annotation kind and supports undo redo",ReferenceBoardWindow.VerifyMarqueeInk);
        Test("Document sampling preserves shape colors under pan/zoom and excludes UI",ReferenceBoardWindow.VerifyDocumentSampling);
        Test("Palette spectrum anchors and exact HEX/alpha round trips",()=>
        {
            Require(Clipxel.Controls.ColorSpectrum.At(0,.3)==Colors.White,"Spectrum left edge must be white");
            Require(Clipxel.Controls.ColorSpectrum.At(1,.6)==Colors.Black,"Spectrum right edge must be black");
            Require(Clipxel.Controls.ColorSpectrum.At(.5,0)==Colors.Red,"Spectrum top-center must be red");
            Require(Clipxel.Controls.ColorSpectrum.At(.5,1d/3)==Colors.Lime,"Spectrum green mismatch");
            Require(Clipxel.Controls.ColorSpectrum.At(.5,2d/3)==Colors.Blue,"Spectrum blue mismatch");
            var picker=new Clipxel.Controls.ColorPicker(Colors.White);int changes=0;picker.ColorChanged+=_=>changes++;
            foreach(var color in new[]{Color.FromArgb(73,120,50,200),Color.FromRgb(128,128,128),Colors.Transparent,Colors.Black})
            {picker.SetColor(color);Require(picker.Selected==color,"Programmatic color was quantized or lost alpha");}
            Require(changes==0,"Syncing the color fired feedback callbacks");
        });
        Test("Closing boards releases their embedded toolbar windows",()=>
        {
            int windows=Application.Current.Windows.Count;
            for(int i=0;i<12;i++){var board=new ReferenceBoardWindow{AllowClose=true};board.Close();}
            Require(Application.Current.Windows.Count==windows,"Hidden toolbar windows accumulated after closing boards");
        });
        Test("Export formats round-trip dimensions and JPEG flattens transparency",()=>
        {
            string folder=Path.Combine(Path.GetTempPath(),"Clipxel-formats-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
            try
            {
                var bitmap=BitmapSource.Create(8,8,96,96,PixelFormats.Bgra32,null,new byte[8*8*4],8*4);bitmap.Freeze();
                foreach(string extension in new[]{"png","jpg","bmp","tiff"})
                {
                    string path=Path.Combine(folder,"export."+extension);ImageExportService.SaveImageAsync(bitmap,path).GetAwaiter().GetResult();
                    using var stream=File.OpenRead(path);var frame=BitmapDecoder.Create(stream,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad).Frames[0];
                    Require(frame.PixelWidth==8&&frame.PixelHeight==8,"Export dimensions changed: "+extension);
                    if(extension is "jpg" or "bmp"){var pixel=Pixel(frame,4,4);Require(pixel.R>245&&pixel.G>245&&pixel.B>245,"Transparency was not flattened to white");}
                }
            }
            finally{Directory.Delete(folder,true);}
        });
        Test("Canvas pie plates have separated bounds including hover",()=>
        {
            var menu=new BoardPieWindow(false);try
            {
                var root=(System.Windows.Controls.Grid)menu.Content;
                var plates=root.Children.OfType<System.Windows.Controls.Border>().Where(b=>b.RenderTransform is TranslateTransform).ToArray();Require(plates.Length==8,"Eight pie directions expected");
                var rectangles=plates.Select(b=>{var t=(TranslateTransform)b.RenderTransform;return new Rect(t.X-b.Width*1.07/2,t.Y-b.Height*1.07/2,b.Width*1.07,b.Height*1.07);}).ToArray();
                for(int i=0;i<rectangles.Length;i++)for(int j=i+1;j<rectangles.Length;j++)Require(!rectangles[i].IntersectsWith(rectangles[j]),"Pie buttons overlap");
            }finally{menu.Close();}
        });
        Test("Canvas inline text supports commit cancel undo redo", ReferenceBoardWindow.VerifyInlineText);
        Test("Color picker input stays inside picker boundary", () =>
        {
            var host=new System.Windows.Controls.Grid();var picker=new Clipxel.Controls.ColorPicker(Colors.White);host.Children.Add(picker);
            Require(InputBoundary.IsControlInteraction(picker,host),"Picker must not arm toolbar dragging");
            var button=new System.Windows.Controls.Button();host.Children.Add(button);
            Require(!InputBoundary.IsControlInteraction(button,host),"Ordinary toolbar button should retain dragging");
        });
        Test("Color wheel retains hue, black and alpha", () =>
        {
            Require(Clipxel.Controls.ColorWheel.FromHsv(0,1,1,128)==Color.FromArgb(128,255,0,0),"Red/alpha mismatch");
            Require(Clipxel.Controls.ColorWheel.FromHsv(120,1,1,255)==Colors.Lime,"Green hue mismatch");
            Require(Clipxel.Controls.ColorWheel.FromHsv(240,1,0,0)==Color.FromArgb(0,0,0,0),"Black/transparent mismatch");
            var picker=new Clipxel.Controls.ColorPicker(Color.FromArgb(73,120,50,200));
            Require(picker.Selected==Color.FromArgb(73,120,50,200),"Color picker loses initial alpha");
        });
        Test("Directional gesture theme follows canvas color", () =>
        {
            Require(RadialGesture.ThemeFor(Colors.White).Surface.R==105,"White canvas should use grey boxes");
            Require(RadialGesture.ThemeFor(Colors.Gray).Surface.R==238,"Grey canvas should use white boxes");
            Require(RadialGesture.ThemeFor(Colors.Black).Surface.R==49,"Black canvas should use dark boxes");
            Require(RadialGesture.ThemeFor(Colors.Gold).Surface.R==49,"Colored canvas should use dark boxes");
        });
        Test("Group spacing is used by layout", ReferenceBoardWindow.VerifyGroupSpacing);
        Test("Custom directions survive preferences JSON and copy independently", () =>
        {
            var original=new Preferences();original.AnnotationDirections[0]=9;original.BoardDirections[6]=10;
            var copy=original.Copy();copy.AnnotationDirections[0]=8;
            Require(original.AnnotationDirections[0]==9,"Editing pending settings mutated active settings");
            var roundtrip=System.Text.Json.JsonSerializer.Deserialize<Preferences>(System.Text.Json.JsonSerializer.Serialize(original))!;
            roundtrip.Validate();Require(roundtrip.AnnotationDirections[0]==9&&roundtrip.BoardDirections[6]==10,"Custom directions lost");
            var repaired=GestureTools.Normalize(new[]{999,-1,2},GestureTools.AnnotationLabels.Length);
            Require(repaired.Length==8&&repaired[0]==0&&repaired[1]==1&&repaired[7]==7,"Invalid direction fallback failed");
        });
        Test("Preferences defaults preserve original annotation behavior", () =>
        {
            var preferences = new Preferences(); preferences.Validate();
            Require(preferences.AnnotationColor == Colors.White, "Initial color must be white");
            Require(preferences.FontSize == 22 && preferences.StrokeWidth == 3, "Unexpected defaults");
            Require(!preferences.ClosePinAfterCopy && preferences.CloseSelectionAfterCopy, "Copy behavior changed by default");
            Require(!preferences.AutoSave && !preferences.AutoPause, "Optional features must default off");
        });
        Test("Shortcut parsing normalizes modifiers and rejects plain typing keys", () =>
        {
            Require(HotkeyHost.Parse("Ctrl+Shift+A") == HotkeyHost.Parse("shift+ctrl+a"), "Equivalent combinations differ");
            Require(HotkeyHost.Parse("F1").Key == 0x70, "Wrong virtual key");
            bool rejected = false; try { HotkeyHost.Parse("A"); } catch (ArgumentException) { rejected = true; }
            Require(rejected, "Plain A must not intercept normal typing");
        });
        Test("Preferences reject duplicate bindings and path traversal in filenames", () =>
        {
            var preferences = new Preferences { AlternateKey = "F1" };
            bool duplicate = false; try { preferences.Validate(); } catch (ArgumentException) { duplicate = true; }
            Require(duplicate, "Duplicate shortcut accepted");
            foreach (string name in new[] { "../capture", "CON", "{unknown}", "bad:name" })
            {
                preferences = new Preferences { NamePattern = name };
                bool rejected = false; try { preferences.Validate(); } catch (ArgumentException) { rejected = true; }
                Require(rejected, "Invalid filename accepted: " + name);
            }
        });
        Test("Preferences JSON round trip preserves custom values", () =>
        {
            var original = new Preferences { FontSize = 36, PasteKey = "Ctrl+Alt+V", AutoPause = true, PausePrograms = "blender.exe" };
            var json = System.Text.Json.JsonSerializer.Serialize(original, new System.Text.Json.JsonSerializerOptions { IgnoreReadOnlyProperties = true });
            var restored = System.Text.Json.JsonSerializer.Deserialize<Preferences>(json)!; restored.Validate();
            Require(restored.FontSize == 36 && restored.PasteKey == original.PasteKey && restored.AutoPause && restored.PausePrograms == original.PausePrograms, "Settings lost during serialization");
        });
        Test("Local shortcuts preserve editing isolation and reject conflicts", () =>
        {
            var preferences = new Preferences(); preferences.Validate();
            var copy = preferences.Copy(); copy.BoardShortcuts["Delete"] = "Ctrl+D";
            Require(preferences.BoardShortcuts["Delete"] == "Delete", "Editing settings mutated active bindings");
            Require(LocalShortcuts.Match(copy.BoardShortcuts, System.Windows.Input.Key.D, System.Windows.Input.ModifierKeys.Control) == "Delete", "Custom binding not resolved");
            Require(LocalShortcuts.Match(copy.BoardShortcuts, System.Windows.Input.Key.Delete, System.Windows.Input.ModifierKeys.None) is null, "Old binding remains active");
            copy.BoardShortcuts["Delete"] = "V";
            bool rejected = false; try { copy.Validate(); } catch(ArgumentException) { rejected = true; }
            Require(rejected, "Duplicate local key accepted");
            var migrated = System.Text.Json.JsonSerializer.Deserialize<Preferences>("{\"Color\":\"#FFFFFF\"}")!;
            migrated.Validate(); Require(migrated.BoardShortcuts["ToggleChrome"] == "Tab", "Old settings lost new defaults");
            var json = System.Text.Json.JsonSerializer.Serialize(preferences, new System.Text.Json.JsonSerializerOptions { IgnoreReadOnlyProperties = true });
            var restored = System.Text.Json.JsonSerializer.Deserialize<Preferences>(json)!; restored.Validate();
            Require(restored.AnnotationShortcuts["畫筆"] == "B", "Annotation bindings lost during round trip");
        });
        Test("Line styles survive transforms and render distinct endpoints and dashes", () =>
        {
            var transparent = MakeImage(64,48,Colors.Transparent);
            BitmapSource Render(LineStyle style) => ImageExportService.Compose(transparent, new[] { AnnotationRenderer.Build(new Annotation { Tool=AnnotationTool.Arrow, LineStyle=style, Start=new Point(8,24), End=new Point(56,24), Color=Colors.Red, StrokeWidth=2 }) });
            var plain=Render(LineStyle.Plain); var dashed=Render(LineStyle.Dashed); var round=Render(LineStyle.RoundEndpoints);
            Require(Enumerable.Range(12,38).All(x => Pixel(plain,x,24).A > 0), "Plain line has gaps");
            Require(Enumerable.Range(12,38).Any(x => Pixel(dashed,x,24).A == 0), "Dashed line has no gaps");
            Require(Pixel(round,8,21).A > Pixel(plain,8,21).A, "Round endpoint missing");
            var source=new Annotation { Tool=AnnotationTool.Arrow, LineStyle=LineStyle.Dashed };
            Require(AnnotationTransforms.Translate(source,new Vector(5,5)).LineStyle==LineStyle.Dashed && AnnotationTransforms.Scale(source,2,2).LineStyle==LineStyle.Dashed, "Transform lost line style");
        });
        Test("Project annotation round trip preserves editable points and shape style", () =>
        {
            var source=new Annotation { Tool=AnnotationTool.Pen,Start=new Point(-2,5),End=new Point(20,30),Color=Colors.CornflowerBlue,StrokeWidth=4,FontSize=28,LineStyle=LineStyle.RoundEndpoints,UsesIndependentShapeStyle=true,ShapeFillEnabled=true,FillOpacity=.2 };
            source.Points.Add(new Point(-2,5));source.Points.Add(new Point(20,30));
            var options=new System.Text.Json.JsonSerializerOptions { IncludeFields=true };
            string json=System.Text.Json.JsonSerializer.Serialize(ReferenceBoardWindow.InkData.From(source),options);
            var restored=System.Text.Json.JsonSerializer.Deserialize<ReferenceBoardWindow.InkData>(json,options)!.Model();
            Require(restored.Points.SequenceEqual(source.Points) && restored.Start==source.Start && restored.Color==source.Color, "Project lost editable geometry");
            Require(restored.LineStyle==source.LineStyle && restored.ShapeFillEnabled && restored.FillOpacity==.2, "Project lost annotation style");
            bool rejected=false; try { new ReferenceBoardWindow.InkData { Width=double.NaN }.Model(); } catch(InvalidDataException) { rejected=true; }
            Require(rejected,"Project accepted non-finite geometry");
        });
        Test("Project manifest preserves group appearance, endpoints and viewport preferences", () =>
        {
            var data=new ReferenceBoardWindow.ProjectData { Zoom=.5,PanX=-150,DrawingVisible=false,Background="#FF102030" };
            data.Groups.Add(new ReferenceBoardWindow.GroupData { Id="a",Name="參考甲",Width=400,Height=300,Fill="#FF465CFF",Border="#FFFFFFFF",Opacity=.25,Dashed=true,TitleSize=32,TitleColor="#FFFFAA00",ColumnGap=37,RowGap=51 });
            data.Links.Add(new ReferenceBoardWindow.LinkData { From="a",To="b",FromSide=1,ToSide=0,Style=LineStyle.Dashed,Width=5 });
            var options=new System.Text.Json.JsonSerializerOptions { IncludeFields=true };
            var copy=System.Text.Json.JsonSerializer.Deserialize<ReferenceBoardWindow.ProjectData>(System.Text.Json.JsonSerializer.Serialize(data,options),options)!;
            Require(copy.Groups[0].Name=="參考甲" && copy.Groups[0].Dashed && copy.Groups[0].Opacity==.25 && copy.Groups[0].ColumnGap==37 && copy.Groups[0].RowGap==51 && copy.Groups[0].TitleSize==32 && copy.Groups[0].TitleColor=="#FFFFAA00","Group style lost");
            Require(copy.Links[0].Style==LineStyle.Dashed && copy.Links[0].FromSide==1 && copy.Zoom==.5 && !copy.DrawingVisible,"Connector or viewport data lost");
        });
        Test("Project PNG encoding works with non-seekable ZIP entry destinations", () =>
        {
            var source=MakeImage(17,13,Colors.CornflowerBlue);
            using var storage=new MemoryStream();
            using(var archive=new System.IO.Compression.ZipArchive(storage,System.IO.Compression.ZipArchiveMode.Create,true))
                ProjectImageCodec.WritePng(archive,"images/0.png",source);
            storage.Position=0;
            using var reopened=new System.IO.Compression.ZipArchive(storage,System.IO.Compression.ZipArchiveMode.Read);
            using var entry=reopened.GetEntry("images/0.png")!.Open();
            using var png=new MemoryStream();entry.CopyTo(png);png.Position=0;
            var decoded=BitmapDecoder.Create(png,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad).Frames[0];
            Require(decoded.PixelWidth==17 && decoded.PixelHeight==13,"ZIP PNG dimensions changed");
            Require(Pixel(decoded,8,6)==Colors.CornflowerBlue,"ZIP PNG pixels changed");
        });
        Test("Typeface survives project serialization and annotation transforms", () =>
        {
            var source=new Annotation { Tool=AnnotationTool.Text,Text="字型測試",FontFamily="Arial",FontSize=24,Color=Colors.White };
            var restored=ReferenceBoardWindow.InkData.From(source).Model();
            Require(restored.FontFamily=="Arial" && AnnotationTransforms.Translate(restored,new Vector(3,4)).FontFamily=="Arial","Typeface lost");
        });
        Test("Adaptive toolbar wraps into full cells without a scrollbar", () =>
        {
            Require(AdaptiveToolPanel.LayoutFor(8,272)==(8,1),"Wide toolbar did not remain a row");
            Require(AdaptiveToolPanel.LayoutFor(8,136)==(4,2),"Two rows incorrect");
            Require(AdaptiveToolPanel.LayoutFor(8,102)==(3,3),"Partial last row incorrect");
            Require(AdaptiveToolPanel.LayoutFor(8,34)==(1,8),"Vertical toolbar incorrect");
        });
        Test("History retains redo through unchanged selection and clears it after an edit", () =>
        {
            var history=new HistoryTimeline<string>(s=>s,2);history.Reset("initial");history.Observe("move");history.Observe("delete");
            Require(history.TryMove(false,out var state)&&state=="move","Undo did not restore move");
            history.Observe("move");Require(history.CanRedo,"No-op edit cleared redo");
            Require(history.TryMove(true,out state)&&state=="delete","Redo did not restore deletion");
            history.TryMove(false,out state);history.Observe("new edit");Require(!history.CanRedo,"New branch retained stale redo");
        });
        Test("Group side resize preserves opposite edge and orthogonal axis", () =>
        {
            var rect=new Rect(20,30,300,200);
            var left=ReferenceBoardWindow.ResizeGroupBounds(rect,4,new Point(50,500));
            Require(left.Left==50&&left.Right==320&&left.Top==30&&left.Height==200,"Left edge resized wrong axes");
            var bottom=ReferenceBoardWindow.ResizeGroupBounds(rect,7,new Point(900,300));
            Require(bottom.Bottom==300&&bottom.Top==30&&bottom.Left==20&&bottom.Width==300,"Bottom edge resized wrong axes");
            var limited=ReferenceBoardWindow.ResizeGroupBounds(rect,0,new Point(999,999));
            Require(limited.Width==100&&limited.Height==70&&limited.BottomRight==rect.BottomRight,"Minimum size/opposite corner changed");
        });
        Test("Canvas undo/redo restores named groups, connectors and text", ReferenceBoardWindow.VerifyHistoryRoundTrip);
        var background = MakeImage(64, 48, Color.FromRgb(17, 34, 51));
        Test("Arrow geometry closes before freeze and exports visible pixels", () =>
        {
            var arrow = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Arrow,
                Start = new Point(5, 24), End = new Point(55, 24), Color = Colors.Red, StrokeWidth = 3 });
            Require(arrow.IsFrozen, "Drawing must be immutable");
            var output = ImageExportService.Compose(background, new[] { arrow });
            Require(Pixel(output, 50, 24).R > 200, "Arrowhead was not exported");
            Require(output.PixelWidth == 64 && output.PixelHeight == 48, "Export changed source dimensions");
        });
        Test("Filled and reverse-dragged rectangles are opaque", () =>
        {
            foreach (bool reverse in new[] { false, true })
            {
                var rect = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Rectangle,
                    Start = new Point(reverse ? 30 : 5, reverse ? 30 : 5),
                    End = new Point(reverse ? 5 : 30, reverse ? 5 : 30),
                    Color = Colors.Red, RectangleMode = RectangleAnnotationMode.Fill, FillOpacity = 1 });
                Require(Pixel(ImageExportService.Compose(background, new[] { rect }), 15, 15) == Colors.Red,
                    "Rectangle center should be opaque red");
            }
        });
        Test("Circle annotations render as equal-axis geometry", () =>
        {
            var circle = AnnotationRenderer.Build(new Annotation
            {
                Tool = AnnotationTool.Circle, Start = new Point(10, 10), End = new Point(40, 40),
                Color = Colors.Blue, StrokeWidth = 4, UsesIndependentShapeStyle = true,
                ShapeStrokeEnabled = true, ShapeFillEnabled = false, StrokeOpacity = 1.0
            });
            Require(Math.Abs(circle.Bounds.Width - circle.Bounds.Height) < .01,
                $"Circle bounds are not square: {circle.Bounds.Width} x {circle.Bounds.Height}");
        });
        Test("Outline does not change interior pixels", () =>
        {
            var rect = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Rectangle,
                Start = new Point(5, 5), End = new Point(30, 30), Color = Colors.Red,
                StrokeWidth = 3, RectangleMode = RectangleAnnotationMode.Outline });
            Require(Pixel(ImageExportService.Compose(background, new[] { rect }), 15, 15) == Pixel(background, 15, 15),
                "Outline filled its interior");
        });
        Test("Single-point pen strokes produce a dot", () =>
        {
            var pen = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Pen,
                Start = new Point(20, 20), End = new Point(20, 20), Color = Colors.Red, StrokeWidth = 6 });
            Require(Pixel(ImageExportService.Compose(background, new[] { pen }), 20, 20).R > 200, "Dot is missing");
        });
        Test("Crop is independent of the original screen buffer", () =>
        {
            var mutable = new WriteableBitmap(background);
            var crop = ScreenCaptureService.CropDetached(mutable, new Int32Rect(3, 4, 7, 5));
            byte[] green = { 0, 255, 0, 255 };
            mutable.WritePixels(new Int32Rect(3, 4, 1, 1), green, 4, 0);
            Require(crop.IsFrozen && crop.PixelWidth == 7 && crop.PixelHeight == 5, "Invalid crop metadata");
            Require(Pixel(crop, 0, 0) == Pixel(background, 3, 4), "Crop still depends on source");
        });
        Test("One-pixel crop retains exact size", () =>
        {
            var crop = ScreenCaptureService.CropDetached(background, new Int32Rect(63, 47, 1, 1));
            Require(crop.PixelWidth == 1 && crop.PixelHeight == 1, "One-pixel crop was enlarged");
        });
        Test("Retained annotations survive scale and undo/redo without rebuilding", () =>
        {
            var drawing = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Text,
                Start = new Point(2, 3), Text = "Hello 中文", Color = Colors.White });
            var layer = new AnnotationLayer();
            layer.Add(drawing);
            layer.SetScale(.25, .25);
            layer.SetScale(4, 4);
            Require(ReferenceEquals(layer.Drawings[0], drawing), "Zoom rebuilt committed drawing");
            var removed = layer.RemoveLast();
            Require(layer.Drawings.Count == 0 && ReferenceEquals(removed, drawing), "Undo lost history entry");
            layer.Add(removed!);
            var preview = ImageExportService.Compose(background, layer.Drawings);
            var expected = ImageExportService.Compose(background, new[] { drawing });
            Require(Bytes(preview).SequenceEqual(Bytes(expected)), "Preview and export disagree after redo");
        });
        Test("Editable text drawing can be replaced in place", () =>
        {
            var layer = new AnnotationLayer();
            var first = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Text, Start = new Point(2, 3), Text = "First", Color = Colors.White });
            var second = AnnotationRenderer.Build(new Annotation { Tool = AnnotationTool.Text, Start = new Point(9, 10), Text = "Edited", Color = Colors.White });
            layer.Add(first);
            layer.ReplaceAt(0, second);
            Require(layer.Drawings.Count == 1 && ReferenceEquals(layer.Drawings[0], second), "Text replacement changed history length or wrong drawing");
        });
        Test("Negative-monitor coordinates and clipped child bounds", () =>
        {
            var desktop = new PixelRect(-1920, -200, 3840, 1280);
            var child = new PixelRect(-1950, -250, 500, 500);
            var clipped = WindowSnapService.Intersect(desktop, child);
            Require(clipped == new PixelRect(-1920, -200, 470, 450), "Incorrect intersection");
            Require(!clipped.Contains(clipped.Right, clipped.Bottom), "Right/bottom bounds are exclusive");
        });
        Test("PNG writes original-resolution image and replaces only after encoding", () =>
        {
            string folder = Path.Combine(Path.GetTempPath(), "Clipxel-test-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(folder);
            try
            {
                string path = Path.Combine(folder, "test.png");
                File.WriteAllText(path, "old placeholder");
                ImageExportService.SavePngAsync(background, path).GetAwaiter().GetResult();
                using var stream = File.OpenRead(path);
                var decoder = new PngBitmapDecoder(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                Require(Bytes(decoder.Frames[0]).SequenceEqual(Bytes(background)), "PNG changed pixels");
                Require(Directory.GetFiles(folder).Length == 1, "Temporary export file leaked");
            }
            finally { Directory.Delete(folder, recursive: true); }
        });
        Test("Rectangle and circle both toggle off on repeated selection", () =>
        {
            var pin = new PinWindow(background);
            var selector = new SelectionWindow(new DesktopCapture(background, new PixelRect(0, 0, background.PixelWidth, background.PixelHeight)));
            try
            {
                const System.Reflection.BindingFlags flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
                foreach (var pair in new[] { (Window: (object)pin, Method: "SetAnnotationTool", Field: "_activeTool"),
                    (Window: (object)selector, Method: "SetSelectionAnnotationTool", Field: "_selectionActiveTool") })
                foreach (var shape in new[] { AnnotationTool.Rectangle, AnnotationTool.Circle })
                {
                    var method = pair.Window.GetType().GetMethod(pair.Method, flags)!;
                    var field = pair.Window.GetType().GetField(pair.Field, flags)!;
                    method.Invoke(pair.Window, new object[] { shape });
                    Require((AnnotationTool)field.GetValue(pair.Window)! == shape, "Shape did not activate");
                    method.Invoke(pair.Window, new object[] { shape });
                    Require((AnnotationTool)field.GetValue(pair.Window)! == AnnotationTool.None, "Repeated shape selection did not exit");
                }
            }
            finally { selector.Close(); pin.Close(); }
        });
        Test("Smoothed pen is curved, frozen and exports anti-aliased edges", () =>
        {
            var model = new Annotation { Tool = AnnotationTool.Pen, Color = Colors.Red, StrokeWidth = 1 };
            model.Points.AddRange(new[] { new Point(4.2, 6.4), new Point(20.6, 30.7), new Point(40.3, 10.4), new Point(55.8, 33.2) });
            var geometry = AnnotationRenderer.BuildPenGeometry(model.Points);
            Require(geometry.IsFrozen, "Pen geometry must be immutable");
            var path = PathGeometry.CreateFromGeometry(geometry);
            Require(path.Figures.SelectMany(f => f.Segments).Any(segment => segment is QuadraticBezierSegment || segment is PolyQuadraticBezierSegment), "Pen still uses only straight segments");
            var image = ImageExportService.Compose(MakeImage(64, 48, Colors.Transparent), new[] { AnnotationRenderer.Build(model) });
            bool partialAlpha = false;
            for (int y = 0; y < 48 && !partialAlpha; y++) for (int x = 0; x < 64; x++)
            { byte alpha = Pixel(image, x, y).A; if (alpha > 0 && alpha < 255) { partialAlpha = true; break; } }
            Require(partialAlpha, "Export did not contain anti-aliased edge pixels");
        });
        Test("Reference board preserves the source bitmap and annotation models", () =>
        {
            var pin = new PinWindow(background, new[] { new Annotation { Tool = AnnotationTool.Rectangle, Start = new Point(5, 5), End = new Point(20, 20), Color = Colors.Red } });
            var board = new ReferenceBoardWindow { AllowClose = true };
            try
            {
                var before = pin.ReferenceBitmap();
                board.SyncPins(new[] { pin }); board.SyncPins(new[] { pin });
                board.RemovePin(pin);
                Require(ReferenceEquals(before, pin.ReferenceBitmap()), "Board changed the original pin");
                Require(before.PixelWidth == background.PixelWidth && before.PixelHeight == background.PixelHeight, "Board changed image resolution");
            }
            finally { board.Close(); pin.Close(); }
        });
        Test("Opacity glyph renders alternating checkerboard cells", () =>
        {
            var glyph = new ToolGlyph { Glyph = "Opacity", Width = 32, Height = 32 };
            glyph.Measure(new Size(32, 32)); glyph.Arrange(new Rect(0, 0, 32, 32)); glyph.UpdateLayout();
            var rendered = new RenderTargetBitmap(32, 32, 96, 96, PixelFormats.Pbgra32);
            rendered.Render(glyph); rendered.Freeze();
            Require(Pixel(rendered, 12, 12).A > 240, "Dark checker cell missing");
            byte alpha = Pixel(rendered, 20, 12).A;
            Require(alpha > 20 && alpha < 100, "Light checker cell missing");
        });
        Test("Board uses custom borderless chrome and its own pie menu", () =>
        {
            var board = new ReferenceBoardWindow { AllowClose = true };
            var pie = new BoardPieWindow(false);
            try
            {
                Require(board.WindowStyle == WindowStyle.None, "Native title bar is still enabled");
                Require(board.ResizeMode == ResizeMode.CanResize, "Board edges cannot be resized");
                Require(System.Windows.Shell.WindowChrome.GetWindowChrome(board) is not null, "Native resize hit testing missing");
                Require(pie.WindowStyle == WindowStyle.None && !pie.ShowInTaskbar, "Pie should be a floating tool window");
                pie.Dismiss(); pie.Dismiss();
            }
            finally { board.Close(); pie.Dismiss(); }
        });
        Test("All WPF windows load their XAML and toolbar history states", () =>
        {
            var pin = new PinWindow(background);
            var toolbar = new ToolbarWindow();
            var selector = new SelectionWindow(new DesktopCapture(background, new PixelRect(0, 0, 64, 48)));
            var pie = new PieMenuWindow(true, true);
            try
            {
                toolbar.SetActiveTool(AnnotationTool.Rectangle);
                toolbar.SetStrokeWidth(6);
                toolbar.SetHistoryState(true, false);
                toolbar.SetRectangleMode(RectangleAnnotationMode.Fill);
                Require(pin.FindName("Annotations") is AnnotationLayer, "Missing retained annotation layer");
            }
            finally { pie.Close(); selector.Close(); toolbar.Close(); pin.Close(); }
        });
        Test("Text editor edge hit testing preserves body editing", TextInteractionTests.VerifyEditorEdges);
        Test("Pinned text: hover, single click, edge select, delete, undo and redo", () =>
            TextInteractionTests.Verify(new PinWindow(background), false));
        Test("Selection text: hover, single click, edge select, delete, undo and redo", () =>
            TextInteractionTests.Verify(new SelectionWindow(new DesktopCapture(background, new PixelRect(0, 0, 64, 48))), true));
        Test("Annotation transforms preserve editable geometry while moving groups", () =>
        {
            var pen = new Annotation { Tool = AnnotationTool.Pen, Start = new Point(2, 3), End = new Point(8, 9),
                Color = Colors.Blue, StrokeWidth = 4 };
            pen.Points.Add(new Point(2, 3));
            pen.Points.Add(new Point(8, 9));
            var moved = AnnotationTransforms.Translate(pen, new Vector(10, 20));
            Require(moved.Points.Count == 2 && moved.Points[0] == new Point(12, 23) && moved.Points[1] == new Point(18, 29),
                "Translated pen points were not retained as editable geometry.");
            var scaled = AnnotationTransforms.Scale(moved, 2, .5);
            Require(scaled.Points[1] == new Point(36, 14.5), "Scaled annotation model is incorrect.");
        });
        Test("Pinned capture imports retained annotation models instead of flattening them", () =>
        {
            var text = new Annotation { Tool = AnnotationTool.Text, Start = new Point(5, 6), Text = "Editable", Color = Colors.White, FontSize = 31 };
            var pen = new Annotation { Tool = AnnotationTool.Pen, Start = new Point(1, 1), End = new Point(10, 10), Color = Colors.Red, StrokeWidth = 3 };
            pen.Points.Add(new Point(1, 1)); pen.Points.Add(new Point(10, 10));
            var pin = new PinWindow(background, new[] { text, pen });
            try
            {
                var layer = (AnnotationLayer)pin.FindName("Annotations");
                Require(layer.Drawings.Count == 2, "Transferred blue-frame annotations were flattened or lost.");
                Require(pin.FindName("ObjectSelectionChrome") is AnnotationSelectionChrome, "Object selection overlay is missing.");
            }
            finally { pin.Close(); }
        });
        Test("Toolbar switches the shared slider between stroke width and font size", () =>
        {
            var toolbar = new ToolbarWindow();
            try
            {
                toolbar.SetStrokeWidth(7);
                toolbar.SetFontSize(36);
                toolbar.SetActiveTool(AnnotationTool.Text);
                var slider = (System.Windows.Controls.Slider)toolbar.FindName("StrokeSlider");
                var divider = (System.Windows.FrameworkElement)toolbar.FindName("ShapeControlsDivider");
                Require(slider.Minimum == 8 && slider.Maximum == 120 && Math.Abs(slider.Value - 36) < .01,
                    "Text tool did not switch the shared bar to font-size mode.");
                Require(divider.Visibility == Visibility.Collapsed, "Collapsed shape controls left an extra divider.");
                toolbar.SetActiveTool(AnnotationTool.Rectangle);
                Require(slider.Minimum == 1 && slider.Maximum == 20 && Math.Abs(slider.Value - 7) < .01,
                    "Leaving text mode did not restore stroke-width mode.");
                Require(divider.Visibility == Visibility.Collapsed, "Integrated shape panel left an inline divider.");
            }
            finally { toolbar.Close(); }
        });
        Test("Shape toolbar keeps equal circle geometry and stable reserved width", () =>
        {
            var toolbar = new ToolbarWindow();
            try
            {
                Require(toolbar.ExpandedWidthDip > 400,
                    "Full toolbar width was not measured before the first show.");
                double expandedWidth = toolbar.ExpandedWidthDip;
                toolbar.SetActiveTool(AnnotationTool.Pen);
                Require(toolbar.ExpandedWidthDip == expandedWidth, "Placement anchor changed when controls collapsed.");
                toolbar.SetActiveTool(AnnotationTool.Circle);
                var strokeCircle = (System.Windows.FrameworkElement)toolbar.FindName("ShapeStrokeCircleIcon");
                var fillCircle = (System.Windows.FrameworkElement)toolbar.FindName("ShapeFillCircleIcon");
                Require(strokeCircle.Width == 14 && strokeCircle.Height == 14 && fillCircle.Width == 14 && fillCircle.Height == 14,
                    "Circle inline icons no longer share the toolbar icon viewport.");
                Require(toolbar.IsShapeControlsVisible, "Shape controls should be visible for Circle.");
                toolbar.SetActiveTool(AnnotationTool.Pen);
                Require(!toolbar.IsShapeControlsVisible, "Shape controls should collapse for Pen.");
            }
            finally { toolbar.Close(); }
        });
        Test("Large captures respect the 30K safety extent while exceeding the legacy 16K cap", () =>
        {
            double maximum = PinWindow.ComputeMaximumScale(8700, 3000);
            double legacy = 16384.0 / 8700.0;
            Require(maximum > legacy + 1.0, $"Large capture did not meaningfully exceed the legacy cap: {maximum:P0}");
            Require(Math.Abs(maximum - (30000.0 / 8700.0)) < .001, $"Unexpected 30K safety scale: {maximum:P0}");
            Require(maximum <= 8.0, "Zoom policy exceeded the intended 800% ceiling.");
        });
        Test("Oversized zoom keeps one logical center instead of accumulating window drift", () =>
        {
            const double cx = 960, cy = 540;
            var a = PinWindow.ComputeCenteredBounds(1920, 1080, cx, cy, 1.0);
            var b = PinWindow.ComputeCenteredBounds(1920, 1080, cx, cy, 2.5);
            var c = PinWindow.ComputeCenteredBounds(1920, 1080, cx, cy, 6.0);
            Require(Math.Abs((a.X + a.Width / 2.0) - cx) <= .5 && Math.Abs((a.Y + a.Height / 2.0) - cy) <= .5,
                "100% bounds lost the requested center.");
            Require(Math.Abs((b.X + b.Width / 2.0) - cx) <= .5 && Math.Abs((b.Y + b.Height / 2.0) - cy) <= .5,
                "250% bounds drifted from the requested center.");
            Require(Math.Abs((c.X + c.Width / 2.0) - cx) <= .5 && Math.Abs((c.Y + c.Height / 2.0) - cy) <= .5,
                "600% bounds drifted from the requested center.");
        });
        Test("Toolbar initial swatch is white and follows color changes", () =>
        {
            var toolbar = new ToolbarWindow();
            try
            {
                var dot = (System.Windows.Shapes.Ellipse)toolbar.FindName("CurrentColorDot");
                Require(((SolidColorBrush)dot.Fill).Color == Colors.White, "Initial swatch is not white");
                toolbar.SetAnnotationColor(Colors.Red);
                Require(((SolidColorBrush)dot.Fill).Color == Colors.Red, "Swatch did not follow selected color");
            }
            finally { toolbar.Close(); }
        });
        log.AppendLine($"Failures: {failures}");
        try
        {
            string path = Path.GetFullPath(reportPath);
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, log.ToString(), new UTF8Encoding(true));
        }
        catch (Exception error) { App.LogError("Write self-test report", error); return 2; }
        return failures == 0 ? 0 : 1;
    }

    private static void Require(bool result, string message)
    {
        if (!result) throw new InvalidOperationException(message);
    }
    private static BitmapSource MakeImage(int width, int height, Color color)
    {
        var pixels = new byte[width * height * 4];
        for (int i = 0; i < pixels.Length; i += 4)
        {
            pixels[i] = color.B; pixels[i + 1] = color.G; pixels[i + 2] = color.R; pixels[i + 3] = color.A;
        }
        var bitmap = BitmapSource.Create(width, height, 96, 96, PixelFormats.Bgra32, null, pixels, width * 4);
        bitmap.Freeze();
        return bitmap;
    }
    private static Color Pixel(BitmapSource bitmap, int x, int y)
    {
        var converted = new FormatConvertedBitmap(bitmap, PixelFormats.Bgra32, null, 0);
        var pixel = new byte[4];
        converted.CopyPixels(new Int32Rect(x, y, 1, 1), pixel, 4, 0);
        return Color.FromArgb(pixel[3], pixel[2], pixel[1], pixel[0]);
    }
    private static byte[] Bytes(BitmapSource bitmap)
    {
        var converted = new FormatConvertedBitmap(bitmap, PixelFormats.Bgra32, null, 0);
        var bytes = new byte[bitmap.PixelWidth * bitmap.PixelHeight * 4];
        converted.CopyPixels(bytes, bitmap.PixelWidth * 4, 0);
        return bytes;
    }
}
