using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Models;
using Clipxel.Rendering;
using Clipxel.Services;
using Clipxel.Windows;

namespace Clipxel.Tests;

// Exercise the real window handlers without showing a capture overlay or altering the clipboard.
internal static class TextInteractionTests
{
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private static object? Call(object target, string name, params object[] args) =>
        target.GetType().GetMethod(name, Private)!.Invoke(target, args);
    private static object? Field(object target, string name) => target.GetType().GetField(name, Private)!.GetValue(target);
    private static void Set(object target, string name, object value) => target.GetType().GetField(name, Private)!.SetValue(target, value);
    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    public static void Verify(Window window, bool selection)
    {
        try
        {
            string add = selection ? "AddSelectionAnnotation" : "AddAnnotation";
            string undo = selection ? "UndoSelectionAnnotation" : "UndoAnnotation";
            string redo = selection ? "RedoSelectionAnnotation" : "RedoAnnotation";
            string endDrag = selection ? "EndSelectionTextDrag" : "EndTextDrag";
            string colorField = selection ? "_selectionAnnotationColor" : "_annotationColor";
            string modelsField = selection ? "_selectionAnnotationModels" : "_annotationModels";
            var host = (FrameworkElement)window.FindName(selection ? "Root" : "ImageFrame");
            host.Measure(new Size(640, 480));
            host.Arrange(new Rect(0, 0, 640, 480));
            if (selection)
            {
                Set(window, "_lockedSelection", new PixelRect(0, 0, 640, 480));
                Set(window, "_lockedDipRect", new Rect(0, 0, 640, 480));
            }
            Require((Color)Field(window, colorField)! == Colors.White, "Initial annotation color is not white.");
            var models = (List<Annotation?>)Field(window, modelsField)!;
            var layer = (AnnotationLayer)window.FindName(selection ? "SelectionAnnotations" : "Annotations");
            var editor = (TextBox)window.FindName(selection ? "SelectionTextEditor" : "AnnotationTextEditor");
            var first = new Annotation { Tool = AnnotationTool.Text, Start = new Point(2, 2), Text = "A", Color = Colors.White };
            var second = new Annotation { Tool = AnnotationTool.Text, Start = new Point(35, 30), Text = "B", Color = Colors.Red };
            Call(window, add, AnnotationRenderer.Build(first), first);
            Call(window, add, AnnotationRenderer.Build(second), second);

            var frame = (Rect)Call(window, "GetTextFrame", 0)!;
            Require(!frame.IsEmpty, "Text hit box is missing.");
            var center = new Point(frame.Left + frame.Width / 2, frame.Top + frame.Height / 2);
            Require((bool)Call(window, "UpdateTextFeedback", center)!, "Existing text does not respond to hover.");
            var beforeHover = layer.Drawings[0];
            Call(window, "UpdateTextFeedback", center);
            Require(ReferenceEquals(beforeHover, layer.Drawings[0]), "Hover modified exported annotation artwork.");

            var click = new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left)
            {
                RoutedEvent = Mouse.MouseDownEvent
            };
            Require((bool)Call(window, "TryHandleTextPointerDown", center, click)!, "Single click did not open text editing.");
            Require(editor.Visibility == Visibility.Visible && editor.Text == "A", "Text editor failed to load existing text.");
            editor.Text = "Edited";
            editor.Measure(new Size(400, 200));
            editor.Arrange(new Rect(0, 0, 240, 60));
            var edge = editor.TranslatePoint(new Point(1, editor.RenderSize.Height / 2), host);
            var borderClick = new MouseButtonEventArgs(Mouse.PrimaryDevice, 1, MouseButton.Left)
            {
                RoutedEvent = Mouse.MouseDownEvent
            };
            Require((bool)Call(window, "TryHandleTextPointerDown", edge, borderClick)!, "Editor edge did not select the object.");
            Call(window, endDrag);
            Require(editor.Visibility == Visibility.Collapsed && (int)Field(window, "_selectedTextIndex")! == 0,
                "Editor did not enter object-selection mode.");
            Require(models[0]!.Text == "Edited", "Object selection discarded the edit.");
            var beforeMove = models[0]!.Start;
            Call(window, selection ? "StartSelectionTextDrag" : "StartTextDrag", 0, new Point(5, 6));
            Call(window, selection ? "UpdateSelectionTextDrag" : "UpdateTextDrag", new Point(9, 11));
            Call(window, endDrag);
            Require(models[0]!.Start != beforeMove, "Dragging did not move the text model.");
            var editedDrawing = layer.Drawings[0];
            var otherDrawing = layer.Drawings[1];
            Require((bool)Call(window, "DeleteSelectedText")!, "Selected text was not deleted.");
            Require(models.Count == 1 && ReferenceEquals(layer.Drawings[0], otherDrawing), "Deletion removed the wrong object.");
            Call(window, undo);
            Require(models.Count == 2 && models[0]!.Text == "Edited" && ReferenceEquals(layer.Drawings[0], editedDrawing),
                "Undo did not restore the deleted text at its original index.");
            Call(window, undo);
            Require(models[0]!.Start == beforeMove, "Undo did not restore the position before the drag.");
            Call(window, redo);
            Require(ReferenceEquals(layer.Drawings[0], editedDrawing), "Redo did not restore the dragged drawing.");
            Call(window, redo);
            Require(models.Count == 1 && ReferenceEquals(layer.Drawings[0], otherDrawing), "Redo did not repeat the deletion.");
            Require(!(bool)Call(window, "DeleteSelectedText")!, "Delete acted without a selected object.");
        }
        finally { window.Close(); }
    }

    public static void VerifyEditorEdges()
    {
        var size = new Size(240, 60);
        foreach (var p in new[] { new Point(1, 30), new Point(239, 30), new Point(120, 1), new Point(120, 59) })
            Require(TextAnnotationChrome.IsEditorEdge(p, size), "Editor border is not selectable.");
        Require(!TextAnnotationChrome.IsEditorEdge(new Point(120, 30), size), "Text body was treated as a drag border.");
        Require(!TextAnnotationChrome.IsEditorEdge(new Point(-1, 30), size), "Outside point was treated as a border click.");
    }
}
