using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clipxel.Services;
namespace Clipxel.Tests;
internal static class ThemeTests
{
    internal static void VerifyFrozenBrushSwitching()
    {
        string saved=App.Settings.Theme;
        var label=new TextBlock {Text="theme",Foreground=ThemeService.Foreground};
        var window=new Window {Content=label};
        var original=ThemeService.Foreground;var originalColor=original.Color;original.Freeze();
        try
        {
            for(int i=0;i<30;i++)
            {
                App.Settings.Theme=new[]{"Dark","Light","White"}[i%3];ThemeService.Apply();
                if(original.Color!=originalColor)throw new InvalidOperationException("Shared brush changed");
                if(label.Foreground is not SolidColorBrush ink || ink.Color!=ThemeService.Foreground.Color)
                    throw new InvalidOperationException("Existing label did not follow theme");
                if(Application.Current.FindResource("BrandCaption") is not DrawingImage)
                    throw new InvalidOperationException("Caption is not a vector wordmark");
            }
        }
        finally {window.Close();App.Settings.Theme=saved;ThemeService.Apply();}
    }
}
