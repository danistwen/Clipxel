# 精簡包驗證

已完成：
- 所有 C#、XAML、csproj、manifest、建置／簽章腳本與 0.4.37 原包逐位元比對一致。
- C#／XAML 所引用的圖檔及資源字典存在；檢查 ThemeService 動態名稱載入的圖檔。
- XAML、csproj、manifest XML 解析通過。
- ZIP 完整性檢查通過。

此环境沒有 .NET SDK 與 Windows WPF，未執行編譯、GUI、自我測試或效能測量。
本文件取代舊版驗證紀錄，不代表舊版或新版執行測試已通過。

在 Windows 本資料夾執行：

```powershell
dotnet build .\Clipxel.csproj -c Release
.\bin\Release\net10.0-windows\Clipxel.exe --self-test .\self-test-report.txt
```

另請手動檢查三種主題、圖示、釘圖／畫布切換、專案存取，以及 0.4.37 群組保留尺寸與自動排列。
