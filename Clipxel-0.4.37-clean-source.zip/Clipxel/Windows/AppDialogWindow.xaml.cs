using System.Linq;
using System.Windows;
using Clipxel.Services;

namespace Clipxel.Windows;

public partial class AppDialogWindow : Window
{
    public AppDialogWindow(string title, string message)
    {
        InitializeComponent();
        WindowIconHelper.ApplyAdaptiveTitleBarIcon(this);
        Title = title;
        TitleText.Text = title;
        MessageText.Text = message;
    }

    private void OkButton_Click(object sender, RoutedEventArgs e) => DialogResult = true;

    public static MessageBoxResult AskToSave(Window owner,string message,string title="Clipxel")
    {
        var dialog=new AppDialogWindow(title,message){Owner=owner};
        var buttons=(System.Windows.Controls.StackPanel)dialog.OkButton.Parent;buttons.Children.Clear();
        var result=MessageBoxResult.Cancel;
        foreach(var choice in new[]{("儲存",MessageBoxResult.Yes),("不儲存",MessageBoxResult.No),("取消",MessageBoxResult.Cancel)})
        {
            var button=new System.Windows.Controls.Button {Content=choice.Item1,MinWidth=82,Height=32,Margin=new Thickness(4),IsCancel=choice.Item2==MessageBoxResult.Cancel,IsDefault=choice.Item2==MessageBoxResult.Yes};
            button.Click+=(_,_)=>{result=choice.Item2;dialog.Close();};buttons.Children.Add(button);
        }
        DialogOwner.Prepare(dialog,dialog.Owner);CanvasTheme.Apply(dialog,CanvasTheme.BackgroundFor(dialog.Owner));dialog.ShowDialog();return result;
    }
    public static void ShowMessage(string message, string title = "Clipxel")
    {
        var existing=Application.Current.Windows.OfType<AppDialogWindow>().FirstOrDefault(w=>w.IsVisible&&w.Title==title);
        if(existing is not null){var front=DialogOwner.Resolve(existing);front?.Activate();return;}
        var dialog = new AppDialogWindow(title, message);
        var owner = Application.Current?.Windows.OfType<Window>().FirstOrDefault(w => w.IsActive && w != dialog);
        if (owner is not null)
            dialog.Owner = owner;
        DialogOwner.Prepare(dialog,dialog.Owner);CanvasTheme.Apply(dialog,CanvasTheme.BackgroundFor(dialog.Owner));dialog.ShowDialog();
    }
}
