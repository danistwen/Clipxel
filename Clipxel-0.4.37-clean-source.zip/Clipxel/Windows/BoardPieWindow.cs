using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Rendering;
using Clipxel.Services;

namespace Clipxel.Windows;
public enum BoardAction { Select, Pan, Import, Paste, Capture, Fit, Arrange, Export, ZoomIn, ZoomOut, Topmost, Return, Minimize, Delete, ToggleChrome, Settings, SelectAll, Group, RenameGroup, Undo, Redo, Pen, Rectangle, Circle, Arrow, Text, SaveProject, OpenProject, ToggleDrawing, BoardSettings, GroupStyle, Copy, CloseBoard, PickColor }

public sealed class BoardPieWindow : Window
{
    private bool _dismissed;
    public event Action<BoardAction>? ActionRequested;
    internal static string Label(BoardAction action) => action switch
    {
        BoardAction.PickColor => "吸色工具", BoardAction.Select => "選取物件", BoardAction.Pan => "平移畫布", BoardAction.Import => "加入圖片",
        BoardAction.Paste => "貼上圖片", BoardAction.Capture => "截圖", BoardAction.Fit => "顯示全部",
        BoardAction.Arrange => "自動排列", BoardAction.Export => "匯出畫布", BoardAction.ZoomIn => "放大畫布",
        BoardAction.ZoomOut => "縮小畫布", BoardAction.Topmost => "切換置頂", BoardAction.Return => "返回釘圖模式", BoardAction.Delete => "刪除選取圖片", BoardAction.ToggleChrome => "隱藏／顯示視窗", BoardAction.Settings => "自訂快捷鍵", BoardAction.SelectAll => "全選圖片", BoardAction.Group => "分類區塊", BoardAction.RenameGroup => "重新命名區塊", BoardAction.Undo => "復原", BoardAction.Redo => "重做", BoardAction.Pen => "畫筆", BoardAction.Rectangle => "矩形", BoardAction.Circle => "圓形", BoardAction.Arrow => "線條", BoardAction.Text => "文字", BoardAction.SaveProject => "儲存專案", BoardAction.OpenProject => "開啟專案", BoardAction.ToggleDrawing => "顯示／隱藏繪圖工具", BoardAction.BoardSettings => "畫布設定", BoardAction.GroupStyle => "分類區塊", BoardAction.Copy => "複製選取物件", BoardAction.CloseBoard => "關閉畫布", _ => "最小化"
    };
    public BoardPieWindow(bool panActive, bool hasSelection = false, bool canUndo = false, bool canRedo = false)
    {
        Width = 470; Height = 278; WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true; Background = Brushes.Transparent; ShowInTaskbar = false; Topmost = true;
        var root = new Grid { Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)) }; Content = root;
        var center = new Border { Width = 124, Height = 84, CornerRadius = new CornerRadius(8), Background = (Brush)Application.Current.FindResource("DialogSurface"), BorderBrush=(Brush)Application.Current.FindResource("GlassEdge"), BorderThickness=new Thickness(1) };
        center.Child = new TextBlock { Text = "畫布", Margin = new Thickness(0, 0, 0, 38), Foreground=Clipxel.Services.ThemeService.Foreground, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontSize = 14 };
        root.Children.Add(center);MistBackdrop.Attach(center);
        var centerTools = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0,18,0,0) };
        foreach(var action in new[] { BoardAction.Undo, BoardAction.Redo, BoardAction.Delete, BoardAction.ToggleChrome })
        {
            var button = new Button { Style=(Style)Application.Current.FindResource("PieButton"), Background=(Brush)Application.Current.FindResource("DialogSurface"), MinWidth=0, Width=28, Height=28, Padding=new Thickness(6), Content=new ToolGlyph { Glyph=action.ToString() }, ToolTip=Label(action) };
            if(action==BoardAction.Delete) button.IsEnabled=hasSelection;
            if(action==BoardAction.Undo) button.IsEnabled=canUndo; if(action==BoardAction.Redo) button.IsEnabled=canRedo;
            ToolHints.Board(button,action);button.Click+=(_,_)=>Fire(action); centerTools.Children.Add(button);
        }
        root.Children.Add(centerTools);
        var centers=RadialLayout.Centers(138,38);
        var actions=new[]{BoardAction.Fit,BoardAction.Arrange,BoardAction.Export,BoardAction.PickColor,BoardAction.Import,BoardAction.Group,BoardAction.Select,BoardAction.Pan};
        Width=centers[0].X*2+170;Height=centers[0].X*2+72;
        var positions=actions.Select((action,i)=>(action,centers[i].X,centers[i].Y));
        foreach (var (action, x, y) in positions)
        {
            var content = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            content.Children.Add(new ToolGlyph { Glyph = action.ToString(), Margin = new Thickness(0, 0, 7, 0) });
            content.Children.Add(new TextBlock { Text = Label(action), FontSize = 11, VerticalAlignment = VerticalAlignment.Center });
            var button = new Button { Content = content, ToolTip = Label(action) + (App.Settings.BoardShortcuts.TryGetValue(action.ToString(), out var shortcut) ? "  " + shortcut : ""), Style = (Style)Application.Current.FindResource("PieButton"), Background = (Brush)Application.Current.FindResource("DialogSurface"),
                Width = 138, Height = 38, Padding = new Thickness(7,0,7,0), Margin = new Thickness(0), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            // Position the plate, preserving the toolbar template's hover scale transform.
            var plate = new Border { CornerRadius=new CornerRadius(7), Width = 138, Height = 38, Background = Brushes.Transparent,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, RenderTransform = new TranslateTransform(x, y), Child = button };
            // The plate owns the mist; the button remains a transparent input layer.
            plate.Background=(Brush)Application.Current.FindResource("DialogSurface");button.Background=Brushes.Transparent;MistBackdrop.Attach(plate);
            if ((action == BoardAction.Pan && panActive) || (action == BoardAction.Select && !panActive)) {button.Foreground=Clipxel.Services.ThemeService.ActiveToolInk;button.Background = Clipxel.Services.ThemeService.ActiveSurface("Pie");}
            ToolHints.Board(button,action);button.Click += (_, _) => Fire(action); root.Children.Add(plate);
        }
        root.MouseLeftButtonDown += (_, e) => { if (ReferenceEquals(e.OriginalSource, root)) Dismiss(); };
        MouseRightButtonUp += (_, _) => Dismiss();
        KeyDown += (_, e) => { if (e.Key == Key.Escape) { Dismiss(); e.Handled = true; } };
        Deactivated += (_, _) => Dismiss();
        Closing += (_, _) => _dismissed = true;
        Closed += (_, _) => _dismissed = true;
    }
    public void ShowAtCursor(Window owner)
    {
        Owner = owner; Show();
        var cursor = WindowPlacementService.CursorPosition; var area = WindowPlacementService.WorkAreaAtCursor(); var size = WindowPlacementService.Bounds(this);
        WindowPlacementService.Move(this, Math.Clamp(cursor.X - size.Width / 2, area.X, Math.Max(area.X, area.Right - size.Width)),
            Math.Clamp(cursor.Y - size.Height / 2, area.Y, Math.Max(area.Y, area.Bottom - size.Height)));
        Activate(); Focus();
    }
    private void Fire(BoardAction action)
    {
        if (_dismissed) return;
        var handler = ActionRequested; Dismiss();
        Dispatcher.BeginInvoke(new Action(() => handler?.Invoke(action)));
    }
    public void Dismiss() { if (_dismissed) return; _dismissed = true; Close(); }
}
