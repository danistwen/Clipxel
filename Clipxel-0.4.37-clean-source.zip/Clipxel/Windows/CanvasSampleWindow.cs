using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Services;

namespace Clipxel.Windows;

// A temporary modal input surface permits sampling while a modal color dialog
// owns input. Closing it leaves the palette alive; Esc does not change the color.
internal sealed class CanvasSampleWindow : Window
{
    private Color? _sample;
    internal static Color? Pick(Window owner, IDocumentSurface source)
    {
        var surface = source.SamplingElement;
        if (!surface.IsVisible || surface.ActualWidth < 1 || surface.ActualHeight < 1) return null;
        var drawing = source.CreateDocumentDrawing();
        var window = new CanvasSampleWindow { Owner = owner, WindowStyle = WindowStyle.None, ResizeMode = ResizeMode.NoResize,
            ShowInTaskbar = false, Topmost = true, Cursor = Cursors.Cross, Background = Brushes.Black };
        var root = new Grid();
        root.Background = new DrawingBrush(drawing) { ViewboxUnits = BrushMappingMode.Absolute, Viewbox = new Rect(surface.RenderSize), Stretch = Stretch.Fill };
        var label = new TextBlock { Foreground=Clipxel.Services.ThemeService.Foreground, Text = "點擊畫布取色 · Esc 取消", Margin = new Thickness(10, 6, 10, 6) };
        var badge = new Border { Child = label, Background = new SolidColorBrush(Color.FromArgb(235, 35, 39, 45)), CornerRadius = new CornerRadius(6),
            HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(12), IsHitTestVisible = false };
        root.Children.Add(badge); window.Content = root;
        Point DocumentPoint(MouseEventArgs e) { var p = e.GetPosition(root); return new Point(p.X / root.ActualWidth * surface.ActualWidth, p.Y / root.ActualHeight * surface.ActualHeight); }
        window.MouseMove += (_, e) => { var c = DocumentSurface.Sample(drawing, DocumentPoint(e)); label.Text = $"#{c.R:X2}{c.G:X2}{c.B:X2} · 點擊取色 · Esc 取消"; };
        window.MouseLeftButtonDown += (_, e) => { window._sample = DocumentSurface.Sample(drawing, DocumentPoint(e)); window.DialogResult = true; e.Handled = true; };
        window.KeyDown += (_, e) => { if (e.Key == Key.Escape) { window.DialogResult = false; e.Handled = true; } };
        window.MouseRightButtonDown += (_, e) => { window.DialogResult = false; e.Handled = true; };
        window.Loaded += (_, _) =>
        {
            var origin = surface.PointToScreen(new Point()); var end = surface.PointToScreen(new Point(surface.ActualWidth, surface.ActualHeight));
            WindowPlacementService.SetBounds(window, new PixelRect((int)Math.Round(origin.X), (int)Math.Round(origin.Y), (int)Math.Round(end.X - origin.X), (int)Math.Round(end.Y - origin.Y)));
        };
        window.ShowDialog(); return window._sample;
    }
}
