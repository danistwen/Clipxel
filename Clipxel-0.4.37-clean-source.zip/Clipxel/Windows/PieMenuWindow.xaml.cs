using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Clipxel.Services;

namespace Clipxel.Windows;

public enum PieMenuAction
{
    Select,
    Pen,
    Rectangle,
    Circle,
    Arrow,
    Text,
    PickColor,
    Copy,
    Save,
    Undo,
    Redo,
    ResetOneToOne
}

public partial class PieMenuWindow : Window
{
    private void Shortcut_Loaded(object sender, RoutedEventArgs e)
    {
        if(sender is System.Windows.Controls.TextBlock label && label.Tag is string action)
        {
            string? shortcut=App.Settings.AnnotationShortcuts.GetValueOrDefault(action);
            label.Text=string.IsNullOrWhiteSpace(shortcut)?"":shortcut.Replace("D0","0");
            label.Visibility=string.IsNullOrWhiteSpace(shortcut)?Visibility.Collapsed:Visibility.Visible;
        }
    }

    public event Action<PieMenuAction>? ActionRequested;
    private bool _isClosing;

    public PieMenuWindow(bool canUndo, bool canRedo, AnnotationTool activeTool = AnnotationTool.None)
    {
        InitializeComponent();
        double plateWidth=176;
        foreach(var shortcut in App.Settings.AnnotationShortcuts.Values)
        {
            if(string.IsNullOrWhiteSpace(shortcut))continue;
            var text=new System.Windows.Media.FormattedText(shortcut,System.Globalization.CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,new System.Windows.Media.Typeface("Segoe UI"),11,System.Windows.Media.Brushes.White,1);
            plateWidth=Math.Max(plateWidth,Math.Ceiling(text.WidthIncludingTrailingWhitespace)+94);
        }
        var points=Clipxel.Services.RadialLayout.Centers(plateWidth,46);Width=points[0].X*2+plateWidth+32;Height=points[0].X*2+82;
        var buttons=new[]{RightButton,BottomRightButton,BottomButton,BottomLeftButton,LeftButton,TopLeftButton,TopButton,TopRightButton};
        var labels=new[]{"箭頭","儲存","文字","複製","取色","選取","畫筆","矩形"};
        for(int i=0;i<8;i++)
        {
            var button=buttons[i];string label=labels[i];Root.Children.Remove(button);button.HorizontalAlignment=HorizontalAlignment.Center;button.VerticalAlignment=VerticalAlignment.Center;button.Margin=new Thickness(0);button.Width=plateWidth;button.Height=46;button.Padding=new Thickness(9,0,9,0);
            var plate=new System.Windows.Controls.Border{Width=plateWidth,Height=46,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center,RenderTransform=new System.Windows.Media.TranslateTransform(points[i].X,points[i].Y),Child=button};Root.Children.Add(plate);
            Clipxel.Services.ToolHints.Attach(button,()=>label,()=>App.Settings.AnnotationShortcuts.GetValueOrDefault(label));
        }
        foreach(var pair in new[]{(UndoButton,"復原"),(RedoButton,"重做"),(ResetButton,"原始比例（釘圖）"),(RectangleChoice,"矩形"),(CircleChoice,"圓形")})
            Clipxel.Services.ToolHints.Attach(pair.Item1,()=>pair.Item2,()=>App.Settings.AnnotationShortcuts.GetValueOrDefault(pair.Item2));
        ShapeChoices.HorizontalAlignment=HorizontalAlignment.Center;ShapeChoices.VerticalAlignment=VerticalAlignment.Center;ShapeChoices.Margin=new Thickness(0);
        ShapeChoices.IsVisibleChanged+=(_,_)=>{var visibility=ShapeChoices.IsVisible?Visibility.Hidden:Visibility.Visible;UndoButton.Visibility=RedoButton.Visibility=ResetButton.Visibility=visibility;};
        UndoButton.IsEnabled = canUndo;
        RedoButton.IsEnabled = canRedo;
        var active = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(100,130,139,154));
        var blue=Clipxel.Services.ThemeService.ActiveToolInk;
        var current=activeTool switch {AnnotationTool.Pen=>TopButton,AnnotationTool.Text=>BottomButton,AnnotationTool.Arrow=>RightButton,AnnotationTool.Rectangle or AnnotationTool.Circle=>TopRightButton,_=>TopLeftButton};current.Foreground=blue;
        if (activeTool == AnnotationTool.Rectangle) RectangleChoice.Foreground=blue;
        if (activeTool == AnnotationTool.Circle) CircleChoice.Foreground=blue;
        if (activeTool == AnnotationTool.Rectangle) RectangleChoice.Background = active;
        if (activeTool == AnnotationTool.Circle) CircleChoice.Background = active;
    }

    public void ShowAtCursor(Window owner)
    {
        Owner = owner;
        Show();

        // Position in native pixels after WPF has created the HWND. This keeps
        // the pie centered under the right-click cursor even on 125/150/200% DPI.
        var cursor = WindowPlacementService.CursorPosition;
        var area = WindowPlacementService.WorkAreaAtCursor();
        var bounds = WindowPlacementService.Bounds(this);
        int x = Math.Clamp(cursor.X - bounds.Width / 2, area.X, Math.Max(area.X, area.Right - bounds.Width));
        int y = Math.Clamp(cursor.Y - bounds.Height / 2, area.Y, Math.Max(area.Y, area.Bottom - bounds.Height));
        WindowPlacementService.Move(this, x, y);
        Activate();
        Focus();
    }

    private void Fire(PieMenuAction action)
    {
        if (_isClosing) return;

        // Close the pie first, then execute the command on the next dispatcher turn.
        // Some commands (SaveFileDialog, focus/tool changes, owner activation) can
        // deactivate this window synchronously. Executing them before Close() used
        // to re-enter Window_Deactivated -> Close() and corrupt the menu lifecycle.
        var requested = ActionRequested;
        Dismiss();

        var dispatcher = Application.Current?.Dispatcher ?? Dispatcher;
        dispatcher.BeginInvoke(DispatcherPriority.Input, new Action(() => requested?.Invoke(action)));
    }

    public void Dismiss()
    {
        if (_isClosing) return;
        _isClosing = true;
        try
        {
            Close();
        }
        catch (InvalidOperationException)
        {
            // The HWND can already be inside WPF's close path after deactivation.
            // In that case there is nothing else to do; the guard prevents a
            // second Close() from escaping as an unhandled exception.
        }
    }

    private void TopButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Pen);
    private void TopLeftButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Select);
    private void TopRightButton_Click(object sender, RoutedEventArgs e)
    {
        ShapeChoices.Visibility = ShapeChoices.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
    }
    private void RectangleChoice_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Rectangle);
    private void CircleChoice_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Circle);
    private void LeftButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.PickColor);
    private void RightButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Arrow);
    private void BottomLeftButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Copy);
    private void BottomRightButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Save);
    private void BottomButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Text);
    private void UndoButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Undo);
    private void RedoButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.Redo);
    private void ResetButton_Click(object sender, RoutedEventArgs e) => Fire(PieMenuAction.ResetOneToOne);

    private void Root_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource == Root)
            Dismiss();
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            Dismiss();
            e.Handled = true;
        }
    }

    private void Window_Deactivated(object? sender, EventArgs e) => Dismiss();
    protected override void OnClosed(EventArgs e)
    {
        _isClosing = true;
        base.OnClosed(e);
    }

}
