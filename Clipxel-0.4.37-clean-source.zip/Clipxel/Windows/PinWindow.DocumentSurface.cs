using System.Windows;
using System.Windows.Media;
using Clipxel.Services;

namespace Clipxel.Windows;

public partial class PinWindow : IDocumentSurface
{
    long IDocumentSurface.DocumentRevision => System.HashCode.Combine(Annotations.Revision,PinnedImage.Source,ImageFrame.RenderSize,PinnedImage.RenderSize);
    FrameworkElement IDocumentSurface.SamplingElement => ImageFrame;
    Drawing IDocumentSurface.CreateDocumentDrawing()
    {
        var drawing = new DrawingGroup();
        using (var dc = drawing.Open())
        {
            var rect = new Rect(0, 0, ImageFrame.ActualWidth, ImageFrame.ActualHeight);
            dc.DrawRectangle(ImageFrame.Background, null, rect);
            foreach (var element in new FrameworkElement[] { PinnedImage, Annotations })
            {
                if (element.ActualWidth <= 0 || element.ActualHeight <= 0) continue;
                var origin = element.TranslatePoint(new Point(), ImageFrame);
                dc.DrawRectangle(new VisualBrush(element) { ViewboxUnits=BrushMappingMode.Absolute, Viewbox=new Rect(element.RenderSize), Stretch=Stretch.Fill }, null, new Rect(origin, element.RenderSize));
            }
        }
        return drawing;
    }
}
