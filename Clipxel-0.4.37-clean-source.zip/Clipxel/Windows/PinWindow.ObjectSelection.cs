using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Rendering;

namespace Clipxel.Windows;

public partial class PinWindow
{
    private bool _objectSelectionMode;
    private bool _objectMarqueeSelecting;
    private bool _objectGroupDragging;
    private bool _objectDragHistoryRecorded;
    private Point _objectSelectionStartDisplay;
    private Point _objectDragStartDisplay;
    private readonly HashSet<int> _selectedAnnotationIndices = new();
    private readonly Dictionary<int, Annotation?> _objectDragOriginalModels = new();
    private readonly Dictionary<int, DrawingGroup> _objectDragOriginalDrawings = new();
    private Rect _objectDragOriginalBounds = Rect.Empty;

    private void ToggleObjectSelectionMode() => SetObjectSelectionMode(!_objectSelectionMode);

    private void SetObjectSelectionMode(bool enabled)
    {
        CommitTextEditor();
        if (_drawing) CancelDraft();
        if (_draggingText) EndTextDrag();
        _pickerEnabled = false;
        ColorLens.Visibility = Visibility.Collapsed;
        _activeTool = AnnotationTool.None;
        _objectSelectionMode = enabled;
        _toolbarWindow?.SetActiveTool(AnnotationTool.None);
        _toolbarWindow?.SetPickerActive(false);
        _toolbarWindow?.SetSelectActive(enabled);
        ClearTextSelection();
        if (!enabled) ClearObjectSelection();
        Cursor = enabled ? Cursors.Arrow : Cursors.Arrow;
        if (enabled) ShowToolbar(); else ScheduleToolbarHide();
    }

    private void ClearObjectSelection()
    {
        CancelObjectSelectionInteraction();
        _selectedAnnotationIndices.Clear();
        ObjectSelectionChrome?.Clear();
    }

    private Rect GetAnnotationDisplayBounds(int index)
    {
        if ((uint)index >= (uint)Annotations.Drawings.Count) return Rect.Empty;
        var bounds = Annotations.Drawings[index].Bounds;
        if (bounds.IsEmpty) return Rect.Empty;
        var display = new Rect(ToDisplayPoint(bounds.TopLeft), ToDisplayPoint(bounds.BottomRight));
        display.Inflate(5, 5);
        display.Intersect(new Rect(0, 0, Math.Max(0, ImageFrame.ActualWidth), Math.Max(0, ImageFrame.ActualHeight)));
        return display;
    }

    private int HitAnnotation(Point displayPoint)
    {
        for (int i = Annotations.Drawings.Count - 1; i >= 0; i--)
            if (GetAnnotationDisplayBounds(i).Contains(displayPoint)) return i;
        return -1;
    }

    private bool HitSelectedAnnotation(Point displayPoint)
    {
        foreach (int index in _selectedAnnotationIndices)
            if (GetAnnotationDisplayBounds(index).Contains(displayPoint)) return true;
        return false;
    }

    private void RefreshObjectSelectionChrome(Rect? marquee = null)
    {
        if (ObjectSelectionChrome is null) return;
        ObjectSelectionChrome.ShowSelected(_selectedAnnotationIndices.OrderBy(i => i).Select(GetAnnotationDisplayBounds));
        if (marquee.HasValue && !marquee.Value.IsEmpty) ObjectSelectionChrome.ShowMarquee(marquee.Value);
        else ObjectSelectionChrome.ClearMarquee();
    }

    private bool TryBeginObjectSelection(Point displayPoint, MouseButtonEventArgs e)
    {
        if (!_objectSelectionMode || e.ChangedButton != MouseButton.Left || Keyboard.IsKeyDown(Key.Space)) return false;
        CommitTextEditor();
        ClearTextSelection();

        int hit = HitAnnotation(displayPoint);
        if (e.ClickCount >= 2 && hit >= 0 &&
            (uint)hit < (uint)_annotationModels.Count && _annotationModels[hit]?.Tool == AnnotationTool.Text)
        {
            SetObjectSelectionMode(false);
            BeginEditExistingText(hit);
            e.Handled = true;
            return true;
        }

        if (hit >= 0)
        {
            if (!_selectedAnnotationIndices.Contains(hit))
            {
                _selectedAnnotationIndices.Clear();
                _selectedAnnotationIndices.Add(hit);
                RefreshObjectSelectionChrome();
            }
            StartObjectGroupDrag(displayPoint);
        }
        else
        {
            _selectedAnnotationIndices.Clear();
            _objectMarqueeSelecting = true;
            _objectSelectionStartDisplay = displayPoint;
            ObjectSelectionChrome.ShowSelected(Array.Empty<Rect>());
            ObjectSelectionChrome.ShowMarquee(new Rect(displayPoint, displayPoint));
            ImageFrame.CaptureMouse();
            Cursor = Cursors.Cross;
        }
        e.Handled = true;
        return true;
    }

    private void StartObjectGroupDrag(Point displayPoint)
    {
        if (_selectedAnnotationIndices.Count == 0) return;
        _objectGroupDragging = true;
        _objectDragHistoryRecorded = false;
        _objectDragStartDisplay = displayPoint;
        _objectDragOriginalModels.Clear();
        _objectDragOriginalDrawings.Clear();
        _objectDragOriginalBounds = Rect.Empty;
        foreach (int index in _selectedAnnotationIndices.OrderBy(i => i))
        {
            if ((uint)index >= (uint)Annotations.Drawings.Count) continue;
            _objectDragOriginalDrawings[index] = Annotations.Drawings[index];
            _objectDragOriginalModels[index] = (uint)index < (uint)_annotationModels.Count ? _annotationModels[index] : null;
            var b = Annotations.Drawings[index].Bounds;
            if (!b.IsEmpty) _objectDragOriginalBounds = _objectDragOriginalBounds.IsEmpty ? b : Rect.Union(_objectDragOriginalBounds, b);
        }
        ImageFrame.CaptureMouse();
        Cursor = Cursors.SizeAll;
    }

    private bool UpdateObjectSelectionInteraction(Point displayPoint, MouseEventArgs e)
    {
        if (_objectMarqueeSelecting)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                EndObjectSelectionInteraction(displayPoint);
                return true;
            }
            var marquee = NormalizeObjectRect(_objectSelectionStartDisplay, displayPoint);
            _selectedAnnotationIndices.Clear();
            if (marquee.Width >= 2 || marquee.Height >= 2)
            {
                for (int i = 0; i < Annotations.Drawings.Count; i++)
                {
                    var bounds = GetAnnotationDisplayBounds(i);
                    if (!bounds.IsEmpty && marquee.IntersectsWith(bounds)) _selectedAnnotationIndices.Add(i);
                }
            }
            RefreshObjectSelectionChrome(marquee);
            return true;
        }

        if (_objectGroupDragging)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                EndObjectSelectionInteraction(displayPoint);
                return true;
            }
            UpdateObjectGroupDrag(displayPoint);
            return true;
        }

        if (_objectSelectionMode)
        {
            Cursor = HitSelectedAnnotation(displayPoint) || HitAnnotation(displayPoint) >= 0 ? Cursors.SizeAll : Cursors.Cross;
            return false;
        }
        return false;
    }

    private void UpdateObjectGroupDrag(Point displayPoint)
    {
        if (!_objectGroupDragging) return;
        double displayW = Math.Max(1, ImageFrame.ActualWidth);
        double displayH = Math.Max(1, ImageFrame.ActualHeight);
        var raw = displayPoint - _objectDragStartDisplay;
        double dx = raw.X / displayW * _bitmap.PixelWidth;
        double dy = raw.Y / displayH * _bitmap.PixelHeight;

        if (!_objectDragOriginalBounds.IsEmpty)
        {
            dx = Math.Clamp(dx, -_objectDragOriginalBounds.Left, _bitmap.PixelWidth - _objectDragOriginalBounds.Right);
            dy = Math.Clamp(dy, -_objectDragOriginalBounds.Top, _bitmap.PixelHeight - _objectDragOriginalBounds.Bottom);
        }
        var delta = new Vector(dx, dy);
        if (Math.Abs(delta.X) < .001 && Math.Abs(delta.Y) < .001) return;

        if (!_objectDragHistoryRecorded)
        {
            _history.Record(Annotations, _annotationModels);
            _objectDragHistoryRecorded = true;
        }

        foreach (int index in _selectedAnnotationIndices.OrderBy(i => i))
        {
            if (!_objectDragOriginalDrawings.TryGetValue(index, out var originalDrawing)) continue;
            if (_objectDragOriginalModels.TryGetValue(index, out var originalModel) && originalModel is not null)
            {
                var moved = AnnotationTransforms.Translate(originalModel, delta);
                if ((uint)index < (uint)_annotationModels.Count) _annotationModels[index] = moved;
                Annotations.ReplaceAt(index, AnnotationRenderer.Build(moved));
            }
            else
            {
                var wrapper = new DrawingGroup { Transform = new TranslateTransform(delta.X, delta.Y) };
                wrapper.Children.Add(originalDrawing);
                wrapper.Freeze();
                Annotations.ReplaceAt(index, wrapper);
            }
        }
        _composite = null;
        RefreshObjectSelectionChrome();
    }

    private bool EndObjectSelectionInteraction(Point displayPoint)
    {
        if (!_objectMarqueeSelecting && !_objectGroupDragging) return false;
        if (_objectGroupDragging) UpdateObjectGroupDrag(displayPoint);
        _objectMarqueeSelecting = false;
        _objectGroupDragging = false;
        _objectDragOriginalModels.Clear();
        _objectDragOriginalDrawings.Clear();
        _objectDragOriginalBounds = Rect.Empty;
        if (ImageFrame.IsMouseCaptured) ImageFrame.ReleaseMouseCapture();
        RefreshObjectSelectionChrome();
        ShowSelectedStyle();
        Cursor = _objectSelectionMode ? Cursors.Arrow : Cursors.Arrow;
        UpdateHistoryButtons();
        return true;
    }

    private void CancelObjectSelectionInteraction()
    {
        _objectMarqueeSelecting = false;
        _objectGroupDragging = false;
        _objectDragOriginalModels.Clear();
        _objectDragOriginalDrawings.Clear();
        _objectDragOriginalBounds = Rect.Empty;
        if (ImageFrame?.IsMouseCaptured == true) ImageFrame.ReleaseMouseCapture();
        ObjectSelectionChrome?.ClearMarquee();
    }

    private bool DeleteSelectedAnnotations()
    {
        if (!_objectSelectionMode || _selectedAnnotationIndices.Count == 0) return false;
        _history.Record(Annotations, _annotationModels);
        foreach (int index in _selectedAnnotationIndices.OrderByDescending(i => i))
        {
            if ((uint)index >= (uint)Annotations.Drawings.Count) continue;
            Annotations.RemoveAt(index);
            if ((uint)index < (uint)_annotationModels.Count) _annotationModels.RemoveAt(index);
        }
        _selectedAnnotationIndices.Clear();
        ObjectSelectionChrome.Clear();
        _composite = null;
        UpdateHistoryButtons();
        return true;
    }

    private static Rect NormalizeObjectRect(Point a, Point b) =>
        new(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y), Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));
}
