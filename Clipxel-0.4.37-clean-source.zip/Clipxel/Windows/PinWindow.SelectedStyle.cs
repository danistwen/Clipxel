using System;
using System.Linq;
using Clipxel.Models;
using Clipxel.Rendering;
namespace Clipxel.Windows;
public partial class PinWindow
{
    private bool _loadingSelectedStyle;
    private void EditSelectedStyle(Func<Annotation,Annotation> edit)
    {
        if(_loadingSelectedStyle||!_objectSelectionMode||_selectedAnnotationIndices.Count==0)return;
        _history.Record(Annotations,_annotationModels);
        foreach(int i in _selectedAnnotationIndices.ToArray())
            if(i>=0&&i<_annotationModels.Count&&_annotationModels[i] is Annotation a)
            {_annotationModels[i]=edit(a);Annotations.ReplaceAt(i,AnnotationRenderer.Build(_annotationModels[i]!));}
        _composite=null;RefreshObjectSelectionChrome();UpdateHistoryButtons();
    }
    private void ShowSelectedStyle()
    {
        if(_toolbarWindow is null||_selectedAnnotationIndices.Count==0)return;
        var a=_selectedAnnotationIndices.Where(i=>i>=0&&i<_annotationModels.Count).Select(i=>_annotationModels[i]).FirstOrDefault(a=>a is not null);if(a is null)return;
        _loadingSelectedStyle=true;
        try{_toolbarWindow.ShowSelectedStyle(a);}
        finally{_loadingSelectedStyle=false;}
    }
}
