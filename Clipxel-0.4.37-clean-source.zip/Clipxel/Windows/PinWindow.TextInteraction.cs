using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Clipxel.Rendering;

namespace Clipxel.Windows;

public partial class PinWindow
{
    private int _selectedTextIndex = -1;
    private bool _textDragHistoryRecorded;

    private bool CanInteractWithText => !_objectSelectionMode && !_drawing && !_middlePanning &&
        (_activeTool == AnnotationTool.None || _activeTool == AnnotationTool.Text) &&
        !IsPicking && !Keyboard.Modifiers.HasFlag(ModifierKeys.Alt) && !Keyboard.IsKeyDown(Key.Space);

    private Rect GetTextFrame(int index)
    {
        if ((uint)index >= (uint)_annotationModels.Count || (uint)index >= (uint)Annotations.Drawings.Count ||
            _annotationModels[index]?.Tool != AnnotationTool.Text) return Rect.Empty;
        var bounds = Annotations.Drawings[index].Bounds;
        if (bounds.IsEmpty) return Rect.Empty;
        var frame = new Rect(ToDisplayPoint(bounds.TopLeft), ToDisplayPoint(bounds.BottomRight));
        frame.Inflate(5, 4); // Constant display-space padding at every zoom/DPI.
        frame.Intersect(new Rect(0, 0, Math.Max(0, ImageFrame.ActualWidth), Math.Max(0, ImageFrame.ActualHeight)));
        return frame;
    }

    private bool HitTextFrame(Point point, out int index)
    {
        for (int i = Math.Min(_annotationModels.Count, Annotations.Drawings.Count) - 1; i >= 0; i--)
            if (GetTextFrame(i).Contains(point)) { index = i; return true; }
        index = -1;
        return false;
    }

    private void ClearTextSelection()
    {
        if (_draggingText) EndTextDrag();
        _selectedTextIndex = -1;
        TextChrome?.Clear();
    }

    private bool UpdateTextFeedback(Point point)
    {
        if (!CanInteractWithText || AnnotationTextEditor.Visibility == Visibility.Visible)
        {
            TextChrome.Clear();
            return false;
        }
        var selected = GetTextFrame(_selectedTextIndex);
        if (!selected.IsEmpty)
        {
            TextChrome.Show(selected, true);
            if (selected.Contains(point)) { Cursor = Cursors.SizeAll; return true; }
        }
        else
        {
            _selectedTextIndex = -1;
            if (HitTextFrame(point, out int hover))
            {
                TextChrome.Show(GetTextFrame(hover), false);
                Cursor = Cursors.IBeam;
                return true;
            }
            TextChrome.Clear();
        }
        return false;
    }

    private bool TryHandleTextPointerDown(Point point, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return false;
        if (AnnotationTextEditor.Visibility == Visibility.Visible)
        {
            var local = ImageFrame.TranslatePoint(point, AnnotationTextEditor);
            if (new Rect(AnnotationTextEditor.RenderSize).Contains(local))
            {
                if (!TextAnnotationChrome.IsEditorEdge(local, AnnotationTextEditor.RenderSize)) return false;
                int index = _editingTextIndex >= 0 ? _editingTextIndex : _annotationModels.Count;
                CommitTextEditor();
                if ((uint)index < (uint)_annotationModels.Count && _annotationModels[index]?.Tool == AnnotationTool.Text)
                {
                    _selectedTextIndex = index;
                    TextChrome.Show(GetTextFrame(index), true);
                    Keyboard.Focus(this);
                    StartTextDrag(index, ToBitmapPoint(point));
                }
                e.Handled = true;
                return true;
            }
            CommitTextEditor();
        }
        if (!CanInteractWithText) return false;
        if (GetTextFrame(_selectedTextIndex).Contains(point))
        {
            if (e.ClickCount == 2) BeginEditExistingText(_selectedTextIndex);
            else { Keyboard.Focus(this); StartTextDrag(_selectedTextIndex, ToBitmapPoint(point)); }
            e.Handled = true;
            return true;
        }
        ClearTextSelection();
        if (!HitTextFrame(point, out int hit)) return false;
        BeginEditExistingText(hit);
        e.Handled = true;
        return true;
    }

    private bool DeleteSelectedText()
    {
        if (AnnotationTextEditor.IsKeyboardFocusWithin || GetTextFrame(_selectedTextIndex).IsEmpty) return false;
        if (_draggingText) EndTextDrag();
        int index = _selectedTextIndex;
        _history.Record(Annotations, _annotationModels);
        Annotations.RemoveAt(index);
        _annotationModels.RemoveAt(index);
        ClearTextSelection();
        _composite = null;
        UpdateHistoryButtons();
        Keyboard.Focus(this);
        return true;
    }

    private void TextEditor_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        AnnotationTextEditor.Cursor = TextAnnotationChrome.IsEditorEdge(e.GetPosition(AnnotationTextEditor), AnnotationTextEditor.RenderSize)
            ? Cursors.SizeAll : Cursors.IBeam;
    }
}
