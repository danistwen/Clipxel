using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Microsoft.Win32;
using Clipxel.Models;
using Clipxel.Rendering;
using Clipxel.Services;

namespace Clipxel.Windows;

public partial class PinWindow : Window
{
    private string _fontFamily = "Segoe UI";

    private LineStyle _lineStyle;

    internal BitmapSource ProjectBitmap => _bitmap;
    internal IEnumerable<Annotation> ProjectAnnotations => _annotationModels.OfType<Annotation>();
    private readonly BitmapSource _bitmap;
    private BitmapSource? _pixelBitmap;
    private BitmapSource? _composite;
    private readonly AnnotationHistory _history = new();
    private readonly List<Annotation?> _annotationModels = new();
    private Annotation? _draft;
    private AnnotationTool _activeTool;
    private Point? _pendingTextPoint;
    private Color _pendingTextColor;
    private int _editingTextIndex = -1;
    private Annotation? _editingTextOriginalModel;
    private DrawingGroup? _editingTextOriginalDrawing;
    private bool _draggingText;
    private int _draggingTextIndex = -1;
    private Point _dragTextMouseStart;
    private Point _dragTextAnnotationStart;
    private bool _drawing, _pickerEnabled, _renderQueued, _draftDirty, _zoomPending;
    private bool _toolbarVisible, _closed, _saving, _copying;
    private double _scale = 1;
    private double _zoomAnchorCenterX;
    private double _zoomAnchorCenterY;
    private bool _zoomAnchorInitialized;
    private PieMenuWindow? _pieMenuWindow;
    private Color _annotationColor = Colors.White;
    private double _strokeWidth = 3;
    private double _fontSize = 22;
    private bool _shapeStrokeEnabled = true;
    private bool _shapeFillEnabled;
    private double _shapeStrokeOpacity = 1.0;
    private double _shapeFillOpacity = 0.45;
    private bool _enforcingAspectRatio;
    private bool _middlePanning;
    private (int X, int Y) _middlePanStartCursor;
    private PixelRect _middlePanStartBounds;
    private readonly DispatcherTimer _toastTimer;
    private readonly DispatcherTimer _qualityTimer;
    private readonly DispatcherTimer _zoomBadgeTimer;
    private readonly DispatcherTimer _toolbarHideTimer;
    private ToolbarWindow? _toolbarWindow;
    private readonly byte[] _sample = new byte[4];
    private readonly byte[] _regionPixels = new byte[9 * 9 * 4];
    private readonly byte[] _lensPixels = new byte[9 * 9 * 4];
    private readonly WriteableBitmap _lensBitmap = new(9, 9, 96, 96, PixelFormats.Bgra32, null);
    private int _lastPixelX = -1, _lastPixelY = -1;

    public PinWindow(BitmapSource bitmap, IEnumerable<Annotation>? initialAnnotations = null)
    {
        InitializeComponent();
        AllowDrop=true;
        DragOver += (_, e) => { e.Effects=e.Data.GetDataPresent(DataFormats.FileDrop)?DragDropEffects.Copy:DragDropEffects.None; e.Handled=true; };
        Drop += (_,e) => { if(e.Data.GetData(DataFormats.FileDrop) is string[] paths) ((App)Application.Current).ImportReferenceFiles(paths);e.Handled=true; };
        var gestures = GestureTools.AnnotationActions;
        AnnotationTextEditor.PreviewMouseRightButtonDown+=(_,e)=>{SetAnnotationTool(AnnotationTool.None);e.Handled=true;};
        RadialGesture.Attach(ImageFrame, GestureTools.AnnotationLabels, i => HandlePieMenuAction(gestures[i]), ShowPieMenu, () => !AnnotationTextEditor.IsMouseOver, mapping:()=>App.Settings.AnnotationDirections,cancelTool:()=>{bool active=HasPersistentTool;SetAnnotationTool(AnnotationTool.None);return active;});
        _annotationColor = App.Settings.AnnotationColor;
        _fontSize = App.Settings.FontSize;
        _strokeWidth = App.Settings.StrokeWidth;
        _bitmap = bitmap;
        if (!_bitmap.IsFrozen && _bitmap.CanFreeze) _bitmap.Freeze();
        PinnedImage.Source = bitmap;
        if (initialAnnotations is not null)
        {
            foreach (var source in initialAnnotations)
            {
                var model = AnnotationTransforms.Clone(source);
                _annotationModels.Add(model);
                Annotations.Add(AnnotationRenderer.Build(model));
            }
        }
        MagnifierImage.Source = _lensBitmap;
        _toastTimer = OneShot(1200, () => CopiedToast.Visibility = Visibility.Collapsed);
        _qualityTimer = OneShot(120, () =>
        {
            RenderOptions.SetBitmapScalingMode(PinnedImage, BitmapScalingMode.HighQuality);
        });
        _zoomBadgeTimer = OneShot(700, () => ZoomBadge.Visibility = Visibility.Collapsed);
        _toolbarHideTimer = OneShot(150, TryAutoHideToolbar);
        // A small provisional size avoids showing a full-size image before placement.
        Width = 160;
        Height = 100;
        Loaded += (_, _) =>
        {
            var area = WindowPlacementService.WorkAreaAtCursor();
            _scale = ClampScale(Math.Min(1, Math.Min(area.Width * .72 / _bitmap.PixelWidth,
                area.Height * .64 / _bitmap.PixelHeight)));
            int width = Math.Max(1, (int)Math.Round(_bitmap.PixelWidth * _scale));
            int height = Math.Max(1, (int)Math.Round(_bitmap.PixelHeight * _scale));
            var cursor = WindowPlacementService.CursorPosition;
            int x = Math.Clamp(cursor.X - width / 2, area.X, Math.Max(area.X, area.Right - width));
            int y = Math.Clamp(cursor.Y - height / 2, area.Y, Math.Max(area.Y, area.Bottom - height));
            WindowPlacementService.SetBounds(this, new PixelRect(x, y, width, height));
            SetZoomAnchor(x + width / 2.0, y + height / 2.0);
            UpdateAnnotationScale();
            CreateToolbar();
        };
        LocationChanged += (_, _) => PositionToolbar();
        ImageFrame.SizeChanged += (_, _) =>
        {
            UpdateAnnotationScale();
            RefreshObjectSelectionChrome();
        };
        SizeChanged += (_, _) =>
        {
            EnforceAspectRatioFromCurrentBounds();
            PositionToolbar();
        };
        Deactivated += (_, _) => ColorLens.Visibility = Visibility.Collapsed;
        PreviewKeyUp += (_, e) =>
        {
            if (e.Key is Key.LeftAlt or Key.RightAlt or Key.System)
                if (!_pickerEnabled) ColorLens.Visibility = Visibility.Collapsed;
        };
        Closed += (_, _) =>
        {
            _closed = true;
            _toastTimer.Stop();
            _qualityTimer.Stop();
            _zoomBadgeTimer.Stop();
            _toolbarHideTimer.Stop();
            if (_renderQueued) CompositionTarget.Rendering -= RenderFrame;
            _renderQueued = false;
            _toolbarWindow?.Close();
            _toolbarWindow = null;
            _pieMenuWindow?.Dismiss();
            _pieMenuWindow = null;
            _composite = null;
        };
    }

    private static DispatcherTimer OneShot(int milliseconds, Action action)
    {
        var timer = new DispatcherTimer(DispatcherPriority.Background)
            { Interval = TimeSpan.FromMilliseconds(milliseconds) };
        timer.Tick += (_, _) => { timer.Stop(); action(); };
        return timer;
    }

    private static void Restart(DispatcherTimer timer) { timer.Stop(); timer.Start(); }

    protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
    {
        base.OnDpiChanged(oldDpi, newDpi);
        if (!IsLoaded || _closed) return;
        _zoomPending = true;
        QueueRender();
    }

    private void CreateToolbar()
    {
        _toolbarWindow = new ToolbarWindow { Owner = this };
        _toolbarWindow.LineStyleSelected += style => _lineStyle = style;
        _toolbarWindow.ToolSelected += SetAnnotationTool;
        _toolbarWindow.ModeSwitchRequested += (_, _) => (Application.Current as App)?.ToggleReferenceMode();
        _toolbarWindow.SelectRequested += (_, _) => ToggleObjectSelectionMode();
        _toolbarWindow.AnnotationColorSelected += color => { _annotationColor = color;if(AnnotationTextEditor.Visibility==Visibility.Visible)AnnotationTextEditor.Foreground=new SolidColorBrush(color); };
        _toolbarWindow.StrokeWidthSelected += width => _strokeWidth = width;
        _toolbarWindow.StrokeWidthSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,width:v));
        _toolbarWindow.AnnotationColorSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,color:AnnotationStyle.Visible(v)));
        _toolbarWindow.ShapeStrokeEnabledSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,stroke:v));
        _toolbarWindow.ShapeFillEnabledSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,fill:v));
        _toolbarWindow.ShapeStrokeOpacitySelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,strokeOpacity:Math.Max(.05,v)));
        _toolbarWindow.ShapeFillOpacitySelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,fillOpacity:Math.Max(.05,v)));
        _toolbarWindow.LineStyleSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,line:v));
        _toolbarWindow.FontSizeSelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,fontSize:v));
        _toolbarWindow.FontFamilySelected += v=>EditSelectedStyle(a=>AnnotationStyle.With(a,font:v));
        _toolbarWindow.FontFamilySelected += family => { _fontFamily = family; AnnotationTextEditor.FontFamily = new FontFamily(family); };
        _toolbarWindow.FontSizeSelected += SetFontSize;
        _toolbarWindow.ShapeStrokeEnabledSelected += enabled => _shapeStrokeEnabled = enabled;
        _toolbarWindow.ShapeFillEnabledSelected += enabled => _shapeFillEnabled = enabled;
        _toolbarWindow.ShapeStrokeOpacitySelected += opacity => _shapeStrokeOpacity = opacity;
        _toolbarWindow.ShapeFillOpacitySelected += opacity => _shapeFillOpacity = opacity;
        _toolbarWindow.UndoRequested += (_, _) => UndoAnnotation();
        _toolbarWindow.RedoRequested += (_, _) => RedoAnnotation();
        _toolbarWindow.PickRequested += (_, _) => TogglePicker();
        _toolbarWindow.CopyRequested += (_, _) => CopyImage();
        _toolbarWindow.SaveRequested += (_, _) => SaveImage();
        _toolbarWindow.ResetRequested += (_, _) => ResetOneToOne();
        _toolbarWindow.CloseRequested += (_, _) => Close();
        _toolbarWindow.SizeUpdated += (_, _) => PositionToolbar();
        _toolbarWindow.MouseEnter += (_, _) => _toolbarHideTimer.Stop();
        _toolbarWindow.MouseLeave += (_, _) => ScheduleToolbarHide();
        _toolbarWindow.PopupClosed += ScheduleToolbarHide;
        _toolbarWindow.SetAnnotationColor(_annotationColor);
        _toolbarWindow.SetStrokeWidth(_strokeWidth);
        _toolbarWindow.SetFontSize(_fontSize);
        _toolbarWindow.SetShapeStyle(_shapeStrokeEnabled, _shapeFillEnabled, _shapeStrokeOpacity, _shapeFillOpacity);
        _toolbarWindow.SetSelectActive(_objectSelectionMode);
        UpdateHistoryButtons();
    }

    private void ShowToolbar()
    {
        if (_toolbarWindow is null || _closed || !IsVisible) return;
        _toolbarHideTimer.Stop();
        _toolbarVisible = true;
        _toolbarWindow.BeginAnimation(OpacityProperty, null);
        if (!_toolbarWindow.IsVisible)
        {
            _toolbarWindow.Opacity = 0;
            _toolbarWindow.Show();
        }
        PositionToolbar();
        _toolbarWindow.BeginAnimation(OpacityProperty, new DoubleAnimation
        {
            To = 1,
            Duration = TimeSpan.FromMilliseconds(125),
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        });
    }

    private void HideToolbar(bool immediate = false)
    {
        _toolbarHideTimer.Stop();
        _toolbarVisible = false;
        if (_toolbarWindow is null) return;
        _toolbarWindow.ClosePopups();
        if (!_toolbarWindow.IsVisible) return;

        _toolbarWindow.BeginAnimation(OpacityProperty, null);
        if (immediate)
        {
            _toolbarWindow.Opacity = 1;
            _toolbarWindow.Hide();
            return;
        }

        var fade = new DoubleAnimation
        {
            To = 0,
            Duration = TimeSpan.FromMilliseconds(110),
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
        };
        fade.Completed += (_, _) =>
        {
            if (_toolbarWindow is null || _toolbarVisible || !_toolbarWindow.IsVisible) return;
            _toolbarWindow.BeginAnimation(OpacityProperty, null);
            _toolbarWindow.Opacity = 1;
            _toolbarWindow.Hide();
        };
        _toolbarWindow.BeginAnimation(OpacityProperty, fade);
    }

    private bool HasPersistentTool => _activeTool != AnnotationTool.None || _pickerEnabled || _objectSelectionMode;

    private const double ToolbarEdgeRevealInsideDip = 2.0;
    private const double ToolbarHiddenRevealMinDip = 40.0;
    private const double ToolbarHiddenRevealMaxDip = 110.0;
    private const double ToolbarHiddenRevealRatio = 0.14;
    private const double ToolbarVisibleCorridorBelowDip = 18.0;
    private const double ToolbarVisibleCorridorAboveDip = 10.0;

    private void ScheduleToolbarHide()
    {
        if (HasPersistentTool || !_toolbarVisible || _toolbarWindow?.HasOpenPopup==true) return;
        if (!_toolbarHideTimer.IsEnabled)
            _toolbarHideTimer.Start();
    }

    private bool IsCursorInsideToolbar((int X, int Y) cursor)
    {
        if (_toolbarWindow?.IsVisible != true) return false;
        var bar = WindowPlacementService.Bounds(_toolbarWindow);
        return cursor.X >= bar.X && cursor.X < bar.Right && cursor.Y >= bar.Y && cursor.Y < bar.Bottom;
    }

    private bool IsCursorInsideRevealBand((int X, int Y) cursor)
    {
        var owner = WindowPlacementService.Bounds(this);
        var dpi = VisualTreeHelper.GetDpi(this);

        int hiddenBandPx = Math.Max(1, (int)Math.Round(Math.Clamp(ImageFrame.ActualHeight * ToolbarHiddenRevealRatio,
            ToolbarHiddenRevealMinDip, ToolbarHiddenRevealMaxDip) * dpi.DpiScaleY));
        int visibleBelowPx = Math.Max(1, (int)Math.Round(ToolbarVisibleCorridorBelowDip * dpi.DpiScaleY));
        int visibleAbovePx = Math.Max(0, (int)Math.Round(ToolbarVisibleCorridorAboveDip * dpi.DpiScaleY));

        int left = owner.X;
        int right = owner.Right;
        int top = owner.Bottom;
        int bottom = owner.Bottom + hiddenBandPx;

        if (_toolbarWindow?.IsVisible == true)
        {
            var bar = WindowPlacementService.Bounds(_toolbarWindow);
            top = Math.Min(top, bar.Y - visibleAbovePx);
            bottom = Math.Max(bottom, bar.Bottom + visibleBelowPx);
        }

        return cursor.X >= left && cursor.X < right && cursor.Y >= top && cursor.Y <= bottom;
    }

    private void TryAutoHideToolbar()
    {
        if (!_toolbarVisible || HasPersistentTool || _toolbarWindow is null || _toolbarWindow.HasOpenPopup) return;
        var cursor = WindowPlacementService.CursorPosition;

        if (IsCursorInsideToolbar(cursor) || IsCursorInsideRevealBand(cursor))
        {
            // Keep polling while the pointer remains within the bottom reveal
            // corridor that spans the screenshot width and scales with image size.
            _toolbarHideTimer.Start();
            return;
        }

        HideToolbar();
    }

    private void UpdateToolbarProximity(Point p)
    {
        if (_middlePanning || _drawing || _closed) return;

        bool touchingLowerEdge = p.X >= 0 && p.X <= ImageFrame.ActualWidth &&
                                 p.Y >= Math.Max(0, ImageFrame.ActualHeight - ToolbarEdgeRevealInsideDip) &&
                                 p.Y <= ImageFrame.ActualHeight;

        if (touchingLowerEdge)
        {
            ShowToolbar();
            ScheduleToolbarHide();
        }
        else if (!HasPersistentTool)
        {
            ScheduleToolbarHide();
        }
    }

    private void PositionToolbar()
    {
        if (!_toolbarVisible || _toolbarWindow?.IsVisible != true) return;
        var owner = WindowPlacementService.Bounds(this);
        var bar = WindowPlacementService.Bounds(_toolbarWindow);
        var area = WindowPlacementService.WorkArea(this);
        double availableWidth = area.Width / VisualTreeHelper.GetDpi(_toolbarWindow).DpiScaleX;
        if (Math.Abs(_toolbarWindow.MaxWidth - availableWidth) > .5)
            _toolbarWindow.MaxWidth = availableWidth;
        int stableWidth = (int)Math.Ceiling(_toolbarWindow.ExpandedWidthDip * VisualTreeHelper.GetDpi(_toolbarWindow).DpiScaleX);
        int gap = Math.Max(1, (int)Math.Round(3 * VisualTreeHelper.GetDpi(this).DpiScaleY));
        int x = Math.Clamp(owner.X, area.X, Math.Max(area.X, area.Right - stableWidth));
        int y = owner.Bottom + gap;
        if (y + bar.Height > area.Bottom) y = owner.Y - gap - bar.Height;
        y = Math.Clamp(y, area.Y, Math.Max(area.Y, area.Bottom - bar.Height));
        WindowPlacementService.Move(_toolbarWindow, x, y);
    }

    private const double MaximumZoomScale = 8.0;          // 800%
    // Keep the native HWND safely below the edge where Windows can clamp only
    // one axis and create a visible aspect-ratio error.
    private const double MaximumNativeWindowExtent = 30000.0;
    private const double WheelZoomBase = 1.14;             // ~14% per wheel notch

    internal static double ComputeMaximumScale(int pixelWidth, int pixelHeight)
    {
        int largestSide = Math.Max(1, Math.Max(pixelWidth, pixelHeight));
        return Math.Min(MaximumZoomScale, MaximumNativeWindowExtent / largestSide);
    }

    private double ClampScale(double requested)
    {
        var dpi = VisualTreeHelper.GetDpi(this);
        double minimum = Math.Max(.04, Math.Max(dpi.DpiScaleX / _bitmap.PixelWidth, dpi.DpiScaleY / _bitmap.PixelHeight));
        double maximum = Math.Max(minimum, ComputeMaximumScale(_bitmap.PixelWidth, _bitmap.PixelHeight));
        return Math.Clamp(requested, minimum, maximum);
    }

    private void SetZoomAnchor(double centerX, double centerY)
    {
        _zoomAnchorCenterX = centerX;
        _zoomAnchorCenterY = centerY;
        _zoomAnchorInitialized = true;
    }

    private void RefreshZoomAnchorFromCurrentBounds()
    {
        if (!IsLoaded || _closed) return;
        var bounds = WindowPlacementService.Bounds(this);
        SetZoomAnchor(bounds.X + bounds.Width / 2.0, bounds.Y + bounds.Height / 2.0);
    }

    internal static PixelRect ComputeCenteredBounds(int pixelWidth, int pixelHeight,
        double centerX, double centerY, double scale)
    {
        int targetWidth = Math.Max(1, (int)Math.Round(pixelWidth * scale));
        int targetHeight = Math.Max(1, (int)Math.Round(pixelHeight * scale));
        int x = (int)Math.Round(centerX - targetWidth / 2.0);
        int y = (int)Math.Round(centerY - targetHeight / 2.0);
        return new PixelRect(x, y, targetWidth, targetHeight);
    }

    private PixelRect BoundsForScale(double scale)
    {
        if (!_zoomAnchorInitialized)
            RefreshZoomAnchorFromCurrentBounds();

        // Keep one logical center for the entire zoom sequence. Oversized HWNDs
        // can be nudged by Windows once they extend beyond the monitor; never use
        // that OS-adjusted position as the next wheel event's center or the pin
        // will visibly drift on every notch.
        return ComputeCenteredBounds(_bitmap.PixelWidth, _bitmap.PixelHeight,
            _zoomAnchorCenterX, _zoomAnchorCenterY, scale);
    }

    private void EnforceAspectRatioFromCurrentBounds()
    {
        if (!IsLoaded || _closed || _enforcingAspectRatio) return;

        var bounds = WindowPlacementService.Bounds(this);
        if (bounds.Width <= 0 || bounds.Height <= 0 || _bitmap.PixelWidth <= 0 || _bitmap.PixelHeight <= 0)
            return;

        // Ignore the unavoidable one-pixel rounding difference. Anything larger
        // means one axis has been altered independently and needs correction.
        long crossError = Math.Abs((long)bounds.Width * _bitmap.PixelHeight -
                                   (long)bounds.Height * _bitmap.PixelWidth);
        long tolerance = Math.Max(_bitmap.PixelWidth, _bitmap.PixelHeight) * 2L;
        if (crossError <= tolerance)
            return;

        double scaleFromWidth = bounds.Width / (double)_bitmap.PixelWidth;
        double scaleFromHeight = bounds.Height / (double)_bitmap.PixelHeight;

        // Use the smaller valid scale so a clamped/oversized axis is pulled back
        // into ratio instead of stretching the other axis to match it.
        double uniformScale = ClampScale(Math.Min(scaleFromWidth, scaleFromHeight));
        var corrected = BoundsForScale(uniformScale);

        _enforcingAspectRatio = true;
        try
        {
            _scale = uniformScale;
            WindowPlacementService.SetBounds(this, corrected);
        }
        finally
        {
            _enforcingAspectRatio = false;
        }
    }

    private void ApplyScale()
    {
        _scale = ClampScale(_scale);
        // Width and height always come from one scalar and use a persistent
        // logical center, so an oversized window cannot accumulate OS clamp drift.
        WindowPlacementService.SetBounds(this, BoundsForScale(_scale));
    }

    private void UpdateAnnotationScale()
    {
        if (_bitmap is null) return;
        Annotations.SetScale(ImageFrame.ActualWidth / _bitmap.PixelWidth, ImageFrame.ActualHeight / _bitmap.PixelHeight);
    }

    private void QueueRender()
    {
        if (_renderQueued || _closed) return;
        _renderQueued = true;
        CompositionTarget.Rendering += RenderFrame;
    }

    private void RenderFrame(object? sender, EventArgs e)
    {
        CompositionTarget.Rendering -= RenderFrame;
        _renderQueued = false;
        if (_closed) return;
        if (_zoomPending) { _zoomPending = false; ApplyScale(); }
        if (_draftDirty)
        {
            _draftDirty = false;
            Annotations.SetDraft(_draft is null ? null : AnnotationRenderer.Build(_draft));
        }
    }

    private bool IsPicking => _pickerEnabled || Keyboard.Modifiers.HasFlag(ModifierKeys.Alt);
    private void ToggleToolbarVisibility()
    {
        if (_toolbarVisible) HideToolbar(); else ShowToolbar();
    }

    private void SetAnnotationTool(AnnotationTool tool)
    {
        CommitTextEditor();
        ClearTextSelection();
        CancelDraft();
        if (_objectSelectionMode)
        {
            _objectSelectionMode = false;
            ClearObjectSelection();
            _toolbarWindow?.SetSelectActive(false);
        }
        _pickerEnabled = false;
        ColorLens.Visibility = Visibility.Collapsed;
        _activeTool = _activeTool == tool ? AnnotationTool.None : tool;
        _toolbarWindow?.SetActiveTool(_activeTool);
        if (_activeTool == AnnotationTool.Text) _toolbarWindow?.SetFontSize(_fontSize);
        _toolbarWindow?.SetPickerActive(false);
        Cursor = _activeTool == AnnotationTool.None ? Cursors.Arrow : Cursors.Cross;
        if (_activeTool != AnnotationTool.None) ShowToolbar();
        else ScheduleToolbarHide();
    }

    private void SetFontSize(double size)
    {
        _fontSize = Math.Clamp(Math.Round(size), 8, 120);
        if (AnnotationTextEditor.Visibility == Visibility.Visible)
            AnnotationTextEditor.FontSize = Math.Clamp(_fontSize * ImageFrame.ActualHeight / Math.Max(1, _bitmap.PixelHeight), 8, 120);
    }

    private Point ToBitmapPoint(Point p) => new(
        Math.Clamp(p.X / Math.Max(1, ImageFrame.ActualWidth) * _bitmap.PixelWidth, 0, _bitmap.PixelWidth),
        Math.Clamp(p.Y / Math.Max(1, ImageFrame.ActualHeight) * _bitmap.PixelHeight, 0, _bitmap.PixelHeight));

    private Point ToDisplayPoint(Point p) => new(
        p.X / Math.Max(1, _bitmap.PixelWidth) * ImageFrame.ActualWidth,
        p.Y / Math.Max(1, _bitmap.PixelHeight) * ImageFrame.ActualHeight);

    private static Annotation CopyTextAnnotation(Annotation source, Point? start = null, string? text = null, double? fontSize = null, string? fontFamily = null) => new()
    {
        Tool = AnnotationTool.Text,
        Start = start ?? source.Start,
        End = start ?? source.End,
        Text = text ?? source.Text,
        Color = source.Color,
        StrokeWidth = source.StrokeWidth, LineStyle = source.LineStyle,
        FontSize = fontSize ?? source.FontSize, FontFamily = fontFamily ?? source.FontFamily,
        RectangleMode = source.RectangleMode,
        UsesIndependentShapeStyle = source.UsesIndependentShapeStyle,
        ShapeStrokeEnabled = source.ShapeStrokeEnabled,
        ShapeFillEnabled = source.ShapeFillEnabled,
        StrokeOpacity = source.StrokeOpacity,
        FillOpacity = source.FillOpacity
    };

    private static DrawingGroup EmptyDrawing()
    {
        var drawing = new DrawingGroup();
        drawing.Freeze();
        return drawing;
    }

    private bool TryHitTextAnnotation(Point bitmapPoint, out int index)
    {
        for (int i = Math.Min(_annotationModels.Count, Annotations.Drawings.Count) - 1; i >= 0; i--)
        {
            var model = _annotationModels[i];
            if (model?.Tool != AnnotationTool.Text) continue;
            var bounds = Annotations.Drawings[i].Bounds;
            if (bounds.IsEmpty) continue;
            bounds.Inflate(5, 4);
            if (bounds.Contains(bitmapPoint))
            {
                index = i;
                return true;
            }
        }
        index = -1;
        return false;
    }

    private void BeginEditExistingText(int index)
    {
        CommitTextEditor();
        ClearTextSelection();
        if ((uint)index >= (uint)_annotationModels.Count || (uint)index >= (uint)Annotations.Drawings.Count) return;
        var model = _annotationModels[index];
        if (model?.Tool != AnnotationTool.Text) return;

        _editingTextIndex = index;
        _editingTextOriginalModel = model;
        _editingTextOriginalDrawing = Annotations.Drawings[index];
        _pendingTextPoint = model.Start;
        _pendingTextColor = model.Color;
        _fontSize = Math.Clamp(model.FontSize, 8, 120);
        Annotations.ReplaceAt(index, EmptyDrawing());

        var display = ToDisplayPoint(model.Start);
        AnnotationTextEditor.Foreground = new SolidColorBrush(model.Color);
        AnnotationTextEditor.Text = model.Text;
        AnnotationTextEditor.Width = Math.Min(260, Math.Max(70, ImageFrame.ActualWidth - display.X));
        AnnotationTextEditor.FontFamily = new FontFamily(model.FontFamily);
        _fontFamily = model.FontFamily;
        AnnotationTextEditor.FontSize = Math.Clamp(model.FontSize * ImageFrame.ActualHeight / Math.Max(1, _bitmap.PixelHeight), 8, 120);
        AnnotationTextEditor.Margin = new Thickness(display.X, display.Y, 0, 0);
        AnnotationTextEditor.Visibility = Visibility.Visible;
        _pickerEnabled = false;
        _activeTool = AnnotationTool.Text;
        _toolbarWindow?.SetPickerActive(false);
        _toolbarWindow?.SetActiveTool(AnnotationTool.Text);
        _toolbarWindow?.SetFontSize(_fontSize);
        ShowToolbar();
        Keyboard.Focus(AnnotationTextEditor);
        AnnotationTextEditor.SelectAll();
    }

    private void StartTextDrag(int index, Point bitmapPoint)
    {
        if ((uint)index >= (uint)_annotationModels.Count) return;
        var model = _annotationModels[index];
        if (model?.Tool != AnnotationTool.Text) return;
        _draggingText = true;
        _draggingTextIndex = index;
        _dragTextMouseStart = bitmapPoint;
        _dragTextAnnotationStart = model.Start;
        _textDragHistoryRecorded = false;
        ImageFrame.CaptureMouse();
        Cursor = Cursors.SizeAll;
    }

    private void UpdateTextDrag(Point bitmapPoint)
    {
        if (!_draggingText || (uint)_draggingTextIndex >= (uint)_annotationModels.Count) return;
        var model = _annotationModels[_draggingTextIndex];
        if (model?.Tool != AnnotationTool.Text) return;
        var delta = bitmapPoint - _dragTextMouseStart;
        var start = new Point(
            Math.Clamp(_dragTextAnnotationStart.X + delta.X, 0, _bitmap.PixelWidth),
            Math.Clamp(_dragTextAnnotationStart.Y + delta.Y, 0, _bitmap.PixelHeight));
        if (start == model.Start) return;
        if (!_textDragHistoryRecorded)
        {
            _history.Record(Annotations, _annotationModels);
            _textDragHistoryRecorded = true;
        }
        var moved = CopyTextAnnotation(model, start);
        _annotationModels[_draggingTextIndex] = moved;
        Annotations.ReplaceAt(_draggingTextIndex, AnnotationRenderer.Build(moved));
        _composite = null;
        TextChrome.Show(GetTextFrame(_draggingTextIndex), true);
    }

    private void EndTextDrag()
    {
        if (!_draggingText) return;
        _draggingText = false;
        _draggingTextIndex = -1;
        if (ImageFrame.IsMouseCaptured) ImageFrame.ReleaseMouseCapture();
        Cursor = _activeTool == AnnotationTool.Text ? Cursors.Cross : Cursors.Arrow;
        UpdateHistoryButtons();
    }

    private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (!_objectSelectionMode && TryHandleTextPointerDown(e.GetPosition(ImageFrame), e)) return;
        if (AnnotationTextEditor.IsMouseOver) return;

        if (e.ChangedButton == MouseButton.Left && e.ClickCount == 2 && ImageFrame.IsMouseOver)
        {
            if ((_activeTool == AnnotationTool.None || _activeTool == AnnotationTool.Text) &&
                TryHitTextAnnotation(ToBitmapPoint(e.GetPosition(ImageFrame)), out int textIndex))
            {
                if (_objectSelectionMode) SetObjectSelectionMode(false);
                BeginEditExistingText(textIndex);
                e.Handled = true;
                return;
            }

            CommitTextEditor();
            if (_drawing) CancelDraft();

            if (_objectSelectionMode)
            {
                SetObjectSelectionMode(false);
                ShowToast("已退出選取模式");
            }
            else if (_activeTool != AnnotationTool.None)
            {
                var active = _activeTool;
                SetAnnotationTool(active);
                ShowToast("已退出標註工具");
            }
            else if (_pickerEnabled)
            {
                TogglePicker();
                ShowToast("已退出取色工具");
            }
            else
            {
                Close();
            }
            e.Handled = true;
            return;
        }

        if (e.ChangedButton != MouseButton.Middle || _drawing || _draggingText) return;
        CommitTextEditor();
        _middlePanning = true;
        _middlePanStartCursor = WindowPlacementService.CursorPosition;
        _middlePanStartBounds = WindowPlacementService.Bounds(this);
        Cursor = Cursors.SizeAll;
        Mouse.Capture(this, CaptureMode.SubTree);
        e.Handled = true;
    }

    private void Window_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (_middlePanning)
        {
            if (e.MiddleButton != MouseButtonState.Pressed)
            {
                EndMiddlePan();
                return;
            }

            var cursor = WindowPlacementService.CursorPosition;
            int dx = cursor.X - _middlePanStartCursor.X;
            int dy = cursor.Y - _middlePanStartCursor.Y;
            WindowPlacementService.SetBounds(this, new PixelRect(
                _middlePanStartBounds.X + dx,
                _middlePanStartBounds.Y + dy,
                _middlePanStartBounds.Width,
                _middlePanStartBounds.Height));
            e.Handled = true;
            return;
        }

        UpdateToolbarProximity(e.GetPosition(ImageFrame));
    }

    private void Window_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Middle || !_middlePanning) return;
        EndMiddlePan();
        e.Handled = true;
    }

    private void EndMiddlePan()
    {
        if (!_middlePanning) return;
        _middlePanning = false;
        if (Mouse.Captured == this) Mouse.Capture(null);
        Cursor = (_activeTool != AnnotationTool.None || IsPicking) ? Cursors.Cross : Cursors.Arrow;
        RefreshZoomAnchorFromCurrentBounds();
    }

    private void ImageFrame_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (AnnotationTextEditor.IsMouseOver) return;
        Activate();
        CommitTextEditor();
        Point displayPoint = e.GetPosition(ImageFrame);
        if (TryBeginObjectSelection(displayPoint, e)) return;
        if (IsPicking)
        {
            UpdateColorLens(displayPoint);
            CopyCurrentHex();
            e.Handled = true;
            return;
        }
        if (_activeTool != AnnotationTool.None && !Keyboard.IsKeyDown(Key.Space))
        {
            if (_activeTool == AnnotationTool.Text)
            {
                Point bitmapPoint = ToBitmapPoint(displayPoint);
                if (TryHitTextAnnotation(bitmapPoint, out int textIndex))
                    BeginEditExistingText(textIndex);
                else
                    BeginTextAnnotation(displayPoint);
            }
            else
            {
                Point p = ToBitmapPoint(displayPoint);
                _draft = new Annotation
                {
                    Tool = _activeTool, Start = p, End = p, Color = AnnotationStyle.Visible(_annotationColor),
                    StrokeWidth = _strokeWidth, LineStyle = _lineStyle,
                    UsesIndependentShapeStyle = _activeTool == AnnotationTool.Rectangle || _activeTool == AnnotationTool.Circle,
                    ShapeStrokeEnabled = _shapeStrokeEnabled,
                    ShapeFillEnabled = _shapeFillEnabled,
                    StrokeOpacity = Math.Max(.05,_shapeStrokeOpacity),
                    FillOpacity = Math.Max(.05,_shapeFillOpacity)
                };
                if (_activeTool == AnnotationTool.Pen) _draft.Points.Add(p);
                _drawing = true;
                ImageFrame.CaptureMouse();
                _draftDirty = true;
                QueueRender();
            }
            e.Handled = true;
            return;
        }
        if (!HasPersistentTool) ScheduleToolbarHide();
        ColorLens.Visibility = Visibility.Collapsed;
        try { DragMove(); } catch (InvalidOperationException) { }
        RefreshZoomAnchorFromCurrentBounds();
        e.Handled = true;
    }

    private void UpdateDraft(Point displayPoint, bool final = false)
    {
        if (_draft is null) return;
        Point p = ToBitmapPoint(displayPoint);
        if (_draft.Tool == AnnotationTool.Pen)
        {
            double distance = (_draft.Points[^1] - p).Length;
            double threshold = Math.Max(.3, .7 * _bitmap.PixelWidth / Math.Max(1, ImageFrame.ActualWidth));
            if (distance > (final ? .001 : threshold)) _draft.Points.Add(p);
        }
        else
        {
            if ((_draft.Tool == AnnotationTool.Rectangle && Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) ||
                _draft.Tool == AnnotationTool.Circle)
            {
                var delta = p - _draft.Start;
                double side = Math.Max(Math.Abs(delta.X), Math.Abs(delta.Y));
                side = Math.Min(side, delta.X < 0 ? _draft.Start.X : _bitmap.PixelWidth - _draft.Start.X);
                side = Math.Min(side, delta.Y < 0 ? _draft.Start.Y : _bitmap.PixelHeight - _draft.Start.Y);
                p = _draft.Start + new Vector(delta.X < 0 ? -side : side, delta.Y < 0 ? -side : side);
            }
            _draft.End = p;
        }
        _draftDirty = true;
        QueueRender();
    }

    private void ImageFrame_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (EndObjectSelectionInteraction(e.GetPosition(ImageFrame)))
        {
            e.Handled = true;
            return;
        }
        if (_draggingText)
        {
            UpdateTextDrag(ToBitmapPoint(e.GetPosition(ImageFrame)));
            EndTextDrag();
            e.Handled = true;
            return;
        }
        if (!_drawing) return;
        UpdateDraft(e.GetPosition(ImageFrame), final: true);
        FinishDraft();
        e.Handled = true;
    }

    private void FinishDraft()
    {
        var completed = _draft;
        CancelDraft();
        if (completed is null) return;
        if (completed.Tool == AnnotationTool.Pen)
        {
            if (completed.Points.Count < 2) return;
            double length = 0;
            for (int i = 1; i < completed.Points.Count; i++) length += (completed.Points[i] - completed.Points[i - 1]).Length;
            if (length < .5) return;
        }
        else if ((completed.Start - completed.End).Length < .5) return;
        if ((completed.Tool == AnnotationTool.Rectangle || completed.Tool == AnnotationTool.Circle) &&
            (Math.Abs(completed.Start.X - completed.End.X) < .5 || Math.Abs(completed.Start.Y - completed.End.Y) < .5)) return;
        AddAnnotation(AnnotationRenderer.Build(completed), completed);
    }

    private void CancelDraft()
    {
        _drawing = false;
        _draft = null;
        _draftDirty = false;
        if (ImageFrame.IsMouseCaptured) ImageFrame.ReleaseMouseCapture();
        Annotations.SetDraft(null);
    }

    private void ImageFrame_LostMouseCapture(object sender, MouseEventArgs e)
    {
        if (_objectMarqueeSelecting || _objectGroupDragging)
            EndObjectSelectionInteraction(Mouse.GetPosition(ImageFrame));
        else if (_draggingText) EndTextDrag();
        else if (_drawing) FinishDraft();
    }
    private void ImageFrame_MouseLeave(object sender, MouseEventArgs e)
    {
        if (_selectedTextIndex < 0) TextChrome.Clear();
        ColorLens.Visibility = Visibility.Collapsed;

        var owner = WindowPlacementService.Bounds(this);
        var cursor = WindowPlacementService.CursorPosition;
        bool leavingBelowImage = cursor.X >= owner.X && cursor.X < owner.Right && cursor.Y >= owner.Bottom;

        if (leavingBelowImage)
        {
            ShowToolbar();
        }

        ScheduleToolbarHide();
    }

    private void ImageFrame_MouseMove(object sender, MouseEventArgs e)
    {
        Point p = e.GetPosition(ImageFrame);
        if (_objectSelectionMode)
        {
            UpdateObjectSelectionInteraction(p, e);
            return;
        }
        if (_draggingText)
        {
            UpdateTextDrag(ToBitmapPoint(p));
            if (e.LeftButton != MouseButtonState.Pressed) EndTextDrag();
            return;
        }
        if (_drawing)
        {
            UpdateDraft(p);
            if (e.LeftButton != MouseButtonState.Pressed) FinishDraft();
        }
        else if (IsPicking && !AnnotationTextEditor.IsMouseOver) UpdateColorLens(p);
        else
        {
            ColorLens.Visibility = Visibility.Collapsed;
            if (UpdateTextFeedback(p)) return;
            if (!_middlePanning)
                Cursor = _activeTool == AnnotationTool.None ? Cursors.Arrow : Cursors.Cross;
        }
    }

    private void ImageFrame_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (AnnotationTextEditor.IsMouseOver) return;
        if (_drawing)
        {
            CancelDraft();
            e.Handled = true;
            return;
        }

        ShowPieMenu();
        e.Handled = true;
    }

    private void ShowPieMenu()
    {
        // A pie can be dismissed by deactivation while an input event is still
        // unwinding. Never reuse or close that same instance through the field.
        var previous = _pieMenuWindow;
        if (previous is not null)
        {
            previous.ActionRequested -= HandlePieMenuAction;
            previous.Dismiss();
        }

        var menu = new PieMenuWindow(_history.CanUndo, _history.CanRedo, _activeTool);
        _pieMenuWindow = menu;
        menu.ActionRequested += HandlePieMenuAction;
        menu.Closed += (_, _) =>
        {
            menu.ActionRequested -= HandlePieMenuAction;
            if (ReferenceEquals(_pieMenuWindow, menu))
                _pieMenuWindow = null;
        };
        menu.ShowAtCursor(this);
    }

    private void HandlePieMenuAction(PieMenuAction action)
    {
        if (_closed) return;

        switch (action)
        {
            case PieMenuAction.Select:
                SetObjectSelectionMode(true);
                break;
            case PieMenuAction.Pen:
                SetAnnotationTool(AnnotationTool.Pen);
                break;
            case PieMenuAction.Rectangle:
                SetAnnotationTool(AnnotationTool.Rectangle);
                break;
            case PieMenuAction.Circle:
                SetAnnotationTool(AnnotationTool.Circle);
                break;
            case PieMenuAction.Arrow:
                SetAnnotationTool(AnnotationTool.Arrow);
                break;
            case PieMenuAction.Text:
                SetAnnotationTool(AnnotationTool.Text);
                break;
            case PieMenuAction.PickColor:
                TogglePicker();
                break;
            case PieMenuAction.Copy:
                CopyImage();
                break;
            case PieMenuAction.Save:
                SaveImage();
                break;
            case PieMenuAction.Undo:
                UndoAnnotation();
                break;
            case PieMenuAction.Redo:
                RedoAnnotation();
                break;
            case PieMenuAction.ResetOneToOne:
                ResetOneToOne();
                break;
        }
    }

    private void BeginTextAnnotation(Point p)
    {
        CommitTextEditor();
        ClearTextSelection();
        _editingTextIndex = -1;
        _editingTextOriginalModel = null;
        _editingTextOriginalDrawing = null;
        double x = Math.Clamp(p.X, 0, Math.Max(0, ImageFrame.ActualWidth - 50));
        double y = Math.Clamp(p.Y, 0, Math.Max(0, ImageFrame.ActualHeight - 32));
        _pendingTextPoint = ToBitmapPoint(new Point(x, y));
        _pendingTextColor = AnnotationStyle.Visible(_annotationColor);
        AnnotationTextEditor.Foreground = new SolidColorBrush(_pendingTextColor);
        AnnotationTextEditor.Text = string.Empty;
        AnnotationTextEditor.Width = Math.Min(220, Math.Max(30, ImageFrame.ActualWidth - x));
        AnnotationTextEditor.FontSize = Math.Clamp(_fontSize * ImageFrame.ActualHeight / Math.Max(1, _bitmap.PixelHeight), 8, 120);
        AnnotationTextEditor.Margin = new Thickness(x, y, 0, 0);
        AnnotationTextEditor.Visibility = Visibility.Visible;
        Keyboard.Focus(AnnotationTextEditor);
    }

    private void CommitTextEditor()
    {
        if (_pendingTextPoint is not Point p) return;
        string text = AnnotationTextEditor.Text.Trim();
        int editingIndex = _editingTextIndex;
        var originalModel = _editingTextOriginalModel;
        var originalDrawing = _editingTextOriginalDrawing;

        _pendingTextPoint = null; // Clear first: hiding can synchronously raise LostKeyboardFocus.
        _editingTextIndex = -1;
        _editingTextOriginalModel = null;
        _editingTextOriginalDrawing = null;
        AnnotationTextEditor.Visibility = Visibility.Collapsed;

        if (editingIndex >= 0 && originalModel?.Tool == AnnotationTool.Text &&
            (uint)editingIndex < (uint)_annotationModels.Count &&
            (uint)editingIndex < (uint)Annotations.Drawings.Count)
        {
            if (text.Length == 0)
            {
                if (originalDrawing is not null) Annotations.ReplaceAt(editingIndex, originalDrawing);
                _annotationModels[editingIndex] = originalModel;
                return;
            }

            if (originalDrawing is not null) Annotations.ReplaceAt(editingIndex, originalDrawing);
            if (text == originalModel.Text && p == originalModel.Start && Math.Abs(_fontSize - originalModel.FontSize) < .01) return;
            _history.Record(Annotations, _annotationModels);
            var edited = CopyTextAnnotation(originalModel, p, text, _fontSize, _fontFamily);
            _annotationModels[editingIndex] = edited;
            Annotations.ReplaceAt(editingIndex, AnnotationRenderer.Build(edited));
            _composite = null;
            UpdateHistoryButtons();
            return;
        }

        if (text.Length > 0)
        {
            var model = new Annotation
            {
                Tool = AnnotationTool.Text,
                Start = p,
                End = p,
                Text = text,
                Color = _pendingTextColor,
                FontFamily = _fontFamily, FontSize = _fontSize
            };
            AddAnnotation(AnnotationRenderer.Build(model), model);
        }
    }

    private void CancelTextEditor()
    {
        if (_editingTextIndex >= 0 && _editingTextOriginalDrawing is not null &&
            (uint)_editingTextIndex < (uint)Annotations.Drawings.Count)
        {
            Annotations.ReplaceAt(_editingTextIndex, _editingTextOriginalDrawing);
            if (_editingTextOriginalModel is not null && (uint)_editingTextIndex < (uint)_annotationModels.Count)
                _annotationModels[_editingTextIndex] = _editingTextOriginalModel;
        }
        _pendingTextPoint = null;
        _editingTextIndex = -1;
        _editingTextOriginalModel = null;
        _editingTextOriginalDrawing = null;
        AnnotationTextEditor.Visibility = Visibility.Collapsed;
    }

    private void AnnotationTextEditor_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
        {
            CommitTextEditor();
            Keyboard.Focus(this);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            CancelTextEditor();
            Keyboard.Focus(this);
            e.Handled = true;
        }
    }
    private void AnnotationTextEditor_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) => CommitTextEditor();

    private void AddAnnotation(DrawingGroup drawing, Annotation? model = null)
    {
        ClearTextSelection();
        _history.Record(Annotations, _annotationModels);
        Annotations.Add(drawing);
        _annotationModels.Add(model);
        _composite = null;
        UpdateHistoryButtons();
    }
    private void UndoAnnotation()
    {
        if (_drawing) { CancelDraft(); return; }
        CommitTextEditor();
        ClearTextSelection();
        ClearObjectSelection();
        if (_history.Undo(Annotations, _annotationModels)) _composite = null;
        UpdateHistoryButtons();
    }
    private void RedoAnnotation()
    {
        if (_drawing) return;
        CommitTextEditor();
        ClearTextSelection();
        ClearObjectSelection();
        if (_history.Redo(Annotations, _annotationModels)) _composite = null;
        UpdateHistoryButtons();
    }
    private void UpdateHistoryButtons() => _toolbarWindow?.SetHistoryState(_history.CanUndo, _history.CanRedo);

    private void UpdateColorLens(Point p)
    {
        if (ImageFrame.ActualWidth <= 0 || ImageFrame.ActualHeight <= 0) return;
        if (_pixelBitmap is null)
        {
            _pixelBitmap = _bitmap.Format == PixelFormats.Bgra32 ? _bitmap :
                new FormatConvertedBitmap(_bitmap, PixelFormats.Bgra32, null, 0);
            _pixelBitmap.Freeze();
        }
        int px = Math.Clamp((int)(p.X / ImageFrame.ActualWidth * _bitmap.PixelWidth), 0, _bitmap.PixelWidth - 1);
        int py = Math.Clamp((int)(p.Y / ImageFrame.ActualHeight * _bitmap.PixelHeight), 0, _bitmap.PixelHeight - 1);
        if (px != _lastPixelX || py != _lastPixelY)
        {
            _lastPixelX = px; _lastPixelY = py;
            _pixelBitmap.CopyPixels(new Int32Rect(px, py, 1, 1), _sample, 4, 0);
            byte b = _sample[0], g = _sample[1], r = _sample[2];
            HexText.Text = $"#{r:X2}{g:X2}{b:X2}";
            RgbText.Text = $"RGB {r}, {g}, {b}";
            ColorSwatch.Background = new SolidColorBrush(Color.FromRgb(r, g, b));
            int left = Math.Max(0, px - 4), top = Math.Max(0, py - 4);
            int width = Math.Min(_bitmap.PixelWidth, px + 5) - left;
            int height = Math.Min(_bitmap.PixelHeight, py + 5) - top;
            _pixelBitmap.CopyPixels(new Int32Rect(left, top, width, height), _regionPixels, width * 4, 0);
            for (int y = 0; y < 9; y++)
                for (int x = 0; x < 9; x++)
                {
                    int sourceX = Math.Clamp(px + x - 4, left, left + width - 1) - left;
                    int sourceY = Math.Clamp(py + y - 4, top, top + height - 1) - top;
                    Buffer.BlockCopy(_regionPixels, (sourceY * width + sourceX) * 4, _lensPixels, (y * 9 + x) * 4, 4);
                }
            _lensBitmap.WritePixels(new Int32Rect(0, 0, 9, 9), _lensPixels, 36, 0);
        }
        double lensX = p.X + 14, lensY = p.Y + 14;
        if (lensX + 116 > ImageFrame.ActualWidth) lensX = p.X - 130;
        if (lensY + 150 > ImageFrame.ActualHeight) lensY = p.Y - 164;
        ColorLens.Margin = new Thickness(Math.Max(0, lensX), Math.Max(0, lensY), 0, 0);
        ColorLens.Visibility = Visibility.Visible;
    }

    private async void CopyCurrentHex()
    {
        if (_copying || string.IsNullOrWhiteSpace(HexText.Text)) return;
        _copying = true;
        string hex = HexText.Text;
        try { await ClipboardService.SetTextAsync(hex); ShowToast($"已複製 {hex}"); }
        catch (Exception ex) { ShowToast("無法複製色碼，請稍後再試"); App.LogError("Copy color", ex); }
        finally { _copying = false; }
    }
    public BitmapSource ReferenceBitmap() => BuildCompositeBitmap();

    private BitmapSource BuildCompositeBitmap()
    {
        CommitTextEditor();
        if (_drawing) FinishDraft();
        return _composite ??= ImageExportService.Compose(_bitmap, Annotations.Drawings);
    }
    public void HideFromTray()
    {
        _pieMenuWindow?.Dismiss();
        CommitTextEditor(); CancelDraft(); ClearTextSelection();
        HideToolbar(immediate: true); ColorLens.Visibility = Visibility.Collapsed;
        Hide();
    }

    private async void CopyImage()
    {
        if (_copying) return;
        _copying = true;
        try { await ClipboardService.SetImageAsync(BuildCompositeBitmap()); if (App.Settings.ClosePinAfterCopy) Close(); else ShowToast("圖片已複製（含標註）"); }
        catch (Exception ex) { ShowToast("無法複製圖片，請稍後再試"); App.LogError("Copy image", ex); }
        finally { _copying = false; }
    }
    private async void SaveImage()
    {
        if (_saving) return;
        _saving = true;
        try
        {
            CommitTextEditor();
            var dialog = new SaveFileDialog { Title = "儲存 Clipxel 圖片", Filter = ImageExportService.ExportFilter,
                DefaultExt = ".png", AddExtension = true, OverwritePrompt = true,
                InitialDirectory = App.Settings.SaveFolder, FileName = System.IO.Path.GetFileNameWithoutExtension(App.Settings.FileName()) };
            if (dialog.ShowDialog(this) != true) return;
            var bitmap = BuildCompositeBitmap();
            ShowToast("正在儲存 PNG…");
            await ImageExportService.SaveImageAsync(bitmap, dialog.FileName);
            ShowToast("PNG 已儲存（含標註）");
        }
        catch (Exception ex) { ShowToast("儲存失敗，請確認路徑與寫入權限"); App.LogError("Save PNG", ex); }
        finally { _saving = false; }
    }

    private void ShowToast(string text)
    {
        if (_closed) return;
        ToastText.Text = text;
        CopiedToast.Visibility = Visibility.Visible;
        Restart(_toastTimer);
    }
    private void TogglePicker()
    {
        CommitTextEditor();
        ClearTextSelection();
        CancelDraft();
        if (_objectSelectionMode)
        {
            _objectSelectionMode = false;
            ClearObjectSelection();
            _toolbarWindow?.SetSelectActive(false);
        }
        _activeTool = AnnotationTool.None;
        _toolbarWindow?.SetActiveTool(AnnotationTool.None);
        _pickerEnabled = !_pickerEnabled;
        _toolbarWindow?.SetPickerActive(_pickerEnabled);
        Cursor = _pickerEnabled ? Cursors.Cross : Cursors.Arrow;
        if (!_pickerEnabled)
        {
            ColorLens.Visibility = Visibility.Collapsed;
            ScheduleToolbarHide();
        }
        else ShowToolbar();
    }
    private void ResetOneToOne()
    {
        CommitTextEditor();
        ClearTextSelection();
        HideToolbar();
        _scale = ClampScale(1);
        _zoomPending = true;
        QueueRender();
        ShowZoomBadge();
        Restart(_qualityTimer);
    }
    private void ShowZoomBadge()
    {
        ZoomText.Text = $"{Math.Round(_scale * 100):0}%";
        ZoomBadge.Visibility = Visibility.Visible;
        Restart(_zoomBadgeTimer);
    }
    private void Window_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (!IsLoaded || _drawing || AnnotationTextEditor.IsKeyboardFocusWithin) return;
        CommitTextEditor();
        ClearTextSelection();
        HideToolbar();
        ColorLens.Visibility = Visibility.Collapsed;
        RenderOptions.SetBitmapScalingMode(PinnedImage, BitmapScalingMode.LowQuality);
        _scale = ClampScale(_scale * Math.Pow(WheelZoomBase, Math.Clamp(e.Delta / 120.0, -20, 20)));
        _zoomPending = true;
        QueueRender();
        ShowZoomBadge();
        Restart(_qualityTimer);
        e.Handled = true;
    }
    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.IsRepeat && (e.Key == Key.Escape || e.Key == Key.Delete) && !AnnotationTextEditor.IsKeyboardFocusWithin)
        { e.Handled = true; return; }
        if (e.Key == Key.Delete && DeleteSelectedAnnotations())
        { e.Handled = true; return; }
        if ((e.Key == Key.Escape || e.Key == Key.Delete) && DeleteSelectedText())
        { e.Handled = true; return; }
        // Let TextBox own Ctrl+C/Z/A, letters, IME composition and multiline input.
        if (AnnotationTextEditor.IsKeyboardFocusWithin) return;
        var (key, modifiers) = LocalShortcuts.AnnotationKey(e.Key == Key.System ? e.SystemKey : e.Key, Keyboard.Modifiers);
        bool ctrl = modifiers.HasFlag(ModifierKeys.Control);
        if (ctrl && key == Key.Z)
        {
            if (modifiers.HasFlag(ModifierKeys.Shift)) RedoAnnotation(); else UndoAnnotation();
        }
        else if (ctrl && key == Key.Y) RedoAnnotation();
        else if (ctrl && key == Key.C) CopyImage();
        else if (ctrl && key == Key.S) SaveImage();
        else if (key == Key.Escape)
        {
            if (_drawing) CancelDraft();
            else if (_objectSelectionMode) SetObjectSelectionMode(false);
            else if (_activeTool != AnnotationTool.None) SetAnnotationTool(_activeTool);
            else if (_pickerEnabled) TogglePicker();
            else if (_toolbarVisible) HideToolbar();
            else Close();
        }
        else if (modifiers == ModifierKeys.None)
        {
            switch (key)
            {
                case Key.B: SetAnnotationTool(AnnotationTool.Pen); break;
                case Key.V: SetObjectSelectionMode(true); break;
                case Key.R: SetAnnotationTool(AnnotationTool.Rectangle); break;
                case Key.C: SetAnnotationTool(AnnotationTool.Circle); break;
                case Key.A: SetAnnotationTool(AnnotationTool.Arrow); break;
                case Key.T: SetAnnotationTool(AnnotationTool.Text); break;
                case Key.I: TogglePicker(); break;
                case Key.D1: case Key.NumPad1: ResetOneToOne(); break;
                case Key.Tab: ToggleToolbarVisibility(); break;
                default: return;
            }
        }
        else return;
        e.Handled = true;
    }
}
