using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Services;

namespace Clipxel.Windows;

public sealed class PreferencesWindow : Window
{
    private TabControl? _tabs;
    public void SelectShortcuts() { if (_tabs is not null) _tabs.SelectedIndex = 1; }
    public PreferencesWindow(Preferences current, Func<Preferences, bool, string?> save)
    {
        Title = "Clipxel 偏好設定"; Width = 570; Height = 640; MinWidth = 500; MinHeight = 520;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = (Brush)Application.Current.FindResource("DialogSurface");
        FontFamily = new FontFamily("Microsoft JhengHei UI"); FontSize = 14;
        WindowIconHelper.ApplyAdaptiveTitleBarIcon(this);
        var root = new DockPanel { Margin = new Thickness(6) }; Content = new Border {Style=(Style)Application.Current.FindResource("MistCard"),Margin=new Thickness(8),Child=root};
        var footer = new StackPanel(); DockPanel.SetDock(footer, Dock.Bottom); root.Children.Add(footer);
        var error = new TextBlock { Foreground = Brushes.Firebrick, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 8) }; footer.Children.Add(error);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right }; footer.Children.Add(buttons);
        var cancel = new Button { Content = "取消", Width = 84, Padding = new Thickness(8), Margin = new Thickness(6) }; buttons.Children.Add(cancel); cancel.Click += (_, _) => Close();
        var ok = new Button { Content = "儲存設定", Width = 110, Padding = new Thickness(8), Margin = new Thickness(6) }; buttons.Children.Add(ok);
        var tabs = new TabControl(); _tabs = tabs; root.Children.Add(tabs);
        StackPanel Tab(string title)
        {
            var panel = new StackPanel { Margin = new Thickness(16) };
            tabs.Items.Add(new TabItem { Header = title, Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto } }); return panel;
        }
        void Note(StackPanel panel, string text) => panel.Children.Add(new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, Foreground = Brushes.DimGray, Margin = new Thickness(0, 8, 0, 12) });
        CheckBox Check(StackPanel panel, string title, bool value)
        {
            var label=new StackPanel {Orientation=Orientation.Horizontal};string glyph=title.Contains("啟動")?"Startup":title.Contains("暫停")?"Pause":title.Contains("儲存")?"SaveProject":title.Contains("複製")?"Copy":"Settings";
            label.Children.Add(new Clipxel.Rendering.ToolGlyph {Glyph=glyph,Foreground=Clipxel.Services.ThemeService.ActiveToolInk,Margin=new Thickness(0,0,8,0)});label.Children.Add(new TextBlock {Text=title,TextWrapping=TextWrapping.Wrap,MaxWidth=340});
            var c = new CheckBox { Style=(Style)Application.Current.FindResource("SwitchToggle"), Content = label, IsChecked = value, Margin = new Thickness(0, 8, 0, 8) }; panel.Children.Add(c); return c;
        }
        TextBox Field(StackPanel panel, string title, string value)
        { panel.Children.Add(new TextBlock { Text = title, Margin = new Thickness(0, 10, 0, 5) }); var t = new TextBox { Text = value, Padding = new Thickness(7) }; panel.Children.Add(t); return t; }
        Slider Bar(StackPanel panel, string title, double value, double min, double max)
        {
            var label = new TextBlock(); panel.Children.Add(label);
            var slider = new Slider { Minimum = min, Maximum = max, Value = value, TickFrequency = 1, IsSnapToTickEnabled = true, IsMoveToPointEnabled = true, Margin = new Thickness(0, 12, 0, 18) };
            void Update() => label.Text = title + "：" + slider.Value.ToString("0");
            slider.ValueChanged += (_, _) => Update(); Update(); panel.Children.Add(slider); return slider;
        }
        var general = Tab("一般");
        bool startupEnabled = false;
        try { startupEnabled = StartupService.Enabled; } catch (Exception ex) { error.Text = "無法讀取開機啟動設定：" + ex.Message; }
        var startup = Check(general, "登入 Windows 時自動啟動 Clipxel", startupEnabled);
        Note(general, "使用目前 Clipxel.exe 的位置。移動程式後，請重新勾選並儲存。開機啟動不會自動截圖。");
        var closePin = Check(general, "複製後關閉釘圖", current.ClosePinAfterCopy);
        var closeSelection = Check(general, "複製後結束截圖選取模式", current.CloseSelectionAfterCopy);
        var autoPause = Check(general, "以下程式在前景時，自動暫停快捷鍵", current.AutoPause);
        var programs = Field(general, "程式檔名（用分號分隔）", current.PausePrograms);
        Note(general, "例如 blender.exe; Cinema 4D.exe。切換離開後恢復；手動暫停期間則繼續暫停。右鍵選單仍可截圖。");
        var shortcuts = Tab("快捷鍵"); Note(shortcuts, "點選欄位後直接按組合鍵；Delete / Backspace 清除。Tab 移至下一欄。設定視窗開啟期間暫停全域快捷鍵。");
        var boxes = new TextBox[5]; string[] labels = { "截圖", "截圖（備用）", "剪貼簿圖片轉釘圖", "隱藏／顯示全部釘圖", "切換畫布／釘圖模式" };
        for (int i = 0; i < 5; i++)
        {
            var box = Field(shortcuts, labels[i], current.Keys[i]); boxes[i] = box; box.IsReadOnly = true;
            box.PreviewKeyDown += (_, e) =>
            {
                Key key = e.Key == Key.System ? e.SystemKey : e.Key;
                if (key == Key.Tab) return;
                e.Handled = true;
                if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin) return;
                var mods = Keyboard.Modifiers;
                if (mods == ModifierKeys.None && key is Key.Delete or Key.Back) { box.Text = ""; return; }
                box.Text = (mods.HasFlag(ModifierKeys.Control) ? "Ctrl+" : "") + (mods.HasFlag(ModifierKeys.Alt) ? "Alt+" : "") + (mods.HasFlag(ModifierKeys.Shift) ? "Shift+" : "") + (mods.HasFlag(ModifierKeys.Windows) ? "Win+" : "") + key;
            };
        }
        Note(shortcuts, "以下為模式內快捷鍵；按『設定』後按鍵記錄，包含 Tab 或 Delete。清除可停用，還原僅作用於該區。文字輸入期間不攔截標註快捷鍵。Esc／Enter／Space 保留。截圖使用上方全域設定。");
        Dictionary<string,TextBox> LocalFields(string title, Dictionary<string,string> values, Dictionary<string,string> defaults, bool board)
        {
            Note(shortcuts,title); var fields=new Dictionary<string,TextBox>();
            foreach(var pair in defaults)
            {
                if(board&&pair.Key=="GroupStyle")continue;
                string label=board && Enum.TryParse<BoardAction>(pair.Key,out var action)?BoardPieWindow.Label(action):pair.Key;
                var box=Field(shortcuts,label,values.TryGetValue(pair.Key,out var value)?value:pair.Value); box.IsReadOnly=true; box.Focusable=false; fields[pair.Key]=box;
                var row=new StackPanel { Orientation=Orientation.Horizontal }; shortcuts.Children.Add(row);
                var record=new Button { Content="設定", Margin=new Thickness(0,4,8,8), Padding=new Thickness(10,3,10,3) };
                var clear=new Button { Content="清除", Margin=new Thickness(0,4,8,8), Padding=new Thickness(10,3,10,3) }; row.Children.Add(record); row.Children.Add(clear);
                bool recording=false;
                record.Click+=(_,_)=>{ recording=true; record.Content="請按快捷鍵…"; record.Focus(); };
                record.LostKeyboardFocus+=(_,_)=>{recording=false;record.Content="設定";};
                record.PreviewKeyDown+=(_,e)=>
                {
                    if(!recording) return; e.Handled=true; var key=e.Key==Key.System?e.SystemKey:e.Key;
                    if(LocalShortcuts.ModifierOnly(key)) return;
                    if(key!=Key.Escape) box.Text=LocalShortcuts.Format(key,Keyboard.Modifiers);
                    recording=false; record.Content="設定";
                };
                clear.Click+=(_,_)=>box.Text="";
            }
            var reset=new Button { Content="還原「"+title+"」預設", Padding=new Thickness(8), Margin=new Thickness(0,8,0,8) }; shortcuts.Children.Add(reset);
            reset.Click+=(_,_)=>{foreach(var pair in defaults) if(fields.TryGetValue(pair.Key,out var field))field.Text=pair.Value;}; return fields;
        }
        var boardFields=LocalFields("畫布模式",current.BoardShortcuts,LocalShortcuts.BoardDefaults(),true);
        var annotationFields=LocalFields("釘圖／截圖標註",current.AnnotationShortcuts,LocalShortcuts.AnnotationDefaults(),false);
        var annotation = Tab("標註"); Note(annotation, "套用於之後建立的截圖與釘圖，既有標註維持原樣。");
        var color = Field(annotation, "預設顏色（#RRGGBB，白色為 #FFFFFF）", current.Color);
        var choose = new Button { Content = "選擇顏色…", HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 6, 0, 18), Padding = new Thickness(10, 5, 10, 5) }; annotation.Children.Add(choose);
        choose.Click += (_, _) => { Color initial;try{initial=(Color)ColorConverter.ConvertFromString(color.Text);}catch{initial=Colors.White;}color.Text=Clipxel.Controls.ColorPicker.Pick(this,initial,c=>color.Text=c.ToString()).ToString(); };
        var font = Bar(annotation, "預設文字字級", current.FontSize, 8, 120); var stroke = Bar(annotation, "預設筆畫粗細", current.StrokeWidth, 1, 24);
        var gestures=Tab("滑鼠方向");
        Note(gestures,"按住右鍵拖向指定方向，放開即執行；短按右鍵仍開啟 pie menu。釘圖與截圖共用一組，畫布使用另一組。儲存後立即生效。");
        ComboBox[] DirectionFields(string title,string[] labels,int[] values)
        {
            gestures.Children.Add(new TextBlock {Text=title,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,12,0,6)});
            var choices=labels.Select((label,index)=>new KeyValuePair<int,string>(index,label)).GroupBy(item=>item.Value).Select(group=>group.First()).ToArray();
            var fields=new ComboBox[8];string[] names={"右 →","右下 ↘","下 ↓","左下 ↙","左 ←","左上 ↖","上 ↑","右上 ↗"};
            for(int i=0;i<8;i++)
            {
                var row=new DockPanel {Margin=new Thickness(0,3,0,3)};gestures.Children.Add(row);
                row.Children.Add(new TextBlock {Text=names[i],Width=82,VerticalAlignment=VerticalAlignment.Center});
                fields[i]=new ComboBox {ItemsSource=choices,DisplayMemberPath="Value",SelectedValuePath="Key",SelectedValue=choices.First(item=>item.Value==labels[values[i]]).Key,MinWidth=190,Padding=new Thickness(7),Background=(Brush)Application.Current.FindResource("DialogField"),Foreground=Clipxel.Services.ThemeService.Foreground};row.Children.Add(fields[i]);
            }
            var reset=new Button {Content="恢復這組預設方向",Margin=new Thickness(0,6,0,12),Padding=new Thickness(8),HorizontalAlignment=HorizontalAlignment.Left};
            reset.Click+=(_,_)=>{for(int i=0;i<8;i++)fields[i].SelectedValue=i;};gestures.Children.Add(reset);return fields;
        }
        var annotationDirections=DirectionFields("釘圖／截圖",GestureTools.AnnotationLabels,GestureTools.Normalize(current.AnnotationDirections,GestureTools.AnnotationLabels.Length));
        var boardDirections=DirectionFields("畫布",GestureTools.BoardLabels,GestureTools.Normalize(current.BoardDirections,GestureTools.BoardActions.Length));
        var appearance=Tab("介面");var glassOpacity=Bar(appearance,"工具列不透明度",current.ToolbarOpacity*100,20,100);
        glassOpacity.Resources["SliderFill"]=Brushes.WhiteSmoke;
        var storage = Tab("儲存"); var autoSave = Check(storage, "完成截圖或複製選區時，自動儲存 PNG", current.AutoSave);
        var folder = Field(storage, "儲存資料夾", current.SaveFolder);
        var browse = new Button { Content = "瀏覽…", HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 6, 0, 6), Padding = new Thickness(10, 5, 10, 5) }; storage.Children.Add(browse);
        browse.Click += (_, _) => { var dialog = new Microsoft.Win32.OpenFolderDialog(); if (dialog.ShowDialog(this) == true) folder.Text = dialog.FolderName; };
        var pattern = Field(storage, "檔名格式（不含副檔名）", current.NamePattern);
        Note(storage, "{date} = 年月日，{time} = 時分秒與毫秒。\n自動儲存另外加上識別碼，避免覆蓋圖片。手動儲存仍會詢問檔案位置。");
        ok.Click += (_, _) =>
        {
            try
            {
                var next = current.Copy(); next.CaptureKey = boxes[0].Text; next.AlternateKey = boxes[1].Text; next.PasteKey = boxes[2].Text; next.TogglePinsKey = boxes[3].Text; next.ToggleModeKey = boxes[4].Text;
                foreach(var pair in boardFields) next.BoardShortcuts[pair.Key]=pair.Value.Text;
                foreach(var pair in annotationFields) next.AnnotationShortcuts[pair.Key]=pair.Value.Text;
                next.ToolbarOpacity=glassOpacity.Value/100;next.Color = color.Text.Trim(); next.FontSize = font.Value; next.StrokeWidth = stroke.Value;
                next.ClosePinAfterCopy = closePin.IsChecked == true; next.CloseSelectionAfterCopy = closeSelection.IsChecked == true;
                next.AutoPause = autoPause.IsChecked == true; next.PausePrograms = programs.Text;
                next.AutoSave = autoSave.IsChecked == true; next.SaveFolder = folder.Text.Trim(); next.NamePattern = pattern.Text.Trim();
                for(int i=0;i<8;i++){next.AnnotationDirections[i]=(int)annotationDirections[i].SelectedValue;next.BoardDirections[i]=(int)boardDirections[i].SelectedValue;}
                next.Validate(); string? failure = save(next, startup.IsChecked == true);
                if (failure is not null) { error.Text = failure; return; } Close();
            }
            catch (Exception ex) { error.Text = ex.Message; }
        };
    }
}
