using System;
using System.Linq;
using Clipxel.Services;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;
using Clipxel.Rendering;

namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private bool _panTool;
    private bool _chromeVisible = true;
    private FrameworkElement? _topBar, _bottomBar;
    private Button? _chromeToggle;
    private BoardPieWindow? _pie;
    private readonly Dictionary<BoardAction, Button> _toolButtons = new();
    private FrameworkElement BuildBoardChrome()
    {
        WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.CanResize;
        WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 0, ResizeBorderThickness = new Thickness(5), GlassFrameThickness = new Thickness(0), CornerRadius = new CornerRadius(14) });
        var root = new Grid();root.Children.Add(_viewport);
        var frame = new Border { Child = root, BorderBrush = null, BorderThickness = new Thickness(0) };
        Brush surface = (Brush)Application.Current.FindResource("WindowChromeSurface");
        var top = new DockPanel { LastChildFill = true, Background = surface, Margin = new Thickness(0) };
        top.SetResourceReference(Panel.BackgroundProperty,"WindowChromeSurface");_topBar = top;
        top.VerticalAlignment=VerticalAlignment.Top;root.Children.Add(top);MistBackdrop.Attach(top,this);
        var right = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(4) }; DockPanel.SetDock(right, Dock.Right); top.Children.Add(right);
        var hideChrome=ToolButton(BoardAction.ToggleChrome, remember:false);hideChrome.SetResourceReference(Control.BackgroundProperty,"DarkGlass");right.Children.Add(hideChrome); right.Children.Add(ToolButton(BoardAction.Topmost)); right.Children.Add(ToolButton(BoardAction.Minimize));
        var close = ToolButton(BoardAction.CloseBoard); ((ToolGlyph)close.Content).Glyph = "Close";  close.ToolTip = "關閉畫布"; right.Children.Add(close);
        var left = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 4, 6, 4) }; DockPanel.SetDock(left, Dock.Left); top.Children.Add(left);
        left.Children.Add(ToolButton(BoardAction.OpenProject)); left.Children.Add(ToolButton(BoardAction.SaveProject)); left.Children.Add(ToolButton(BoardAction.BoardSettings)); left.Children.Add(ToolButton(BoardAction.Import)); left.Children.Add(ToolButton(BoardAction.Paste)); left.Children.Add(ToolButton(BoardAction.Capture));
        var grip = new Border { Background = Brushes.Transparent, Cursor = Cursors.SizeAll, ToolTip = "拖曳移動視窗；雙擊最大化／還原" };
        var caption=new StackPanel {Orientation=Orientation.Horizontal,VerticalAlignment=VerticalAlignment.Center,IsHitTestVisible=false};
        var brandCaption=new Image {Width=52,Height=15,Stretch=Stretch.Uniform};
        brandCaption.SetResourceReference(Image.SourceProperty,"BrandCaption");caption.Children.Add(brandCaption);
        grip.Child=caption;
        grip.MouseLeftButtonDown += (_, e) =>
        {
            if (e.ClickCount == 2) WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
            else if (e.LeftButton == MouseButtonState.Pressed) DragMove();
            e.Handled = true;
        };
        top.Children.Add(grip);
        var bottom = new DockPanel { Background = surface, LastChildFill = false };
        bottom.SetResourceReference(Panel.BackgroundProperty,"WindowChromeSurface");_bottomBar = bottom;
        bottom.VerticalAlignment=VerticalAlignment.Bottom;root.Children.Add(bottom);MistBackdrop.Attach(bottom,this);
        var back = ToolButton(BoardAction.Return, remember: false); back.Margin = new Thickness(4); DockPanel.SetDock(back, Dock.Right); bottom.Children.Add(back);
        _status.FontSize = 11;_status.VerticalAlignment=VerticalAlignment.Center;bottom.Children.Add(_status);
        var directions = GestureTools.BoardActions;
        RadialGesture.Attach(_viewport, directions.Select(BoardPieWindow.Label).ToArray(), i => PerformBoardAction(directions[i]), ShowBoardPie, () => _groupNameEditor?.IsKeyboardFocusWithin != true && _canvasTextEditor?.IsKeyboardFocusWithin != true, null, ()=>App.Settings.BoardDirections,()=>((SolidColorBrush)_viewport.Background).Color,cancelTool:()=>{bool active=_boardTool!=AnnotationTool.None||_canvasPicking||_groupTool||_panTool;SetBoardTool(AnnotationTool.None,false);return active;});
        IsVisibleChanged += (_, _) => { if (!IsVisible) _pie?.Dismiss(); };
        Activated += (_, _) => UpdateToolButtons();
        Closed += (_, _) => { _pie?.Dismiss(); _textDelay?.Stop(); };
        var overlay = new Grid(); overlay.Children.Add(frame);
        _chromeToggle = ToolButton(BoardAction.ToggleChrome); _chromeToggle.HorizontalAlignment = HorizontalAlignment.Right;
        _chromeToggle.VerticalAlignment = VerticalAlignment.Top; _chromeToggle.Margin = new Thickness(0,5,7,0);
        // Outside the collapsible bars: there is always a mouse route to restore them.
        overlay.Children.Add(_chromeToggle);
        BuildFloatingTools(overlay);
        BuildCanvasHelp(overlay);
        BuildToolOptions(overlay);BuildCanvasLens(overlay);
        RoundedWindow.Attach(this, overlay);
        UpdateToolButtons(); return overlay;
    }
    private Button ToolButton(BoardAction action, bool remember = true)
    {
        var button = new Button { Style = (Style)Application.Current.FindResource("ToolbarButton"), Content = new ToolGlyph { Glyph = action.ToString() }, ToolTip = BoardPieWindow.Label(action) };
        if (action == BoardAction.Return) button.Content = new Border { Width=18,Height=18,Background=Clipxel.Services.ThemeService.Foreground,OpacityMask=new ImageBrush(new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/Assets/Legacy-pin-mode.png"))) };
        button.Click += (_, _) => PerformBoardAction(action);
        ToolHints.Board(button,action);
        if (remember) _toolButtons[action] = button; if (action == BoardAction.Group) _groupButton = button; return button;
    }
    private void PerformBoardAction(BoardAction action)
    {
        CommitCanvasText();
        ObserveDocumentHistory();
        _historyBatch++;
        try
        {
        _embeddedToolbar?.ClosePopups();if(_boardMenu is not null)_boardMenu.IsOpen=false;
        
        _canvasPicking=false;
        EndGesture();
        switch (action)
        {
            case BoardAction.PickColor: _lastCopiedHex=null;SetBoardTool(AnnotationTool.None,false); _canvasPicking=true; break;
            case BoardAction.CloseBoard: Close(); break;
            case BoardAction.Copy: CopyObjects(); break;
            case BoardAction.SaveProject: SaveProject(); break;
            case BoardAction.OpenProject: OpenProject(); break;
            case BoardAction.ToggleDrawing: ToggleDrawingPanel(); break;
            case BoardAction.BoardSettings: ShowBoardSettings(); break;
            case BoardAction.GroupStyle: _panTool=false;_boardTool=AnnotationTool.None;_groupTool=true;UpdateDrawingControls();break;
            case BoardAction.Group: CreateGroupFromSelection(); break;
            case BoardAction.RenameGroup: if (_activeGroup is not null) BeginGroupRename(_activeGroup); break;
            case BoardAction.Undo: InkHistory(false); break;
            case BoardAction.Redo: InkHistory(true); break;
            case BoardAction.Pen: SetBoardTool(AnnotationTool.Pen); break;
            case BoardAction.Rectangle: SetBoardTool(AnnotationTool.Rectangle); break;
            case BoardAction.Circle: SetBoardTool(AnnotationTool.Circle); break;
            case BoardAction.Arrow: SetBoardTool(AnnotationTool.Arrow); break;
            case BoardAction.Text: SetBoardTool(AnnotationTool.Text); break;
            case BoardAction.Delete:
                if (DeleteCreative()) break;
                foreach (var card in _selected.ToArray()) card.Pin.Close();
                UpdateSelection(); break;
            case BoardAction.SelectAll: _selectedInk.UnionWith(Enumerable.Range(0,_ink.Count)); _activeInk = -1; RenderCreative(); foreach(var card in _cards.Values) _selected.Add(card); UpdateSelection(); break;
            case BoardAction.ToggleChrome:
                _chromeVisible = !_chromeVisible;
                if (_topBar is not null) _topBar.Visibility = _chromeVisible ? Visibility.Visible : Visibility.Collapsed;
                if (_bottomBar is not null) _bottomBar.Visibility = _chromeVisible ? Visibility.Visible : Visibility.Collapsed;
                _status.Visibility = _chromeVisible ? Visibility.Visible : Visibility.Collapsed;
                SetHelpChromeVisibility();
                Dispatcher.BeginInvoke(new Action(ClampFloating));
                break;
            case BoardAction.Settings: ((App)Application.Current).ShowShortcutPreferences(); break;
            case BoardAction.Select: SetBoardTool(AnnotationTool.None, false); _panTool = false; break;
            case BoardAction.Pan: _boardTool = AnnotationTool.None; _groupTool = false; _panTool = !_panTool; UpdateDrawingControls(); break;
            case BoardAction.Import: ImportRequested?.Invoke(); break;
            case BoardAction.Paste: if (!PasteObjects()) PasteRequested?.Invoke(); break;
            case BoardAction.Capture: CaptureRequested?.Invoke(); break;
            case BoardAction.Fit: FitAll(); break;
            case BoardAction.Arrange: ArrangeGroup(); break;
            case BoardAction.Export: ExportBoard(); break;
            case BoardAction.ZoomIn: ZoomAtCenter(1.12); break;
            case BoardAction.ZoomOut: ZoomAtCenter(1 / 1.12); break;
            case BoardAction.Topmost: Topmost = !Topmost; break;
            case BoardAction.Return: ReturnRequested?.Invoke(); break;
            case BoardAction.Minimize: WindowState = WindowState.Minimized; break;
        }
        }
        finally { _historyBatch--; ObserveDocumentHistory(); UpdateToolButtons(); }
    }

    private void ZoomAtCenter(double factor)
    {
        var center = new Point(_viewport.ActualWidth / 2, _viewport.ActualHeight / 2); var world = World(center);
        double scale = Math.Clamp(_zoom.ScaleX * factor, .02, 16);
        _zoom.ScaleX = _zoom.ScaleY = scale; _pan.X = center.X - world.X * scale; _pan.Y = center.Y - world.Y * scale; UpdateStatus();
    }
    private void UpdateToolButtons()
    {
        foreach (var pair in _toolButtons)
        {
            pair.Value.ToolTip = BoardPieWindow.Label(pair.Key) + (App.Settings.BoardShortcuts.TryGetValue(pair.Key.ToString(), out var shortcut) ? "  " + shortcut : "");
            if(pair.Key == BoardAction.Delete) pair.Value.IsEnabled = _selected.Count > 0 || _activeGroup is not null || _activeInk >= 0 || _selectedInk.Count>0;
            if (pair.Key == BoardAction.Arrange) pair.Value.ToolTip = _activeGroup is null ? "排列全部圖片" : "只排列區塊：" + _activeGroup.Name;
            if(pair.Key == BoardAction.Undo) pair.Value.IsEnabled = _historyTimeline.CanUndo;
            if(pair.Key == BoardAction.Redo) pair.Value.IsEnabled = _historyTimeline.CanRedo;
            bool active = (pair.Key == BoardAction.Group && _groupTool) || (pair.Key == BoardAction.ToggleDrawing && _drawingVisible) || (pair.Key == BoardAction.PickColor && _canvasPicking) || (pair.Key == BoardAction.Select && !_canvasPicking && !_panTool && !_groupTool && _boardTool == AnnotationTool.None) || (pair.Key == BoardAction.Pan && _panTool) || (pair.Key == BoardAction.Topmost && Topmost);
            pair.Value.Foreground=active?Clipxel.Services.ThemeService.ActiveToolInk:Clipxel.Services.ThemeService.Foreground;
            pair.Value.Background = active ? Clipxel.Services.ThemeService.ActiveSurface("Chrome") : Brushes.Transparent;
        }
        if (_chromeToggle is not null) { _chromeToggle.SetResourceReference(Control.BackgroundProperty,"DarkGlass"); _chromeToggle.Visibility = _chromeVisible ? Visibility.Collapsed : Visibility.Visible; }
        if (_groupButton is not null) _groupButton.Background = _groupTool ? Clipxel.Services.ThemeService.ActiveSurface("Drawing") : Brushes.Transparent;
        if(!_canvasPicking&&_canvasLens is not null){_canvasLens.Visibility=Visibility.Collapsed;_canvasMagnifier.Source=null;_canvasRaster.Clear();}
        _viewport.Cursor = _canvasPicking ? Cursors.Cross : _panTool ? Cursors.Hand : (_boardTool != AnnotationTool.None || _groupTool ? Cursors.Cross : Cursors.Arrow);
    }
    private void ShowBoardPie()
    {
         EndGesture(); _pie?.Dismiss();
        var menu = new BoardPieWindow(_panTool, _selected.Count > 0 || _activeGroup is not null || _activeInk >= 0 || _selectedInk.Count>0, _historyTimeline.CanUndo, _historyTimeline.CanRedo); _pie = menu;
        menu.ActionRequested += action => { if (IsVisible) PerformBoardAction(action); };
        menu.Closed += (_, _) => { if (ReferenceEquals(_pie, menu)) _pie = null; };
        menu.ShowAtCursor(this);
    }
}
