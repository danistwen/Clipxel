using System;
using System.Windows;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Services;

namespace Clipxel.Windows;

public sealed partial class ReferenceBoardWindow
{
    internal static void VerifyLineGestures()
    {
        var board=new ReferenceBoardWindow {AllowClose=true};
        try
        {
            foreach(var style in new[]{LineStyle.Arrow,LineStyle.Plain,LineStyle.Dashed,LineStyle.RoundEndpoints})
            {
                var draft=new Annotation {Tool=AnnotationTool.Arrow,Start=new Point(10,10),End=new Point(10,10),LineStyle=style};
                board._inkDraft=draft;board.FinishCreative();
                if(board._ink.Count!=0||board._historyTimeline.CanUndo)throw new InvalidOperationException("Click created a line or history: "+style);
                if(!Clipxel.Rendering.AnnotationRenderer.Build(draft).Bounds.IsEmpty)throw new InvalidOperationException("Zero-length line rendered endpoints");
                draft.End=new Point(12,10);
                if(LineGesture.CanCommit(draft,1,1)||!LineGesture.CanCommit(draft,2,2))throw new InvalidOperationException("Line drag threshold ignores screen zoom");
            }
            board._inkDraft=new Annotation {Tool=AnnotationTool.Arrow,Start=new Point(10,10),End=new Point(30,10)};
            board.FinishCreative();
            if(board._ink.Count!=1||!board._historyTimeline.CanUndo)throw new InvalidOperationException("Dragged line not committed");
            board.InkHistory(false);if(board._ink.Count!=0)throw new InvalidOperationException("Undo did not remove line");
            board.InkHistory(true);if(board._ink.Count!=1)throw new InvalidOperationException("Redo did not restore line");
        }
        finally{board.Close();}
    }
    internal static void VerifyRasterCache()
    {
        var board=new ReferenceBoardWindow {AllowClose=true};
        try
        {
            var root=(FrameworkElement)board.Content;root.Measure(new Size(900,600));root.Arrange(new Rect(0,0,900,600));root.UpdateLayout();
            board._viewport.Background=Brushes.Red;var source=(IDocumentSurface)board;
            var cache=new DocumentRasterCache();var lens=new byte[484];
            for(int x=10;x<100;x++)
            {
                var color=cache.Sample(source,new Point(x,40),lens);
                if(color!=Colors.Red||lens[(5*11+5)*4+2]!=color.R)throw new InvalidOperationException("Lens and copied sample differ");
            }
            if(cache.RenderCount!=1)throw new InvalidOperationException("Pointer movement rerendered the document");
            long before=source.DocumentRevision;
            board._viewport.Background=Brushes.Blue;
            if(source.DocumentRevision==before)throw new InvalidOperationException("Red and blue backgrounds share a revision");
            if(cache.Sample(source,new Point(10,40))!=Colors.Blue||cache.RenderCount!=2)throw new InvalidOperationException("Edited document did not invalidate raster");
            cache.Clear();cache.Sample(source,new Point(10,40));if(cache.RenderCount!=3)throw new InvalidOperationException("Cleared cache still retained pixels");
            foreach(var brush in new[]{Brushes.Red,Brushes.Green,Brushes.Blue,Brushes.White,Brushes.Black})
            {
                long previous=source.DocumentRevision;int renders=cache.RenderCount;
                board._viewport.Background=brush;
                if(source.DocumentRevision==previous)throw new InvalidOperationException("Background change reused a revision: "+brush.Color);
                if(cache.Sample(source,new Point(10,40))!=brush.Color||cache.RenderCount!=renders+1)throw new InvalidOperationException("Background raster mismatch: "+brush.Color);
                long stable=source.DocumentRevision;
                cache.Sample(source,new Point(15,40));
                if(source.DocumentRevision!=stable||cache.RenderCount!=renders+1)throw new InvalidOperationException("Unchanged state unnecessarily rerendered");
            }
        }
        finally{board.Close();}
    }
    internal static void VerifyDocumentSampling()
    {
        var board=new ReferenceBoardWindow { AllowClose=true };
        try
        {
            var root=(FrameworkElement)board.Content;
            root.Measure(new Size(900,600));root.Arrange(new Rect(0,0,900,600));root.UpdateLayout();
            board._viewport.Background=Brushes.White;
            board._zoom.ScaleX=board._zoom.ScaleY=2;board._pan.X=37;board._pan.Y=19;
            var source=(IDocumentSurface)board;
            foreach(var tool in new[]{AnnotationTool.Rectangle,AnnotationTool.Circle})
            {
                board._ink.Clear();board._ink.Add(new Annotation { Tool=tool,Start=new Point(10,10),End=new Point(90,90),
                    Color=Colors.Red,UsesIndependentShapeStyle=true,ShapeFillEnabled=true,FillOpacity=1,ShapeStrokeEnabled=false });
                board._documentVersion++;
                // A deliberately conflicting UI layer must not contaminate the sampled document.
                var overlay=new System.Windows.Controls.Border { Background=Brushes.Lime };
                board._viewport.Children.Add(overlay);
                var drawing=source.CreateDocumentDrawing();
                if(DocumentSurface.Sample(drawing,new Point(137,119))!=Colors.Red)throw new InvalidOperationException("Shape color or pan/zoom sampling mismatch: "+tool);
                if(DocumentSurface.Sample(drawing,new Point(5,5))!=Colors.White)throw new InvalidOperationException("Canvas background sample mismatch");
                if(!ReferenceEquals(drawing,source.CreateDocumentDrawing()))throw new InvalidOperationException("Unchanged document was rebuilt");
                board._viewport.Children.Remove(overlay);
            }
        }
        finally{board.Close();}
    }
}
