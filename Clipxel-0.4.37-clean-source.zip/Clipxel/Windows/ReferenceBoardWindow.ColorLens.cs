using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Services;

namespace Clipxel.Windows;

public sealed partial class ReferenceBoardWindow
{
    private Border? _canvasLens;
    private readonly Image _canvasMagnifier = new() { Width=88, Height=88, Stretch=Stretch.Fill };
    private readonly TextBlock _canvasHex = new() { Foreground=Clipxel.Services.ThemeService.Foreground, FontFamily=new FontFamily("Consolas"), Margin=new Thickness(0,5,0,0) };
    private readonly DocumentRasterCache _canvasRaster = new();
    private readonly byte[] _lensPixels=new byte[11*11*4];
    private readonly WriteableBitmap _lensBitmap=new(11,11,96,96,PixelFormats.Pbgra32,null);
    private readonly TranslateTransform _lensPosition=new();
    private string? _lastCopiedHex;
    private void BuildCanvasLens(Grid host)
    {
        var panel=new StackPanel();var magnifier=new Grid { Width=88, Height=88, ClipToBounds=true };
        RenderOptions.SetBitmapScalingMode(_canvasMagnifier,BitmapScalingMode.NearestNeighbor);
        magnifier.Children.Add(_canvasMagnifier);
        magnifier.Children.Add(new Border { Width=8, Height=8, BorderBrush=Brushes.White, BorderThickness=new Thickness(1), HorizontalAlignment=HorizontalAlignment.Center, VerticalAlignment=VerticalAlignment.Center });
        panel.Children.Add(magnifier);panel.Children.Add(_canvasHex);
        panel.Children.Add(new TextBlock { Text="點擊複製 HEX", Foreground=Clipxel.Services.ThemeService.Foreground, FontSize=10, Margin=new Thickness(0,4,0,0) });
        _canvasLens=new Border { Child=panel, Width=112, Padding=new Thickness(10), CornerRadius=new CornerRadius(10), Background=new SolidColorBrush(Color.FromArgb(245,34,38,45)),
            HorizontalAlignment=HorizontalAlignment.Left, VerticalAlignment=VerticalAlignment.Top, Visibility=Visibility.Collapsed, IsHitTestVisible=false };
        _canvasLens.RenderTransform=_lensPosition;
        host.Children.Add(_canvasLens);
        IsVisibleChanged+=(_,_)=>{if(!IsVisible)_canvasRaster.Clear();};
        Closed+=(_,_)=>{_canvasRaster.Clear();_canvasMagnifier.Source=null;};
        _viewport.MouseLeave+=(_,_)=>{_canvasLens.Visibility=Visibility.Collapsed;_canvasMagnifier.Source=null;};
    }
    private void UpdateCanvasLens(Point at)
    {
        if(_canvasLens is null||_floatHost is null)return;
        if(!_canvasPicking||!_viewport.IsMouseOver){_canvasLens.Visibility=Visibility.Collapsed;_canvasMagnifier.Source=null;_canvasRaster.Clear();return;}
        var color=_canvasRaster.Sample((IDocumentSurface)this,at,_lensPixels);
        _canvasHex.Text=$"#{color.R:X2}{color.G:X2}{color.B:X2}";
        _lensBitmap.WritePixels(new Int32Rect(0,0,11,11),_lensPixels,44,0);
        _canvasMagnifier.Source=_lensBitmap;
        Point cursor=_viewport.TranslatePoint(at,_floatHost);
        _lensPosition.X=Math.Clamp(cursor.X+20,0,Math.Max(0,_floatHost.ActualWidth-120));
        _lensPosition.Y=Math.Clamp(cursor.Y+20,0,Math.Max(0,_floatHost.ActualHeight-158));
        _canvasLens.Visibility=Visibility.Visible;
    }
}
