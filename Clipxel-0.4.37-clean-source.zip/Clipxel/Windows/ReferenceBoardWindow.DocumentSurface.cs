using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clipxel.Rendering;
using Clipxel.Services;

namespace Clipxel.Windows;

public sealed partial class ReferenceBoardWindow : IDocumentSurface
{
    private long _documentVersion;
    private long _cachedDocumentVersion=long.MinValue;
    private Drawing? _cachedDocument;
    // A hash is not an identity: different colors/state can have equal hash codes.
    // Compare the actual state and expose a monotonic token to both sampling caches.
    private (long Version,double PanX,double PanY,double ZoomX,double ZoomY,uint Argb,Size Size,int Cards,int Ink)? _samplingState;
    private long _samplingRevision;
    long IDocumentSurface.DocumentRevision
    {
        get
        {
            var color=CanvasBackground;
            uint argb=((uint)color.A<<24)|((uint)color.R<<16)|((uint)color.G<<8)|color.B;
            var state=(_documentVersion,_pan.X,_pan.Y,_zoom.ScaleX,_zoom.ScaleY,argb,_viewport.RenderSize,_cards.Count,_ink.Count);
            if(!_samplingState.HasValue || !_samplingState.Value.Equals(state))
            {_samplingState=state;_samplingRevision++;}
            return _samplingRevision;
        }
    }
    FrameworkElement IDocumentSurface.SamplingElement => _viewport;
    Drawing IDocumentSurface.CreateDocumentDrawing()
    {
        long revision=((IDocumentSurface)this).DocumentRevision;
        if(_cachedDocument is not null&&revision==_cachedDocumentVersion)return _cachedDocument;
        var drawing = new DrawingGroup();
        using (var dc = drawing.Open())
        {
            var bounds = new Rect(0, 0, _viewport.ActualWidth, _viewport.ActualHeight);
            dc.PushClip(new RectangleGeometry(bounds));
            dc.DrawRectangle(_viewport.Background, null, bounds);
            dc.PushTransform(new TranslateTransform(_pan.X, _pan.Y));
            dc.PushTransform(new ScaleTransform(_zoom.ScaleX, _zoom.ScaleY));
            foreach (var group in _groups) dc.DrawDrawing(GroupDrawing(group, false));
            foreach (var card in _cards.Values.OrderBy(c => Panel.GetZIndex(c.Frame)))
                dc.DrawImage(card.Image.Source, new Rect(card.X + 2, card.Y + 2, card.Width, card.Height));
            foreach (var ink in _ink) dc.DrawDrawing(AnnotationRenderer.Build(ink));
            if (_inkDraft is not null) dc.DrawDrawing(AnnotationRenderer.Build(_inkDraft));
            dc.Pop(); dc.Pop(); dc.Pop();
        }
        _cachedDocumentVersion=revision;return _cachedDocument=drawing;
    }
}
