using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Rendering;

namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private sealed class ReferenceGroup
    {
        public string Id = Guid.NewGuid().ToString("N");
        public string Name = "Reference";
        public Color Fill = Color.FromRgb(70,92,150), Border = Colors.SlateGray;
        public double Opacity = .16;
        public double TitleSize = 16;
        public double ColumnGap=24,RowGap=24; public bool AutoArrange;
        public Color TitleColor = Colors.WhiteSmoke;
        public bool Dashed;
        public Rect Bounds;
    }
    private readonly List<ReferenceGroup> _groups = new();
    private ReferenceGroup? _activeGroup, _movingGroup;
    private Rect _groupOrigin;
    private readonly AnnotationLayer _groupLayer = new(), _inkLayer = new();
    private readonly List<Annotation> _ink = new();
    private readonly Dictionary<AnnotationTool, Button> _drawingButtons = new();
    private System.Windows.Threading.DispatcherTimer? _textDelay;
    private ReferenceGroup? _snapPreview;
    private AnnotationTool _boardTool;
    private LineStyle _boardLineStyle;
    private Annotation? _inkDraft, _inkDragOrigin;
    private int _activeInk = -1;
    private bool _groupTool, _groupDraft;
    private Point _creativeStart;
    private Color _boardColor = Colors.White;
    private double _boardWidth = 3, _boardFont = 22;
    private Slider? _sizeBar;
    private TextBlock? _sizeLabel;
    private Button? _groupButton;
    private bool _configuringSize;

    private void AddDrawingTools(Panel tools)
    {
        foreach (var tool in new[] { AnnotationTool.Pen, AnnotationTool.Rectangle, AnnotationTool.Arrow, AnnotationTool.Text })
        {
            var button = new Button { Style = (Style)Application.Current.FindResource("ToolbarButton"), Content = new ToolGlyph { Glyph = tool == AnnotationTool.Rectangle ? "Shape" : tool.ToString() }, ToolTip = tool switch { AnnotationTool.Pen => "畫筆", AnnotationTool.Rectangle => "形狀：矩形／圓形", AnnotationTool.Arrow => "線條樣式", _ => "文字" } };
            button.Click += (_, _) =>
            {
                if (tool is AnnotationTool.Rectangle or AnnotationTool.Arrow)
                {
                    var menu = new ContextMenu { PlacementTarget = button, Placement = System.Windows.Controls.Primitives.PlacementMode.Top };
                    if (tool == AnnotationTool.Rectangle)
                    {
                        foreach (var shape in new[] { AnnotationTool.Rectangle, AnnotationTool.Circle })
                        {
                            var item = new MenuItem { Header = shape == AnnotationTool.Rectangle ? "矩形" : "圓形", Icon = new ToolGlyph { Glyph = shape.ToString() } };
                            item.Click += (_, _) => SetBoardTool(shape); menu.Items.Add(item);
                        }
                    }
                    else foreach (var style in Enum.GetValues<LineStyle>())
                    {
                        var item = new MenuItem { Header = style switch { LineStyle.Arrow => "箭頭", LineStyle.Plain => "純直線", LineStyle.Dashed => "虛線", _ => "圓端點" }, Icon = new ToolGlyph { Glyph = style.ToString() } };
                        item.Click += (_, _) => { _boardLineStyle = style; button.Content = new ToolGlyph { Glyph = style.ToString() }; SetBoardTool(AnnotationTool.Arrow, toggle: false); }; menu.Items.Add(item);
                    }
                    menu.IsOpen = true;
                }
                else SetBoardTool(tool);
            };
            tools.Children.Add(button); _drawingButtons[tool] = button;
        }
        var color = new Button { Style = (Style)Application.Current.FindResource("ToolbarButton"), ToolTip = "繪圖顏色", Content = new System.Windows.Shapes.Ellipse { Width = 14, Height = 14, Fill = Brushes.White, Stroke = Brushes.Gray, StrokeThickness = .5 } };
        color.Click += (_, _) =>
        {
            _boardColor=Clipxel.Controls.ColorPicker.Pick(this,_boardColor,c=>{_boardColor=c;((System.Windows.Shapes.Ellipse)color.Content).Fill=new SolidColorBrush(c);});((System.Windows.Shapes.Ellipse)color.Content).Fill=new SolidColorBrush(_boardColor);
        }; tools.Children.Add(color);
        _sizeLabel = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.DimGray, Margin = new Thickness(4), MinWidth = 58 };
        _sizeBar = new Slider { Width = 80, Minimum = 1, Maximum = 24, Value = 3, IsMoveToPointEnabled = true, IsSnapToTickEnabled = true, TickFrequency = 1, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4) };
        _sizeBar.ValueChanged += (_, _) => { if (_configuringSize) return; if (_boardTool == AnnotationTool.Text) _boardFont = _sizeBar.Value; else _boardWidth = _sizeBar.Value; UpdateDrawingControls(); };
        tools.Children.Add(_sizeBar); tools.Children.Add(_sizeLabel);

        tools.Children.Add(ToolButton(BoardAction.Undo)); tools.Children.Add(ToolButton(BoardAction.Redo));
        UpdateDrawingControls();
    }
    private void SetBoardTool(AnnotationTool tool, bool toggle = true)
    {
        _embeddedToolbar?.ClosePopups();if(_boardMenu is not null)_boardMenu.IsOpen=false;
        CommitCanvasText();
        _canvasPicking=false; _selectedInk.Clear();
        
        _textDelay?.Stop(); _textDelay = null;
        EndGesture(); _boardTool = toggle && _boardTool == tool ? AnnotationTool.None : tool;
        _groupTool = false; _panTool = false; _activeInk = -1;_selectedCanvasText=-1; UpdateDrawingControls(); UpdateToolButtons();
    }
    private void UpdateDrawingControls()
    {
        if (_embeddedToolbar is not null) _embeddedToolbar.SetActiveTool(_canvasTextEditor is not null?AnnotationTool.Text:_boardTool);
        foreach (var pair in _drawingButtons)
            pair.Value.Background = pair.Key == _boardTool || (pair.Key == AnnotationTool.Rectangle && _boardTool == AnnotationTool.Circle) ? Clipxel.Services.ThemeService.ActiveSurface("Drawing") : Brushes.Transparent;
        if (_groupButton is not null) _groupButton.Background = _groupTool ? Clipxel.Services.ThemeService.ActiveSurface("Drawing") : Brushes.Transparent;
        if (_sizeBar is not null && _sizeLabel is not null)
        {
            _configuringSize = true;
            bool text = _boardTool == AnnotationTool.Text;
            _sizeBar.Maximum = text ? 120 : 24; _sizeBar.Minimum = text ? 8 : 1; _sizeBar.Value = text ? _boardFont : _boardWidth;
            _sizeLabel.Text = text ? $"字級 {_boardFont:0}" : $"粗細 {_boardWidth:0}"; _configuringSize = false;
        }
        UpdateToolOptions();
        ClampFloating();
        RenderCreative();
    }
    private ReferenceGroup? GroupFor(Card card) => _groups.Where(g => g.Bounds.Contains(new Point(card.X + card.Width / 2, card.Y + card.Height / 2))).OrderBy(g => g.Bounds.Width * g.Bounds.Height).FirstOrDefault();
    private bool CreativeDown(Point point, int clicks)
    {
        if(_canvasPicking){SampleCanvasColor(point);return true;}
        if(_boardTool==AnnotationTool.None && BeginInkSelectionDrag(point))return true;
        if (clicks == 2 && (_boardTool != AnnotationTool.None || _groupTool)) { SetBoardTool(AnnotationTool.None, false); return true; }
        if (CardResizeDown(point)) return true;
        if (GroupPointerDown(point)) return true;
        _creativeStart = point;
        if (_groupTool) { _groupDraft = true; _viewport.CaptureMouse(); return true; }
        if (_boardTool != AnnotationTool.None)
        {
            if (_boardTool == AnnotationTool.Text)
            {
                int hit=_ink.FindLastIndex(a=>a.Tool==AnnotationTool.Text&&AnnotationRenderer.Build(a).Bounds.Contains(point));
                BeginCanvasText(point,hit);
            }
            else
            {
                _inkDraft = new Annotation { UsesIndependentShapeStyle = true, ShapeStrokeEnabled = _boardStroke, ShapeFillEnabled = _boardFill, StrokeOpacity = Math.Max(.05,_boardStrokeOpacity), FillOpacity = Math.Max(.05,_boardFillOpacity), Tool = _boardTool, Start = point, End = point, Color = AnnotationStyle.Visible(_boardColor), StrokeWidth = _boardWidth, LineStyle = _boardLineStyle };
                _inkDraft.Points.Add(point); _viewport.CaptureMouse();
            }
            return true;
        }
        _activeInk = -1;
        for (int i = _ink.Count - 1; i >= 0; i--)
        {
            Rect bounds = AnnotationRenderer.Build(_ink[i]).Bounds; bounds.Inflate(4 / _zoom.ScaleX, 4 / _zoom.ScaleX);
            if (!bounds.Contains(point)) continue;
            _selectedInk.Clear(); _selected.Clear(); _activeGroup = null; _activeInk = i;
            if (_ink[i].Tool == AnnotationTool.Text && (_selectedCanvasText!=i||clicks==2))
            {
                BeginCanvasText(point,i);
            }
            else { RecordInk(); _inkDragOrigin = AnnotationTransforms.Clone(_ink[i]); _viewport.CaptureMouse(); }
            RenderCreative(); return true;
        }
        var header = _groups.LastOrDefault(g => new Rect(g.Bounds.X, g.Bounds.Y, g.Bounds.Width, g.TitleSize*1.5+10).Contains(point));
        if (header is not null && !_cards.Values.Any(c=>new Rect(c.X,c.Y,c.Width+4,c.Height+4).Contains(point)))
        {
            _activeInk = -1; _activeGroup = header; _selected.Clear();
            if (point.X < header.Bounds.Right - 32) { BeginGroupRename(header); }
            else
            {
                _movingGroup = header; _groupOrigin = header.Bounds; _dragOrigins.Clear();
                foreach (var card in _cards.Values.Where(c => GroupFor(c) == header)) _dragOrigins[card] = new Point(card.X,card.Y);
                _viewport.CaptureMouse();
            }
            RenderCreative(); return true;
        }
        // Images and annotations retain their own gestures; the exposed group surface moves the group.
        if(!_cards.Values.Any(c=>new Rect(c.X,c.Y,c.Width+4,c.Height+4).Contains(point)))
        {
            var body=_groups.LastOrDefault(g=>g.Bounds.Contains(point));
            if(body is not null){_activeGroup=body;_selected.Clear();_movingGroup=body;_groupOrigin=body.Bounds;PrepareGroupDrag(body,point);RenderCreative();return true;}
        }
        _activeGroup = null; RenderCreative(); return false;
    }
    private bool CreativeMove(Point at)
    {
        if(MoveInkSelection(at))return true;
        
        if (ResizeCard(at)) return true;
        
        if (MoveGroupResize(at)) return true;
        if (_inkDraft is not null)
        {
            if (_inkDraft.Tool == AnnotationTool.Circle) { double side = Math.Min(Math.Abs(at.X - _creativeStart.X), Math.Abs(at.Y - _creativeStart.Y)); at = new Point(_creativeStart.X + Math.Sign(at.X - _creativeStart.X) * side, _creativeStart.Y + Math.Sign(at.Y - _creativeStart.Y) * side); }
            _inkDraft.End = at; if (_inkDraft.Tool == AnnotationTool.Pen && (at - _inkDraft.Points[^1]).Length >= .7 / _zoom.ScaleX) _inkDraft.Points.Add(at);
            _documentVersion++;_inkLayer.SetDraft(Clipxel.Services.LineGesture.CanCommit(_inkDraft,_zoom.ScaleX,_zoom.ScaleY)?AnnotationRenderer.Build(_inkDraft):null); return true;
        }
        if (_groupDraft) { RenderGroups(new Rect(_creativeStart, at)); return true; }
        if (_inkDragOrigin is not null && _activeInk >= 0) { _ink[_activeInk] = AnnotationTransforms.Translate(_inkDragOrigin, at - _creativeStart); RenderCreative(); return true; }
        if (_movingGroup is not null)
        {
            Vector delta = at - _creativeStart;
            if (_groupDragOrigins.Count > 0) foreach(var pair in _groupDragOrigins) { var bounds = pair.Value; bounds.Offset(delta); pair.Key.Bounds = bounds; }
            else { var bounds = _groupOrigin; bounds.Offset(delta); _movingGroup.Bounds = bounds; }
            foreach(var pair in _dragOrigins) { pair.Key.X = pair.Value.X + delta.X; pair.Key.Y = pair.Value.Y + delta.Y; Layout(pair.Key); }
            RenderCreative(); return true;
        }
        return false;
    }
    private void FinishCreative()
    {
        _resizingCard = null;_cardResizeGroup=null;_cardResizeMembers=Array.Empty<Card>();
        
        if (_inkDraft is not null) { var draft = _inkDraft; _inkDraft = null; if (Clipxel.Services.LineGesture.CanCommit(draft,_zoom.ScaleX,_zoom.ScaleY)) { RecordInk(); _ink.Add(draft); } }
        if (_groupDraft)
        {
            _groupDraft = false; var bounds = new Rect(_creativeStart, World(Mouse.GetPosition(_viewport)));
            if (bounds.Width >= 80 && bounds.Height >= 60)
            {
                // Release capture before opening an owned naming dialog.
                EndGesture(); _activeGroup = new ReferenceGroup { Name = "Reference " + (_groups.Count + 1), Bounds = bounds }; _groups.Add(_activeGroup);
                BeginGroupRename(_activeGroup);
            }
            _groupTool = true;
        }
        _inkDragOrigin = null; _movingGroup = null; RenderCreative(); UpdateDrawingControls();
    }
    private void CancelCreative()
    {
        _groupDragOrigins.Clear(); _resizingCard = null;_cardResizeGroup=null;_cardResizeMembers=Array.Empty<Card>(); 
        _resizingGroup = null;
        _inkDraft = null; _groupDraft = false; _inkDragOrigin = null; _movingGroup = null; RenderCreative();
    }
    private void RenderCreative()
    {
        ObserveDocumentHistory();
        _inkLayer.ReplaceAll(_ink.Where((a,i)=>_canvasTextEditor is null||i!=_canvasTextIndex).Select(AnnotationRenderer.Build)); _inkLayer.SetDraft(null);
        if (_activeInk >= 0 && _activeInk < _ink.Count)
        {
            var bounds = AnnotationRenderer.Build(_ink[_activeInk]).Bounds; bounds.Inflate(4,4);
            var selection = new DrawingGroup(); using(var dc = selection.Open()) dc.DrawRectangle(null, new Pen(Clipxel.Services.ThemeService.ActiveToolInk,1 / _zoom.ScaleX) { DashStyle = DashStyles.Dash }, bounds);
            _inkLayer.SetDraft(selection);
        }
        if(_selectedInk.Count>0)
        {
            var selection=new DrawingGroup();using(var dc=selection.Open()) foreach(int index in _selectedInk.Where(i=>i>=0&&i<_ink.Count))
            {var bounds=AnnotationRenderer.Build(_ink[index]).Bounds;bounds.Inflate(4/_zoom.ScaleX,4/_zoom.ScaleX);dc.DrawRectangle(null,new Pen(Clipxel.Services.ThemeService.ActiveToolInk,1/_zoom.ScaleX){DashStyle=DashStyles.Dash},bounds);}
            _inkLayer.SetDraft(selection);
        }
        RenderGroups();
    }
    private DrawingGroup GroupDrawing(ReferenceGroup group, bool selected)
    {
        var drawing = new DrawingGroup(); using(var dc = drawing.Open())
        {
            dc.DrawRoundedRectangle(new SolidColorBrush(group.Fill) { Opacity = group.Opacity }, new Pen(selected ? Clipxel.Services.ThemeService.ActiveToolInk : new SolidColorBrush(group.Border), 1.5) { DashStyle = group.Dashed ? DashStyles.Dash : DashStyles.Solid }, group.Bounds, 5,5);
            dc.PushClip(new RectangleGeometry(new Rect(group.Bounds.X+6,group.Bounds.Y,Math.Max(1,group.Bounds.Width-12),Math.Min(group.Bounds.Height,group.TitleSize*1.5+10))));
            dc.DrawText(new FormattedText(group.Name, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, new Typeface("Segoe UI"), group.TitleSize, new SolidColorBrush(group.TitleColor), 1), new Point(group.Bounds.X+8,group.Bounds.Y+5)); dc.Pop();
        } drawing.Freeze(); return drawing;
    }
    private void RenderGroups(Rect? draft = null)
    {
        _documentVersion++;
        _groupLayer.ReplaceAll(_groups.Select(g => GroupDrawing(g, g == _activeGroup || _selectedGroups.Contains(g) || g == _snapPreview)).Concat(GroupHandles()).Concat(CardHandles()));
        _groupLayer.SetDraft(null); if (draft.HasValue) _groupLayer.SetDraft(GroupDrawing(new ReferenceGroup { Bounds = draft.Value, Name = "分類區塊" },true));
    }
    private void ArrangeGroup()
    {
        if (_activeGroup is null) { ArrangeTopLevel(); return; }
        var cards = _cards.Values.Where(c => GroupFor(c) == _activeGroup).ToArray(); if (cards.Length == 0) return;
        ArrangeItemsInGroup(_activeGroup,cards);RenderCreative();
    }
    private bool DeleteCreative()
    {
        if(_selectedInk.Count>0)
        {
            foreach(int index in _selectedInk.OrderByDescending(i=>i))if(index>=0&&index<_ink.Count)_ink.RemoveAt(index);
            _selectedInk.Clear();_activeInk=-1;
            foreach(var card in _selected.ToArray())card.Pin.Close();
            foreach(var group in _selectedGroups.ToArray()){_groups.Remove(group);}
            _selectedGroups.Clear();_activeGroup=null;UpdateSelection();return true;
        }
        
        if (_activeInk >= 0 && _activeInk < _ink.Count) { RecordInk(); _ink.RemoveAt(_activeInk); _activeInk = -1; RenderCreative(); return true; }
        if (_selected.Count == 0 && _activeGroup is not null) {  _groups.Remove(_activeGroup); _activeGroup = null; RenderCreative(); return true; }
        return false;
    }
}
