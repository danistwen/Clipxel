using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Clipxel.Controls;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private ReferenceGroup? _optionsGroup;
    private bool _optionsGroupMode;
    private void BuildGroupOptions()
    {
        _toolOptionsTitle!.Text="分類區塊";var group=_activeGroup;
        if(group is null)
        {
            _toolOptionsBody!.Children.Add(new TextBlock{Text="拖曳建立分類區塊",Foreground=Clipxel.Services.ThemeService.Foreground});return;
        }
        void ColorRow(string title,Func<Color> get,Action<Color> set)
        {
            var chip=new Border{Width=44,Height=22,CornerRadius=new CornerRadius(4),Background=new SolidColorBrush(get())};
            var button=new Button{Content=chip,Padding=new Thickness(3),Background=Brushes.Transparent,BorderThickness=new Thickness(0)};
            Clipxel.Services.ToolHints.Attach(button,()=>title,()=>null);
            var row=new DockPanel{Margin=new Thickness(0,3,0,5)};DockPanel.SetDock(button,Dock.Right);row.Children.Add(button);row.Children.Add(new TextBlock{Text=title,Foreground=Clipxel.Services.ThemeService.Foreground,VerticalAlignment=VerticalAlignment.Center});
            button.Click+=(_,_)=>{if(!_groups.Contains(group))return;ObserveDocumentHistory();_historyBatch++;
                try{set(ColorPicker.Pick(this,get(),c=>{set(c);chip.Background=new SolidColorBrush(c);SyncOptionColor();RenderCreative();}));}
                finally{_historyBatch--;ObserveDocumentHistory();}
                chip.Background=new SolidColorBrush(get());SyncOptionColor();RenderCreative();};_toolOptionsBody!.Children.Add(row);
        }
        ColorRow("區塊底色",()=>group.Fill,c=>group.Fill=c);
        AddOptionBar("底色不透明度",0,100,group.Opacity*100,v=>{group.Opacity=v/100;RenderCreative();});
        ColorRow("邊框顏色",()=>group.Border,c=>group.Border=c);
        AddOptionSwitch("虛線邊框",group.Dashed,v=>{group.Dashed=v;RenderCreative();});
        ColorRow("標題顏色",()=>group.TitleColor,c=>group.TitleColor=c);
        AddOptionBar("標題字級",10,96,group.TitleSize,v=>{group.TitleSize=v;RenderCreative();});
        void Arrange(){ArrangeItemsInGroup(group,_cards.Values.Where(c=>GroupFor(c)==group).ToArray());RenderCreative();}
        AddOptionSwitch("圖片自動排列",group.AutoArrange,v=>{group.AutoArrange=v;if(v)Arrange();else RenderCreative();});
        AddOptionBar("水平間距",0,200,group.ColumnGap,v=>{group.ColumnGap=v;Arrange();});
        AddOptionBar("垂直行距",0,200,group.RowGap,v=>{group.RowGap=v;Arrange();});
    }
}
