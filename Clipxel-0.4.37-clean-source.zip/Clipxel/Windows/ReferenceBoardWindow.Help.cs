using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private ToggleButton? _helpToggle;
    private Border? _helpCard;
    private void SetHelpChromeVisibility()
    {
        if(_helpToggle is not null)_helpToggle.Visibility=_chromeVisible?Visibility.Visible:Visibility.Collapsed;
        if(_helpCard is not null)_helpCard.Visibility=_chromeVisible&&_helpToggle?.IsChecked==true?Visibility.Visible:Visibility.Collapsed;
    }
    private void BuildCanvasHelp(Grid overlay)
    {
        var content=new StackPanel {Margin=new Thickness(14)};
        var scroll=new ScrollViewer {Content=content,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled};
        var card=new Border {Child=scroll,CornerRadius=new CornerRadius(16),Background=(Brush)Application.Current.FindResource("GlassSurface"),BorderBrush=(Brush)Application.Current.FindResource("GlassEdge"),BorderThickness=new Thickness(1),HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Bottom,Margin=new Thickness(12,0,0,100),Visibility=Visibility.Collapsed};
        Clipxel.Services.MistBackdrop.Attach(card,this);
        var toggle=new ToggleButton {Opacity=1,Width=14.4,Height=14.4,Content="!",FontWeight=FontWeights.Bold,FontSize=8.4,Foreground=Clipxel.Services.ThemeService.Foreground,Background=new SolidColorBrush(Color.FromRgb(48,54,64)),BorderBrush=Brushes.Gray,BorderThickness=new Thickness(1),HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Bottom,Margin=new Thickness(12,0,0,48),ToolTip=Clipxel.Services.ToolHints.Format("顯示／隱藏操作說明",null)};
        var plate=new FrameworkElementFactory(typeof(Border));plate.SetValue(Border.CornerRadiusProperty,new CornerRadius(7.2));plate.SetResourceReference(Border.BackgroundProperty,"HelpSurface");plate.SetResourceReference(Border.BorderBrushProperty,"HelpBorder");plate.SetValue(Border.BorderThicknessProperty,new Thickness(1));
        var presenter=new FrameworkElementFactory(typeof(ContentPresenter));presenter.SetValue(FrameworkElement.HorizontalAlignmentProperty,HorizontalAlignment.Center);presenter.SetValue(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center);plate.AppendChild(presenter);
        toggle.SetResourceReference(Control.ForegroundProperty,"TextPrimary");
        toggle.SetResourceReference(Control.BorderBrushProperty,"HelpBorder");
        toggle.SetResourceReference(Control.BackgroundProperty,"HelpSurface");
        toggle.Template=new ControlTemplate(typeof(ToggleButton)){VisualTree=plate};
        string Key(string action)=>App.Settings.BoardShortcuts.TryGetValue(action,out var key)&&!string.IsNullOrWhiteSpace(key)?key:"未設定";
        void Heading(string text)=>content.Children.Add(new TextBlock {Text=text,FontWeight=FontWeights.SemiBold,Foreground=Clipxel.Services.ThemeService.Foreground,Margin=new Thickness(0,10,0,5)});
        void Row(string label,string keys)=>content.Children.Add(new TextBlock {Text=label+"  ·  "+keys,TextWrapping=TextWrapping.Wrap,Foreground=Clipxel.Services.ThemeService.Foreground,FontSize=12,Margin=new Thickness(0,2,0,2)});
        void Refresh()
        {
            content.Children.Clear();Heading("畫布操作說明");
            Heading("瀏覽與選取");Row("縮放畫布","滑鼠滾輪");Row("平移","中鍵拖曳／按住空白鍵拖曳");Row("選取工具",Key("Select")+"；拖空白處框選，Shift 點選多選");Row("顯示全部",Key("Fit"));
            Heading("圖片與分類區塊");Row("圖片尺寸","拖曳四角等比縮放；Alt 拖曳可自由變形");Row("分類區塊","拖空白底面移動整組；四邊與四角縮放");Row("標題","點文字編輯；"+Key("Group")+" 開啟分類區塊工具，於細項面板調整外觀");Row("複製／貼上／刪除",Key("Copy")+"／"+Key("Paste")+"／"+Key("Delete"));Row("排列",Key("Arrange"));
            Heading("繪圖與歷史");Row("畫筆／矩形／圓形",Key("Pen")+"／"+Key("Rectangle")+"／"+Key("Circle"));Row("線條／文字",Key("Arrow")+"／"+Key("Text"));Row("退出繪圖工具","滑鼠左鍵雙擊");Row("復原／重做",Key("Undo")+"／"+Key("Redo"));
            Heading("介面與專案");Row("視窗／繪圖工具",Key("ToggleChrome")+"／"+Key("ToggleDrawing"));Row("儲存／開啟專案",Key("SaveProject")+"／"+Key("OpenProject"));Row("匯出 PNG",Key("Export"));Row("右鍵","短按開啟 pie menu；按住拖向工具後放開執行");Row("自訂方向","偏好設定 → 滑鼠方向");
        }
        void Fit(){card.Width=Math.Max(140,Math.Min(380,overlay.ActualWidth-24));scroll.MaxHeight=Math.Max(80,overlay.ActualHeight-128);}
        toggle.Checked+=(_,_)=>{Refresh();Fit();card.Visibility=Visibility.Visible;};toggle.Unchecked+=(_,_)=>card.Visibility=Visibility.Collapsed;
        Activated+=(_,_)=>{if(toggle.IsChecked==true)Refresh();};overlay.SizeChanged+=(_,_)=>Fit();
        _helpToggle=toggle;_helpCard=card;
        PreviewMouseDown+=(_,e)=>
        {
            if(toggle.IsChecked==true && !card.IsMouseOver && !toggle.IsMouseOver)
                toggle.IsChecked=false;
        };
        overlay.Children.Add(card);overlay.Children.Add(toggle);
        void AlignHelp()
        {
            if(_drawingToggleButton is null)return;
            double height=_drawingToggleButton.ActualHeight>0?_drawingToggleButton.ActualHeight:34;
            toggle.Margin=new Thickness(12,0,0,_drawingToggleButton.Margin.Bottom+(height-toggle.Height)/2);
            card.Margin=new Thickness(12,0,0,toggle.Margin.Bottom+toggle.Height+10);
        }
        Loaded+=(_,_)=>AlignHelp();overlay.SizeChanged+=(_,_)=>AlignHelp();
    }
}
