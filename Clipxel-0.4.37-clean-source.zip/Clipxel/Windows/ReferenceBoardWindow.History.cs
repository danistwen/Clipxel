using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Models;
using Clipxel.Services;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private sealed record ImageState(string Id,BitmapSource Bitmap,Annotation[] Ink,double X,double Y,double Width,double Height,int Z);
    private sealed record DocumentState(ImageState[] Images,GroupData[] Groups,Annotation[] Ink,string Background,string Key);
    private readonly HistoryTimeline<DocumentState> _historyTimeline=new(s=>s.Key);
    private bool _historyReady,_restoringHistory;
    private int _historyBatch;
    private DocumentState CaptureDocument()
    {
        var images=_cards.Values.Select(c=>new ImageState(c.Id,c.Pin.ProjectBitmap,c.Pin.ProjectAnnotations.Select(AnnotationTransforms.Clone).ToArray(),c.X,c.Y,c.Width,c.Height,Panel.GetZIndex(c.Frame))).OrderBy(c=>c.Id).ToArray();
        var groups=_groups.Select(g=>new GroupData {Id=g.Id,Name=g.Name,X=g.Bounds.X,Y=g.Bounds.Y,Width=g.Bounds.Width,Height=g.Bounds.Height,Fill=g.Fill.ToString(),Border=g.Border.ToString(),Opacity=g.Opacity,Dashed=g.Dashed,ColumnGap=g.ColumnGap,RowGap=g.RowGap,AutoArrange=g.AutoArrange,TitleSize=g.TitleSize,TitleColor=g.TitleColor.ToString()}).ToArray();
        var ink=_ink.Select(AnnotationTransforms.Clone).ToArray();string background=((SolidColorBrush)_viewport.Background).Color.ToString();
        string key=JsonSerializer.Serialize(new {Images=images.Select(i=>new {i.Id,Bitmap=i.Bitmap.GetHashCode(),Ink=i.Ink.Select(InkData.From).ToArray(),i.X,i.Y,i.Width,i.Height,i.Z}).ToArray(),Groups=groups,Ink=ink.Select(InkData.From).ToArray(),Background=background},ProjectJson);
        return new DocumentState(images,groups,ink,background,key);
    }
    private void ResetDocumentHistory(){_historyTimeline.Reset(CaptureDocument());_historyReady=true;RefreshHistoryButtons();}
    private void ObserveDocumentHistory()
    {
        if(_selectionDragging)return;
        if(_canvasTextEditor is not null||!_historyReady||_restoringHistory||_historyBatch>0||_moving||_panning||_selecting||_inkDraft is not null||_groupDraft||_inkDragOrigin is not null||_movingGroup is not null||_resizingGroup is not null||_resizingCard is not null||_groupNameEditor is not null)return;
        _historyTimeline.Observe(CaptureDocument());RefreshHistoryButtons();
    }
    private void RefreshHistoryButtons()
    {
        _embeddedToolbar?.SetHistoryState(_historyTimeline.CanUndo,_historyTimeline.CanRedo);
        if(_toolButtons.TryGetValue(BoardAction.Undo,out var undo))undo.IsEnabled=_historyTimeline.CanUndo;
        if(_toolButtons.TryGetValue(BoardAction.Redo,out var redo))redo.IsEnabled=_historyTimeline.CanRedo;
    }
    private void RestoreDocument(DocumentState state)
    {
        _restoringHistory=true;
        try
        {
            var byId=_cards.Values.ToDictionary(c=>c.Id);var wanted=state.Images.Select(i=>i.Id).ToHashSet();
            foreach(var card in _cards.Values.Where(c=>!wanted.Contains(c.Id)).ToArray())card.Pin.Close();
            var restored=new List<(PinWindow Pin,ImageState State)>();
            foreach(var image in state.Images)
            {
                PinWindow pin;
                if(byId.TryGetValue(image.Id,out var existing))
                {
                    string actual=JsonSerializer.Serialize(existing.Pin.ProjectAnnotations.Select(InkData.From).ToArray(),ProjectJson);
                    string expected=JsonSerializer.Serialize(image.Ink.Select(InkData.From).ToArray(),ProjectJson);
                    if(actual==expected)pin=existing.Pin;
                    else {existing.Pin.Close();pin=new PinWindow(image.Bitmap,image.Ink.Select(AnnotationTransforms.Clone));((App)Application.Current).RegisterProjectPin(pin);}
                }
                else {pin=new PinWindow(image.Bitmap,image.Ink.Select(AnnotationTransforms.Clone));((App)Application.Current).RegisterProjectPin(pin);}
                restored.Add((pin,image));
            }
            SyncPins(restored.Select(p=>p.Pin));
            foreach(var (pin,image) in restored){var card=_cards[pin];card.Id=image.Id;card.X=image.X;card.Y=image.Y;card.Width=image.Width;card.Height=image.Height;Panel.SetZIndex(card.Frame,image.Z);Layout(card);}
            _groups.Clear();foreach(var g in state.Groups)_groups.Add(new ReferenceGroup {Id=g.Id,Name=g.Name,Bounds=new Rect(g.X,g.Y,g.Width,g.Height),Fill=ParseColor(g.Fill),Border=ParseColor(g.Border),Opacity=g.Opacity,Dashed=g.Dashed,ColumnGap=g.ColumnGap,RowGap=g.RowGap,AutoArrange=g.AutoArrange,TitleSize=g.TitleSize,TitleColor=ParseColor(g.TitleColor)});
            _selectedInk.Clear();_ink.Clear();_ink.AddRange(state.Ink.Select(AnnotationTransforms.Clone));_viewport.Background=new SolidColorBrush(Clipxel.Services.ThemeService.Background);
            _selected.Clear();_selectedGroups.Clear();_activeGroup=null;_activeInk=-1;_selectedCanvasText=-1;RenderCreative();UpdateSelection();
        }
        finally{_restoringHistory=false;RefreshHistoryButtons();}
    }
    private void InkHistory(bool redo)
    {
        if(_historyTimeline.TryMove(redo,out var state)){RestoreDocument(state);_status.Text=redo?"已重做":"已復原";}
        else _status.Text=redo?"沒有可重做的操作":"沒有可復原的操作";
    }
    // Legacy call sites mark the start of drawing; document checkpoints are committed at the end of each action.
    private void RecordInk(){ }
    internal static void VerifyGroupSpacing()
    {
        var bitmap=BitmapSource.Create(1,1,96,96,PixelFormats.Bgra32,null,new byte[]{0,0,0,255},4);bitmap.Freeze();
        var pins=new[]{new PinWindow(bitmap),new PinWindow(bitmap),new PinWindow(bitmap)};
        var board=new ReferenceBoardWindow{AllowClose=true};
        try
        {
            board.SyncPins(pins);var cards=board._cards.Values.ToArray();var group=new ReferenceGroup{Bounds=new Rect(0,0,800,800),ColumnGap=37,RowGap=51};
            cards[0].Width=410;cards[0].Height=320;cards[1].Width=130;cards[1].Height=90;cards[2].Width=270;cards[2].Height=180;
            var sizes=cards.Select(c=>new Size(c.Width,c.Height)).ToArray();
            board.ArrangeItemsInGroup(group,cards);
            if(cards.Where((c,i)=>new Size(c.Width,c.Height)!=sizes[i]).Any())throw new InvalidOperationException("Arrangement resized images.");
            if(Math.Abs(cards[1].X-cards[0].X-cards[0].Width-37)>.001||Math.Abs(cards[2].Y-cards[0].Y-cards[0].Height-51)>.001)throw new InvalidOperationException("Group spacing mismatch.");
            cards[0].Width=600;cards[0].Height=460;
            var desired=new Point(cards[0].X-20,cards[0].Y-10);cards[0].X=desired.X;cards[0].Y=desired.Y;
            board.ReflowResizedGroup(group,cards,cards[0]);
            if(new Point(cards[0].X,cards[0].Y)!=desired||cards[0].Width!=600||cards[1].Width!=130||Math.Abs(cards[1].X-cards[0].X-600-37)>.001||Math.Abs(cards[2].Y-cards[0].Y-460-51)>.001)throw new InvalidOperationException("Automatic arrangement failed.");
            var saved=JsonSerializer.Serialize(new GroupData{AutoArrange=true},ProjectJson);
            if(JsonSerializer.Deserialize<GroupData>(saved,ProjectJson)?.AutoArrange!=true)throw new InvalidOperationException("Auto arrangement setting did not round-trip.");
        }
        finally{board.Close();foreach(var pin in pins)pin.Close();}
    }
    internal static void VerifyHistoryRoundTrip()
    {
        var board=new ReferenceBoardWindow {AllowClose=true};
        try
        {
            var first=new ReferenceGroup {Name="A",Bounds=new Rect(0,0,100,100)};
            var second=new ReferenceGroup {Name="B",Bounds=new Rect(200,0,100,100)};
            board._groups.Add(first);board._groups.Add(second);
            board._ink.Add(new Annotation {Tool=AnnotationTool.Text,Text="Before",FontFamily="Arial",FontSize=24,Color=Colors.White});
            board.ObserveDocumentHistory();
            first.AutoArrange=true;first.TitleSize=32;first.TitleColor=Colors.Gold;first.Bounds=new Rect(40,50,180,120);board.ObserveDocumentHistory();
            board.InkHistory(false);
            if(board._groups[0].AutoArrange || board._groups[0].TitleSize!=16 || board._groups[0].Bounds.X!=0 || !board._historyTimeline.CanRedo)throw new InvalidOperationException("Undo failed for group state.");
            board.ObserveDocumentHistory();
            if(!board._historyTimeline.CanRedo)throw new InvalidOperationException("Selection/render falsely cleared redo.");
            board.InkHistory(true);
            if(!board._groups[0].AutoArrange || board._groups[0].TitleSize!=32 || board._groups[0].TitleColor!=Colors.Gold || board._groups[0].Bounds.X!=40 || board._ink[0].FontFamily!="Arial")throw new InvalidOperationException("Redo failed to restore document.");
        }
        finally{board.Close();}
    }
}
