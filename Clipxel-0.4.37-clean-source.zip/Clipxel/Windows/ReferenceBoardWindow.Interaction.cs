using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Models;

namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private readonly HashSet<ReferenceGroup> _selectedGroups=new();
    private readonly Dictionary<ReferenceGroup,Rect> _groupDragOrigins=new();
    private Card? _resizingCard;
    private ReferenceGroup? _cardResizeGroup;
    private Rect _cardResizeOrigin;
    private Rect _cardResizeGroupBounds;
    private Card[] _cardResizeMembers=Array.Empty<Card>();
    private int _cardCorner;
    private double _floatingWidth=620,_floatingHeight=120;
    private ToolbarWindow? _embeddedToolbar;
    private Clipxel.Rendering.AdaptiveToolPanel? _adaptiveTools;
    private string _boardFontFamily="Segoe UI";
    private sealed record CopiedCard(BitmapSource Bitmap,Annotation[] Ink,double X,double Y,double Width,double Height);
    private sealed record ObjectCopy(string Token,CopiedCard[] Cards,GroupData[] Groups);
    private static ObjectCopy? _objectCopy;
    private FrameworkElement EmbeddedDrawingTools()
    {
        var bar=new ToolbarWindow();_embeddedToolbar=bar;
        var root=(FrameworkElement)bar.Content;bar.Content=null;
        var scope=new NameScope();
        void RegisterNames(DependencyObject parent)
        {
            if(parent is FrameworkElement element && !string.IsNullOrEmpty(element.Name) && scope.FindName(element.Name) is null) scope.RegisterName(element.Name,element);
            foreach(var child in LogicalTreeHelper.GetChildren(parent)) if(child is DependencyObject dependency) RegisterNames(dependency);
        }
        RegisterNames(root);NameScope.SetNameScope(root,scope);
        if(root is Border glass) { glass.Background=Brushes.Transparent; glass.BorderThickness=new Thickness(0); glass.Effect=null; }
        foreach(string name in new[]{"ResetButton","PickButton","CopyButton","SaveButton","CloseButton","ModeSwitchButton"})if(bar.FindName(name)is FrameworkElement button)button.Visibility=Visibility.Collapsed;
        if (root is Border container && container.Child is Panel original)
        {
            _adaptiveTools=new Clipxel.Rendering.AdaptiveToolPanel();
            foreach(UIElement child in original.Children.Cast<UIElement>().ToArray()) { original.Children.Remove(child); _adaptiveTools.Children.Add(child); }
            // Selection -> drawing -> grouping/layout -> navigation -> history/output.
            _adaptiveTools.Children.Insert(0,ToolButton(BoardAction.Select));
            _adaptiveTools.Children.Add(ToolButton(BoardAction.PickColor));
            foreach(string name in new[]{"UndoButton","RedoButton"})if(bar.FindName(name) is UIElement item)_adaptiveTools.Children.Remove(item);
            foreach(var action in new[]{BoardAction.Group,BoardAction.Arrange,BoardAction.Pan,BoardAction.Fit})_adaptiveTools.Children.Add(ToolButton(action));
            foreach(string name in new[]{"UndoButton","RedoButton"})if(bar.FindName(name) is UIElement item)_adaptiveTools.Children.Add(item);
            _adaptiveTools.Children.Add(ToolButton(BoardAction.Delete));_adaptiveTools.Children.Add(ToolButton(BoardAction.Export));
            container.Child=_adaptiveTools;
        }
        bar.ToolSelected+=tool=>SetBoardTool(tool);
        bar.LineStyleSelected+=style=>{_boardLineStyle=style;_optionsFor=(AnnotationTool)(-1);UpdateToolOptions();};
        bar.AnnotationColorSelected+=color=>{_boardColor=color;UpdateCanvasTextStyle();};
        bar.StrokeWidthSelected+=width=>_boardWidth=width;
        bar.FontSizeSelected+=size=>{_boardFont=size;UpdateCanvasTextStyle();};
        bar.FontFamilySelected+=font=>
        {
            _boardFontFamily=font;UpdateCanvasTextStyle();_optionsFor=(AnnotationTool)(-1);UpdateToolOptions();
        };
        bar.ShapeStrokeEnabledSelected+=value=>_boardStroke=value;bar.ShapeFillEnabledSelected+=value=>_boardFill=value;
        bar.ShapeStrokeOpacitySelected+=value=>_boardStrokeOpacity=value;bar.ShapeFillOpacitySelected+=value=>_boardFillOpacity=value;
        bar.UndoRequested+=(_,_)=>PerformBoardAction(BoardAction.Undo);bar.RedoRequested+=(_,_)=>PerformBoardAction(BoardAction.Redo);
        Closed+=(_,_)=>bar.Close();return root;
    }
    private string BoardState() => JsonSerializer.Serialize(new
    {
        Cards=_cards.Values.OrderBy(c=>c.Id).Select(c=>new { c.Id,c.X,c.Y,c.Width,c.Height,Ink=c.Pin.ProjectAnnotations.Select(InkData.From).ToArray() }).ToArray(),
        Groups=_groups.Select(g=>new {g.Id,g.Name,X=g.Bounds.X,Y=g.Bounds.Y,W=g.Bounds.Width,H=g.Bounds.Height,Fill=g.Fill.ToString(),Border=g.Border.ToString(),g.Opacity,g.Dashed,g.AutoArrange,g.ColumnGap,g.RowGap,g.TitleSize,TitleColor=g.TitleColor.ToString()}).ToArray(),
        Ink=_ink.Select(InkData.From).ToArray(),Zoom=_zoom.ScaleX,PanX=_pan.X,PanY=_pan.Y,FloatingX=_floatingX,FloatingY=_floatingY,FloatingWidth=_floatingWidth,FloatingHeight=_floatingHeight,DrawingVisible=_drawingVisible,ChromeVisible=_chromeVisible,Snap=_snapEnabled,Topmost=Topmost,Background=((SolidColorBrush)_viewport.Background).Color.ToString()
    },ProjectJson);
    private bool ConfirmCloseBoard()
    {
        CommitCanvasText();CommitGroupRename();EndGesture();
        if(BoardState()==_savedState)return true;
        var choice=AppDialogWindow.AskToSave(this,"畫布專案有尚未儲存的變更。是否儲存後關閉？");
        return choice==MessageBoxResult.No||(choice==MessageBoxResult.Yes&&SaveProject());
    }
    private void CopyObjects()
    {
        var groups=_selectedGroups.ToHashSet();if(_activeGroup is not null && _selected.Count==0)groups.Add(_activeGroup);
        var cards=_selected.Concat(_cards.Values.Where(c=>GroupFor(c)is ReferenceGroup g&&groups.Contains(g))).Distinct().ToArray();
        if(cards.Length==0&&groups.Count==0)return;
        var ids=groups.Select(g=>g.Id).ToHashSet();string token=Guid.NewGuid().ToString("N");
        var snapshot=new ObjectCopy(token,cards.Select(c=>new CopiedCard(c.Pin.ProjectBitmap,c.Pin.ProjectAnnotations.Select(AnnotationTransforms.Clone).ToArray(),c.X,c.Y,c.Width,c.Height)).ToArray(),
            groups.Select(g=>new GroupData{Id=g.Id,Name=g.Name,Fill=g.Fill.ToString(),Border=g.Border.ToString(),Opacity=g.Opacity,Dashed=g.Dashed,ColumnGap=g.ColumnGap,RowGap=g.RowGap,AutoArrange=g.AutoArrange,TitleSize=g.TitleSize,TitleColor=g.TitleColor.ToString(),X=g.Bounds.X,Y=g.Bounds.Y,Width=g.Bounds.Width,Height=g.Bounds.Height}).ToArray());
        try { Clipboard.SetData("Clipxel.CanvasObjects",token);_objectCopy=snapshot;_status.Text="選取物件已複製"; }catch(Exception ex){_status.Text="複製失敗："+ex.Message;}
    }
    private bool PasteObjects()
    {
        var copy=_objectCopy;
        try { if(copy is null||!Equals(Clipboard.GetData("Clipxel.CanvasObjects"),copy.Token))return false; }
        catch(Exception ex){_status.Text="讀取剪貼簿失敗："+ex.Message;return true;}
        _selected.Clear();_selectedGroups.Clear();_activeGroup=null;_activeInk=-1;
        var map=new Dictionary<string,string>();double offset=30/_zoom.ScaleX;
        foreach(var d in copy.Groups)
        {var group=new ReferenceGroup{Id=Guid.NewGuid().ToString("N"),Name=d.Name+" 副本",Bounds=new Rect(d.X+offset,d.Y+offset,d.Width,d.Height),Fill=ParseColor(d.Fill),Border=ParseColor(d.Border),Opacity=d.Opacity,Dashed=d.Dashed,ColumnGap=d.ColumnGap,RowGap=d.RowGap,AutoArrange=d.AutoArrange,TitleSize=d.TitleSize,TitleColor=ParseColor(d.TitleColor)};_groups.Add(group);_selectedGroups.Add(group);map[d.Id]=group.Id;}
        var added=new List<(PinWindow Pin,CopiedCard Data)>();
        foreach(var d in copy.Cards){var pin=new PinWindow(d.Bitmap,d.Ink.Select(AnnotationTransforms.Clone));((App)Application.Current).RegisterProjectPin(pin);added.Add((pin,d));}
        SyncPins(_cards.Keys.Concat(added.Select(x=>x.Pin)).ToArray());
        foreach(var (pin,d) in added){var card=_cards[pin];card.X=d.X+offset;card.Y=d.Y+offset;card.Width=d.Width;card.Height=d.Height;Layout(card);_selected.Add(card);}
        _activeGroup=_selectedGroups.FirstOrDefault();RenderCreative();UpdateSelection();return true;
    }
    private bool CardResizeDown(Point point)
    {
        if(_boardTool!=AnnotationTool.None||_groupTool)return false;
        foreach(var card in _selected.Reverse())
        {
            var corners=Corners(new Rect(card.X,card.Y,card.Width,card.Height));
            for(int i=0;i<4;i++)if((corners[i]-point).Length<=12/_zoom.ScaleX)
            {_resizingCard=card;_cardResizeGroup=GroupFor(card);
                _cardResizeMembers=_cardResizeGroup is null?Array.Empty<Card>():_cards.Values.Where(c=>GroupFor(c)==_cardResizeGroup).OrderBy(c=>c.Y).ThenBy(c=>c.X).ToArray();
                _cardResizeGroupBounds=_cardResizeGroup?.Bounds??Rect.Empty;
                _cardCorner=i;_cardResizeOrigin=new Rect(card.X,card.Y,card.Width,card.Height);_viewport.CaptureMouse();return true;}
        }
        return false;
    }
    internal static Rect ExpandedGroupBounds(Rect group,Rect image,double titleSpace)
    {
        // Expansion only: preserve other members and the existing group position when possible.
        return new Rect(new Point(Math.Min(group.Left,image.Left-12),Math.Min(group.Top,image.Top-titleSpace)),
            new Point(Math.Max(group.Right,image.Right+12),Math.Max(group.Bottom,image.Bottom+12)));
    }
    private bool ResizeCard(Point point)
    {
        if(_resizingCard is null)return false;Point anchor=Corners(_cardResizeOrigin)[(_cardCorner+2)%4];
        double w=Math.Max(8,Math.Abs(point.X-anchor.X)),h=Math.Max(8,Math.Abs(point.Y-anchor.Y));
        if(!Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)){double scale=Math.Min(Math.Max(w/_cardResizeOrigin.Width,h/_cardResizeOrigin.Height),Math.Min(16000/_cardResizeOrigin.Width,16000/_cardResizeOrigin.Height));w=_cardResizeOrigin.Width*scale;h=_cardResizeOrigin.Height*scale;}
        w=Math.Min(16000,w);h=Math.Min(16000,h);var card=_resizingCard;card.X=point.X<anchor.X?anchor.X-w:anchor.X;card.Y=point.Y<anchor.Y?anchor.Y-h:anchor.Y;card.Width=w;card.Height=h;Layout(card);
        if(_cardResizeGroup is { } group && _groups.Contains(group))
        {
            if(group.AutoArrange)
            {
                group.Bounds=_cardResizeGroupBounds;
                ReflowResizedGroup(group,_cardResizeMembers,card);
            }
            else group.Bounds=ExpandedGroupBounds(group.Bounds,new Rect(card.X,card.Y,card.Width+4,card.Height+4),Math.Max(36,group.TitleSize*1.5+16));
        }
        RenderCreative();return true;
    }
    private void ReflowResizedGroup(ReferenceGroup group,Card[] members,Card resized)
    {
        // Freeze membership/order at gesture start. Keep the resized image at the pointer.
        var desired=new Point(resized.X,resized.Y);
        ArrangeItemsInGroup(group,members);
        var shift=desired-new Point(resized.X,resized.Y);
        foreach(var member in members){member.X+=shift.X;member.Y+=shift.Y;Layout(member);}
        group.Bounds=new Rect(group.Bounds.Location+shift,group.Bounds.Size);
    }
    private void HoverCursor(Point point)
    {
        if(_canvasPicking){_viewport.Cursor=Cursors.Cross;return;}
        if(_selectedInk.Count>0){_viewport.Cursor=Cursors.Arrow;return;}
        if(_moving||_panning||_selecting||_inkDraft is not null||_resizingCard is not null||_movingGroup is not null||_resizingGroup is not null)return;
        if(_canvasTextEditor is null&&_activeInk<0&&!_groupTool&&(_boardTool==AnnotationTool.None||_boardTool==AnnotationTool.Text))
        {
            int text=_ink.FindLastIndex(a=>a.Tool==AnnotationTool.Text&&Clipxel.Rendering.AnnotationRenderer.Build(a).Bounds.Contains(point));
            if(text>=0)
            {
                var bounds=Clipxel.Rendering.AnnotationRenderer.Build(_ink[text]).Bounds;var hover=new DrawingGroup();using(var dc=hover.Open())dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(45,255,255,255)),null,new Rect(bounds.Left,bounds.Bottom-6/_zoom.ScaleX,bounds.Width,6/_zoom.ScaleX));_inkLayer.SetDraft(hover);_viewport.Cursor=Cursors.IBeam;return;
            }
            _inkLayer.SetDraft(null);
        }
        if(_boardTool!=AnnotationTool.None||_groupTool){_viewport.Cursor=Cursors.Cross;return;}
        double hit=12/_zoom.ScaleX;
        foreach(var card in _selected) {var points=Corners(new Rect(card.X,card.Y,card.Width,card.Height));for(int i=0;i<4;i++)if((point-points[i]).Length<hit){_viewport.Cursor=i%2==0?Cursors.SizeNWSE:Cursors.SizeNESW;return;}}
        foreach(var group in _groups.AsEnumerable().Reverse())
        {
            int handle=GroupResizeHit(group.Bounds,point,hit);
            if(handle>=0){_viewport.Cursor=handle<4?(handle%2==0?Cursors.SizeNWSE:Cursors.SizeNESW):(handle<6?Cursors.SizeWE:Cursors.SizeNS);return;}
            if(group.Bounds.Contains(point)&&!_cards.Values.Any(c=>new Rect(c.X,c.Y,c.Width+4,c.Height+4).Contains(point)))
            {_viewport.Cursor=point.Y<group.Bounds.Top+group.TitleSize*1.5+10?Cursors.IBeam:Cursors.SizeAll;return;}

        }
        _viewport.Cursor=_panTool?Cursors.Hand:Cursors.Arrow;
    }
    private IEnumerable<DrawingGroup> CardHandles()
    {
        var drawing=new DrawingGroup();using(var dc=drawing.Open())foreach(var card in _selected)foreach(var point in Corners(new Rect(card.X,card.Y,card.Width,card.Height)))dc.DrawRectangle(Brushes.White,new Pen(Clipxel.Services.ThemeService.ActiveToolInk,1/_zoom.ScaleX),new Rect(point.X-4/_zoom.ScaleX,point.Y-4/_zoom.ScaleX,8/_zoom.ScaleX,8/_zoom.ScaleX));drawing.Freeze();yield return drawing;
    }
    
    
    private void PrepareGroupDrag(ReferenceGroup group,Point start)
    {
        if (!_selectedGroups.Contains(group)) { _selectedGroups.Clear(); _selectedGroups.Add(group); }
        _groupDragOrigins.Clear(); _dragOrigins.Clear();
        foreach(var selected in _selectedGroups) _groupDragOrigins[selected]=selected.Bounds;
        foreach(var card in _cards.Values) if(GroupFor(card) is ReferenceGroup owner && _selectedGroups.Contains(owner)) _dragOrigins[card]=new Point(card.X,card.Y);
        _activeGroup=group;_movingGroup=group;_groupOrigin=group.Bounds;_creativeStart=start;_viewport.CaptureMouse();
    }
}
