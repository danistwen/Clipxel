using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Clipxel.Models;

namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private string? _projectPath;
    private string _savedState = "";
    private static readonly JsonSerializerOptions ProjectJson = new() { IncludeFields = true, WriteIndented = true };
    public sealed class InkData
    {
        public AnnotationTool Tool; public LineStyle Style; public double X, Y, X2, Y2, Width = 3, Font = 22, StrokeOpacity = 1, FillOpacity = .45;
        public string Color = "#FFFFFFFF", Text = "", FontFamily = "Segoe UI"; public bool Independent, Stroke = true, Fill; public RectangleAnnotationMode RectangleMode;
        public double[][] Points = Array.Empty<double[]>();
        public static InkData From(Annotation a) => new() { Tool=a.Tool, Style=a.LineStyle, X=a.Start.X,Y=a.Start.Y,X2=a.End.X,Y2=a.End.Y,Width=a.StrokeWidth,Font=a.FontSize,Color=a.Color.ToString(),Text=a.Text,FontFamily=a.FontFamily,Independent=a.UsesIndependentShapeStyle,Stroke=a.ShapeStrokeEnabled,Fill=a.ShapeFillEnabled,StrokeOpacity=a.StrokeOpacity,FillOpacity=a.FillOpacity,RectangleMode=a.RectangleMode,Points=a.Points.Select(p=>new[]{p.X,p.Y}).ToArray() };
        public Annotation Model()
        {
            if(!Enum.IsDefined(Tool)||!Enum.IsDefined(Style)||!Enum.IsDefined(RectangleMode)||Points is null||Points.Length>1000000||Text is null||Text.Length>1000000) throw new InvalidDataException("無效標註。");
            foreach(var n in new[]{X,Y,X2,Y2,Width,Font,StrokeOpacity,FillOpacity}) Finite(n);
            if(Width<=0||Width>10000||Font<=0||Font>10000||StrokeOpacity<0||StrokeOpacity>1||FillOpacity<0||FillOpacity>1) throw new InvalidDataException("無效標註尺寸。");
            if(string.IsNullOrWhiteSpace(FontFamily)||FontFamily.Length>500) throw new InvalidDataException("無效字型名稱。");
            var a=new Annotation { Tool=Tool,LineStyle=Style,Start=new Point(X,Y),End=new Point(X2,Y2),StrokeWidth=Width,FontSize=Font,Color=ParseColor(Color),Text=Text,FontFamily=FontFamily,UsesIndependentShapeStyle=Independent,ShapeStrokeEnabled=Stroke,ShapeFillEnabled=Fill,StrokeOpacity=StrokeOpacity,FillOpacity=FillOpacity,RectangleMode=RectangleMode };
            foreach(var point in Points) { if(point is null||point.Length!=2) throw new InvalidDataException("無效筆畫。"); Finite(point[0]);Finite(point[1]);a.Points.Add(new Point(point[0],point[1])); } return a;
        }
    }
    public sealed class CardData { public double X,Y,Width,Height; public int Z; public List<InkData> Ink = new(); }
    public sealed class GroupData { public string Id="",Name="",Fill="",Border=""; public double X,Y,Width,Height,Opacity; public double ColumnGap=24,RowGap=24; public bool AutoArrange; public double TitleSize=16; public string TitleColor="#FFF5F5F5"; public bool Dashed; }
    // Import-only compatibility: old node links become ordinary selectable line annotations.
    private static IEnumerable<Annotation> ConvertLegacyLinks(IEnumerable<LinkData> links,IEnumerable<ReferenceGroup> groups)
    {
        var lookup=groups.ToDictionary(g=>g.Id);
        foreach(var link in links)
            yield return new Annotation{Tool=AnnotationTool.Arrow,Start=Port(lookup[link.From],link.FromSide),End=Port(lookup[link.To],link.ToSide),LineStyle=link.Style,Color=ParseColor(link.Color),StrokeWidth=link.Width};
    }
    public sealed class LinkData { public string From="",To="",Color="#FF465CFF"; public int FromSide=1,ToSide=0; public LineStyle Style; public double Width=3; }
    public sealed class ProjectData
    {
        public int Version=1; public string Background="#FF1E2128"; public double Zoom=1,PanX,PanY,FloatingX=16,FloatingY=60,FloatingWidth=620,FloatingHeight=120;
        public bool DrawingVisible=true, Snap=true, ChromeVisible=true, Topmost=true;
        public List<CardData> Cards=new(); public List<GroupData> Groups=new(); public List<InkData> Ink=new(); public List<LinkData> Links=new();
    }
    private static Color ParseColor(string value) => (Color)ColorConverter.ConvertFromString(value);
    private static void Finite(double value) { if(!double.IsFinite(value)||Math.Abs(value)>10000000) throw new InvalidDataException("專案座標或尺寸無效。"); }
    private static void CheckRect(double x,double y,double w,double h) { foreach(var n in new[]{x,y,w,h}) Finite(n); if(w<=0||h<=0) throw new InvalidDataException("專案尺寸必須大於零。"); }
    private bool SaveProject()
    {
        CommitCanvasText();
        CommitGroupRename();
        var dialog=new SaveFileDialog { Filter="Clipxel 畫布專案|*.clipxel|PinShot 舊版專案|*.pinshot",DefaultExt=".clipxel",AddExtension=true,FileName=_projectPath ?? "Reference.clipxel" };
        if(dialog.ShowDialog(this)!=true) return false;
        string temp=dialog.FileName+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            var cards=_cards.Values.ToArray(); var data=new ProjectData { Background=((SolidColorBrush)_viewport.Background).Color.ToString(),Zoom=_zoom.ScaleX,PanX=_pan.X,PanY=_pan.Y,FloatingX=_floatingX,FloatingY=_floatingY,FloatingWidth=_floatingWidth,FloatingHeight=_floatingHeight,DrawingVisible=_drawingVisible,Snap=_snapEnabled,ChromeVisible=_chromeVisible,Topmost=Topmost,
                Cards=cards.Select(c=>new CardData { X=c.X,Y=c.Y,Width=c.Width,Height=c.Height,Z=System.Windows.Controls.Panel.GetZIndex(c.Frame),Ink=c.Pin.ProjectAnnotations.Select(InkData.From).ToList() }).ToList(),
                Groups=_groups.Select(g=>new GroupData { Id=g.Id,Name=g.Name,X=g.Bounds.X,Y=g.Bounds.Y,Width=g.Bounds.Width,Height=g.Bounds.Height,Fill=g.Fill.ToString(),Border=g.Border.ToString(),Opacity=g.Opacity,Dashed=g.Dashed,ColumnGap=g.ColumnGap,RowGap=g.RowGap,AutoArrange=g.AutoArrange,TitleSize=g.TitleSize,TitleColor=g.TitleColor.ToString() }).ToList(),Ink=_ink.Select(InkData.From).ToList() };
            using(var zip=ZipFile.Open(temp,ZipArchiveMode.Create))
            {
                using(var stream=zip.CreateEntry("project.json").Open()) JsonSerializer.Serialize(stream,data,ProjectJson);
                for(int i=0;i<cards.Length;i++) Clipxel.Services.ProjectImageCodec.WritePng(zip, $"images/{i}.png", cards[i].Pin.ProjectBitmap);
            }
            File.Move(temp,dialog.FileName,true); _projectPath=dialog.FileName; _savedState=BoardState(); _status.Text="專案已儲存："+Path.GetFileName(_projectPath);return true;
        }
        catch(Exception ex) { App.LogError("Save project",ex);AppDialogWindow.ShowMessage("儲存失敗："+ex.Message);return false; }
        finally { try { if(File.Exists(temp)) File.Delete(temp); } catch(Exception cleanup) { App.LogError("Clean project temp",cleanup); } }
    }
    public void OpenProject(string? projectPath = null)
    {
        CommitCanvasText();
        if(projectPath is null) { var dialog=new OpenFileDialog { Filter="Clipxel／PinShot 畫布專案|*.clipxel;*.pinshot" }; if(dialog.ShowDialog(this)!=true)return; projectPath=dialog.FileName; }
        var pending=new List<PinWindow>();
        try
        {
            using var zip=ZipFile.OpenRead(projectPath);
            var entry=zip.GetEntry("project.json")??throw new InvalidDataException("找不到專案內容。");
            if(entry.Length>64_000_000) throw new InvalidDataException("專案內容過大。");
            ProjectData data; using(var stream=entry.Open())data=JsonSerializer.Deserialize<ProjectData>(stream,ProjectJson)??throw new InvalidDataException("無效專案。");
            if(data.Version!=1||data.Cards is null||data.Groups is null||data.Ink is null||data.Links is null||data.Cards.Count>1000||data.Groups.Count>10000||data.Ink.Count>100000||data.Links.Count>10000)throw new InvalidDataException("不支援此專案格式或容量。");
            var background=ParseColor(data.Background); foreach(var n in new[]{data.Zoom,data.PanX,data.PanY,data.FloatingX,data.FloatingY,data.FloatingWidth,data.FloatingHeight})Finite(n); if(data.Zoom<.02||data.Zoom>16)throw new InvalidDataException("無效缩放。");
            var groups=new List<ReferenceGroup>();
            foreach(var g in data.Groups) { CheckRect(g.X,g.Y,g.Width,g.Height);Finite(g.ColumnGap);Finite(g.RowGap);if(g.ColumnGap<0||g.ColumnGap>200||g.RowGap<0||g.RowGap>200)throw new InvalidDataException("無效區塊間距。");Finite(g.TitleSize);if(g.TitleSize<10||g.TitleSize>96)throw new InvalidDataException("無效標題字級。");Finite(g.Opacity);if(g.Opacity<0||g.Opacity>1||string.IsNullOrWhiteSpace(g.Id)||g.Name is null||g.Name.Length>10000)throw new InvalidDataException("無效區塊。");groups.Add(new ReferenceGroup { Id=g.Id,Name=g.Name,Bounds=new Rect(g.X,g.Y,g.Width,g.Height),Fill=ParseColor(g.Fill),Border=ParseColor(g.Border),Opacity=g.Opacity,Dashed=g.Dashed,ColumnGap=g.ColumnGap,RowGap=g.RowGap,AutoArrange=g.AutoArrange,TitleSize=g.TitleSize,TitleColor=ParseColor(g.TitleColor) }); }
            var ids=groups.Select(g=>g.Id).ToHashSet();if(ids.Count!=groups.Count)throw new InvalidDataException("重複區塊識別碼。");
            foreach(var link in data.Links) { if(!ids.Contains(link.From)||!ids.Contains(link.To)||link.From==link.To||link.FromSide<0||link.FromSide>3||link.ToSide<0||link.ToSide>3||!Enum.IsDefined(link.Style))throw new InvalidDataException("無效連接線。");Finite(link.Width);if(link.Width<1||link.Width>24)throw new InvalidDataException("無效線寬。");_ = ParseColor(link.Color); }
            var ink=data.Ink.Select(a=>a.Model()).Concat(ConvertLegacyLinks(data.Links,groups)).ToArray();long pixels=0;
            for(int i=0;i<data.Cards.Count;i++)
            {
                var card=data.Cards[i];CheckRect(card.X,card.Y,card.Width,card.Height);if(card.Ink is null)throw new InvalidDataException("無效圖片標註。"); var models=card.Ink.Select(a=>a.Model()).ToArray();
                var image=zip.GetEntry($"images/{i}.png")??throw new InvalidDataException("缺少圖片。");if(image.Length>256_000_000)throw new InvalidDataException("圖片過大。");
                using var input=image.Open();using var memory=new MemoryStream();input.CopyTo(memory);memory.Position=0;
                var bitmap=new BitmapImage();bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.StreamSource=memory;bitmap.EndInit();bitmap.Freeze();
                pixels+=(long)bitmap.PixelWidth*bitmap.PixelHeight;if(pixels>128_000_000)throw new InvalidDataException("專案圖片總像素超過本版上限。");pending.Add(new PinWindow(bitmap,models));
            }
            // Validate all content before asking to replace the current board.
            if(_cards.Count+_groups.Count+_ink.Count>0)
            {
                var answer=AppDialogWindow.AskToSave(this,"開啟專案將取代目前畫布。是否先儲存？","開啟專案");
                if(answer==MessageBoxResult.Cancel || (answer==MessageBoxResult.Yes&&!SaveProject()))return;
            }
            CommitGroupRename();_historyReady=false;foreach(var card in _cards.Values.ToArray())card.Pin.Close();
            _groups.Clear();_groups.AddRange(groups);_selectedInk.Clear();_ink.Clear();_ink.AddRange(ink);_activeGroup=null;_activeInk=-1;_selectedGroups.Clear();
            foreach(var pin in pending)((App)Application.Current).RegisterProjectPin(pin);SyncPins(pending);
            for(int i=0;i<pending.Count;i++) { var c=_cards[pending[i]];var d=data.Cards[i];c.X=d.X;c.Y=d.Y;c.Width=d.Width;c.Height=d.Height;System.Windows.Controls.Panel.SetZIndex(c.Frame,d.Z);Layout(c); }
            pending.Clear();_viewport.Background=new SolidColorBrush(Clipxel.Services.ThemeService.Background);_zoom.ScaleX=_zoom.ScaleY=data.Zoom;_pan.X=data.PanX;_pan.Y=data.PanY;
            _floatingX=data.FloatingX;_floatingY=data.FloatingY;_floatingWidth=Math.Max(52,data.FloatingWidth);_floatingHeight=Math.Max(90,data.FloatingHeight);_drawingVisible=data.DrawingVisible;_snapEnabled=data.Snap;Topmost=data.Topmost;
            if(_chromeVisible!=data.ChromeVisible)PerformBoardAction(BoardAction.ToggleChrome);ClampFloating();RenderCreative();UpdateSelection();_projectPath=projectPath; _savedState=BoardState(); ResetDocumentHistory();
        }
        catch(Exception ex) { App.LogError("Open project",ex);AppDialogWindow.ShowMessage("開啟失敗："+ex.Message); }
        finally { foreach(var pin in pending)pin.Close(); }
    }
}
