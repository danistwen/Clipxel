using System;
using System.Linq;
using Clipxel.Models;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private string _styleSelection="";
    private void LoadSelectedStyle()
    {
        string key=string.Join(",",_selectedInk.OrderBy(i=>i));if(key==_styleSelection)return;_styleSelection=key;
        _optionsFor=(AnnotationTool)(-1);
        var a=_selectedInk.Where(i=>i>=0&&i<_ink.Count).Select(i=>_ink[i]).FirstOrDefault();if(a is null)return;
        _boardColor=a.Color;_boardWidth=a.StrokeWidth;_boardStroke=a.ShapeStrokeEnabled;_boardFill=a.ShapeFillEnabled;_boardStrokeOpacity=a.StrokeOpacity;_boardFillOpacity=a.FillOpacity;_boardFont=a.FontSize;_boardFontFamily=a.FontFamily;_boardLineStyle=a.LineStyle;
    }
    private void EditSelectedStyle(Func<Annotation,Annotation> edit)
    {
        if(_boardTool!=AnnotationTool.None||_selectedInk.Count==0)return;
        ObserveDocumentHistory();
        foreach(int i in _selectedInk.ToArray())if(i>=0&&i<_ink.Count)_ink[i]=edit(_ink[i]);
        RenderCreative();ObserveDocumentHistory();
    }
}
