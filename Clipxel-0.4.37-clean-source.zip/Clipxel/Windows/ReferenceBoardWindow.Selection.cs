using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Clipxel.Models;
using Clipxel.Rendering;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private bool _canvasPicking,_selectionDragging;
    private readonly HashSet<int> _selectedInk=new();
    private readonly Dictionary<int,Annotation> _selectionInkOrigins=new();
    private readonly Dictionary<ReferenceGroup,Rect> _selectionGroupOrigins=new();
    public Color CanvasBackground => (_viewport.Background as SolidColorBrush)?.Color??Colors.Black;
    private bool _copyingCanvasColor;
    private async void SampleCanvasColor(Point world)
    {
        if(_copyingCanvasColor)return;
        _copyingCanvasColor=true;
        try
        {
            var point=new Point(world.X*_zoom.ScaleX+_pan.X,world.Y*_zoom.ScaleY+_pan.Y);
            _boardColor=_canvasRaster.Sample((Clipxel.Services.IDocumentSurface)this,point);
            string hex=$"#{_boardColor.R:X2}{_boardColor.G:X2}{_boardColor.B:X2}";
            _embeddedToolbar?.SetAnnotationColor(_boardColor);SyncOptionColor();
            await Clipxel.Services.ClipboardService.SetTextAsync(hex);
            _lastCopiedHex=hex;if(IsVisible&&_canvasPicking)UpdateStatus();
        }
        catch(Exception ex){App.LogError("Canvas color copy",ex);if(IsVisible)_status.Text="色號複製失敗，請再點一次。";}
        finally{_copyingCanvasColor=false;}
    }
    private void SelectInkIn(Rect region)
    {
        for(int i=0;i<_ink.Count;i++)
        {var bounds=AnnotationRenderer.Build(_ink[i]).Bounds;bounds.Inflate(2/_zoom.ScaleX,2/_zoom.ScaleX);if(region.IntersectsWith(bounds))_selectedInk.Add(i);}
    }
    internal static void VerifyMarqueeInk()
    {
        var board=new ReferenceBoardWindow{AllowClose=true};
        try
        {
            foreach(var tool in new[]{AnnotationTool.Pen,AnnotationTool.Rectangle,AnnotationTool.Circle,AnnotationTool.Arrow,AnnotationTool.Text})
            {
                var ink=new Annotation{Tool=tool,Start=new Point(20,20),End=new Point(60,60),Text="文字",Color=Colors.White};ink.Points.Add(new Point(20,20));ink.Points.Add(new Point(60,60));board._ink.Add(ink);
            }
            board.SelectInkIn(new Rect(0,0,200,200));if(board._selectedInk.Count!=5)throw new InvalidOperationException("Marquee missed annotation kinds");
            board.ResetDocumentHistory();board._selectionDragging=true;board._creativeStart=new Point(0,0);
            foreach(int index in board._selectedInk)board._selectionInkOrigins[index]=AnnotationTransforms.Clone(board._ink[index]);
            board.MoveInkSelection(new Point(30,40));board._selectionDragging=false;board.ObserveDocumentHistory();
            if(board._ink.Any(a=>a.Start!=new Point(50,60)))throw new InvalidOperationException("Selected ink did not move together");
            board.InkHistory(false);if(board._ink.Any(a=>a.Start!=new Point(20,20)))throw new InvalidOperationException("Undo failed after marquee drag");
            board.InkHistory(true);if(board._ink.Any(a=>a.Start!=new Point(50,60)))throw new InvalidOperationException("Redo failed after marquee drag");
        }
        finally{board.Close();}
    }
    private bool BeginInkSelectionDrag(Point point)
    {
        if(_selectedInk.Count==0)return false;
        bool hit=_selectedInk.Any(i=>i>=0&&i<_ink.Count&&AnnotationRenderer.Build(_ink[i]).Bounds.Contains(point))||_selected.Any(c=>new Rect(c.X,c.Y,c.Width,c.Height).Contains(point))||_selectedGroups.Any(g=>g.Bounds.Contains(point));
        if(!hit)return false;
        ObserveDocumentHistory();_selectionDragging=true;_creativeStart=point;_selectionInkOrigins.Clear();_selectionGroupOrigins.Clear();_dragOrigins.Clear();
        foreach(int i in _selectedInk.Where(i=>i>=0&&i<_ink.Count))_selectionInkOrigins[i]=AnnotationTransforms.Clone(_ink[i]);
        foreach(var group in _selectedGroups)_selectionGroupOrigins[group]=group.Bounds;
        foreach(var card in _selected.Concat(_cards.Values.Where(c=>GroupFor(c)is ReferenceGroup g&&_selectedGroups.Contains(g))).Distinct())_dragOrigins[card]=new Point(card.X,card.Y);
        _viewport.CaptureMouse();return true;
    }
    private bool MoveInkSelection(Point at)
    {
        if(!_selectionDragging)return false;var delta=at-_creativeStart;
        foreach(var pair in _selectionInkOrigins)_ink[pair.Key]=AnnotationTransforms.Translate(pair.Value,delta);
        foreach(var pair in _selectionGroupOrigins){var rect=pair.Value;rect.Offset(delta);pair.Key.Bounds=rect;}
        foreach(var pair in _dragOrigins){pair.Key.X=pair.Value.X+delta.X;pair.Key.Y=pair.Value.Y+delta.Y;Layout(pair.Key);}
        RenderCreative();return true;
    }
}
