using System;
using System.Linq;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    internal static void VerifyLegacyLinkMigration()
    {
        var first=new ReferenceGroup{Id="a",Bounds=new System.Windows.Rect(0,0,100,80)};
        var second=new ReferenceGroup{Id="b",Bounds=new System.Windows.Rect(200,0,100,80)};
        var data=new LinkData{From="a",To="b",FromSide=1,ToSide=0,Style=Clipxel.Models.LineStyle.Dashed,Width=5,Color="#FF336699"};
        var ink=System.Linq.Enumerable.Single(ConvertLegacyLinks(new[]{data},new[]{first,second}));
        if(ink.Tool!=AnnotationTool.Arrow||ink.LineStyle!=Clipxel.Models.LineStyle.Dashed||ink.StrokeWidth!=5||ink.Start!=new System.Windows.Point(100,40)||ink.End!=new System.Windows.Point(200,40))
            throw new System.InvalidOperationException("Legacy connection geometry/style was lost.");
        var before=ink.End;second.Bounds=new System.Windows.Rect(400,0,100,80);
        if(ink.End!=before)throw new System.InvalidOperationException("Imported line must not retain node attachment.");
    }
    internal static void VerifyToolSwitching()
    {
        var board=new ReferenceBoardWindow{AllowClose=true};
        try
        {
            var tools=new[]{AnnotationTool.Pen,AnnotationTool.Rectangle,AnnotationTool.Text,AnnotationTool.Arrow,AnnotationTool.Circle,AnnotationTool.None};
            for(int pass=0;pass<30;pass++)foreach(var tool in tools)
            {
                board.SetBoardTool(tool,false);board.ApplyToolOptions();
                if(board._boardTool!=tool||board._optionsFor!=tool||board._updatingOptions||board._historyBatch!=0)throw new InvalidOperationException("Tool switching left an incomplete UI transaction");
            }
            board.SetBoardTool(AnnotationTool.Pen,false);var removed=board._optionBars.First();
            board.SetBoardTool(AnnotationTool.Text,false);double width=board._boardWidth,font=board._boardFont;
            removed.Value=Math.Min(removed.Maximum,removed.Value+7);
            var removedFont=board._toolOptionsBody!.Children.OfType<System.Windows.Controls.ComboBox>().First();
            board.SetBoardTool(AnnotationTool.Pen,false);string family=board._boardFontFamily;
            removedFont.SelectedIndex=removedFont.SelectedIndex==0?1:0;
            if(board._boardFontFamily!=family)throw new InvalidOperationException("Detached font menu changed active settings");
            if(board._boardWidth!=width||board._boardFont!=font)throw new InvalidOperationException("Detached slider changed active settings");
        }
        finally{board.Close();}
    }
}
