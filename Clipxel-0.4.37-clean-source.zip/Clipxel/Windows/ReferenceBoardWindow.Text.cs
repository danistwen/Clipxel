using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Rendering;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    internal static void VerifyInlineText()
    {
        var board=new ReferenceBoardWindow{AllowClose=true};
        try
        {
            board.BeginCanvasText(new Point(20,30));board._canvasTextEditor!.Text="中文測試\nSecond line";board.CommitCanvasText();
            if(board._ink.Count!=1||board._ink[0].Start!=new Point(20,30)||board._ink[0].Text!="中文測試\nSecond line")throw new InvalidOperationException("Inline text commit failed.");
            board.BeginCanvasText(new Point(),0);board._canvasTextEditor!.Text="取消修改";board.CommitCanvasText(cancel:true);
            if(board._ink[0].Text!="中文測試\nSecond line")throw new InvalidOperationException("Cancel changed existing text.");
            board.InkHistory(false);if(board._ink.Count!=0)throw new InvalidOperationException("Inline commit should be one undo step.");
            board.InkHistory(true);if(board._ink.Count!=1)throw new InvalidOperationException("Inline text redo failed.");
        }
        finally{board.Close();}
    }
    private TextBox? _canvasTextEditor;
    private Annotation? _canvasTextDraft;
    private int _canvasTextIndex=-1,_selectedCanvasText=-1;
    private void BeginCanvasText(Point point,int index=-1)
    {
        CommitCanvasText();EndGesture();ObserveDocumentHistory();
        _canvasTextIndex=index;_selectedCanvasText=-1;
        _canvasTextDraft=index>=0?AnnotationTransforms.Clone(_ink[index]):new Annotation {Tool=AnnotationTool.Text,Start=point,End=point,Text="",Color=AnnotationStyle.Visible(_boardColor),FontSize=_boardFont,FontFamily=_boardFontFamily};
        var model=_canvasTextDraft;
        _boardFont=model.FontSize;_boardFontFamily=model.FontFamily;_boardColor=model.Color;
        var editor=new TextBox {Text=model.Text,AcceptsReturn=true,AcceptsTab=false,TextWrapping=TextWrapping.Wrap,MinWidth=120,MaxWidth=1200,MinHeight=36,Padding=new Thickness(5),Background=new SolidColorBrush(Color.FromArgb(180,45,50,60)),BorderBrush=Clipxel.Services.ThemeService.ActiveToolInk,BorderThickness=new Thickness(1),CaretBrush=Brushes.White,FontFamily=new FontFamily(model.FontFamily),FontSize=model.FontSize,Foreground=new SolidColorBrush(model.Color)};
        _canvasTextEditor=editor;_activeInk=-1;
        Canvas.SetLeft(editor,model.Start.X-6);Canvas.SetTop(editor,model.Start.Y-6);Panel.SetZIndex(editor,2000001);_surface.Children.Add(editor);
        void FitText(){double longest=0;foreach(var line in editor.Text.Split('\n'))longest=Math.Max(longest,new FormattedText(line.Length==0?" ":line,System.Globalization.CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,new Typeface(editor.FontFamily,FontStyles.Normal,FontWeights.Normal,FontStretches.Normal),editor.FontSize,Brushes.Black,1).WidthIncludingTrailingWhitespace);editor.Width=Math.Clamp(longest+24,120,1200);}
        editor.TextChanged+=(_,_)=>FitText();FitText();
        editor.PreviewMouseMove+=(_,e)=>editor.Cursor=TextAnnotationChrome.IsEditorEdge(e.GetPosition(editor),editor.RenderSize)?Cursors.SizeAll:Cursors.IBeam;
        editor.PreviewMouseLeftButtonDown+=(_,e)=>
        {
            if(!TextAnnotationChrome.IsEditorEdge(e.GetPosition(editor),editor.RenderSize))return;
            int selected=CommitCanvasText(select:true);
            if(selected>=0){_activeInk=selected;_creativeStart=World(e.GetPosition(_viewport));_inkDragOrigin=AnnotationTransforms.Clone(_ink[selected]);_viewport.Focus();_viewport.CaptureMouse();RenderCreative();}e.Handled=true;
        };
        editor.PreviewMouseRightButtonDown+=(_,e)=>{SetBoardTool(AnnotationTool.None,false);e.Handled=true;};
        editor.PreviewKeyDown+=(_,e)=>
        {
            if(Clipxel.Services.LocalShortcuts.Match(App.Settings.BoardShortcuts,e.Key,Keyboard.Modifiers)=="SaveProject"){CommitCanvasText();PerformBoardAction(BoardAction.SaveProject);e.Handled=true;}
            else if(e.Key==Key.Escape){CommitCanvasText(cancel:true);_viewport.Focus();e.Handled=true;}
            else if(e.Key==Key.Enter&&Keyboard.Modifiers.HasFlag(ModifierKeys.Control)){CommitCanvasText();_viewport.Focus();e.Handled=true;}
        };
        _embeddedToolbar?.SetActiveTool(AnnotationTool.Text);_embeddedToolbar?.SetFontSize(model.FontSize);_embeddedToolbar?.SetAnnotationColor(model.Color);
        RenderCreative();editor.Focus();editor.CaretIndex=editor.Text.Length;
    }
    private int CommitCanvasText(bool cancel=false,bool select=false)
    {
        var editor=_canvasTextEditor;var draft=_canvasTextDraft;if(editor is null||draft is null)return -1;
        int index=_canvasTextIndex;_canvasTextEditor=null;_canvasTextDraft=null;_canvasTextIndex=-1;_surface.Children.Remove(editor);
        if(!cancel)
        {
            draft=AnnotationTransforms.WithTextStyle(draft,text:editor.Text);
            if(!string.IsNullOrWhiteSpace(draft.Text)){if(index>=0)_ink[index]=draft;else{index=_ink.Count;_ink.Add(draft);}}
            else if(index>=0){_ink.RemoveAt(index);index=-1;}
        }
        _selectedCanvasText=select?index:-1;_activeInk=select?index:-1;_embeddedToolbar?.SetActiveTool(_boardTool);RenderCreative();return index;
    }
    private void UpdateCanvasTextStyle()
    {
        if(_canvasTextEditor is not null&&_canvasTextDraft is not null)
        {
            _canvasTextDraft=AnnotationTransforms.WithTextStyle(_canvasTextDraft,color:_boardColor,fontSize:_boardFont,fontFamily:_boardFontFamily);
            _canvasTextEditor.Foreground=new SolidColorBrush(_boardColor);_canvasTextEditor.FontSize=_boardFont;_canvasTextEditor.FontFamily=new FontFamily(_boardFontFamily);
        }
        else if(_activeInk>=0&&_activeInk<_ink.Count&&_ink[_activeInk].Tool==AnnotationTool.Text)
        {
            _ink[_activeInk]=AnnotationTransforms.WithTextStyle(_ink[_activeInk],color:_boardColor,fontSize:_boardFont,fontFamily:_boardFontFamily);RenderCreative();
        }
    }
}
