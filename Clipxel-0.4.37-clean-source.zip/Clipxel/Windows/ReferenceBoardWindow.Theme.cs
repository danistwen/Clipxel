using System.Windows.Media;
using Clipxel.Services;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    internal void ApplyBrandTheme()
    {
        _viewport.Background=new SolidColorBrush(Clipxel.Services.ThemeService.Background);
        Background=_viewport.Background;
        _status.Foreground=Clipxel.Services.ThemeService.Foreground;
        _documentVersion++;
        UpdateToolButtons();
    }
}
