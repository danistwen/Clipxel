using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Controls;
using Clipxel.Models;
using Clipxel.Services;
namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private Border? _toolOptions;
    private StackPanel? _toolOptionsBody;
    private TextBlock? _toolOptionsTitle;
    private AnnotationTool _optionsFor=(AnnotationTool)(-1);
    private readonly List<Slider> _optionBars=new();
    private Border? _optionColor;
    private double _optionsX=double.NaN,_optionsY=double.NaN;
    private void BuildToolOptions(Grid host)
    {
        var grid=new Grid();grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});grid.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        _toolOptions=new Border{Width=290,Height=double.NaN,MinWidth=220,MinHeight=0,CornerRadius=new CornerRadius(5),BorderThickness=new Thickness(1),BorderBrush=new SolidColorBrush(Color.FromRgb(85,89,97)),Background=new SolidColorBrush(Color.FromArgb(245,43,46,52)),Child=grid,HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Top,Visibility=Visibility.Collapsed};
        CanvasTheme.Apply(_toolOptions,Color.FromRgb(43,46,52));
        _toolOptions.SetValue(TextBlock.ForegroundProperty,Brushes.WhiteSmoke);
        var head=new Grid{Height=28};_toolOptionsTitle=new TextBlock{Margin=new Thickness(30,4,4,4),IsHitTestVisible=false,Foreground=Clipxel.Services.ThemeService.Foreground};head.Children.Add(_toolOptionsTitle);head.Children.Add(new Clipxel.Rendering.ToolGlyph{Glyph="DragHandle",Width=16,Height=18,HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(8,0,0,0),Foreground=Clipxel.Services.ThemeService.Foreground});
        var drag=OptionThumb(Cursors.SizeAll);head.Children.Add(drag);grid.Children.Add(head);
        _toolOptionsBody=new StackPanel{Width=266,Margin=new Thickness(10,0,10,12)};
        var fit=new Viewbox{Child=_toolOptionsBody,Stretch=Stretch.Uniform,HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Top};Grid.SetRow(fit,1);grid.Children.Add(fit);
        var resize=OptionThumb(Cursors.SizeWE);resize.Width=resize.Height=14;resize.HorizontalAlignment=HorizontalAlignment.Right;resize.VerticalAlignment=VerticalAlignment.Bottom;Grid.SetRow(resize,1);grid.Children.Add(resize);
        drag.DragDelta+=(_,e)=>{_optionsX=_toolOptions.Margin.Left+e.HorizontalChange;_optionsY=_toolOptions.Margin.Top+e.VerticalChange;ClampToolOptions();};
        resize.DragDelta+=(_,e)=>{_toolOptions.Width=Math.Max(220,_toolOptions.Width+e.HorizontalChange);ClampToolOptions();};
        _toolOptions.PreviewMouseRightButtonDown+=(_,e)=>e.Handled=true;
        host.Children.Add(_toolOptions);Loaded+=(_,_)=>ClampToolOptions();_viewport.SizeChanged+=(_,_)=>ClampToolOptions();UpdateToolOptions();
    }
    private static Thumb OptionThumb(Cursor cursor)
    {
        var factory=new FrameworkElementFactory(typeof(Border));factory.SetValue(Border.BackgroundProperty,Brushes.Transparent);
        return new Thumb{Cursor=cursor,Template=new ControlTemplate(typeof(Thumb)){VisualTree=factory}};
    }
    private void HideEmbeddedOptions()
    {
        if(_embeddedToolbar is null)return;
        foreach(string name in new[]{"ColorButton","StrokeButton","ShapeStrokeToggleButton","ShapeStrokeOpacityGroup","ShapeFillToggleButton","ShapeFillOpacityGroup","ShapeControlsDivider"})
        {
            if(_embeddedToolbar.FindName(name)is not FrameworkElement element)continue;
            if((name is "ColorButton" or "StrokeButton") && element.Parent is FrameworkElement parent)parent.Visibility=Visibility.Collapsed;
            else element.Visibility=Visibility.Collapsed;
        }
    }
    private bool _updatingOptions,_optionsDirty;
    private System.Windows.Threading.DispatcherOperation? _optionsRefresh;
    private int _optionsGeneration;
    private static readonly Lazy<string[]> AvailableFonts=new(()=>Fonts.SystemFontFamilies.Select(f=>f.Source).OrderBy(s=>s).ToArray());
    private void UpdateToolOptions()
    {
        if(_toolOptions is null)return;
        if(_updatingOptions){_optionsDirty=true;return;}
        if(!IsLoaded){ApplyToolOptions();return;}
        if(_optionsRefresh?.Status==System.Windows.Threading.DispatcherOperationStatus.Pending)return;
        _optionsRefresh=Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,new Action(()=>{_optionsRefresh=null;ApplyToolOptions();}));
    }
    private void ApplyToolOptions()
    {
        if(_updatingOptions)return;
        _updatingOptions=true;
        try{RebuildToolOptions();}
        finally{_updatingOptions=false;if(_optionsDirty){_optionsDirty=false;UpdateToolOptions();}}
    }
    private void RebuildToolOptions()
    {
        HideEmbeddedOptions();if(_toolOptions is null||_toolOptionsBody is null)return;
        var tool=_canvasTextEditor is not null?AnnotationTool.Text:_boardTool;
        if(tool==AnnotationTool.None&&_selectedInk.Count>0){var first=_selectedInk.FirstOrDefault(i=>i>=0&&i<_ink.Count,-1);if(first>=0)tool=_ink[first].Tool;}
        bool groupMode=tool==AnnotationTool.None&&(_groupTool||_activeGroup is not null);
        if(tool!=_optionsFor||groupMode!=_optionsGroupMode||_optionsGroup!=_activeGroup)
        {
            SliderScrub.CancelWithin(_toolOptionsBody);_optionsGeneration++;
            _optionsGroupMode=groupMode;_optionsGroup=_activeGroup;_optionsFor=tool;_toolOptionsBody.Children.Clear();_optionBars.Clear();_optionColor=null;
            _toolOptionsTitle!.Text=tool switch{AnnotationTool.Pen=>"畫筆設定",AnnotationTool.Text=>"文字設定",AnnotationTool.Arrow=>"線條設定",AnnotationTool.Rectangle or AnnotationTool.Circle=>"形狀設定",_=>"工具設定"};
            if(groupMode){BuildGroupOptions();}
            if(tool!=AnnotationTool.None)
            {
                int generation=_optionsGeneration;
                _optionColor=new Border{Width=54,Height=26,CornerRadius=new CornerRadius(5)};
                var swatch=new Button{Content=_optionColor,Padding=new Thickness(3),HorizontalAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,4,0,8),Background=Brushes.Transparent,BorderThickness=new Thickness(0)};
                ToolHints.Attach(swatch,()=>"顏色",()=>null);_toolOptionsBody.Children.Add(swatch);
                swatch.Click+=(_,_)=>{if(generation!=_optionsGeneration)return;_boardColor=AnnotationStyle.Visible(PickColor(_boardColor,c=>{_boardColor=AnnotationStyle.Visible(c);EditSelectedStyle(a=>AnnotationStyle.With(a,color:_boardColor));UpdateCanvasTextStyle();SyncOptionColor();}));UpdateCanvasTextStyle();_optionsFor=(AnnotationTool)(-1);UpdateToolOptions();};
                if(tool==AnnotationTool.Text)
                {
                    var fonts=new ComboBox{ItemsSource=AvailableFonts.Value,SelectedItem=_boardFontFamily,MaxDropDownHeight=260,Margin=new Thickness(0,2,0,6)};
                    fonts.SelectionChanged+=(_,_)=>{if(generation==_optionsGeneration && fonts.SelectedItem is string font){_boardFontFamily=font;EditSelectedStyle(a=>AnnotationStyle.With(a,font:font));UpdateCanvasTextStyle();}};_toolOptionsBody.Children.Add(fonts);
                    AddOptionBar("字級",8,120,_boardFont,value=>{_boardFont=value;EditSelectedStyle(a=>AnnotationStyle.With(a,fontSize:value));UpdateCanvasTextStyle();});
                }
                else AddOptionBar("筆畫粗細",1,80,_boardWidth,value=>{_boardWidth=value;EditSelectedStyle(a=>AnnotationStyle.With(a,width:value));});
                AddOptionBar("顏色不透明度",5,100,_boardColor.A/255d*100,value=>{_boardColor=Color.FromArgb((byte)Math.Max(13,Math.Round(value*2.55)),_boardColor.R,_boardColor.G,_boardColor.B);EditSelectedStyle(a=>AnnotationStyle.With(a,color:_boardColor));UpdateCanvasTextStyle();SyncOptionColor();});
                if(tool is AnnotationTool.Rectangle or AnnotationTool.Circle)
                {
                    AddOptionSwitch("外框",_boardStroke,value=>{_boardStroke=value;EditSelectedStyle(a=>AnnotationStyle.With(a,stroke:value));});AddOptionBar("外框不透明度",5,100,_boardStrokeOpacity*100,value=>{_boardStrokeOpacity=value/100;EditSelectedStyle(a=>AnnotationStyle.With(a,strokeOpacity:value/100));});
                    AddOptionSwitch("填滿",_boardFill,value=>{_boardFill=value;EditSelectedStyle(a=>AnnotationStyle.With(a,fill:value));});AddOptionBar("填滿不透明度",5,100,_boardFillOpacity*100,value=>{_boardFillOpacity=value/100;EditSelectedStyle(a=>AnnotationStyle.With(a,fillOpacity:value/100));});
                }
                if(tool==AnnotationTool.Arrow)
                {
                    var lines=new ComboBox{ItemsSource=new[]{"箭頭","純直線","虛線","圓端點"},SelectedIndex=(int)_boardLineStyle};
                    lines.SelectionChanged+=(_,_)=>{if(generation==_optionsGeneration && lines.SelectedIndex>=0){_boardLineStyle=(LineStyle)lines.SelectedIndex;EditSelectedStyle(a=>AnnotationStyle.With(a,line:_boardLineStyle));if(_embeddedToolbar?.FindName("ArrowButton")is Button arrow)arrow.Content=new Clipxel.Rendering.ToolGlyph{Glyph=_boardLineStyle.ToString()};}};_toolOptionsBody.Children.Add(lines);
                }
            }
        }
        SyncOptionColor();ClampToolOptions();
    }
    private void AddOptionSwitch(string name,bool initial,Action<bool> change)
    {
        var toggle=new CheckBox{Content=name,IsChecked=initial,Style=(Style)Application.Current.FindResource("SwitchToggle"),Foreground=Clipxel.Services.ThemeService.Foreground,Margin=new Thickness(0,4,0,2)};
        int generation=_optionsGeneration;toggle.Checked+=(_,_)=>{if(!_updatingOptions&&generation==_optionsGeneration)change(true);};toggle.Unchecked+=(_,_)=>{if(!_updatingOptions&&generation==_optionsGeneration)change(false);};_toolOptionsBody!.Children.Add(toggle);
    }
    private void AddOptionBar(string name,double min,double max,double value,Action<double> change)
    {
        var label=new TextBlock{Text=name,Foreground=Clipxel.Services.ThemeService.Foreground,FontSize=11};
        var slider=new Slider{Minimum=min,Maximum=max,Value=value,IsMoveToPointEnabled=true,Margin=new Thickness(0,0,0,4),Tag=name.Contains("透明")?"Opacity":"Color"};
        int generation=_optionsGeneration;bool editing=false;
        void EndEdit(){if(!editing)return;editing=false;_historyBatch--;ObserveDocumentHistory();}
        slider.GotMouseCapture+=(_,_)=>{if(!_updatingOptions&&generation==_optionsGeneration&&!editing){ObserveDocumentHistory();_historyBatch++;editing=true;}};
        slider.LostMouseCapture+=(_,_)=>EndEdit();slider.Unloaded+=(_,_)=>EndEdit();
        slider.ValueChanged+=(_,_)=>{if(_updatingOptions||generation!=_optionsGeneration)return;change(slider.Value);};_optionBars.Add(slider);var heading=new DockPanel();var number=Clipxel.Controls.NumericSlider.Editor(slider);DockPanel.SetDock(number,Dock.Right);heading.Children.Add(number);heading.Children.Add(label);_toolOptionsBody!.Children.Add(heading);
        var barRow=new DockPanel();_toolOptionsBody.Children.Add(barRow);
        if(name=="筆畫粗細")
        {
            // Round caps extend half the stroke width beyond each endpoint.
            // Reserve the maximum width once so adjusting thickness never clips or shifts the row.
            const double segmentLength=32,safePadding=4;
            double maximumStroke=slider.Maximum;
            double inset=maximumStroke/2+safePadding;
            var preview=new System.Windows.Shapes.Line{X1=inset,Y1=inset,X2=inset+segmentLength,Y2=inset,Stroke=new SolidColorBrush(_boardColor),StrokeThickness=slider.Value,StrokeStartLineCap=PenLineCap.Round,StrokeEndLineCap=PenLineCap.Round};
            var host=new Canvas{Width=segmentLength+maximumStroke+safePadding*2,Height=maximumStroke+safePadding*2,ClipToBounds=true,Margin=new Thickness(4,0,0,0),VerticalAlignment=VerticalAlignment.Center};host.Children.Add(preview);DockPanel.SetDock(host,Dock.Right);barRow.Children.Add(host);
            slider.VerticalAlignment=VerticalAlignment.Center;
            slider.ValueChanged+=(_,_)=>{preview.StrokeThickness=slider.Value;preview.Stroke=new SolidColorBrush(_boardColor);};_widthPreview=preview;
        }
        barRow.Children.Add(slider);
    }
    private System.Windows.Shapes.Line? _widthPreview;
    private void SyncOptionColor()
    {
        if(_widthPreview is not null)_widthPreview.Stroke=new SolidColorBrush(_boardColor);
        if(_optionColor is not null)_optionColor.Background=new SolidColorBrush(_boardColor);
        foreach(var slider in _optionBars.ToArray())slider.Resources["SliderFill"]=Equals(slider.Tag,"Opacity")?Brushes.WhiteSmoke:new SolidColorBrush(_optionsGroupMode&&_optionsGroup is not null?_optionsGroup.Fill:Color.FromRgb(_boardColor.R,_boardColor.G,_boardColor.B));
    }
    private void ClampToolOptions()
    {
        if(_toolOptions is null||_floatHost is null)return;
        _toolOptions.Visibility=_drawingVisible&&(_optionsFor!=AnnotationTool.None||_optionsGroupMode)?Visibility.Visible:Visibility.Collapsed;
        if(!_viewport.IsLoaded)return;
        Point start=_viewport.TranslatePoint(new Point(),_floatHost);
        _toolOptions.Width=Math.Min(_toolOptions.Width,Math.Max(220,_viewport.ActualWidth-16));_toolOptions.Height=double.NaN;
        // Measure the content, excluding the floating panel's positioning margin.
        double optionsHeight=28;
        if(_toolOptions.Child is FrameworkElement content)
        {
            content.Measure(new Size(Math.Max(1,_toolOptions.Width-2),double.PositiveInfinity));
            optionsHeight=content.DesiredSize.Height+2;
        }
        double right=Math.Max(start.X+8,start.X+_viewport.ActualWidth-_toolOptions.Width-8),bottom=Math.Max(start.Y+8,start.Y+_viewport.ActualHeight-optionsHeight-8);
        double x=Math.Clamp(double.IsNaN(_optionsX)?start.X+(_viewport.ActualWidth-_toolOptions.Width)/2:_optionsX,start.X+8,right),
            y=Math.Clamp(double.IsNaN(_optionsY)?start.Y+(_viewport.ActualHeight-optionsHeight)/2:_optionsY,start.Y+8,bottom);
        _toolOptions.Margin=new Thickness(x,y,0,0);
    }
}
