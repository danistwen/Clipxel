using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Models;
using Clipxel.Rendering;

namespace Clipxel.Windows;
public sealed partial class ReferenceBoardWindow
{
    private Border? _floating;
    private Button? _drawingToggleButton;
    private Grid? _floatHost;
    private double _floatingX=16,_floatingY=60;
    private bool _drawingVisible=true,_snapEnabled=true;
    private bool _boardStroke=true,_boardFill;
    private double _boardStrokeOpacity=1,_boardFillOpacity=.45;
    private TextBox? _groupNameEditor;
    private ReferenceGroup? _renamingGroup,_resizingGroup;
    private int _resizeCorner;
    private Rect _resizeOrigin;

    private void BuildFloatingTools(Grid host)
    {
        _floatHost=host;var panel=new Grid();
        _floating=new Border { Width=_floatingWidth,Child=panel,CornerRadius=new CornerRadius(20),Background=(Brush)Application.Current.FindResource("GlassShell"),BorderBrush=(Brush)Application.Current.FindResource("GlassEdge"),BorderThickness=new Thickness(1),HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Top };
        _floating.SetResourceReference(Border.BackgroundProperty,"GlassShell");
        var content=EmbeddedDrawingTools();content.Margin=new Thickness(0,2,0,2);panel.Children.Add(content);
        // Transparent resize hit strips have no stock Thumb border or white control lines.
        System.Windows.Controls.Primitives.Thumb ResizeGrip(HorizontalAlignment side)
        {
            var visual=new FrameworkElementFactory(typeof(Border));visual.SetValue(Border.BackgroundProperty,Brushes.Transparent);
            return new System.Windows.Controls.Primitives.Thumb { Width=5,HorizontalAlignment=side,Cursor=Cursors.SizeWE,Template=new ControlTemplate(typeof(System.Windows.Controls.Primitives.Thumb)) { VisualTree=visual } };
        }
        var leftResize=ResizeGrip(HorizontalAlignment.Left);var rightResize=ResizeGrip(HorizontalAlignment.Right);panel.Children.Add(leftResize);panel.Children.Add(rightResize);
        rightResize.DragDelta+=(_,e)=>{_floatingWidth=Math.Max(52,_floatingWidth+e.HorizontalChange);ClampFloating();};
        leftResize.DragDelta+=(_,e)=>{double before=_floatingWidth;_floatingWidth=Math.Max(52,_floatingWidth-e.HorizontalChange);_floatingX+=before-_floatingWidth;ClampFloating();};
        Point origin=new();double x=0,y=0;bool armed=false,dragging=false;
        _floating.PreviewMouseLeftButtonDown+=(_,e)=>
        {
            armed=dragging=false;
            if(Clipxel.Services.InputBoundary.IsControlInteraction(e.OriginalSource as DependencyObject,_floating))return;
            if(e.OriginalSource is DependencyObject source)
            {
                for(var node=source;node is not null;node=node is Visual?VisualTreeHelper.GetParent(node):LogicalTreeHelper.GetParent(node))
                    if(node is System.Windows.Controls.Primitives.Thumb)return;
            }
            armed=true;dragging=false;origin=e.GetPosition(host);x=_floatingX;y=_floatingY;
        };
        _floating.PreviewMouseMove+=(_,e)=>
        {
            if(!armed||e.LeftButton!=MouseButtonState.Pressed)return;Vector d=e.GetPosition(host)-origin;
            if(!dragging && (Math.Abs(d.X)>SystemParameters.MinimumHorizontalDragDistance||Math.Abs(d.Y)>SystemParameters.MinimumVerticalDragDistance)) { dragging=true;_floating.CaptureMouse(); }
            if(dragging){_floatingX=x+d.X;_floatingY=y+d.Y;ClampFloating();e.Handled=true;}
        };
        _floating.PreviewMouseLeftButtonUp+=(_,e)=>{if(dragging){e.Handled=true;_floating.ReleaseMouseCapture();}armed=dragging=false;};
        _floating.LostMouseCapture+=(_,_)=>{if(dragging&&!_floating.IsMouseCaptured)armed=dragging=false;};
        _floating.SizeChanged+=(_,_)=>ClampFloating();
        host.Children.Add(_floating);
        var restore=ToolButton(BoardAction.ToggleDrawing,remember:false);_drawingToggleButton=restore;restore.HorizontalAlignment=HorizontalAlignment.Right;restore.VerticalAlignment=VerticalAlignment.Bottom;restore.Margin=new Thickness(0,0,8,48);restore.SetResourceReference(Control.BackgroundProperty,"DarkGlass");host.Children.Add(restore);
        Loaded+=(_,_)=>ClampFloating();SizeChanged+=(_,_)=>ClampFloating();_viewport.SizeChanged+=(_,_)=>ClampFloating();UpdateDrawingControls();
    }
    private static void AddOpacityBar(Panel panel,double value,Action<double> change)
    {
        panel.Children.Add(new ToolGlyph { Glyph="Opacity",Margin=new Thickness(4) });
        var label=new TextBlock { Text=$"{value:P0}",Width=40,VerticalAlignment=VerticalAlignment.Center,Foreground=Brushes.DimGray };
        var bar=new Slider { Width=80,Minimum=0,Maximum=1,Value=value,IsMoveToPointEnabled=true,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(4) };
        bar.ValueChanged+=(_,_)=>{change(bar.Value);label.Text=$"{bar.Value:P0}";};panel.Children.Add(Clipxel.Controls.NumericSlider.Wrap(bar));panel.Children.Add(label);
    }
    private void ToggleDrawingPanel()
    {
        
        _drawingVisible=!_drawingVisible;
        if (!_drawingVisible) _embeddedToolbar?.ClosePopups();
        ClampFloating();
    }
    private bool _clampingFloating;
    private void ClampFloating()
    {
        ClampToolOptions();
        if(_floating is null||_floatHost is null||_clampingFloating)return;
        _clampingFloating=true;
        try
        {
            _floating.Visibility=_drawingVisible?Visibility.Visible:Visibility.Collapsed;
            if(_drawingToggleButton is not null)_drawingToggleButton.Foreground=_drawingVisible?Clipxel.Services.ThemeService.ActiveToolInk:Clipxel.Services.ThemeService.Foreground;
            if(!_viewport.IsLoaded)return;
            Point start=_viewport.TranslatePoint(new Point(),_floatHost);double width=_viewport.ActualWidth,height=_viewport.ActualHeight;
            int count=_adaptiveTools?.VisibleCount??8;
            int maxRows=Math.Max(1,(int)((height-32)/AdaptiveToolPanel.Cell));
            double minimum=18+AdaptiveToolPanel.Cell*Math.Max(1,(int)Math.Ceiling((double)count/maxRows));
            _floating.Width=Math.Clamp(_floatingWidth,minimum,Math.Max(minimum,width-16));
            _floating.Height=double.NaN;
            var layout=AdaptiveToolPanel.LayoutFor(count,Math.Max(34,_floating.Width-18));_floatingHeight=layout.Rows*AdaptiveToolPanel.Cell+18;
            _floatingX=Math.Clamp(_floatingX,start.X+8,Math.Max(start.X+8,start.X+width-_floating.Width-8));
            _floatingY=Math.Clamp(_floatingY,start.Y+8,Math.Max(start.Y+8,start.Y+height-_floatingHeight-8));
            _floating.Margin=new Thickness(_floatingX,_floatingY,0,0);
        }
        finally{_clampingFloating=false;}
    }
    private void BeginGroupRename(ReferenceGroup group)
    {
        CommitGroupRename();_renamingGroup=group;
        var editor=new TextBox { Text=group.Name,Width=Math.Max(60,group.Bounds.Width-42),Height=group.TitleSize*1.5+8,FontSize=group.TitleSize,Padding=new Thickness(2),Background=new SolidColorBrush(Color.FromRgb(36,40,52)),Foreground=new SolidColorBrush(group.TitleColor),BorderBrush=Clipxel.Services.ThemeService.ActiveToolInk };
        _groupNameEditor=editor;Canvas.SetLeft(editor,group.Bounds.X+5);Canvas.SetTop(editor,group.Bounds.Y+1);Panel.SetZIndex(editor,2000000);_surface.Children.Add(editor);
        editor.KeyDown+=(_,e)=>{if(e.Key==Key.Enter){CommitGroupRename();e.Handled=true;}else if(e.Key==Key.Escape){_renamingGroup=null;CommitGroupRename();e.Handled=true;}};
        editor.LostKeyboardFocus+=(_,_)=>CommitGroupRename();editor.Focus();editor.SelectAll();
    }
    private void CommitGroupRename()
    {
        var editor=_groupNameEditor;if(editor is null)return;_groupNameEditor=null;
        if(_renamingGroup is not null&&!string.IsNullOrWhiteSpace(editor.Text))_renamingGroup.Name=editor.Text.Trim();_renamingGroup=null;_surface.Children.Remove(editor);RenderCreative();
    }
    private void CreateGroupFromSelection()
    {
        if(_selected.Count==0) { _groupTool=!_groupTool;_boardTool=AnnotationTool.None;_panTool=false;UpdateDrawingControls();return; }
        _activeInk=-1; var cards=_selected.ToArray();Rect bounds=Rect.Empty;foreach(var c in cards)bounds.Union(new Rect(c.X,c.Y,c.Width,c.Height));bounds.Inflate(16,40);
        var group=new ReferenceGroup { Name="Reference "+(_groups.Count+1),Bounds=bounds };_groups.Add(group);_activeInk=-1;_activeGroup=group;
        // Arrange exactly the selected images; nearby unselected references remain untouched.
        ArrangeItemsInGroup(group,cards);_selected.Clear();_groupTool=true;_boardTool=AnnotationTool.None;_panTool=false;BeginGroupRename(group);UpdateDrawingControls();RenderCreative();
    }
    private void ArrangeItemsInGroup(ReferenceGroup group,Card[] cards)
    {
        if(cards.Length==0)return;int columns=Math.Max(1,(int)Math.Ceiling(Math.Sqrt(cards.Length)));
        double y=group.Bounds.Y+Math.Max(40,group.TitleSize*1.5+16),right=group.Bounds.X+16;
        for(int start=0;start<cards.Length;start+=columns)
        {
            double x=group.Bounds.X+16,rowHeight=0;
            foreach(var card in cards.Skip(start).Take(columns))
            {
                // Arrangement changes positions only; preserve each image's chosen size.
                card.X=x;card.Y=y;Layout(card);rowHeight=Math.Max(rowHeight,card.Height);right=Math.Max(right,x+card.Width);x+=card.Width+group.ColumnGap;
            }
            y+=rowHeight+group.RowGap;
        }
        group.Bounds=new Rect(group.Bounds.Location,new Size(Math.Max(100,right-group.Bounds.X+16),Math.Max(70,y-group.RowGap-group.Bounds.Y+16)));

    }
    private void ArrangeTopLevel()
    {
        if(_selected.Count>0) { var selected=_selected.ToArray();var temp=new ReferenceGroup { Bounds=new Rect(selected.Min(c=>c.X),selected.Min(c=>c.Y)-40,100,100) };ArrangeItemsInGroup(temp,selected);return; }
        var memberships=_groups.ToDictionary(g=>g,g=>_cards.Values.Where(c=>GroupFor(c)==g).ToArray());
        var loose=_cards.Values.Where(c=>GroupFor(c)is null).ToArray();int count=_groups.Count+loose.Length;if(count==0)return;
        int columns=Math.Max(1,(int)Math.Ceiling(Math.Sqrt(count)));double x=0,y=0,rowHeight=0;int index=0;
        foreach(var group in _groups)
        {
            Vector delta=new Point(x,y)-group.Bounds.Location;var rect=group.Bounds;rect.Offset(delta);group.Bounds=rect;
            foreach(var c in memberships[group]){c.X+=delta.X;c.Y+=delta.Y;Layout(c);}rowHeight=Math.Max(rowHeight,rect.Height);x+=rect.Width+40;if(++index%columns==0){x=0;y+=rowHeight+40;rowHeight=0;}
        }
        foreach(var c in loose) { c.X=x;c.Y=y;Layout(c);rowHeight=Math.Max(rowHeight,c.Height);x+=c.Width+40;if(++index%columns==0){x=0;y+=rowHeight+40;rowHeight=0;} }
        RenderCreative();FitAll();
    }
    private static Point[] Corners(Rect r)=>new[]{r.TopLeft,r.TopRight,r.BottomRight,r.BottomLeft};
    private static Point Port(ReferenceGroup g,int side)=>side switch { 0=>new Point(g.Bounds.Left,g.Bounds.Top+g.Bounds.Height/2),1=>new Point(g.Bounds.Right,g.Bounds.Top+g.Bounds.Height/2),2=>new Point(g.Bounds.Left+g.Bounds.Width/2,g.Bounds.Top),_=>new Point(g.Bounds.Left+g.Bounds.Width/2,g.Bounds.Bottom) };
    private bool GroupPointerDown(Point point)
    {
        if(_boardTool!=AnnotationTool.None||_groupTool)return false;
        double hit=12/_zoom.ScaleX;
        foreach(var group in _groups.AsEnumerable().Reverse())
        {
            
            int handle=GroupResizeHit(group.Bounds,point,hit);
            if(handle>=0)
            { _activeInk=-1;_activeGroup=group;_resizingGroup=group;_resizeCorner=handle;_resizeOrigin=group.Bounds;_selected.Clear();_viewport.CaptureMouse();RenderCreative();return true; }

        }
        return false;
    }
    private bool MoveGroupResize(Point point)
    {
        if(_resizingGroup is null)return false;
        _resizingGroup.Bounds=ResizeGroupBounds(_resizeOrigin,_resizeCorner,point);RenderCreative();return true;
    }
    private static int GroupResizeHit(Rect bounds,Point point,double hit)
    {
        var corners=Corners(bounds);
        for(int i=0;i<4;i++)if((corners[i]-point).Length<=hit)return i;
        if(point.Y>=bounds.Top-hit&&point.Y<=bounds.Bottom+hit)
        {if(Math.Abs(point.X-bounds.Left)<=hit)return 4;if(Math.Abs(point.X-bounds.Right)<=hit)return 5;}
        if(point.X>=bounds.Left-hit&&point.X<=bounds.Right+hit)
        {if(Math.Abs(point.Y-bounds.Top)<=hit)return 6;if(Math.Abs(point.Y-bounds.Bottom)<=hit)return 7;}
        return -1;
    }
    internal static Rect ResizeGroupBounds(Rect r,int handle,Point p)
    {
        double left=r.Left,right=r.Right,top=r.Top,bottom=r.Bottom;
        if(handle is 0 or 3 or 4)left=Math.Min(p.X,right-100);
        if(handle is 1 or 2 or 5)right=Math.Max(p.X,left+100);
        if(handle is 0 or 1 or 6)top=Math.Min(p.Y,bottom-70);
        if(handle is 2 or 3 or 7)bottom=Math.Max(p.Y,top+70);
        return new Rect(new Point(left,top),new Point(right,bottom));
    }

    private IEnumerable<DrawingGroup> GroupHandles()
    {
        var drawing=new DrawingGroup();using(var dc=drawing.Open())
        {
            if(_activeGroup is not null)foreach(var point in Corners(_activeGroup.Bounds).Concat(Enumerable.Range(0,4).Select(i=>Port(_activeGroup,i))))dc.DrawRectangle(Brushes.White,new Pen(Clipxel.Services.ThemeService.ActiveToolInk,1/_zoom.ScaleX),new Rect(point.X-4/_zoom.ScaleX,point.Y-4/_zoom.ScaleX,8/_zoom.ScaleX,8/_zoom.ScaleX));
        }drawing.Freeze();yield return drawing;
    }
    
    private void SnapMovedCards()
    {
        if(!_snapEnabled||_selected.Count==0)return;
        double distance=24/_zoom.ScaleX;
        foreach(var card in _selected)
        {
            var center=new Point(card.X+card.Width/2,card.Y+card.Height/2);
            var target=_groups.OrderBy(g=>g.Bounds.Width*g.Bounds.Height).FirstOrDefault(g=>{var r=g.Bounds;r.Inflate(distance,distance);return r.IntersectsWith(new Rect(card.X,card.Y,card.Width,card.Height));});
            if(target is null)continue;
            // Keep the entire image inside; reduce only if it cannot fit the region.
            double scale=Math.Min(1,Math.Min(Math.Max(1,target.Bounds.Width-24)/card.Width,Math.Max(1,target.Bounds.Height-48)/card.Height));card.Width*=scale;card.Height*=scale;
            card.X=Math.Clamp(card.X,target.Bounds.Left+12,Math.Max(target.Bounds.Left+12,target.Bounds.Right-card.Width-12));card.Y=Math.Clamp(card.Y,target.Bounds.Top+36,Math.Max(target.Bounds.Top+36,target.Bounds.Bottom-card.Height-12));Layout(card);_activeGroup=target;
        }
        RenderCreative();
    }
    private Color PickColor(Color current,Action<Color>? preview=null)
    {
        ObserveDocumentHistory();_historyBatch++;
        try{return Clipxel.Controls.ColorPicker.Pick(this,current,preview);}
        finally{_historyBatch--;ObserveDocumentHistory();}
    }
    private ContextMenu? _boardMenu;
    private ContextMenu Popup()
    {
        if(_boardMenu is not null)_boardMenu.IsOpen=false;
        var menu=new ContextMenu { PlacementTarget=_viewport,Placement=System.Windows.Controls.Primitives.PlacementMode.MousePoint };_boardMenu=menu;
        menu.Closed+=(_,_)=>{if(ReferenceEquals(_boardMenu,menu))_boardMenu=null;};
        bool batched=false;
        menu.Opened+=(_,_)=>{ObserveDocumentHistory();_historyBatch++;batched=true;};
        menu.Closed+=(_,_)=>{if(batched){batched=false;_historyBatch--;ObserveDocumentHistory();}};
        return menu;
    }
    private static string MenuGlyph(string label)=>label.Contains("透明")?"Opacity":label.Contains("線寬")?"StrokeWidth":label.Contains("磁吸")?"Magnet":label.Contains("置頂")?"Topmost":label.Contains("繪圖工具")?"ToggleDrawing":label.Contains("隱藏")&&label.Contains("視窗")?"ToggleChrome":label.Contains("標題顏色")?"TextColor":label.Contains("邊框顏色")?"StrokeColor":label.Contains("底色")?"FillColor":label.Contains("顏色")?"Color":label.Contains("字級")?"Font":label.Contains("命名")?"Rename":label.Contains("水平")?"Spacing":label.Contains("垂直")?"Rows":label.Contains("刪除")?"Delete":label.Contains("排列")?"Arrange":"Settings";
    private static void MenuAction(ItemsControl menu,string title,Action action)
    { var item=new MenuItem { Header=title,Icon=new ToolGlyph {Glyph=MenuGlyph(title),Foreground=Clipxel.Services.ThemeService.ActiveToolInk} };item.Click+=(_,_)=>action();menu.Items.Add(item); }
    private static void MenuSlider(ItemsControl menu,string title,double value,double min,double max,Action<double> action)
    {
        var panel=new StackPanel();var text=new TextBlock { Text=title+" "+value.ToString("0.##") };panel.Children.Add(text);
        var slider=new Slider { Width=180,Minimum=min,Maximum=max,Value=value,IsMoveToPointEnabled=true,Margin=new Thickness(4) };panel.Children.Add(Clipxel.Controls.NumericSlider.Wrap(slider));
        if(title.Contains("透明"))slider.Resources["SliderFill"]=Brushes.WhiteSmoke;
        slider.ValueChanged+=(_,_)=>{text.Text=title+" "+slider.Value.ToString("0.##");action(slider.Value);};menu.Items.Add(new MenuItem { Header=panel,Icon=new ToolGlyph {Glyph=MenuGlyph(title)},StaysOpenOnClick=true });
    }
    private void ShowGroupStyle()
    {
        var group=_activeGroup;if(group is null){_status.Text="先選取分類區塊，再調整外觀。";return;}
        var menu=Popup();MenuAction(menu,"區塊底色…",()=>{group.Fill=PickColor(group.Fill,c=>{group.Fill=c;RenderCreative();});RenderCreative();});
        MenuSlider(menu,"底色透明度（0 透明／1 不透明）",group.Opacity,0,1,v=>{group.Opacity=v;RenderCreative();});
        MenuAction(menu,"邊框顏色…",()=>{group.Border=PickColor(group.Border,c=>{group.Border=c;RenderCreative();});RenderCreative();});
        var dashed=new MenuItem { Header="虛線邊框",Icon=new ToolGlyph {Glyph="Dashed"},IsCheckable=true,IsChecked=group.Dashed };dashed.Click+=(_,_)=>{group.Dashed=dashed.IsChecked;RenderCreative();};menu.Items.Add(dashed);
        MenuSlider(menu,"標題字級",group.TitleSize,10,96,v=>{group.TitleSize=Math.Round(v);RenderCreative();});
        MenuAction(menu,"標題顏色…",()=>{group.TitleColor=PickColor(group.TitleColor,c=>{group.TitleColor=c;RenderCreative();});RenderCreative();});
        var members=_cards.Values.Where(c=>GroupFor(c)==group).ToArray();
        MenuSwitch(menu,"圖片自動排列",group.AutoArrange,v=>{group.AutoArrange=v;if(v)ArrangeItemsInGroup(group,members);RenderCreative();});
        MenuSlider(menu,"圖片水平間距",group.ColumnGap,0,200,v=>{group.ColumnGap=Math.Round(v);ArrangeItemsInGroup(group,members);RenderCreative();});
        MenuSlider(menu,"圖片垂直行距",group.RowGap,0,200,v=>{group.RowGap=Math.Round(v);ArrangeItemsInGroup(group,members);RenderCreative();});
        MenuAction(menu,"重新命名",()=>BeginGroupRename(group));menu.IsOpen=true;
    }
    
    private static void MenuSwitch(ItemsControl menu,string label,bool value,Action<bool> change)
    {
        var toggle=new CheckBox {Content=label,IsChecked=value,MinWidth=240,Padding=new Thickness(4),Style=(Style)Application.Current.FindResource("SwitchToggle")};
        toggle.Checked+=(_,_)=>change(true);toggle.Unchecked+=(_,_)=>change(false);
        menu.Items.Add(new MenuItem {Header=toggle,Icon=new ToolGlyph {Glyph=MenuGlyph(label)},StaysOpenOnClick=true});
    }
    private void ShowBoardSettings()
    {
        var menu=Popup();menu.Closed+=(_,_)=>ObserveDocumentHistory();MenuSlider(menu,"工具列不透明度",App.Settings.ToolbarOpacity*100,20,100,value=>{App.Settings.ToolbarOpacity=value/100;Clipxel.Services.GlassAppearance.Apply(value/100);});
        menu.Closed+=(_,_)=>{try{Clipxel.Services.PreferenceStore.Save(App.Settings);}catch(Exception ex){_status.Text="偏好設定未儲存："+ex.Message;}};
        var themes=new MenuItem {Header="主題設定",Icon=new ToolGlyph {Glyph="Settings"}};
        foreach(var preset in new[]{("Dark","深灰主題"),("Light","淺灰主題"),("White","白亮主題")})
        {
            var key=preset.Item1;var item=new MenuItem {Header=preset.Item2,IsCheckable=true,IsChecked=App.Settings.Theme==key,Tag="ThemeChoice",CommandParameter=key};
            item.Click+=(_,_)=>{App.Settings.Theme=key;Clipxel.Services.ThemeService.Apply();foreach(var choice in themes.Items.OfType<MenuItem>())choice.IsChecked=Equals(choice.CommandParameter,key);};themes.Items.Add(item);
        }
        menu.Items.Add(themes);
        MenuSwitch(menu,"圖片靠近區塊時磁吸",_snapEnabled,v=>_snapEnabled=v);
        MenuSwitch(menu,"視窗置頂",Topmost,v=>{Topmost=v;UpdateToolButtons();});
        MenuAction(menu,"顯示／隱藏繪圖工具 (F8)",ToggleDrawingPanel);MenuAction(menu,"隱藏／顯示視窗 (Tab)",()=>PerformBoardAction(BoardAction.ToggleChrome));
        MenuAction(menu,"一般偏好設定…",()=>((App)Application.Current).ShowCanvasPreferences());menu.IsOpen=true;
    }
    
}
