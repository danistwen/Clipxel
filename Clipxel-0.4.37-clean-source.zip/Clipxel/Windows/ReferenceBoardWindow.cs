using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using Clipxel.Services;
using Clipxel.Models;

namespace Clipxel.Windows;

// The original PinWindow remains the owner of the bitmap and editable annotations.
// This window only owns the reference layout and its view transform.
public sealed partial class ReferenceBoardWindow : Window
{
    private sealed class Card
    {
        public string Id=Guid.NewGuid().ToString("N");
        public PinWindow Pin = null!;
        public Image Image = null!;
        public Border Frame = null!;
        public double X, Y, Width, Height;
    }
    private readonly Dictionary<PinWindow, Card> _cards = new();
    private readonly HashSet<Card> _selected = new();
    private readonly Dictionary<Card, Point> _dragOrigins = new();
    private readonly Grid _viewport = new() { Background = new SolidColorBrush(Clipxel.Services.ThemeService.Background), ClipToBounds = true, Focusable = true };
    private readonly Canvas _surface = new();
    private readonly ScaleTransform _zoom = new(1, 1);
    private readonly TranslateTransform _pan = new(30, 30);
    private readonly TextBlock _status = new() { Foreground=Clipxel.Services.ThemeService.Foreground, Margin = new Thickness(12, 8, 12, 8), TextWrapping = TextWrapping.Wrap };
    private readonly System.Windows.Shapes.Rectangle _marquee = new() { Stroke = Clipxel.Services.ThemeService.ActiveToolInk, Fill = new SolidColorBrush(Color.FromArgb(30, 70, 92, 255)), StrokeThickness = 1, Visibility = Visibility.Collapsed, IsHitTestVisible = false, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
    private Point _down;
    private Vector _panStart;
    private bool _panning, _moving, _selecting;
    private bool _exporting;
    public event Action? ReturnRequested;
    public event Action? ImportRequested;
    public event Action? PasteRequested;
    public event Action? CaptureRequested;
    public bool AllowClose { get; set; }

    public ReferenceBoardWindow()
    {
        Title = "Clipxel 0.4.37 — 參考畫布";
        Width = 1100; Height = 740; MinWidth = 760; MinHeight = 460;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = _viewport.Background; Topmost = true;
        WindowIconHelper.ApplyAdaptiveTitleBarIcon(this);
        Content = BuildBoardChrome();
        var transforms = new TransformGroup(); transforms.Children.Add(_zoom); transforms.Children.Add(_pan); _surface.RenderTransform = transforms;
        _surface.Children.Add(_groupLayer); _surface.Children.Add(_inkLayer); Panel.SetZIndex(_groupLayer, -10); Panel.SetZIndex(_inkLayer, 1000000);
        _viewport.Children.Add(_surface); _viewport.Children.Add(_marquee);
        _viewport.PreviewMouseDown += Down;
        _viewport.MouseMove += Move;
        _viewport.MouseUp += (_, _) => { if (_canvasPicking) return; FinishCreative(); EndGesture(); };
        _viewport.LostMouseCapture += (_, _) => { if (!_viewport.IsMouseCaptured) EndGesture(false); };
        _viewport.MouseWheel += Wheel;
        PreviewKeyDown += KeyPressed;
        Deactivated += (_, _) => EndGesture();
        IsVisibleChanged += (_, _) => { if (!IsVisible) { EndGesture();_embeddedToolbar?.ClosePopups();if(_boardMenu is not null)_boardMenu.IsOpen=false;_optionsRefresh?.Abort();_optionsRefresh=null; } };
        Closed+=(_,_)=>{if(_boardMenu is not null)_boardMenu.IsOpen=false;_optionsRefresh?.Abort();if(_toolOptionsBody is not null)SliderScrub.CancelWithin(_toolOptionsBody);};
        Closing += (_, e) => { if (!AllowClose) { e.Cancel = true; if (ConfirmCloseBoard()) Hide(); } };
        AllowDrop = true;
        DragOver += (_, e) => { e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
        Drop += (_, e) => { if (e.Data.GetData(DataFormats.FileDrop) is string[] files) (Application.Current as App)?.ImportReferenceFiles(files); e.Handled = true; };
        UpdateStatus(); _savedState=BoardState(); ResetDocumentHistory();
    }
    public void SyncPins(IEnumerable<PinWindow> pins)
    {
        _documentVersion++;
        var list = pins.ToArray();
        foreach (var obsolete in _cards.Keys.Except(list).ToArray()) RemovePin(obsolete);
        foreach (var pin in list)
        {
            var bitmap = pin.ReferenceBitmap();
            if (_cards.TryGetValue(pin, out var existing)) { existing.Image.Source = bitmap; continue; }
            double scale = Math.Min(1, 320.0 / Math.Max(bitmap.PixelWidth, bitmap.PixelHeight));
            var card = new Card { Pin = pin, Image = new Image { Source = bitmap, Stretch = Stretch.Fill }, Width = bitmap.PixelWidth * scale, Height = bitmap.PixelHeight * scale };
            RenderOptions.SetBitmapScalingMode(card.Image, BitmapScalingMode.HighQuality);
            card.Frame = new Border { Child = card.Image, BorderThickness = new Thickness(2), BorderBrush = Brushes.Transparent, Background = Brushes.Transparent, Tag = card };
            // New cards receive a predictable grid position; App fits the view after import.
            int index = _cards.Count;
            card.X = index % 3 * 350; card.Y = index / 3 * 350;
            _cards.Add(pin, card); _surface.Children.Add(card.Frame); Layout(card);
        }
        UpdateStatus(); ObserveDocumentHistory();
    }
    public void RemovePin(PinWindow pin)
    {
        if (!_cards.Remove(pin, out var card)) return;
        _selected.Remove(card); _surface.Children.Remove(card.Frame); _dragOrigins.Remove(card); UpdateSelection();
    }
    private static void Layout(Card card)
    {
        Canvas.SetLeft(card.Frame, card.X); Canvas.SetTop(card.Frame, card.Y);
        card.Frame.Width = card.Width + 4; card.Frame.Height = card.Height + 4;
    }
    private Point World(Point point) => new((point.X - _pan.X) / _zoom.ScaleX, (point.Y - _pan.Y) / _zoom.ScaleY);
    private Card? HitCard(DependencyObject? hit)
    {
        while (hit is not null && hit != _viewport)
        {
            if (hit is Border frame && frame.Tag is Card card) return card;
            hit = VisualTreeHelper.GetParent(hit);
        }
        return null;
    }
    private void Down(object sender, MouseButtonEventArgs e)
    {
        if (_canvasTextEditor?.IsMouseOver == true) return;
        CommitCanvasText();
        if (_groupNameEditor?.IsMouseOver == true) return;
        CommitGroupRename();
        if (e.ChangedButton is not (MouseButton.Left or MouseButton.Middle)) return;
        _viewport.Focus(); _down = e.GetPosition(_viewport);
        if (_panTool || e.ChangedButton == MouseButton.Middle || Keyboard.IsKeyDown(Key.Space))
        {
            _panning = true; _panStart = new Vector(_pan.X, _pan.Y); _viewport.Cursor = Cursors.Hand;
        }
        else
        {
            if(_canvasPicking){SampleCanvasColor(World(_down));e.Handled=true;return;}
            if (CreativeDown(World(_down), e.ClickCount)) { UpdateSelection(); e.Handled = true; return; }
            var card = HitCard(e.OriginalSource as DependencyObject);
            bool extend = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
            if (card is null)
            {
                if (!extend) { _selected.Clear(); _selectedGroups.Clear(); _selectedInk.Clear(); }
                _selecting = true; _marquee.Visibility = Visibility.Visible;
                _marquee.Margin = new Thickness(_down.X, _down.Y, 0, 0); _marquee.Width = _marquee.Height = 0;
            }
            else
            {
                if (extend && _selected.Contains(card)) { _selected.Remove(card); UpdateSelection(); e.Handled = true; return; }
                if (!extend && !_selected.Contains(card)) { _selected.Clear(); _selectedGroups.Clear(); _selectedInk.Clear(); _activeGroup=null; }
                _selected.Add(card); _moving = true; _dragOrigins.Clear();
                foreach (var selected in _selected) _dragOrigins[selected] = new Point(selected.X, selected.Y);
                Panel.SetZIndex(card.Frame, _cards.Values.Max(c => Panel.GetZIndex(c.Frame)) + 1);
            }
        }
        UpdateSelection(); _viewport.CaptureMouse(); e.Handled = true;
    }
    private void Move(object sender, MouseEventArgs e)
    {
        Point at = e.GetPosition(_viewport); UpdateCanvasLens(at); HoverCursor(World(at)); if (CreativeMove(World(at))) return; Vector delta = at - _down;
        if (_panning) { _pan.X = _panStart.X + delta.X; _pan.Y = _panStart.Y + delta.Y; }
        else if (_moving)
        {
            foreach (var pair in _dragOrigins) { pair.Key.X = pair.Value.X + delta.X / _zoom.ScaleX; pair.Key.Y = pair.Value.Y + delta.Y / _zoom.ScaleY; Layout(pair.Key); }
            _snapPreview = _snapEnabled ? _groups.FirstOrDefault(g => _selected.Any(c => { var bounds = g.Bounds; bounds.Inflate(24 / _zoom.ScaleX, 24 / _zoom.ScaleX); return bounds.IntersectsWith(new Rect(c.X,c.Y,c.Width,c.Height)); })) : null;
            RenderGroups();
        }
        else if (_selecting)
        {
            var rect = new Rect(_down, at); _marquee.Margin = new Thickness(rect.Left, rect.Top, 0, 0); _marquee.Width = rect.Width; _marquee.Height = rect.Height;
        }
    }
    private void EndGesture(bool release = true)
    {
        if (_moving) SnapMovedCards();
        _snapPreview = null;
        _selectionDragging=false;_selectionInkOrigins.Clear();_selectionGroupOrigins.Clear();
        CancelCreative();
        if (_selecting)
        {
            var region = new Rect(World(_down), World(Mouse.GetPosition(_viewport)));
            if (region.Width > 3 / _zoom.ScaleX && region.Height > 3 / _zoom.ScaleX) foreach (var group in _groups) if (region.IntersectsWith(group.Bounds)) _selectedGroups.Add(group);
            SelectInkIn(region);
            _activeGroup = _selectedGroups.FirstOrDefault();
            foreach (var card in _cards.Values) if (region.IntersectsWith(new Rect(card.X, card.Y, card.Width + 4, card.Height + 4))) _selected.Add(card);
        }
        _panning = _moving = _selecting = false; _dragOrigins.Clear(); _marquee.Visibility = Visibility.Collapsed;
        _viewport.Cursor = _panTool ? Cursors.Hand : Cursors.Arrow;
        if (release && _viewport.IsMouseCaptured) _viewport.ReleaseMouseCapture();
        UpdateSelection();
    }
    private void Wheel(object sender, MouseWheelEventArgs e)
    {
        if (_moving || _panning || _selecting || _inkDraft is not null || _groupDraft || _movingGroup is not null || _inkDragOrigin is not null) return;
        double factor = Math.Pow(1.12, Math.Clamp(e.Delta / 120.0, -10, 10));
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) && _selected.Count > 0)
        {
            foreach (var card in _selected)
            {
                double width = Math.Clamp(card.Width * factor, 8, 16000);
                double height = card.Height * width / card.Width;
                card.X -= (width - card.Width) / 2; card.Y -= (height - card.Height) / 2;
                card.Width = width; card.Height = height; Layout(card);
            }
        }
        else
        {
            Point cursor = e.GetPosition(_viewport), world = World(cursor);
            double scale = Math.Clamp(_zoom.ScaleX * factor, .02, 16);
            _zoom.ScaleX = _zoom.ScaleY = scale; _pan.X = cursor.X - world.X * scale; _pan.Y = cursor.Y - world.Y * scale;
        }
        UpdateStatus(); ObserveDocumentHistory(); e.Handled = true;
    }
    private void KeyPressed(object sender, KeyEventArgs e)
    {
        if(e.OriginalSource is ComboBox or ComboBoxItem)return;
        if (_canvasTextEditor?.IsKeyboardFocusWithin == true || _groupNameEditor?.IsKeyboardFocusWithin == true || e.OriginalSource is System.Windows.Controls.Primitives.TextBoxBase) return;
        if (e.Key == Key.Escape) { _canvasPicking=false; _boardTool = AnnotationTool.None; _groupTool = false; _activeInk = -1; _activeGroup = null; UpdateDrawingControls(); _panTool = false; UpdateToolButtons(); EndGesture(); _selected.Clear(); _selectedGroups.Clear(); _selectedInk.Clear(); UpdateSelection(); e.Handled = true; }
        else
        {
            if(e.OriginalSource is System.Windows.Controls.Primitives.TextBoxBase) return;
            var action = LocalShortcuts.Match(App.Settings.BoardShortcuts, e.Key == Key.System ? e.SystemKey : e.Key, Keyboard.Modifiers);
            if(action is not null && Enum.TryParse<BoardAction>(action, out var command))
            { e.Handled = true; if(!e.IsRepeat || command is BoardAction.ZoomIn or BoardAction.ZoomOut) PerformBoardAction(command); }
        }
    }

    private Rect Extent()
    {
        Rect bounds = Rect.Empty; foreach (var c in _cards.Values) bounds.Union(new Rect(c.X, c.Y, c.Width + 4, c.Height + 4)); foreach(var group in _groups) bounds.Union(group.Bounds); foreach(var ink in _ink) bounds.Union(Clipxel.Rendering.AnnotationRenderer.Build(ink).Bounds); return bounds;
    }
    public void FitAll()
    {
        Rect bounds = Extent(); if (bounds.IsEmpty || _viewport.ActualWidth <= 0 || _viewport.ActualHeight <= 0) return;
        double scale = Math.Clamp(Math.Min(Math.Max(1, _viewport.ActualWidth - 60) / bounds.Width, Math.Max(1, _viewport.ActualHeight - 60) / bounds.Height), .02, 16);
        _zoom.ScaleX = _zoom.ScaleY = scale;
        _pan.X = (_viewport.ActualWidth - bounds.Width * scale) / 2 - bounds.X * scale;
        _pan.Y = (_viewport.ActualHeight - bounds.Height * scale) / 2 - bounds.Y * scale; UpdateStatus();
    }
    private void ArrangeCards()
    {
        int columns = Math.Max(1, (int)Math.Ceiling(Math.Sqrt(_cards.Count))), index = 0;
        foreach (var card in _cards.Values)
        {
            var bitmap = (BitmapSource)card.Image.Source;
            double scale = Math.Min(1, 320.0 / Math.Max(bitmap.PixelWidth, bitmap.PixelHeight));
            card.Width = bitmap.PixelWidth * scale; card.Height = bitmap.PixelHeight * scale;
            card.X = index % columns * 350; card.Y = index / columns * 350; index++; Layout(card);
        }
        FitAll();
    }
    private void UpdateSelection()
    {
        LoadSelectedStyle();
        UpdateToolOptions();
        UpdateToolButtons();
        foreach (var card in _cards.Values) card.Frame.BorderBrush = _selected.Contains(card) ? Clipxel.Services.ThemeService.ActiveToolInk : Brushes.Transparent;
        RenderCreative(); UpdateStatus();
    }
    private void UpdateStatus() => _status.Text = _canvasPicking ? (_lastCopiedHex is null?"點擊畫布複製色號 · Esc 結束":"已複製 "+_lastCopiedHex+" · 可繼續點擊吸色；Esc 結束") : $"{_cards.Count} 張圖片　·　已選 {_selected.Count} 張／{_selectedGroups.Count} 區塊／{_selectedInk.Count} 標註　·　{_zoom.ScaleX * 100:0}%";
    private async void ExportBoard()
    {
        CommitCanvasText();
        if (_exporting || (_cards.Count == 0 && _groups.Count == 0 && _ink.Count == 0)) return;
        var dialog = new SaveFileDialog { Filter = ImageExportService.ExportFilter, FileName = "Clipxel-reference-board", AddExtension = true, DefaultExt = ".png" };
        if (dialog.ShowDialog(this) != true) return;
        _exporting = true;
        try
        {
            Rect bounds = Extent();
            if (bounds.IsEmpty || bounds.Width <= 0 || bounds.Height <= 0) return;
            // Bound memory use for very large arrangements while retaining aspect ratio.
            double scale = Math.Min(1, Math.Min(8192 / Math.Max(bounds.Width, bounds.Height), Math.Sqrt(32_000_000 / (bounds.Width * bounds.Height))));
            int width = Math.Max(1, (int)Math.Ceiling(bounds.Width * scale)), height = Math.Max(1, (int)Math.Ceiling(bounds.Height * scale));
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                dc.PushTransform(new ScaleTransform(scale, scale));
                dc.PushTransform(new TranslateTransform(-bounds.X, -bounds.Y));
                foreach (var group in _groups) dc.DrawDrawing(GroupDrawing(group, false));
                foreach (var c in _cards.Values.OrderBy(c => Panel.GetZIndex(c.Frame))) dc.DrawImage(c.Image.Source, new Rect(c.X + 2, c.Y + 2, c.Width, c.Height));
                foreach (var ink in _ink) dc.DrawDrawing(Clipxel.Rendering.AnnotationRenderer.Build(ink));
                dc.Pop(); dc.Pop();
            }
            var result = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32); result.Render(visual); result.Freeze();
            await ImageExportService.SaveImageAsync(result, dialog.FileName);
            _status.Text = $"畫布已匯出圖片（{width} × {height}），不含選取框。";
        }
        catch (Exception ex) { App.LogError("Export reference board", ex); _status.Text = "匯出失敗：" + ex.Message; }
        finally { _exporting = false; }
    }
}
