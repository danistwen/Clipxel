using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using Clipxel.Models;
using Clipxel.Rendering;
using Clipxel.Services;

namespace Clipxel.Windows;

public partial class SelectionWindow
{
    private void SelectionGesture(int direction)
    {
        switch(direction)
        {
            case 0: SetSelectionAnnotationTool(AnnotationTool.Arrow); break;
            case 1: _ = SaveCurrentSelectionAsync(); break;
            case 2: SetSelectionAnnotationTool(AnnotationTool.Text); break;
            case 3: _ = CopyCurrentSelectionAsync(); break;
            case 4: ToggleSelectionPicker(); break;
            case 5: if (_selectionActiveTool != AnnotationTool.None) SetSelectionAnnotationTool(_selectionActiveTool); break;
            case 6: SetSelectionAnnotationTool(AnnotationTool.Pen); break;
            case 7: SetSelectionAnnotationTool(AnnotationTool.Rectangle); break;
            case 8: SetSelectionAnnotationTool(AnnotationTool.Circle); break;
            case 9: UndoSelectionAnnotation(); break;
            case 10: RedoSelectionAnnotation(); break;
        }
    }
    private void ShowSelectionPie()
    {
        var menu = new PieMenuWindow(true, true, _selectionActiveTool);
        menu.ActionRequested += action =>
        {
            if (action == PieMenuAction.Circle) SetSelectionAnnotationTool(AnnotationTool.Circle);
            else if (action == PieMenuAction.Undo) UndoSelectionAnnotation();
            else if (action == PieMenuAction.Redo) RedoSelectionAnnotation();
            else { var map = new[] { PieMenuAction.Arrow, PieMenuAction.Save, PieMenuAction.Text, PieMenuAction.Copy, PieMenuAction.PickColor, PieMenuAction.Select, PieMenuAction.Pen, PieMenuAction.Rectangle }; int i = Array.IndexOf(map, action); if (i >= 0) SelectionGesture(i); }
        };
        menu.ShowAtCursor(this);
    }

    private string _selectionFontFamily = "Segoe UI";

    private LineStyle _selectionLineStyle;

    private ToolbarWindow? _selectionToolbarWindow;
    private AnnotationTool _selectionActiveTool = AnnotationTool.None;
    private Color _selectionAnnotationColor = Colors.White;
    private double _selectionStrokeWidth = 3;
    private double _selectionFontSize = 22;
    private bool _selectionShapeStrokeEnabled = true;
    private bool _selectionShapeFillEnabled;
    private double _selectionShapeStrokeOpacity = 1.0;
    private double _selectionShapeFillOpacity = 0.45;
    private readonly AnnotationHistory _selectionHistory = new();
    private readonly List<Annotation?> _selectionAnnotationModels = new();
    private Annotation? _selectionDraft;
    private bool _selectionDrawing;
    private bool _selectionPickerEnabled;
    private Point? _selectionTextPoint;
    private Color _selectionTextColor;
    private int _selectionEditingTextIndex = -1;
    private Annotation? _selectionEditingTextOriginalModel;
    private DrawingGroup? _selectionEditingTextOriginalDrawing;
    private bool _selectionDraggingText;
    private int _selectionDraggingTextIndex = -1;
    private Point _selectionTextDragStartPoint;
    private Point _selectionTextDragOriginalStart;
    private Vector _selectionTextDragDelta;
    private DrawingGroup? _selectionTextDragOriginalDrawing;
    private readonly DispatcherTimer _selectionToastTimer = new() { Interval = TimeSpan.FromMilliseconds(1000) };

    private void InitializeSelectionEditing()
    {
        MouseLeave += (_, _) => { if (_selectedTextIndex < 0) TextChrome.Clear(); };
        _selectionToastTimer.Tick += (_, _) =>
        {
            _selectionToastTimer.Stop();
            SelectionToast.Visibility = Visibility.Collapsed;
        };
    }

    private void EnsureSelectionToolbar()
    {
        if (_selectionToolbarWindow is not null) return;

        _selectionToolbarWindow = new ToolbarWindow { Owner = this };
        _selectionToolbarWindow.SetSelectionCaptureMode(true);
        _selectionToolbarWindow.LineStyleSelected += style => _selectionLineStyle = style;
        _selectionToolbarWindow.ToolSelected += SetSelectionAnnotationTool;
        _selectionToolbarWindow.SelectRequested += (_, _) => SetSelectionAnnotationTool(AnnotationTool.None);
        _selectionToolbarWindow.AnnotationColorSelected += color => {_selectionAnnotationColor=color;if(SelectionTextEditor.Visibility==Visibility.Visible)SelectionTextEditor.Foreground=new SolidColorBrush(color);};
        _selectionToolbarWindow.StrokeWidthSelected += width => _selectionStrokeWidth = width;
        _selectionToolbarWindow.FontFamilySelected += family => { _selectionFontFamily = family; SelectionTextEditor.FontFamily = new FontFamily(family); };
        _selectionToolbarWindow.FontSizeSelected += SetSelectionFontSize;
        _selectionToolbarWindow.ShapeStrokeEnabledSelected += enabled => _selectionShapeStrokeEnabled = enabled;
        _selectionToolbarWindow.ShapeFillEnabledSelected += enabled => _selectionShapeFillEnabled = enabled;
        _selectionToolbarWindow.ShapeStrokeOpacitySelected += opacity => _selectionShapeStrokeOpacity = opacity;
        _selectionToolbarWindow.ShapeFillOpacitySelected += opacity => _selectionShapeFillOpacity = opacity;
        _selectionToolbarWindow.UndoRequested += (_, _) => UndoSelectionAnnotation();
        _selectionToolbarWindow.RedoRequested += (_, _) => RedoSelectionAnnotation();
        _selectionToolbarWindow.PickRequested += (_, _) => ToggleSelectionPicker();
        _selectionToolbarWindow.CopyRequested += async (_, _) => await CopyCurrentSelectionAsync();
        _selectionToolbarWindow.SaveRequested += async (_, _) => await SaveCurrentSelectionAsync();
        _selectionToolbarWindow.ResetRequested += (_, _) =>
        {
            if (_lockedSelection.HasValue) CapturePixelRect(_lockedSelection.Value);
        };
        _selectionToolbarWindow.CloseRequested += (_, _) => UnlockSelection();
        _selectionToolbarWindow.SizeUpdated += (_, _) =>
        {
            if (_lockedSelection.HasValue) PositionSelectionToolbar(_lockedSelection.Value);
        };
        _selectionToolbarWindow.SetAnnotationColor(_selectionAnnotationColor);
        _selectionToolbarWindow.SetStrokeWidth(_selectionStrokeWidth);
        _selectionToolbarWindow.SetFontSize(_selectionFontSize);
        _selectionToolbarWindow.SetShapeStyle(_selectionShapeStrokeEnabled, _selectionShapeFillEnabled,
            _selectionShapeStrokeOpacity, _selectionShapeFillOpacity);
        _selectionToolbarWindow.SetActiveTool(_selectionActiveTool);
        _selectionToolbarWindow.SetPickerActive(_selectionPickerEnabled);
        UpdateSelectionHistoryButtons();
    }

    private void ShowSelectionToolbar(Rect selectionRect)
    {
        if (!_lockedSelection.HasValue) return;
        EnsureSelectionToolbar();
        if (_selectionToolbarWindow is null) return;

        if (!_selectionToolbarWindow.IsVisible)
            _selectionToolbarWindow.Show();
        _selectionToolbarWindow.Opacity = 1;
        PositionSelectionToolbar(_lockedSelection.Value);
    }

    private void PositionSelectionToolbar(PixelRect selection)
    {
        if (_selectionToolbarWindow?.IsVisible != true) return;

        _selectionToolbarWindow.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        var bar = WindowPlacementService.Bounds(_selectionToolbarWindow);
        int right = _desktop.X + selection.Right;
        int bottom = _desktop.Y + selection.Bottom;
        int left = _desktop.X + selection.X;
        int top = _desktop.Y + selection.Y;
        int gap = 3;

        var monitor = WindowPlacementService.MonitorBoundsAtPoint(
            Math.Clamp(left, _desktop.X, Math.Max(_desktop.X, _desktop.Right - 1)),
            Math.Clamp(bottom - 1, _desktop.Y, Math.Max(_desktop.Y, _desktop.Bottom - 1)));

        int stableWidth = (int)Math.Ceiling(_selectionToolbarWindow.ExpandedWidthDip * VisualTreeHelper.GetDpi(_selectionToolbarWindow).DpiScaleX);
        int x = left;
        int y = bottom + gap;
        if (y + bar.Height > monitor.Bottom)
            y = top - gap - bar.Height;

        x = Math.Clamp(x, monitor.X, Math.Max(monitor.X, monitor.Right - stableWidth));
        y = Math.Clamp(y, monitor.Y, Math.Max(monitor.Y, monitor.Bottom - bar.Height));
        WindowPlacementService.Move(_selectionToolbarWindow, x, y);
    }

    private void HideSelectionToolbar()
    {
        if (_selectionToolbarWindow is null) return;
        _selectionToolbarWindow.ClosePopups();
        if (_selectionToolbarWindow.IsVisible)
            _selectionToolbarWindow.Hide();
    }

    private void DisposeSelectionToolbar()
    {
        if (_selectionToolbarWindow is null) return;
        try { _selectionToolbarWindow.Close(); } catch { }
        _selectionToolbarWindow = null;
    }

    private void SetSelectionAnnotationTool(AnnotationTool tool)
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        CancelSelectionDraft();
        _selectionPickerEnabled = false;
        _selectionActiveTool = _selectionActiveTool == tool ? AnnotationTool.None : tool;
        _selectionToolbarWindow?.SetActiveTool(_selectionActiveTool);
        if (_selectionActiveTool == AnnotationTool.Text) _selectionToolbarWindow?.SetFontSize(_selectionFontSize);
        _selectionToolbarWindow?.SetPickerActive(false);
        Cursor = _selectionActiveTool == AnnotationTool.None ? Cursors.Arrow : Cursors.Cross;
    }

    private void SetSelectionFontSize(double size)
    {
        _selectionFontSize = Math.Clamp(Math.Round(size), 8, 120);
        if (SelectionTextEditor.Visibility == Visibility.Visible)
            SelectionTextEditor.FontSize = Math.Clamp(_selectionFontSize / Math.Max(.001, ScaleY), 8, 120);
    }

    private void ToggleSelectionPicker()
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        CancelSelectionDraft();
        _selectionActiveTool = AnnotationTool.None;
        _selectionPickerEnabled = !_selectionPickerEnabled;
        _selectionToolbarWindow?.SetActiveTool(AnnotationTool.None);
        _selectionToolbarWindow?.SetPickerActive(_selectionPickerEnabled);
        Cursor = _selectionPickerEnabled ? Cursors.Cross : Cursors.Arrow;
    }

    private bool HasSelectionEditingTool => _selectionActiveTool != AnnotationTool.None || _selectionPickerEnabled;

    private static Annotation CopySelectionTextAnnotation(Annotation source, Point? start = null, string? text = null, double? fontSize = null, string? fontFamily = null) => new()
    {
        Tool = AnnotationTool.Text,
        Start = start ?? source.Start,
        End = start ?? source.End,
        Text = text ?? source.Text,
        Color = source.Color,
        StrokeWidth = source.StrokeWidth, LineStyle = source.LineStyle,
        FontSize = fontSize ?? source.FontSize, FontFamily = fontFamily ?? source.FontFamily,
        RectangleMode = source.RectangleMode,
        UsesIndependentShapeStyle = source.UsesIndependentShapeStyle,
        ShapeStrokeEnabled = source.ShapeStrokeEnabled,
        ShapeFillEnabled = source.ShapeFillEnabled,
        StrokeOpacity = source.StrokeOpacity,
        FillOpacity = source.FillOpacity
    };

    private static DrawingGroup EmptySelectionDrawing()
    {
        var drawing = new DrawingGroup();
        drawing.Freeze();
        return drawing;
    }

    private bool TryHitSelectionTextAnnotation(Point rootPoint, out int index)
    {
        if (!_lockedSelection.HasValue || !_lockedDipRect.Contains(rootPoint))
        {
            index = -1;
            return false;
        }
        Point pixel = ToSelectionPixelPoint(rootPoint);
        for (int i = Math.Min(_selectionAnnotationModels.Count, SelectionAnnotations.Drawings.Count) - 1; i >= 0; i--)
        {
            var model = _selectionAnnotationModels[i];
            if (model?.Tool != AnnotationTool.Text) continue;
            var bounds = SelectionAnnotations.Drawings[i].Bounds;
            if (bounds.IsEmpty) continue;
            bounds.Inflate(5, 4);
            if (bounds.Contains(pixel))
            {
                index = i;
                return true;
            }
        }
        index = -1;
        return false;
    }

    private Point SelectionPixelToRoot(Point local)
    {
        if (!_lockedSelection.HasValue) return local;
        var pixels = _lockedSelection.Value;
        return new Point(
            _lockedDipRect.Left + local.X / Math.Max(1, pixels.Width) * _lockedDipRect.Width,
            _lockedDipRect.Top + local.Y / Math.Max(1, pixels.Height) * _lockedDipRect.Height);
    }

    private void BeginEditSelectionText(int index)
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        if ((uint)index >= (uint)_selectionAnnotationModels.Count ||
            (uint)index >= (uint)SelectionAnnotations.Drawings.Count || !_lockedSelection.HasValue) return;
        var model = _selectionAnnotationModels[index];
        if (model?.Tool != AnnotationTool.Text) return;

        var drawing = SelectionAnnotations.Drawings[index];
        Point start = model.Start;
        _selectionEditingTextIndex = index;
        _selectionEditingTextOriginalModel = model;
        _selectionEditingTextOriginalDrawing = drawing;
        _selectionTextPoint = start;
        _selectionTextColor = model.Color;
        _selectionFontSize = Math.Clamp(model.FontSize, 8, 120);
        SelectionAnnotations.ReplaceAt(index, EmptySelectionDrawing());

        Point root = SelectionPixelToRoot(start);
        SelectionTextEditor.Foreground = new SolidColorBrush(model.Color);
        SelectionTextEditor.Text = model.Text;
        SelectionTextEditor.Width = Math.Min(240, Math.Max(70, _lockedDipRect.Right - root.X));
        SelectionTextEditor.FontFamily = new FontFamily(model.FontFamily);
        _selectionFontFamily = model.FontFamily;
        SelectionTextEditor.FontSize = Math.Clamp(model.FontSize / Math.Max(.001, ScaleY), 8, 120);
        Canvas.SetLeft(SelectionTextEditor, root.X);
        Canvas.SetTop(SelectionTextEditor, root.Y);
        SelectionTextEditor.Visibility = Visibility.Visible;
        _selectionPickerEnabled = false;
        _selectionActiveTool = AnnotationTool.Text;
        _selectionToolbarWindow?.SetPickerActive(false);
        _selectionToolbarWindow?.SetActiveTool(AnnotationTool.Text);
        _selectionToolbarWindow?.SetFontSize(_selectionFontSize);
        Keyboard.Focus(SelectionTextEditor);
        SelectionTextEditor.SelectAll();
    }

    private void StartSelectionTextDrag(int index, Point rootPoint)
    {
        if ((uint)index >= (uint)_selectionAnnotationModels.Count ||
            (uint)index >= (uint)SelectionAnnotations.Drawings.Count) return;
        if (_selectionAnnotationModels[index]?.Tool != AnnotationTool.Text) return;
        _selectionDraggingText = true;
        _selectionDraggingTextIndex = index;
        _selectionTextDragStartPoint = ToSelectionPixelPoint(rootPoint);
        _selectionTextDragOriginalStart = _selectionAnnotationModels[index]!.Start;
        _selectionTextDragDelta = new Vector();
        _selectionTextDragOriginalDrawing = SelectionAnnotations.Drawings[index];
        _textDragHistoryRecorded = false;
        CaptureMouse();
        Cursor = Cursors.SizeAll;
    }

    private void UpdateSelectionTextDrag(Point rootPoint)
    {
        if (!_selectionDraggingText || _selectionTextDragOriginalDrawing is null ||
            (uint)_selectionDraggingTextIndex >= (uint)SelectionAnnotations.Drawings.Count) return;
        Point current = ToSelectionPixelPoint(rootPoint);
        Vector delta = current - _selectionTextDragStartPoint;
        _selectionTextDragDelta = delta;
        if (!_textDragHistoryRecorded)
        {
            if (delta.Length < 0.01) return;
            _selectionHistory.Record(SelectionAnnotations, _selectionAnnotationModels);
            _textDragHistoryRecorded = true;
        }
        var wrapper = new DrawingGroup { Transform = new TranslateTransform(delta.X, delta.Y) };
        wrapper.Children.Add(_selectionTextDragOriginalDrawing);
        wrapper.Freeze();
        SelectionAnnotations.ReplaceAt(_selectionDraggingTextIndex, wrapper);
        TextChrome.Show(GetTextFrame(_selectionDraggingTextIndex), true);
    }

    private void EndSelectionTextDrag()
    {
        if (!_selectionDraggingText) return;
        int index = _selectionDraggingTextIndex;
        _selectionDraggingText = false;
        _selectionDraggingTextIndex = -1;
        _selectionTextDragOriginalDrawing = null;
        if (Mouse.Captured == this) ReleaseMouseCapture();
        if (_textDragHistoryRecorded && (uint)index < (uint)_selectionAnnotationModels.Count &&
            (uint)index < (uint)SelectionAnnotations.Drawings.Count &&
            _selectionAnnotationModels[index]?.Tool == AnnotationTool.Text)
        {
            var model = _selectionAnnotationModels[index]!;
            _selectionAnnotationModels[index] = CopySelectionTextAnnotation(model,
                _selectionTextDragOriginalStart + _selectionTextDragDelta);
        }
        Cursor = _selectionActiveTool == AnnotationTool.Text ? Cursors.Cross : Cursors.Arrow;
        UpdateSelectionHistoryButtons();
    }

    private bool TryHandleSelectionToolDoubleClick(Point p, MouseButtonEventArgs e)
    {
        if (e.ClickCount != 2 || !_lockedDipRect.Contains(p))
            return false;

        if ((_selectionActiveTool == AnnotationTool.None || _selectionActiveTool == AnnotationTool.Text) &&
            TryHitSelectionTextAnnotation(p, out int textIndex))
        {
            BeginEditSelectionText(textIndex);
            e.Handled = true;
            return true;
        }

        if (!HasSelectionEditingTool)
            return false;

        if (_selectionActiveTool != AnnotationTool.None)
            SetSelectionAnnotationTool(_selectionActiveTool);
        else if (_selectionPickerEnabled)
            ToggleSelectionPicker();
        ShowSelectionToast("已退出工具");
        e.Handled = true;
        return true;
    }

    private bool TryBeginSelectionAnnotation(Point p, MouseButtonEventArgs e)
    {
        if (!_lockedSelection.HasValue || !_lockedDipRect.Contains(p)) return false;

        if (_selectionPickerEnabled)
        {
            _ = CopySelectionColorAsync(p);
            e.Handled = true;
            return true;
        }

        if (_selectionActiveTool == AnnotationTool.None) return false;

        if (_selectionActiveTool == AnnotationTool.Text)
        {
            if (TryHitSelectionTextAnnotation(p, out int textIndex))
                BeginEditSelectionText(textIndex);
            else
                BeginSelectionTextAnnotation(p);
            e.Handled = true;
            return true;
        }

        Point pixel = ToSelectionPixelPoint(p);
        _selectionDraft = new Annotation
        {
            Tool = _selectionActiveTool,
            Start = pixel,
            End = pixel,
            Color = AnnotationStyle.Visible(_selectionAnnotationColor),
            StrokeWidth = _selectionStrokeWidth, LineStyle = _selectionLineStyle,
            UsesIndependentShapeStyle = _selectionActiveTool == AnnotationTool.Rectangle || _selectionActiveTool == AnnotationTool.Circle,
            ShapeStrokeEnabled = _selectionShapeStrokeEnabled,
            ShapeFillEnabled = _selectionShapeFillEnabled,
            StrokeOpacity = Math.Max(.05,_selectionShapeStrokeOpacity),
            FillOpacity = Math.Max(.05,_selectionShapeFillOpacity)
        };
        if (_selectionActiveTool == AnnotationTool.Pen)
            _selectionDraft.Points.Add(pixel);

        _selectionDrawing = true;
        CaptureMouse();
        SelectionAnnotations.SetDraft(AnnotationRenderer.Build(_selectionDraft));
        e.Handled = true;
        return true;
    }

    private bool UpdateSelectionAnnotation(Point p, MouseEventArgs e)
    {
        if (_selectionDraggingText)
        {
            UpdateSelectionTextDrag(p);
            if (e.LeftButton != MouseButtonState.Pressed) EndSelectionTextDrag();
            e.Handled = true;
            return true;
        }
        if (!_selectionDrawing || _selectionDraft is null) return false;
        UpdateSelectionDraft(p, final: false);
        if (e.LeftButton != MouseButtonState.Pressed)
            FinishSelectionDraft();
        e.Handled = true;
        return true;
    }

    private bool EndSelectionAnnotation(Point p, MouseButtonEventArgs e)
    {
        if (_selectionDraggingText)
        {
            UpdateSelectionTextDrag(p);
            EndSelectionTextDrag();
            e.Handled = true;
            return true;
        }
        if (!_selectionDrawing) return false;
        UpdateSelectionDraft(p, final: true);
        FinishSelectionDraft();
        e.Handled = true;
        return true;
    }

    private Point ToSelectionPixelPoint(Point rootPoint)
    {
        if (!_lockedSelection.HasValue) return new Point();
        var pixels = _lockedSelection.Value;
        double localX = Math.Clamp(rootPoint.X - _lockedDipRect.Left, 0, Math.Max(0, _lockedDipRect.Width));
        double localY = Math.Clamp(rootPoint.Y - _lockedDipRect.Top, 0, Math.Max(0, _lockedDipRect.Height));
        return new Point(
            localX / Math.Max(1, _lockedDipRect.Width) * pixels.Width,
            localY / Math.Max(1, _lockedDipRect.Height) * pixels.Height);
    }

    private void UpdateSelectionDraft(Point rootPoint, bool final)
    {
        if (_selectionDraft is null || !_lockedSelection.HasValue) return;
        Point p = ToSelectionPixelPoint(rootPoint);
        var pixels = _lockedSelection.Value;

        if (_selectionDraft.Tool == AnnotationTool.Pen)
        {
            if (_selectionDraft.Points.Count == 0)
                _selectionDraft.Points.Add(p);
            else
            {
                double distance = (_selectionDraft.Points[^1] - p).Length;
                if (distance > (final ? .001 : .45))
                    _selectionDraft.Points.Add(p);
            }
        }
        else
        {
            if ((_selectionDraft.Tool == AnnotationTool.Rectangle && Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) ||
                _selectionDraft.Tool == AnnotationTool.Circle)
            {
                var delta = p - _selectionDraft.Start;
                double side = Math.Max(Math.Abs(delta.X), Math.Abs(delta.Y));
                side = Math.Min(side, delta.X < 0 ? _selectionDraft.Start.X : pixels.Width - _selectionDraft.Start.X);
                side = Math.Min(side, delta.Y < 0 ? _selectionDraft.Start.Y : pixels.Height - _selectionDraft.Start.Y);
                p = _selectionDraft.Start + new Vector(delta.X < 0 ? -side : side, delta.Y < 0 ? -side : side);
            }
            _selectionDraft.End = p;
        }
        SelectionAnnotations.SetDraft(AnnotationRenderer.Build(_selectionDraft));
    }

    private void FinishSelectionDraft()
    {
        var completed = _selectionDraft;
        CancelSelectionDraft();
        if (completed is null) return;

        if (completed.Tool == AnnotationTool.Pen)
        {
            if (completed.Points.Count < 2) return;
            double length = 0;
            for (int i = 1; i < completed.Points.Count; i++)
                length += (completed.Points[i] - completed.Points[i - 1]).Length;
            if (length < .5) return;
        }
        else if ((completed.Start - completed.End).Length < .5) return;

        if ((completed.Tool == AnnotationTool.Rectangle || completed.Tool == AnnotationTool.Circle) &&
            (Math.Abs(completed.Start.X - completed.End.X) < .5 || Math.Abs(completed.Start.Y - completed.End.Y) < .5))
            return;

        AddSelectionAnnotation(AnnotationRenderer.Build(completed), completed);
    }

    private void CancelSelectionDraft()
    {
        _selectionDrawing = false;
        _selectionDraft = null;
        SelectionAnnotations.SetDraft(null);
        if (Mouse.Captured == this)
            ReleaseMouseCapture();
    }

    private void AddSelectionAnnotation(DrawingGroup drawing, Annotation? model = null)
    {
        ClearTextSelection();
        _selectionHistory.Record(SelectionAnnotations, _selectionAnnotationModels);
        SelectionAnnotations.Add(drawing);
        _selectionAnnotationModels.Add(model);
        UpdateSelectionHistoryButtons();
    }

    private void UndoSelectionAnnotation()
    {
        CommitSelectionTextEditor();
        if (_selectionDrawing) { CancelSelectionDraft(); return; }
        ClearTextSelection();
        _selectionHistory.Undo(SelectionAnnotations, _selectionAnnotationModels);
        UpdateSelectionHistoryButtons();
    }

    private void RedoSelectionAnnotation()
    {
        CommitSelectionTextEditor();
        if (_selectionDrawing) return;
        ClearTextSelection();
        _selectionHistory.Redo(SelectionAnnotations, _selectionAnnotationModels);
        UpdateSelectionHistoryButtons();
    }

    private void UpdateSelectionHistoryButtons() =>
        _selectionToolbarWindow?.SetHistoryState(_selectionHistory.CanUndo, _selectionHistory.CanRedo);

    private void ClearSelectionAnnotations()
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        CancelSelectionDraft();
        SelectionAnnotations.Clear();
        _selectionAnnotationModels.Clear();
        _selectionHistory.Clear();
        UpdateSelectionHistoryButtons();
    }

    private void UpdateSelectionAnnotationLayer(Rect selectionRect)
    {
        if (!_lockedSelection.HasValue)
        {
            SelectionAnnotations.Visibility = Visibility.Collapsed;
            return;
        }

        var pixels = _lockedSelection.Value;
        Canvas.SetLeft(SelectionAnnotations, selectionRect.Left);
        Canvas.SetTop(SelectionAnnotations, selectionRect.Top);
        SelectionAnnotations.Width = selectionRect.Width;
        SelectionAnnotations.Height = selectionRect.Height;
        SelectionAnnotations.SetScale(
            selectionRect.Width / Math.Max(1, pixels.Width),
            selectionRect.Height / Math.Max(1, pixels.Height));
        SelectionAnnotations.Visibility = Visibility.Visible;
    }

    private static DrawingGroup ScaleDrawing(DrawingGroup drawing, double sx, double sy)
    {
        if (Math.Abs(sx - 1) < .000001 && Math.Abs(sy - 1) < .000001)
            return drawing;

        var wrapper = new DrawingGroup
        {
            Transform = new ScaleTransform(sx, sy)
        };
        wrapper.Children.Add(drawing);
        wrapper.Freeze();
        return wrapper;
    }

    private void RebaseSelectionAnnotations(PixelRect oldRect, PixelRect newRect)
    {
        if (oldRect.Width <= 0 || oldRect.Height <= 0)
            return;
        if (oldRect.Width == newRect.Width && oldRect.Height == newRect.Height)
            return;

        double sx = newRect.Width / (double)oldRect.Width;
        double sy = newRect.Height / (double)oldRect.Height;
        Annotation? RebaseModel(Annotation? model) => model is null ? null : AnnotationTransforms.Scale(model, sx, sy);
        var rebasedModels = _selectionAnnotationModels.Select(RebaseModel).ToArray();
        var transformed = SelectionAnnotations.Drawings.Select((drawing, index) =>
            index < rebasedModels.Length && rebasedModels[index] is Annotation model
                ? AnnotationRenderer.Build(model)
                : ScaleDrawing(drawing, sx, sy)).ToArray();
        ClearTextSelection();
        SelectionAnnotations.ReplaceAll(transformed);
        for (int i = 0; i < _selectionAnnotationModels.Count; i++)
            _selectionAnnotationModels[i] = rebasedModels[i];
        _selectionHistory.Transform(d => ScaleDrawing(d, sx, sy), RebaseModel);
        UpdateSelectionHistoryButtons();
    }

    private void BeginSelectionTextAnnotation(Point rootPoint)
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        if (!_lockedSelection.HasValue) return;

        _selectionEditingTextIndex = -1;
        _selectionEditingTextOriginalModel = null;
        _selectionEditingTextOriginalDrawing = null;
        _selectionTextColor = AnnotationStyle.Visible(_selectionAnnotationColor);
        double x = Math.Clamp(rootPoint.X, _lockedDipRect.Left, Math.Max(_lockedDipRect.Left, _lockedDipRect.Right - 40));
        double y = Math.Clamp(rootPoint.Y, _lockedDipRect.Top, Math.Max(_lockedDipRect.Top, _lockedDipRect.Bottom - 28));
        _selectionTextPoint = ToSelectionPixelPoint(new Point(x, y));
        SelectionTextEditor.Foreground = new SolidColorBrush(_selectionTextColor);
        SelectionTextEditor.Text = string.Empty;
        SelectionTextEditor.Width = Math.Min(220, Math.Max(50, _lockedDipRect.Right - x));
        SelectionTextEditor.FontSize = Math.Clamp(_selectionFontSize / Math.Max(.001, ScaleY), 8, 120);
        Canvas.SetLeft(SelectionTextEditor, x);
        Canvas.SetTop(SelectionTextEditor, y);
        SelectionTextEditor.Visibility = Visibility.Visible;
        Keyboard.Focus(SelectionTextEditor);
    }

    private void CommitSelectionTextEditor()
    {
        if (_selectionTextPoint is not Point p) return;
        string text = SelectionTextEditor.Text.Trim();
        int editingIndex = _selectionEditingTextIndex;
        var originalModel = _selectionEditingTextOriginalModel;
        var originalDrawing = _selectionEditingTextOriginalDrawing;

        _selectionTextPoint = null;
        _selectionEditingTextIndex = -1;
        _selectionEditingTextOriginalModel = null;
        _selectionEditingTextOriginalDrawing = null;
        SelectionTextEditor.Visibility = Visibility.Collapsed;

        if (editingIndex >= 0 && originalModel?.Tool == AnnotationTool.Text &&
            (uint)editingIndex < (uint)_selectionAnnotationModels.Count &&
            (uint)editingIndex < (uint)SelectionAnnotations.Drawings.Count)
        {
            if (text.Length == 0)
            {
                if (originalDrawing is not null) SelectionAnnotations.ReplaceAt(editingIndex, originalDrawing);
                _selectionAnnotationModels[editingIndex] = originalModel;
                return;
            }

            if (originalDrawing is not null) SelectionAnnotations.ReplaceAt(editingIndex, originalDrawing);
            if (text == originalModel.Text && p == originalModel.Start && Math.Abs(_selectionFontSize - originalModel.FontSize) < .01) return;
            _selectionHistory.Record(SelectionAnnotations, _selectionAnnotationModels);
            var edited = CopySelectionTextAnnotation(originalModel, p, text, _selectionFontSize, _selectionFontFamily);
            _selectionAnnotationModels[editingIndex] = edited;
            SelectionAnnotations.ReplaceAt(editingIndex, AnnotationRenderer.Build(edited));
            UpdateSelectionHistoryButtons();
            return;
        }

        if (text.Length == 0) return;
        var model = new Annotation
        {
            Tool = AnnotationTool.Text,
            Start = p,
            End = p,
            Text = text,
            Color = _selectionTextColor,
            FontFamily = _selectionFontFamily, FontSize = _selectionFontSize
        };
        AddSelectionAnnotation(AnnotationRenderer.Build(model), model);
    }

    private void CancelSelectionTextEditor()
    {
        if (_selectionEditingTextIndex >= 0 && _selectionEditingTextOriginalDrawing is not null &&
            (uint)_selectionEditingTextIndex < (uint)SelectionAnnotations.Drawings.Count)
        {
            SelectionAnnotations.ReplaceAt(_selectionEditingTextIndex, _selectionEditingTextOriginalDrawing);
            if (_selectionEditingTextOriginalModel is not null &&
                (uint)_selectionEditingTextIndex < (uint)_selectionAnnotationModels.Count)
                _selectionAnnotationModels[_selectionEditingTextIndex] = _selectionEditingTextOriginalModel;
        }
        _selectionTextPoint = null;
        _selectionEditingTextIndex = -1;
        _selectionEditingTextOriginalModel = null;
        _selectionEditingTextOriginalDrawing = null;
        SelectionTextEditor.Visibility = Visibility.Collapsed;
    }

    private void SelectionTextEditor_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
        {
            CommitSelectionTextEditor();
            Keyboard.Focus(this);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            CancelSelectionTextEditor();
            Keyboard.Focus(this);
            e.Handled = true;
        }
    }

    private void SelectionTextEditor_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) =>
        CommitSelectionTextEditor();

    private bool IsSelectionTextEditorSource(object? source)
    {
        if (source is not DependencyObject d) return false;
        while (d is not null)
        {
            if (ReferenceEquals(d, SelectionTextEditor)) return true;
            d = VisualTreeHelper.GetParent(d);
        }
        return false;
    }

    private async Task CopySelectionColorAsync(Point rootPoint)
    {
        int px = Math.Clamp((int)Math.Floor(rootPoint.X * ScaleX), 0, _screen.PixelWidth - 1);
        int py = Math.Clamp((int)Math.Floor(rootPoint.Y * ScaleY), 0, _screen.PixelHeight - 1);
        BitmapSource pixelSource = _screen.Format == PixelFormats.Bgra32
            ? _screen
            : new FormatConvertedBitmap(_screen, PixelFormats.Bgra32, null, 0);
        byte[] pixel = new byte[4];
        pixelSource.CopyPixels(new Int32Rect(px, py, 1, 1), pixel, 4, 0);
        string hex = $"#{pixel[2]:X2}{pixel[1]:X2}{pixel[0]:X2}";
        try
        {
            await ClipboardService.SetTextAsync(hex);
            ShowSelectionToast($"已複製 {hex}");
        }
        catch (Exception ex)
        {
            App.LogError("Selection picker clipboard", ex);
            ShowSelectionToast("複製色號失敗");
        }
    }

    private BitmapSource BuildCurrentSelectionBitmap()
    {
        if (!_lockedSelection.HasValue)
            throw new InvalidOperationException("尚未鎖定擷取範圍。");
        var rect = _lockedSelection.Value;
        var crop = ScreenCaptureService.CropDetached(_screen,
            new Int32Rect(rect.X, rect.Y, rect.Width, rect.Height));
        return ImageExportService.Compose(crop, SelectionAnnotations.Drawings);
    }

    private bool _copySelectionBusy;
    private async Task CopyCurrentSelectionAsync()
    {
        if (!_lockedSelection.HasValue || _copySelectionBusy) return;
        var copiedRegion = _lockedSelection.Value;
        _copySelectionBusy = true;
        try
        {
            CommitSelectionTextEditor();
            var bitmap = BuildCurrentSelectionBitmap();
            await ClipboardService.SetImageAsync(bitmap);

            (Application.Current as App)?.RememberRegion(copiedRegion, _desktop);
            if (App.Settings.CloseSelectionAfterCopy)
            {
                HideSelectionToolbar(); Hide(); Close();
            }
            else ShowSelectionToast("圖片已複製（含標註）");
            await CaptureStorage.AutoSaveAsync(bitmap);
        }
        catch (Exception ex)
        {
            App.LogError("Copy locked selection", ex);
            ShowSelectionToast("複製失敗");
        }
        finally { _copySelectionBusy = false; }
    }

    private async Task SaveCurrentSelectionAsync()
    {
        if (!_lockedSelection.HasValue) return;
        try
        {
            CommitSelectionTextEditor();
            var dialog = new SaveFileDialog
            {
                Title = "儲存 Clipxel 選區",
                Filter = "PNG 圖片 (*.png)|*.png",
                DefaultExt = ".png",
                AddExtension = true,
                OverwritePrompt = true,
                InitialDirectory = App.Settings.SaveFolder, FileName = App.Settings.FileName()
            };
            if (dialog.ShowDialog(this) != true) return;
            var bitmap = BuildCurrentSelectionBitmap();
            await ImageExportService.SavePngAsync(bitmap, dialog.FileName);
            ShowSelectionToast("PNG 已儲存（含標註）");
        }
        catch (Exception ex)
        {
            App.LogError("Save locked selection", ex);
            ShowSelectionToast("儲存失敗");
        }
    }

    private void ShowSelectionToast(string text)
    {
        SelectionToastText.Text = text;
        SelectionToast.Visibility = Visibility.Visible;
        SelectionToast.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        double x = _lockedDipRect.IsEmpty ? 12 : _lockedDipRect.Left + Math.Max(0, (_lockedDipRect.Width - SelectionToast.DesiredSize.Width) / 2);
        double y = _lockedDipRect.IsEmpty ? 12 : _lockedDipRect.Top + 10;
        Canvas.SetLeft(SelectionToast, Math.Clamp(x, 8, Math.Max(8, ActualWidth - SelectionToast.DesiredSize.Width - 8)));
        Canvas.SetTop(SelectionToast, Math.Clamp(y, 8, Math.Max(8, ActualHeight - SelectionToast.DesiredSize.Height - 8)));
        _selectionToastTimer.Stop();
        _selectionToastTimer.Start();
    }

    private void ResetSelectionEditingState(bool clearDrawings)
    {
        CommitSelectionTextEditor();
        ClearTextSelection();
        CancelSelectionDraft();
        _selectionActiveTool = AnnotationTool.None;
        _selectionPickerEnabled = false;
        _selectionToolbarWindow?.SetActiveTool(AnnotationTool.None);
        _selectionToolbarWindow?.SetPickerActive(false);
        if (clearDrawings)
        {
            SelectionAnnotations.Clear();
            _selectionAnnotationModels.Clear();
            _selectionHistory.Clear();
        }
        _selectionDraggingText = false;
        _selectionDraggingTextIndex = -1;
        _selectionTextDragOriginalDrawing = null;
        _selectionEditingTextIndex = -1;
        _selectionEditingTextOriginalModel = null;
        _selectionEditingTextOriginalDrawing = null;
        SelectionAnnotations.Visibility = Visibility.Collapsed;
        SelectionToast.Visibility = Visibility.Collapsed;
        _selectionToastTimer.Stop();
        UpdateSelectionHistoryButtons();
    }
}
