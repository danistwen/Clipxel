using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Clipxel.Rendering;

namespace Clipxel.Windows;

public partial class SelectionWindow
{
    private int _selectedTextIndex = -1;
    private bool _textDragHistoryRecorded;

    private bool CanInteractWithText => _lockedSelection.HasValue && !_selectionDrawing && !_adjustingSelection &&
        (_selectionActiveTool == AnnotationTool.None || _selectionActiveTool == AnnotationTool.Text) &&
        !_selectionPickerEnabled && !Keyboard.Modifiers.HasFlag(ModifierKeys.Alt) && !Keyboard.IsKeyDown(Key.Space);

    private Rect GetTextFrame(int index)
    {
        if ((uint)index >= (uint)_selectionAnnotationModels.Count || (uint)index >= (uint)SelectionAnnotations.Drawings.Count ||
            _selectionAnnotationModels[index]?.Tool != AnnotationTool.Text) return Rect.Empty;
        var bounds = SelectionAnnotations.Drawings[index].Bounds;
        if (bounds.IsEmpty) return Rect.Empty;
        var frame = new Rect(SelectionPixelToRoot(bounds.TopLeft), SelectionPixelToRoot(bounds.BottomRight));
        frame.Inflate(5, 4); // Constant display-space padding at every zoom/DPI.
        frame.Intersect(_lockedDipRect);
        return frame;
    }

    private bool HitTextFrame(Point point, out int index)
    {
        for (int i = Math.Min(_selectionAnnotationModels.Count, SelectionAnnotations.Drawings.Count) - 1; i >= 0; i--)
            if (GetTextFrame(i).Contains(point)) { index = i; return true; }
        index = -1;
        return false;
    }

    private void ClearTextSelection()
    {
        if (_selectionDraggingText) EndSelectionTextDrag();
        _selectedTextIndex = -1;
        TextChrome?.Clear();
    }

    private bool UpdateTextFeedback(Point point)
    {
        if (!CanInteractWithText || SelectionTextEditor.Visibility == Visibility.Visible)
        {
            TextChrome.Clear();
            return false;
        }
        var selected = GetTextFrame(_selectedTextIndex);
        if (!selected.IsEmpty)
        {
            TextChrome.Show(selected, true);
            if (selected.Contains(point)) { Cursor = Cursors.SizeAll; return true; }
        }
        else
        {
            _selectedTextIndex = -1;
            if (HitTextFrame(point, out int hover))
            {
                TextChrome.Show(GetTextFrame(hover), false);
                Cursor = Cursors.IBeam;
                return true;
            }
            TextChrome.Clear();
        }
        return false;
    }

    private bool TryHandleTextPointerDown(Point point, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return false;
        if (SelectionTextEditor.Visibility == Visibility.Visible)
        {
            var local = Root.TranslatePoint(point, SelectionTextEditor);
            if (new Rect(SelectionTextEditor.RenderSize).Contains(local))
            {
                if (!TextAnnotationChrome.IsEditorEdge(local, SelectionTextEditor.RenderSize)) return false;
                int index = _selectionEditingTextIndex >= 0 ? _selectionEditingTextIndex : _selectionAnnotationModels.Count;
                CommitSelectionTextEditor();
                if ((uint)index < (uint)_selectionAnnotationModels.Count && _selectionAnnotationModels[index]?.Tool == AnnotationTool.Text)
                {
                    _selectedTextIndex = index;
                    TextChrome.Show(GetTextFrame(index), true);
                    Keyboard.Focus(this);
                    StartSelectionTextDrag(index, point);
                }
                e.Handled = true;
                return true;
            }
            CommitSelectionTextEditor();
        }
        if (!CanInteractWithText) return false;
        if (GetTextFrame(_selectedTextIndex).Contains(point))
        {
            if (e.ClickCount == 2) BeginEditSelectionText(_selectedTextIndex);
            else { Keyboard.Focus(this); StartSelectionTextDrag(_selectedTextIndex, point); }
            e.Handled = true;
            return true;
        }
        ClearTextSelection();
        if (!HitTextFrame(point, out int hit)) return false;
        BeginEditSelectionText(hit);
        e.Handled = true;
        return true;
    }

    private bool DeleteSelectedText()
    {
        if (SelectionTextEditor.IsKeyboardFocusWithin || GetTextFrame(_selectedTextIndex).IsEmpty) return false;
        if (_selectionDraggingText) EndSelectionTextDrag();
        int index = _selectedTextIndex;
        _selectionHistory.Record(SelectionAnnotations, _selectionAnnotationModels);
        SelectionAnnotations.RemoveAt(index);
        _selectionAnnotationModels.RemoveAt(index);
        ClearTextSelection();
        
        UpdateSelectionHistoryButtons();
        Keyboard.Focus(this);
        return true;
    }

    private void TextEditor_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        SelectionTextEditor.Cursor = TextAnnotationChrome.IsEditorEdge(e.GetPosition(SelectionTextEditor), SelectionTextEditor.RenderSize)
            ? Cursors.SizeAll : Cursors.IBeam;
    }
}
