using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Media.Imaging;
using Clipxel.Models;
using Clipxel.Services;

namespace Clipxel.Windows;

public partial class SelectionWindow : Window
{
    private enum SelectionResizeMode
    {
        None, Move, Left, Top, Right, Bottom, TopLeft, TopRight, BottomLeft, BottomRight
    }

    private readonly BitmapSource _screen;
    private List<SnapCandidate> _snapCandidates = new();
    private Point _start;
    private int _lastPixelX = -1, _lastPixelY = -1;
    private bool _snapDisabled;
    private readonly PixelRect _desktop;
    private readonly WindowSnapService _snapService;
    private bool _mouseDown;
    private bool _manualDragging;
    private int _candidateIndex;
    private PixelRect? _hoverSnap;
    private PixelRect? _pressedSnap;

    // A snapped/manual region is locked first, then can be moved/resized before capture.
    private PixelRect? _lockedSelection;
    private Rect _lockedDipRect;
    private bool _adjustingSelection;
    private SelectionResizeMode _resizeMode;
    private Point _adjustStartPoint;
    private Rect _adjustStartRect;

    public static bool IsCaptureActive { get; private set; }
    public event EventHandler<CapturedRegionEventArgs>? RegionCaptured;

    public SelectionWindow(DesktopCapture capture)
    {
        InitializeComponent();
        SelectionTextEditor.PreviewMouseRightButtonDown+=(_,e)=>{SetSelectionAnnotationTool(AnnotationTool.None);e.Handled=true;};
        RadialGesture.Attach(Root, GestureTools.AnnotationLabels, SelectionGesture, ShowSelectionPie, () => _lockedSelection.HasValue && !SelectionTextEditor.IsMouseOver, mapping:()=>App.Settings.AnnotationDirections,cancelTool:()=>{bool active=HasSelectionEditingTool;SetSelectionAnnotationTool(AnnotationTool.None);return active;});
        _selectionAnnotationColor = App.Settings.AnnotationColor;
        _selectionFontSize = App.Settings.FontSize;
        _selectionStrokeWidth = App.Settings.StrokeWidth;
        _screen = capture.Bitmap;
        _desktop = capture.Bounds;
        _snapService = new WindowSnapService(_desktop);
        ScreenImage.Source = _screen;
        InitializeSelectionEditing();

        Left = SystemParameters.VirtualScreenLeft;
        Top = SystemParameters.VirtualScreenTop;
        Width = SystemParameters.VirtualScreenWidth;
        Height = SystemParameters.VirtualScreenHeight;

        Loaded += (_, _) =>
        {
            WindowPlacementService.SetBounds(this, _desktop);
            IsCaptureActive = true;
            UpdateMasks(new Rect(0, 0, 0, 0));
            Focus();
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                if (IsVisible) RefreshSnapCandidates(Mouse.GetPosition(Root), force: true);
            }));
        };
        Closed += (_, _) =>
        {
            IsCaptureActive = false;
            _selectionToastTimer.Stop();
            DisposeSelectionToolbar();
        };
        LostMouseCapture += (_, _) =>
        {
            if (_selectionDraggingText)
            {
                EndSelectionTextDrag();
                return;
            }
            if (_selectionDrawing)
            {
                FinishSelectionDraft();
                return;
            }
            if (_adjustingSelection)
            {
                _adjustingSelection = false;
                _resizeMode = SelectionResizeMode.None;
                if (_lockedSelection.HasValue) ShowLockedSelection(_lockedDipRect);
                return;
            }
            if (!_mouseDown) return;
            _mouseDown = false;
            _manualDragging = false;
            if (!_lockedSelection.HasValue)
            {
                SelectionRect.Visibility = Visibility.Collapsed;
                RefreshSnapCandidates(Mouse.GetPosition(Root), force: true);
            }
        };
    }

    private double ScaleX => _screen.PixelWidth / Math.Max(1, ActualWidth);
    private double ScaleY => _screen.PixelHeight / Math.Max(1, ActualHeight);

    private void Window_PreviewTextMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (_lockedSelection.HasValue) TryHandleTextPointerDown(e.GetPosition(Root), e);
    }

    private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (IsSelectionTextEditorSource(e.OriginalSource)) return;
        var p = ClampPoint(e.GetPosition(Root));

        if (_lockedSelection.HasValue)
        {
            if (TryHandleSelectionToolDoubleClick(p, e)) return;

            var mode = HitTestLockedSelection(p);
            bool onResizeEdge = mode != SelectionResizeMode.None && mode != SelectionResizeMode.Move;
            if (onResizeEdge)
            {
                CommitSelectionTextEditor();
                ClearTextSelection();
                CancelSelectionDraft();
                _adjustingSelection = true;
                _resizeMode = mode;
                _adjustStartPoint = p;
                _adjustStartRect = _lockedDipRect;
                CaptureMouse();
                e.Handled = true;
                return;
            }

            if (TryBeginSelectionAnnotation(p, e)) return;

            if (e.ClickCount == 2 && _lockedDipRect.Contains(p) && !HasSelectionEditingTool)
            {
                CapturePixelRect(_lockedSelection.Value);
                e.Handled = true;
                return;
            }

            if (mode != SelectionResizeMode.None)
            {
                CommitSelectionTextEditor();
                _adjustingSelection = true;
                _resizeMode = mode;
                _adjustStartPoint = p;
                _adjustStartRect = _lockedDipRect;
                CaptureMouse();
                e.Handled = true;
                return;
            }

            UnlockSelection(refreshSnap: false);
        }

        _mouseDown = true;
        _manualDragging = false;
        _start = p;
        RefreshSnapCandidates(_start, force: true);
        _pressedSnap = _snapDisabled ? null : _hoverSnap;
        CaptureMouse();
        e.Handled = true;
    }

    private void Window_MouseMove(object sender, MouseEventArgs e)
    {
        if (IsSelectionTextEditorSource(e.OriginalSource)) return;
        Point current = ClampPoint(e.GetPosition(Root));

        if (UpdateSelectionAnnotation(current, e)) return;

        if (_lockedSelection.HasValue)
        {
            if (UpdateTextFeedback(current)) return;
            if (_adjustingSelection && e.LeftButton == MouseButtonState.Pressed)
                UpdateLockedAdjustment(current);
            else if (HasSelectionEditingTool && _lockedDipRect.Contains(current))
                Cursor = Cursors.Cross;
            else
                Cursor = CursorFor(HitTestLockedSelection(current));
            return;
        }

        Cursor = Cursors.Cross;
        if (_mouseDown)
        {
            if (!_manualDragging && (current - _start).Length >= 4)
            {
                _manualDragging = true;
                _pressedSnap = null;
                SnapRect.Visibility = Visibility.Collapsed;
            }

            if (_manualDragging)
                UpdateManualSelection(current);
        }
        else
        {
            RefreshSnapCandidates(current, force: false);
        }
    }

    private void Window_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (IsSelectionTextEditorSource(e.OriginalSource)) return;
        var point = ClampPoint(e.GetPosition(Root));
        if (EndSelectionAnnotation(point, e)) return;

        if (_adjustingSelection)
        {
            _adjustingSelection = false;
            ReleaseMouseCapture();
            _resizeMode = SelectionResizeMode.None;
            Cursor = CursorFor(HitTestLockedSelection(ClampPoint(e.GetPosition(Root))));
            e.Handled = true;
            return;
        }

        if (!_mouseDown) return;
        _mouseDown = false;
        ReleaseMouseCapture();

        if (!_manualDragging && _pressedSnap is PixelRect snapped)
        {
            LockSelection(snapped);
            e.Handled = true;
            return;
        }

        if (!_manualDragging)
        {
            // With snap disabled, a click without dragging simply waits for another action.
            RefreshSnapCandidates(ClampPoint(e.GetPosition(Root)), force: true);
            return;
        }

        var dipRect = Normalize(_start, ClampPoint(e.GetPosition(Root)));
        _manualDragging = false;
        if (dipRect.Width <= 1 || dipRect.Height <= 1)
        {
            RefreshSnapCandidates(ClampPoint(e.GetPosition(Root)), force: true);
            return;
        }

        LockSelection(DipToPixels(dipRect));
        e.Handled = true;
    }

    private void LockSelection(PixelRect rect)
    {
        ResetSelectionEditingState(clearDrawings: true);
        int x = Math.Clamp(rect.X, 0, Math.Max(0, _screen.PixelWidth - 1));
        int y = Math.Clamp(rect.Y, 0, Math.Max(0, _screen.PixelHeight - 1));
        int right = Math.Clamp(rect.Right, x + 1, _screen.PixelWidth);
        int bottom = Math.Clamp(rect.Bottom, y + 1, _screen.PixelHeight);
        _lockedSelection = new PixelRect(x, y, right - x, bottom - y);
        _lockedDipRect = PixelToDipRect(_lockedSelection.Value);
        _hoverSnap = null;
        _pressedSnap = null;
        _snapCandidates.Clear();
        _lastPixelX = _lastPixelY = -1;
        Cursor = Cursors.Arrow;
        ShowLockedSelection(_lockedDipRect);
        InstructionText.Text = "藍框編輯模式 · 工具列常駐 · 可直接標註 / 取色 / 複製 / 儲存 · ✓ 或 Enter 完成擷取";
    }

    private void UnlockSelection(bool refreshSnap = true)
    {
        _lockedSelection = null;
        _lockedDipRect = new Rect(0, 0, 0, 0);
        _adjustingSelection = false;
        _resizeMode = SelectionResizeMode.None;
        SelectionRect.Visibility = Visibility.Collapsed;
        SetHandlesVisibility(Visibility.Collapsed);
        HideSelectionToolbar();
        ResetSelectionEditingState(clearDrawings: true);
        InstructionText.Text = "移動滑鼠吸附 · Tab 切換範圍 · 單擊鎖定 · 拖曳自由框選 · Alt 暫停吸附 · Esc / 右鍵取消";
        Cursor = Cursors.Cross;
        if (refreshSnap) RefreshSnapCandidates(Mouse.GetPosition(Root), force: true);
    }

    private void ShowLockedSelection(Rect r)
    {
        SnapRect.Visibility = Visibility.Collapsed;
        Canvas.SetLeft(SelectionRect, r.Left);
        Canvas.SetTop(SelectionRect, r.Top);
        SelectionRect.Width = r.Width;
        SelectionRect.Height = r.Height;
        SelectionRect.Visibility = Visibility.Visible;
        UpdateMasks(r);
        var pixels = _lockedSelection ?? DipToPixels(r);
        ShowSizeBadge(r, pixels.Width, pixels.Height);
        UpdateSelectionAnnotationLayer(r);
        PositionHandles(r);
        SetHandlesVisibility(Visibility.Visible);
        ShowSelectionToolbar(r);
    }

    private void PositionHandles(Rect r)
    {
        const double half = 4.5;
        PlaceHandle(HandleTL, r.Left - half, r.Top - half);
        PlaceHandle(HandleT, r.Left + r.Width / 2 - half, r.Top - half);
        PlaceHandle(HandleTR, r.Right - half, r.Top - half);
        PlaceHandle(HandleL, r.Left - half, r.Top + r.Height / 2 - half);
        PlaceHandle(HandleR, r.Right - half, r.Top + r.Height / 2 - half);
        PlaceHandle(HandleBL, r.Left - half, r.Bottom - half);
        PlaceHandle(HandleB, r.Left + r.Width / 2 - half, r.Bottom - half);
        PlaceHandle(HandleBR, r.Right - half, r.Bottom - half);
    }

    private static void PlaceHandle(FrameworkElement handle, double x, double y)
    {
        Canvas.SetLeft(handle, x);
        Canvas.SetTop(handle, y);
    }

    private void SetHandlesVisibility(Visibility visibility)
    {
        foreach (var handle in new FrameworkElement[] { HandleTL, HandleT, HandleTR, HandleL, HandleR, HandleBL, HandleB, HandleBR })
            handle.Visibility = visibility;
    }

    private SelectionResizeMode HitTestLockedSelection(Point p)
    {
        if (!_lockedSelection.HasValue) return SelectionResizeMode.None;
        var r = _lockedDipRect;
        const double hit = 8;
        bool nearLeft = Math.Abs(p.X - r.Left) <= hit && p.Y >= r.Top - hit && p.Y <= r.Bottom + hit;
        bool nearRight = Math.Abs(p.X - r.Right) <= hit && p.Y >= r.Top - hit && p.Y <= r.Bottom + hit;
        bool nearTop = Math.Abs(p.Y - r.Top) <= hit && p.X >= r.Left - hit && p.X <= r.Right + hit;
        bool nearBottom = Math.Abs(p.Y - r.Bottom) <= hit && p.X >= r.Left - hit && p.X <= r.Right + hit;

        if (nearLeft && nearTop) return SelectionResizeMode.TopLeft;
        if (nearRight && nearTop) return SelectionResizeMode.TopRight;
        if (nearLeft && nearBottom) return SelectionResizeMode.BottomLeft;
        if (nearRight && nearBottom) return SelectionResizeMode.BottomRight;
        if (nearLeft) return SelectionResizeMode.Left;
        if (nearRight) return SelectionResizeMode.Right;
        if (nearTop) return SelectionResizeMode.Top;
        if (nearBottom) return SelectionResizeMode.Bottom;
        if (r.Contains(p)) return SelectionResizeMode.Move;
        return SelectionResizeMode.None;
    }

    private static Cursor CursorFor(SelectionResizeMode mode) => mode switch
    {
        SelectionResizeMode.Left or SelectionResizeMode.Right => Cursors.SizeWE,
        SelectionResizeMode.Top or SelectionResizeMode.Bottom => Cursors.SizeNS,
        SelectionResizeMode.TopLeft or SelectionResizeMode.BottomRight => Cursors.SizeNWSE,
        SelectionResizeMode.TopRight or SelectionResizeMode.BottomLeft => Cursors.SizeNESW,
        SelectionResizeMode.Move => Cursors.SizeAll,
        _ => Cursors.Arrow
    };

    private void UpdateLockedAdjustment(Point current)
    {
        double dx = current.X - _adjustStartPoint.X;
        double dy = current.Y - _adjustStartPoint.Y;
        var r = _adjustStartRect;
        const double min = 8;
        double left = r.Left, top = r.Top, right = r.Right, bottom = r.Bottom;

        switch (_resizeMode)
        {
            case SelectionResizeMode.Move:
                double newLeft = Math.Clamp(r.Left + dx, 0, Math.Max(0, ActualWidth - r.Width));
                double newTop = Math.Clamp(r.Top + dy, 0, Math.Max(0, ActualHeight - r.Height));
                left = newLeft; right = newLeft + r.Width; top = newTop; bottom = newTop + r.Height;
                break;
            case SelectionResizeMode.Left: left = Math.Clamp(r.Left + dx, 0, r.Right - min); break;
            case SelectionResizeMode.Right: right = Math.Clamp(r.Right + dx, r.Left + min, ActualWidth); break;
            case SelectionResizeMode.Top: top = Math.Clamp(r.Top + dy, 0, r.Bottom - min); break;
            case SelectionResizeMode.Bottom: bottom = Math.Clamp(r.Bottom + dy, r.Top + min, ActualHeight); break;
            case SelectionResizeMode.TopLeft:
                left = Math.Clamp(r.Left + dx, 0, r.Right - min);
                top = Math.Clamp(r.Top + dy, 0, r.Bottom - min);
                break;
            case SelectionResizeMode.TopRight:
                right = Math.Clamp(r.Right + dx, r.Left + min, ActualWidth);
                top = Math.Clamp(r.Top + dy, 0, r.Bottom - min);
                break;
            case SelectionResizeMode.BottomLeft:
                left = Math.Clamp(r.Left + dx, 0, r.Right - min);
                bottom = Math.Clamp(r.Bottom + dy, r.Top + min, ActualHeight);
                break;
            case SelectionResizeMode.BottomRight:
                right = Math.Clamp(r.Right + dx, r.Left + min, ActualWidth);
                bottom = Math.Clamp(r.Bottom + dy, r.Top + min, ActualHeight);
                break;
        }

        var oldSelection = _lockedSelection;
        _lockedDipRect = new Rect(left, top, Math.Max(min, right - left), Math.Max(min, bottom - top));
        var newSelection = DipToPixels(_lockedDipRect);
        if (oldSelection.HasValue) RebaseSelectionAnnotations(oldSelection.Value, newSelection);
        _lockedSelection = newSelection;
        ShowLockedSelection(_lockedDipRect);
        Cursor = CursorFor(_resizeMode);
    }

    private void RefreshSnapCandidates(Point p, bool force)
    {
        if (_lockedSelection.HasValue) return;
        _snapDisabled = Keyboard.Modifiers.HasFlag(ModifierKeys.Alt);
        int px = Math.Clamp((int)Math.Round(p.X * ScaleX), 0, _screen.PixelWidth - 1);
        int py = Math.Clamp((int)Math.Round(p.Y * ScaleY), 0, _screen.PixelHeight - 1);

        if (!force && px == _lastPixelX && py == _lastPixelY) return;
        _lastPixelX = px;
        _lastPixelY = py;
        var previous = _candidateIndex > 0 ? _hoverSnap : null;
        _snapCandidates = _snapDisabled ? new List<SnapCandidate>() :
            _snapService.GetCandidatesAtPoint(_desktop.X + px, _desktop.Y + py);
        _candidateIndex = previous.HasValue ? Math.Max(0, _snapCandidates.FindIndex(c => c.Rect == previous.Value)) : 0;
        ShowCurrentSnapCandidate();
    }

    private void CycleCandidate(int direction)
    {
        if (_mouseDown || _lockedSelection.HasValue || _snapCandidates.Count <= 1)
            return;

        _candidateIndex = (_candidateIndex + direction) % _snapCandidates.Count;
        if (_candidateIndex < 0)
            _candidateIndex += _snapCandidates.Count;
        ShowCurrentSnapCandidate();
    }

    private void ShowCurrentSnapCandidate()
    {
        if (_lockedSelection.HasValue) return;
        if (_snapCandidates.Count == 0)
        {
            _hoverSnap = null;
            SnapRect.Visibility = Visibility.Collapsed;
            SizeBadge.Visibility = Visibility.Collapsed;
            HideSelectionToolbar();
            UpdateMasks(new Rect(0, 0, 0, 0));
            return;
        }

        var candidate = _snapCandidates[Math.Clamp(_candidateIndex, 0, _snapCandidates.Count - 1)];
        _hoverSnap = candidate.Rect;
        var dip = PixelToDipRect(candidate.Rect);

        Canvas.SetLeft(SnapRect, dip.Left);
        Canvas.SetTop(SnapRect, dip.Top);
        SnapRect.Width = dip.Width;
        SnapRect.Height = dip.Height;
        SnapRect.Visibility = Visibility.Visible;
        SelectionRect.Visibility = Visibility.Collapsed;
        SetHandlesVisibility(Visibility.Collapsed);
        UpdateMasks(dip);
        ShowSizeBadge(dip, candidate.Rect.Width, candidate.Rect.Height);
    }

    private void UpdateManualSelection(Point current)
    {
        var r = Normalize(_start, current);
        var pixels = DipToPixels(r);
        Canvas.SetLeft(SelectionRect, r.Left);
        Canvas.SetTop(SelectionRect, r.Top);
        SelectionRect.Width = r.Width;
        SelectionRect.Height = r.Height;
        SelectionRect.Visibility = Visibility.Visible;
        SnapRect.Visibility = Visibility.Collapsed;
        SetHandlesVisibility(Visibility.Collapsed);
        UpdateMasks(r);
        ShowSizeBadge(r, pixels.Width, pixels.Height);
    }

    private void ShowSizeBadge(Rect r, int pixelW, int pixelH)
    {
        SizeText.Text = $"{pixelW} × {pixelH} px";
        SizeBadge.Visibility = Visibility.Visible;
        SizeBadge.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));

        double badgeX = Math.Min(Math.Max(0, r.Left), Math.Max(0, ActualWidth - SizeBadge.DesiredSize.Width));
        double badgeY = r.Top - SizeBadge.DesiredSize.Height - 8;
        if (badgeY < 8) badgeY = r.Bottom + 8;
        if (badgeY + SizeBadge.DesiredSize.Height > ActualHeight) badgeY = Math.Max(0, r.Top + 8);
        Canvas.SetLeft(SizeBadge, badgeX);
        Canvas.SetTop(SizeBadge, badgeY);
    }

    private Rect PixelToDipRect(PixelRect r) =>
        new(r.X / ScaleX, r.Y / ScaleY, r.Width / ScaleX, r.Height / ScaleY);

    private PixelRect DipToPixels(Rect r)
    {
        int x = Math.Clamp((int)Math.Round(r.Left * ScaleX), 0, _screen.PixelWidth - 1);
        int y = Math.Clamp((int)Math.Round(r.Top * ScaleY), 0, _screen.PixelHeight - 1);
        int right = Math.Clamp((int)Math.Round(r.Right * ScaleX), x + 1, _screen.PixelWidth);
        int bottom = Math.Clamp((int)Math.Round(r.Bottom * ScaleY), y + 1, _screen.PixelHeight);
        return new PixelRect(x, y, right - x, bottom - y);
    }

    private void CapturePixelRect(PixelRect rect)
    {
        int x = Math.Clamp(rect.X, 0, _screen.PixelWidth - 1);
        int y = Math.Clamp(rect.Y, 0, _screen.PixelHeight - 1);
        int w = Math.Clamp(rect.Width, 1, _screen.PixelWidth - x);
        int h = Math.Clamp(rect.Height, 1, _screen.PixelHeight - y);
        try
        {
            if (WindowPlacementService.DesktopBounds != _desktop)
                throw new InvalidOperationException("螢幕設定已變更，請重新截圖。");
            CommitSelectionTextEditor();
            var crop = ScreenCaptureService.CropDetached(_screen, new Int32Rect(x, y, w, h));
            var retained = new List<Annotation>();
            if (_lockedSelection.HasValue && _lockedSelection.Value.X == x && _lockedSelection.Value.Y == y &&
                _lockedSelection.Value.Width == w && _lockedSelection.Value.Height == h)
            {
                foreach (var model in _selectionAnnotationModels)
                    if (model is not null) retained.Add(AnnotationTransforms.Clone(model));
            }
            (Application.Current as App)?.RememberRegion(new PixelRect(x, y, w, h), _desktop);
            Hide();
            RegionCaptured?.Invoke(this, new CapturedRegionEventArgs(crop, retained));
        }
        catch (Exception ex)
        {
            Hide();
            App.LogError("Capture region", ex);
            AppDialogWindow.ShowMessage("擷取失敗，請重新按 F1。\n" + ex.Message, "Clipxel");
        }
        finally { Close(); }
    }


    private void UpdateMasks(Rect r)
    {
        double w = SafeFiniteNonNegative(ActualWidth);
        double h = SafeFiniteNonNegative(ActualHeight);
        if (r.IsEmpty || !IsFinite(r.X) || !IsFinite(r.Y) || !IsFinite(r.Width) || !IsFinite(r.Height))
            r = new Rect(0, 0, 0, 0);

        double left = Math.Clamp(r.Left, 0, w);
        double top = Math.Clamp(r.Top, 0, h);
        double right = Math.Clamp(r.Right, 0, w);
        double bottom = Math.Clamp(r.Bottom, 0, h);
        if (right < left) right = left;
        if (bottom < top) bottom = top;

        SetRect(MaskTop, 0, 0, w, top);
        SetRect(MaskBottom, 0, bottom, w, h - bottom);
        SetRect(MaskLeft, 0, top, left, bottom - top);
        SetRect(MaskRight, right, top, w - right, bottom - top);
    }

    private static bool IsFinite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    private static double SafeFiniteNonNegative(double value) => IsFinite(value) && value > 0 ? value : 0;

    private static void SetRect(FrameworkElement element, double x, double y, double w, double h)
    {
        x = IsFinite(x) ? x : 0;
        y = IsFinite(y) ? y : 0;
        w = SafeFiniteNonNegative(w);
        h = SafeFiniteNonNegative(h);
        Canvas.SetLeft(element, x);
        Canvas.SetTop(element, y);
        element.Width = w;
        element.Height = h;
    }

    private Point ClampPoint(Point p) => new(Math.Clamp(p.X, 0, Math.Max(0, ActualWidth)),
        Math.Clamp(p.Y, 0, Math.Max(0, ActualHeight)));

    private static Rect Normalize(Point a, Point b) =>
        new(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y), Math.Abs(a.X - b.X), Math.Abs(a.Y - b.Y));

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.IsRepeat && (e.Key == Key.Escape || e.Key == Key.Delete) && !SelectionTextEditor.IsKeyboardFocusWithin)
        { e.Handled = true; return; }
        if ((e.Key == Key.Escape || e.Key == Key.Delete) && DeleteSelectedText())
        { e.Handled = true; return; }
        if (SelectionTextEditor.IsKeyboardFocusWithin) return;

        var (key, mods) = LocalShortcuts.AnnotationKey(e.Key == Key.System ? e.SystemKey : e.Key, Keyboard.Modifiers);
        bool ctrl = mods.HasFlag(ModifierKeys.Control);
        if (_lockedSelection.HasValue)
        {
            if (ctrl && key == Key.Z)
            {
                if (mods.HasFlag(ModifierKeys.Shift)) RedoSelectionAnnotation();
                else UndoSelectionAnnotation();
                e.Handled = true; return;
            }
            if (ctrl && key == Key.Y) { RedoSelectionAnnotation(); e.Handled = true; return; }
            if (ctrl && key == Key.C) { _ = CopyCurrentSelectionAsync(); e.Handled = true; return; }
            if (ctrl && key == Key.S) { _ = SaveCurrentSelectionAsync(); e.Handled = true; return; }

            if (key == Key.Enter || key == Key.Return)
            {
                CapturePixelRect(_lockedSelection.Value);
                e.Handled = true; return;
            }
            if (key == Key.Escape)
            {
                if (_selectionDrawing) CancelSelectionDraft();
                else if (_selectionActiveTool != AnnotationTool.None) SetSelectionAnnotationTool(_selectionActiveTool);
                else if (_selectionPickerEnabled) ToggleSelectionPicker();
                else UnlockSelection();
                e.Handled = true; return;
            }
            if (mods == ModifierKeys.None)
            {
                switch (key)
                {
                    case Key.B: SetSelectionAnnotationTool(AnnotationTool.Pen); break;
                    case Key.V: SetSelectionAnnotationTool(AnnotationTool.None); break;
                    case Key.R: SetSelectionAnnotationTool(AnnotationTool.Rectangle); break;
                    case Key.C: SetSelectionAnnotationTool(AnnotationTool.Circle); break;
                    case Key.A: SetSelectionAnnotationTool(AnnotationTool.Arrow); break;
                    case Key.T: SetSelectionAnnotationTool(AnnotationTool.Text); break;
                    case Key.I: ToggleSelectionPicker(); break;
                    default: return;
                }
                e.Handled = true; return;
            }
        }

        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Alt))
        {
            _snapDisabled = true;
            if (!_mouseDown) RefreshSnapCandidates(Mouse.GetPosition(Root), force: true);
        }
        if (e.Key == Key.Escape)
        {
            Close();
            e.Handled = true;
        }
        else if (e.Key == Key.Tab)
        {
            CycleCandidate(Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) ? -1 : 1);
            e.Handled = true;
        }
    }

    private void Window_KeyUp(object sender, KeyEventArgs e)
    {
        if (_lockedSelection.HasValue) return;
        if (!_snapDisabled || Keyboard.Modifiers.HasFlag(ModifierKeys.Alt)) return;
        _snapDisabled = false;
        if (!_mouseDown) RefreshSnapCandidates(Mouse.GetPosition(Root), force: true);
    }

    private void Window_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_lockedSelection.HasValue)
        {
            if (_selectionDrawing) CancelSelectionDraft();
            else if (_selectionActiveTool != AnnotationTool.None) SetSelectionAnnotationTool(_selectionActiveTool);
            else if (_selectionPickerEnabled) ToggleSelectionPicker();
            else UnlockSelection();
        }
        else Close();
        e.Handled = true;
    }

    protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
    {
        base.OnDpiChanged(oldDpi, newDpi);
        if (IsLoaded) Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
        {
            if (!IsVisible) return;
            WindowPlacementService.SetBounds(this, _desktop);
            if (_lockedSelection.HasValue)
            {
                _lockedDipRect = PixelToDipRect(_lockedSelection.Value);
                ShowLockedSelection(_lockedDipRect);
            }
        }));
    }
}
