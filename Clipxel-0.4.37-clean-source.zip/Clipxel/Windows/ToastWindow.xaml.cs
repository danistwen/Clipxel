using System;
using System.Windows;
using System.Windows.Threading;

namespace Clipxel.Windows;

public partial class ToastWindow : Window
{
    private readonly DispatcherTimer _closeTimer;

    public ToastWindow(string title, string message, TimeSpan? duration = null)
    {
        InitializeComponent();
        Title = title;
        TitleText.Text = title;
        MessageText.Text = message;
        _closeTimer = new DispatcherTimer
        {
            Interval = duration ?? TimeSpan.FromSeconds(4)
        };
        _closeTimer.Tick += (_, _) => Close();
        Loaded += OnLoaded;
        MouseLeftButtonDown += (_, _) => Close();
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        var area = SystemParameters.WorkArea;
        Left = Math.Max(area.Left + 8, area.Right - ActualWidth - 16);
        Top = Math.Max(area.Top + 8, area.Bottom - ActualHeight - 16);
        _closeTimer.Start();
    }

    protected override void OnClosed(EventArgs e)
    {
        _closeTimer.Stop();
        base.OnClosed(e);
    }

    public static void ShowToast(string title, string message, TimeSpan? duration = null)
    {
        var toast = new ToastWindow(title, message, duration);
        toast.Show();
    }
}
