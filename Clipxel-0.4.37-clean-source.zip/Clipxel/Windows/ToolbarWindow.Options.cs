using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using Clipxel.Services;

namespace Clipxel.Windows;
public partial class ToolbarWindow
{
    private StackPanel? _integratedShapeOptions;
    private CheckBox? _integratedStroke, _integratedFill;
    private Slider? _integratedAlpha;
    private TextBlock? _integratedAlphaLabel;
    private bool _syncingOptions;
    private ComboBox? _integratedFonts;
    private Window? _paletteOwner;

    private void BuildIntegratedOptions()
    {
        if(StrokePopup.Child is not Border shell || shell.Child is not Grid widthControl)return;
        shell.Child=null; widthControl.Width=266;
        var body=new StackPanel{Width=266};shell.Child=body;
        var handle=new Grid{Height=26};
        handle.Children.Add(new Clipxel.Rendering.ToolGlyph{Glyph="DragHandle",Width=16,Height=18,HorizontalAlignment=HorizontalAlignment.Left,Foreground=ThemeService.Foreground});
        handle.Children.Add(new TextBlock{Text="工具設定",Margin=new Thickness(22,3,0,0),Foreground=ThemeService.Foreground});
        var drag=new Thumb{Cursor=Cursors.SizeAll};var face=new FrameworkElementFactory(typeof(Border));face.SetValue(Border.BackgroundProperty,Brushes.Transparent);drag.Template=new ControlTemplate(typeof(Thumb)){VisualTree=face};handle.Children.Add(drag);
        drag.DragDelta+=(_,e)=>{StrokePopup.HorizontalOffset+=e.HorizontalChange;StrokePopup.VerticalOffset+=e.VerticalChange;};body.Children.Add(handle);
        _integratedFonts=new ComboBox{ItemsSource=System.Linq.Enumerable.OrderBy(Fonts.SystemFontFamilies,f=>f.Source),DisplayMemberPath="Source",MaxDropDownHeight=260,Margin=new Thickness(0,4,0,8),Visibility=Visibility.Collapsed};
        _integratedFonts.SelectionChanged+=(_,_)=>{if(_integratedFonts.SelectedItem is FontFamily family)FontFamilySelected?.Invoke(family.Source);};body.Children.Add(_integratedFonts);
        body.Children.Add(widthControl);
        shell.Background=(Brush)Application.Current.FindResource("DialogSurface");
        _integratedAlphaLabel=new TextBlock{Margin=new Thickness(2,8,2,2),Foreground=Clipxel.Services.ThemeService.Foreground};
        _integratedAlpha=new Slider{Minimum=5,Maximum=100,Value=100,IsMoveToPointEnabled=true,Margin=new Thickness(0,0,0,4)};
        _integratedAlpha.Resources["SliderFill"]=Brushes.WhiteSmoke;
        body.Children.Add(_integratedAlphaLabel);body.Children.Add(Clipxel.Controls.NumericSlider.Wrap(_integratedAlpha));
        _integratedAlpha.ValueChanged+=(_,_)=>
        {
            if(_syncingOptions)return;
            var color=((SolidColorBrush)CurrentColorDot.Fill).Color;
            color.A=(byte)Math.Round(_integratedAlpha.Value*255/100);
            SetAnnotationColor(color);AnnotationColorSelected?.Invoke(color);
        };
        _integratedShapeOptions=new StackPanel();body.Children.Add(_integratedShapeOptions);
        CheckBox Toggle(string text,RoutedEventHandler click)
        {
            var control=new CheckBox{Content=text,Foreground=Clipxel.Services.ThemeService.Foreground,Style=(Style)Application.Current.FindResource("SwitchToggle"),Margin=new Thickness(2,8,2,4)};
            control.Click+=(_,e)=>{if(!_syncingOptions)click(control,e);};
            _integratedShapeOptions.Children.Add(control);return control;
        }
        _integratedStroke=Toggle("外框",ShapeStrokeToggleButton_Click);
        MoveOpacityContent(ShapeStrokeOpacityPopup);
        _integratedFill=Toggle("填滿",ShapeFillToggleButton_Click);
        MoveOpacityContent(ShapeFillOpacityPopup);
        void MoveOpacityContent(Popup popup)
        {
            if(popup.Child is not Border border || border.Child is not FrameworkElement content)return;
            border.Child=null;content.Width=266;_integratedShapeOptions.Children.Add(content);
        }
        MistBackdrop.Attach(shell,this);
        ColorPopup.StaysOpen=true;
        ColorPopup.Opened+=(_,_)=>
        {
            // Scoped to the open popup; nothing remains subscribed after close.
            InputManager.Current.PreProcessInput-=PaletteInput;
            InputManager.Current.PreProcessInput+=PaletteInput;
            _paletteOwner=Owner??Window.GetWindow(ColorButton);
            if(_paletteOwner is not null)_paletteOwner.Deactivated+=PaletteOwnerDeactivated;
        };
        ColorPopup.Closed+=(_,_)=>
        {
            InputManager.Current.PreProcessInput-=PaletteInput;
            if(_paletteOwner is not null)_paletteOwner.Deactivated-=PaletteOwnerDeactivated;
            _paletteOwner=null;
        };
    }
    private void PaletteOwnerDeactivated(object? sender,EventArgs e)
    {
        if(!_samplingColor && ColorPopup.Child?.IsMouseOver!=true)ColorPopup.IsOpen=false;
    }
    private void PaletteInput(object sender,PreProcessInputEventArgs e)
    {
        if(_samplingColor)return;
        if(e.StagingItem.Input is KeyEventArgs key && key.IsDown && key.Key==Key.Escape)
        {ColorPopup.IsOpen=false;key.Handled=true;return;}
        if(e.StagingItem.Input is MouseButtonEventArgs mouse && mouse.ButtonState==MouseButtonState.Pressed
            && ColorPopup.Child?.IsMouseOver!=true && !ColorButton.IsMouseOver)
            ColorPopup.IsOpen=false;
        // Clicking the color button is left to its Click handler, which toggles exactly once.
    }
    private void SyncIntegratedOptions()
    {
        if(_integratedShapeOptions is null || _integratedAlpha is null)return;
        if(_integratedFonts is not null)_integratedFonts.Visibility=_fontSizeMode?Visibility.Visible:Visibility.Collapsed;
        _syncingOptions=true;
        try
        {
            _integratedShapeOptions.Visibility=IsShapeControlsVisible?Visibility.Visible:Visibility.Collapsed;
            _integratedStroke!.IsChecked=_shapeStrokeEnabled;_integratedFill!.IsChecked=_shapeFillEnabled;
            _integratedStroke.IsEnabled=!_shapeStrokeEnabled||_shapeFillEnabled;
            _integratedFill.IsEnabled=!_shapeFillEnabled||_shapeStrokeEnabled;
            ShapeStrokeOpacitySlider.IsEnabled=_shapeStrokeEnabled;
            ShapeFillOpacitySlider.IsEnabled=_shapeFillEnabled;
            StrokeSlider.IsEnabled=!IsShapeControlsVisible||_shapeStrokeEnabled;
            _integratedAlpha.Value=((SolidColorBrush)CurrentColorDot.Fill).Color.A*100d/255;
            _integratedAlphaLabel!.Text="顏色不透明度";
            // Width, outline, fill and opacity now share one compact panel.
            ShapeControlsDivider.Visibility=ShapeStrokeToggleButton.Visibility=ShapeStrokeOpacityGroup.Visibility=
                ShapeFillToggleButton.Visibility=ShapeFillOpacityGroup.Visibility=Visibility.Collapsed;
            StrokeButton.IsEnabled=true;
        }
        finally{_syncingOptions=false;}
    }
}
