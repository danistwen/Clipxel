using Clipxel.Models;
namespace Clipxel.Windows;
public partial class ToolbarWindow
{
    internal void ShowSelectedStyle(Annotation a)
    {
        SetActiveTool(a.Tool);SetStrokeWidth(a.StrokeWidth);SetFontSize(a.FontSize);SetAnnotationColor(a.Color);SetShapeStyle(a.ShapeStrokeEnabled,a.ShapeFillEnabled,a.StrokeOpacity,a.FillOpacity);
        SyncIntegratedOptions();StrokePopup.IsOpen=true;
    }
}
