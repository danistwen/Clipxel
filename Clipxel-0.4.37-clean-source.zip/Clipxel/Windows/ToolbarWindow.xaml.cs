using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace Clipxel.Windows;

public enum AnnotationTool
{
    None,
    Pen,
    Rectangle,
    Circle,
    Arrow,
    Text
}

// Retained for compatibility with annotations/tests from older 0.4.37.x builds.
public enum RectangleAnnotationMode
{
    Outline,
    Fill
}

public partial class ToolbarWindow : Window
{
    public event EventHandler? PickRequested;
    public event EventHandler? CopyRequested;
    public event EventHandler? SaveRequested;
    public event EventHandler? ResetRequested;
    public event EventHandler? SelectRequested;
    public event EventHandler? UndoRequested;
    public event EventHandler? RedoRequested;
    public event Action<double>? StrokeWidthSelected;
    public event Action<string>? FontFamilySelected;
    public event Action<double>? FontSizeSelected;
    public event Action<Clipxel.Models.LineStyle>? LineStyleSelected;
    public event Action<AnnotationTool>? ToolSelected;
    public event Action<Color>? AnnotationColorSelected;

    public event Action<bool>? ShapeStrokeEnabledSelected;
    public event Action<bool>? ShapeFillEnabledSelected;
    public event Action<double>? ShapeStrokeOpacitySelected;
    public event Action<double>? ShapeFillOpacitySelected;

    // Backward-compatible aliases. New code should use ShapeFillOpacitySelected and
    // the independent shape-style events above.
    public event Action<double>? FillOpacitySelected;
    public event Action<RectangleAnnotationMode>? RectangleModeSelected;

    public event EventHandler? ModeSwitchRequested;
    public event EventHandler? CloseRequested;
    public event EventHandler? SizeUpdated;

    private HwndSource? _source;
    private bool _settingStrokeControl;
    private bool _settingShapeStrokeOpacity;
    private bool _settingShapeFillOpacity;
    private bool _fontSizeMode;
    private double _strokeWidthValue = 3;
    private double _fontSizeValue = 22;
    private AnnotationTool _activeTool;
    private AnnotationTool _activeShapeTool = AnnotationTool.Rectangle;
    private bool _shapeStrokeEnabled = true;
    private bool _shapeFillEnabled;
    private double _shapeStrokeOpacity = 1.0;
    private double _shapeFillOpacity = 0.45;
    private bool _selectionCaptureMode;
    private bool _selectActive;

    // Historical compatibility constant. Placement now uses measured ExpandedWidthDip
    // so changing native widths during layout cannot re-center the bar.
    public const double ShapeInlineExpansionWidthDip = 139.0;
    public double ExpandedWidthDip { get; private set; }
    public bool IsShapeControlsVisible => _activeTool == AnnotationTool.Rectangle || _activeTool == AnnotationTool.Circle;

    public ToolbarWindow()
    {
        InitializeComponent();
        BuildIntegratedOptions();
        foreach(var popup in new[]{ShapePopup,ColorPopup,StrokePopup,ShapeStrokeOpacityPopup,ShapeFillOpacityPopup})popup.Closed+=(_,_)=>PopupClosed?.Invoke();
        foreach(var entry in new[]{("ResetButton","選取","Select"),("PenButton","畫筆","Pen"),("ShapeButton","形狀","Rectangle"),("ShapeRectangleButton","矩形","Rectangle"),("ShapeCircleButton","圓形","Circle"),("ArrowButton","箭頭","Arrow"),("TextButton","文字","Text"),("UndoButton","復原","Undo"),("RedoButton","重做","Redo"),("ColorButton","顏色",""),("StrokeButton","粗細／字級",""),("ShapeStrokeToggleButton","外框",""),("ShapeFillToggleButton","填滿",""),("ShapeStrokeOpacityButton","外框不透明度",""),("ShapeFillOpacityButton","填滿不透明度",""),("PickButton","取色","PickColor"),("CopyButton","複製","Copy"),("SaveButton","儲存","Export"),("CloseButton","關閉",""),("ModeSwitchButton","切換模式","Return")})
        {
            if(FindName(entry.Item1)is not FrameworkElement button)continue;
            Clipxel.Services.ToolHints.Attach(button,()=>entry.Item1=="StrokeButton"?"工具設定":entry.Item2,()=>entry.Item1=="ModeSwitchButton"?App.Settings.ToggleModeKey:Window.GetWindow(button)is ReferenceBoardWindow?App.Settings.BoardShortcuts.GetValueOrDefault(entry.Item3):App.Settings.AnnotationShortcuts.GetValueOrDefault(entry.Item2=="形狀"?"矩形":entry.Item2));
        }
        var fontMenu = new ContextMenu();fontMenu.Closed+=(_,_)=>PopupClosed?.Invoke();
        fontMenu.Opened+=(_,_)=>
        {
        if(fontMenu.Items.Count>0)return;
        foreach (var family in Fonts.SystemFontFamilies.OrderBy(f => f.Source))
        {
            var item = new MenuItem { Header = family.Source, Icon=new Clipxel.Rendering.ToolGlyph {Glyph="Text",Foreground=Clipxel.Services.ThemeService.ActiveToolInk}, FontFamily = family };
            item.Click += (_, _) => FontFamilySelected?.Invoke(family.Source); fontMenu.Items.Add(item);
        }
        };
        TextButton.ContextMenu = fontMenu; TextButton.ToolTip = "文字（右鍵選字型）";
        IsVisibleChanged += (_, _) =>
        {
            if (!IsVisible) return;
            string Hint(string label) => label + (App.Settings.AnnotationShortcuts.TryGetValue(label, out var shortcut) && !string.IsNullOrEmpty(shortcut) ? " (" + shortcut + ")" : "");
            ShapeRectangleButton.ToolTip = Hint("矩形"); ShapeCircleButton.ToolTip = Hint("圓形");
            PenButton.ToolTip = Hint("畫筆"); ArrowButton.ToolTip = Hint("箭頭"); TextButton.ToolTip = Hint("文字") + "；右鍵選字型";
            UndoButton.ToolTip = Hint("復原"); RedoButton.ToolTip = Hint("重做");
        };
        SetAnnotationColor(Colors.White);
        ConfigureValueControl(false);
        SetShapeStyle(true, false, 1.0, 0.45);
        SetActiveTool(AnnotationTool.Rectangle);
        var surface = (FrameworkElement)Content;
        surface.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        ExpandedWidthDip = surface.DesiredSize.Width;
        SetActiveTool(AnnotationTool.None);
        SizeChanged += (_, _) => SizeUpdated?.Invoke(this, EventArgs.Empty);
        SourceInitialized += (_, _) =>
        {
            _source = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
            _source?.AddHook(WindowHook);
        };
        Closed += (_, _) => { ClosePopups(); ColorPopup.Child=null; _colorPicker=null; _source?.RemoveHook(WindowHook); };
        ((FrameworkElement)Content).IsVisibleChanged+=(_,_)=>{if(Content is FrameworkElement content&&!content.IsVisible&&!_samplingColor)ClosePopups();};
    }

    private IntPtr WindowHook(IntPtr window, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == 0x0021) { handled = true; return new IntPtr(3); } // MA_NOACTIVATE
        return IntPtr.Zero;
    }

    public void SetSelectionCaptureMode(bool enabled)
    {
        _selectionCaptureMode = enabled;
        ModeSwitchButton.IsEnabled = !enabled;
        ModeSwitchButton.ToolTip = enabled ? "完成擷取後可切換至參考畫布" : "切換至參考畫布模式";
        if (ResetButton is null || SelectModeIcon is null || ConfirmModeIcon is null || CloseButton is null) return;
        SelectModeIcon.Visibility = enabled ? Visibility.Collapsed : Visibility.Visible;
        ConfirmModeIcon.Visibility = enabled ? Visibility.Visible : Visibility.Collapsed;
        ResetButton.ToolTip = enabled ? "完成擷取 (Enter)" : "選取 / 指標模式";
        CloseButton.ToolTip = enabled ? "取消目前選區" : "關閉";
        if (enabled) ResetButton.Background = Brushes.Transparent;
        else SetSelectActive(_selectActive);
    }

    public void SetSelectActive(bool active)
    {
        _selectActive = active;
        if (_selectionCaptureMode || ResetButton is null) return;
        ResetButton.Foreground=active?Clipxel.Services.ThemeService.ActiveToolInk:Clipxel.Services.ThemeService.Foreground;
        ResetButton.Background = active
            ? Clipxel.Services.ThemeService.ActiveToolSurface
            : Brushes.Transparent;
    }

    public void SetHistoryState(bool undo, bool redo)
    {
        UndoButton.IsEnabled = undo;
        RedoButton.IsEnabled = redo;
    }

    public void SetPickerActive(bool active)
    {PickButton.Foreground=active?Clipxel.Services.ThemeService.ActiveToolInk:Clipxel.Services.ThemeService.Foreground;PickButton.Background=active?Clipxel.Services.ThemeService.ActiveToolSurface:Brushes.Transparent;}

    public void SetStrokeWidth(double width)
    {
        _strokeWidthValue = Math.Clamp(Math.Round(width), 1, 20);
        if (!_fontSizeMode) SyncValueControl(_strokeWidthValue);
    }

    public void SetFontSize(double size)
    {
        _fontSizeValue = Math.Clamp(Math.Round(size), 8, 120);
        if (_fontSizeMode) SyncValueControl(_fontSizeValue);
    }

    public void SetShapeStyle(bool strokeEnabled, bool fillEnabled, double strokeOpacity, double fillOpacity)
    {
        if (!strokeEnabled && !fillEnabled) strokeEnabled = true;
        _shapeStrokeEnabled = strokeEnabled;
        _shapeFillEnabled = fillEnabled;
        SetShapeStrokeOpacity(strokeOpacity);
        SetShapeFillOpacity(fillOpacity);
        UpdateShapeControls();
    }

    public void SetShapeStrokeOpacity(double opacity)
    {
        _shapeStrokeOpacity = Math.Clamp(opacity, 0.0, 1.0);
        double percent = Math.Clamp(Math.Round(_shapeStrokeOpacity * 100 / 5.0) * 5.0,
            ShapeStrokeOpacitySlider.Minimum, ShapeStrokeOpacitySlider.Maximum);
        _shapeStrokeOpacity = percent / 100.0;
        _settingShapeStrokeOpacity = true;
        ShapeStrokeOpacitySlider.Value = percent;
        ShapeStrokeOpacityText.Text = $"{percent:0}%";

        _settingShapeStrokeOpacity = false;
    }

    public void SetShapeFillOpacity(double opacity)
    {
        _shapeFillOpacity = Math.Clamp(opacity, 0.0, 1.0);
        double percent = Math.Clamp(Math.Round(_shapeFillOpacity * 100 / 5.0) * 5.0,
            ShapeFillOpacitySlider.Minimum, ShapeFillOpacitySlider.Maximum);
        _shapeFillOpacity = percent / 100.0;
        _settingShapeFillOpacity = true;
        ShapeFillOpacitySlider.Value = percent;
        ShapeFillOpacityText.Text = $"{percent:0}%";

        _settingShapeFillOpacity = false;
    }

    // Compatibility with 0.4.37.2 callers/tests.
    public void SetFillOpacity(double opacity) => SetShapeFillOpacity(opacity);

    public void SetRectangleMode(RectangleAnnotationMode mode)
    {
        if (mode == RectangleAnnotationMode.Outline)
            SetShapeStyle(true, false, _shapeStrokeOpacity, _shapeFillOpacity);
        else
            SetShapeStyle(false, true, _shapeStrokeOpacity, _shapeFillOpacity);
    }

    public bool HasOpenPopup => _samplingColor || ShapePopup.IsOpen || ColorPopup.IsOpen || StrokePopup.IsOpen || ShapeStrokeOpacityPopup.IsOpen || ShapeFillOpacityPopup.IsOpen || TextButton.ContextMenu?.IsOpen==true || _toolMenu?.IsOpen==true;
    public event Action? PopupClosed;
    private ContextMenu? _toolMenu;
    private Clipxel.Controls.ColorPicker? _colorPicker;
    private bool _samplingColor;
    public bool IsSamplingColor => _samplingColor;
    public void ClosePopups()
    {
        if(_toolMenu is not null)_toolMenu.IsOpen=false;
        if(TextButton.ContextMenu is not null)TextButton.ContextMenu.IsOpen=false;
        ShapePopup.IsOpen = false;
        ColorPopup.IsOpen = false;
        StrokePopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = false;
    }

    public void SetActiveTool(AnnotationTool tool)
    {
        _activeTool = tool;
        bool shape = tool == AnnotationTool.Rectangle || tool == AnnotationTool.Circle;
        if (shape) _activeShapeTool = tool;
        ShapeControlsDivider.Visibility = shape ? Visibility.Visible : Visibility.Collapsed;
        ShapeStrokeToggleButton.Visibility = shape ? Visibility.Visible : Visibility.Collapsed;
        ShapeStrokeOpacityGroup.Visibility = shape ? Visibility.Visible : Visibility.Collapsed;
        ShapeFillToggleButton.Visibility = shape ? Visibility.Visible : Visibility.Collapsed;
        ShapeFillOpacityGroup.Visibility = shape ? Visibility.Visible : Visibility.Collapsed;
        ConfigureValueControl(tool == AnnotationTool.Text);
        if (shape) StrokeButton.ToolTip = "外框粗細（原圖像素）";
        UpdateShapeControls();
        UpdateShapeGlyphs();

        var blue=Clipxel.Services.ThemeService.ActiveToolInk;
        ShapeRectangleButton.Foreground=tool==AnnotationTool.Rectangle?blue:Clipxel.Services.ThemeService.Foreground;
        ShapeCircleButton.Foreground=tool==AnnotationTool.Circle?blue:Clipxel.Services.ThemeService.Foreground;
        PenButton.Foreground=tool==AnnotationTool.Pen?blue:Clipxel.Services.ThemeService.Foreground;ShapeButton.Foreground=shape?blue:Clipxel.Services.ThemeService.Foreground;
        ArrowButton.Foreground=tool==AnnotationTool.Arrow?blue:Clipxel.Services.ThemeService.Foreground;TextButton.Foreground=tool==AnnotationTool.Text?blue:Clipxel.Services.ThemeService.Foreground;
        PenButton.Background = tool == AnnotationTool.Pen
            ? Clipxel.Services.ThemeService.ActiveToolSurface : Brushes.Transparent;
        ShapeButton.Background = shape
            ? Clipxel.Services.ThemeService.ActiveToolSurface : Brushes.Transparent;
        ArrowButton.Background = tool == AnnotationTool.Arrow
            ? Clipxel.Services.ThemeService.ActiveToolSurface : Brushes.Transparent;
        TextButton.Background = tool == AnnotationTool.Text
            ? Clipxel.Services.ThemeService.ActiveToolSurface : Brushes.Transparent;

        if (!shape) ShapePopup.IsOpen = false;
        SyncIntegratedOptions();
    }

    public void SetAnnotationColor(Color color)
    {
        CurrentColorDot.Fill = new SolidColorBrush(color);
        StrokePreviewLine.Stroke=new SolidColorBrush(color);
        FontSizePreviewText.Foreground=new SolidColorBrush(color);
        StrokeSlider.Resources["SliderFill"]=new SolidColorBrush(Color.FromRgb(color.R,color.G,color.B));
        SyncIntegratedOptions();
        ShapeStrokeOpacitySlider.Resources["SliderFill"]=Brushes.WhiteSmoke;ShapeFillOpacitySlider.Resources["SliderFill"]=Brushes.WhiteSmoke;


    }

    private void ConfigureValueControl(bool fontSizeMode)
    {
        _fontSizeMode = fontSizeMode;
        _settingStrokeControl = true;
        if (fontSizeMode)
        {
            StrokeSlider.Minimum = 8;
            StrokeSlider.Maximum = 120;
            StrokeSlider.TickFrequency = 1;
            StrokeSlider.SmallChange = 1;
            StrokeSlider.LargeChange = 8;
            StrokePopupLabel.Text = "文字字級";
            StrokeUnitText.Text = "pt";
            StrokeButton.ToolTip = "文字字級";
            StrokeModeIcon.Visibility = Visibility.Collapsed;
            FontModeIcon.Visibility = Visibility.Visible;
            StrokePreviewLineHost.Visibility = Visibility.Collapsed;
            FontSizePreviewText.Visibility = Visibility.Visible;
            StrokeSlider.Value = Math.Clamp(_fontSizeValue, StrokeSlider.Minimum, StrokeSlider.Maximum);
        }
        else
        {
            StrokeSlider.Minimum = 1;
            StrokeSlider.Maximum = 20;
            StrokeSlider.TickFrequency = 1;
            StrokeSlider.SmallChange = 1;
            StrokeSlider.LargeChange = 2;
            StrokePopupLabel.Text = "筆畫粗細";
            StrokeUnitText.Text = "px";
            StrokeButton.ToolTip = "筆畫粗細（原圖像素）";
            StrokeModeIcon.Visibility = Visibility.Visible;
            FontModeIcon.Visibility = Visibility.Collapsed;
            StrokePreviewLineHost.Visibility = Visibility.Visible;
            FontSizePreviewText.Visibility = Visibility.Collapsed;
            StrokeSlider.Value = Math.Clamp(_strokeWidthValue, StrokeSlider.Minimum, StrokeSlider.Maximum);
        }
        UpdateValueText(StrokeSlider.Value);
        _settingStrokeControl = false;
    }

    private void SyncValueControl(double value)
    {
        _settingStrokeControl = true;
        StrokeSlider.Value = Math.Clamp(value, StrokeSlider.Minimum, StrokeSlider.Maximum);
        UpdateValueText(StrokeSlider.Value);
        _settingStrokeControl = false;
    }

    private void UpdateValueText(double value)
    {
        value = Math.Round(value);
        StrokeText.Text = value.ToString("0", CultureInfo.InvariantCulture);
        StrokeValueInput.Text = value.ToString("0", CultureInfo.InvariantCulture);
        if (_fontSizeMode)
            FontSizePreviewText.FontSize = 10 + Math.Clamp((value - 8) / 112.0, 0, 1) * 10;
    }

    private void UpdateShapeGlyphs()
    {
        if (ShapeStrokeRectangleIcon is null || ShapeStrokeCircleIcon is null ||
            ShapeFillRectangleIcon is null || ShapeFillCircleIcon is null) return;

        bool circle = _activeShapeTool == AnnotationTool.Circle;
        ShapeStrokeRectangleIcon.Visibility = circle ? Visibility.Collapsed : Visibility.Visible;
        ShapeStrokeCircleIcon.Visibility = circle ? Visibility.Visible : Visibility.Collapsed;
        ShapeFillRectangleIcon.Visibility = circle ? Visibility.Collapsed : Visibility.Visible;
        ShapeFillCircleIcon.Visibility = circle ? Visibility.Visible : Visibility.Collapsed;
    }

    private void UpdateShapeControls()
    {
        if (ShapeStrokeToggleButton is null || ShapeFillToggleButton is null) return;
        var active = Clipxel.Services.ThemeService.ActiveToolSurface;
        ShapeStrokeToggleButton.Background = _shapeStrokeEnabled ? active : Brushes.Transparent;
        ShapeFillToggleButton.Background = _shapeFillEnabled ? active : Brushes.Transparent;
        ShapeStrokeOpacityButton.IsEnabled = _shapeStrokeEnabled;
        ShapeFillOpacityButton.IsEnabled = _shapeFillEnabled;
        bool shapeActive = _activeTool == AnnotationTool.Rectangle || _activeTool == AnnotationTool.Circle;
        StrokeButton.IsEnabled = !shapeActive || _shapeStrokeEnabled;
        SyncIntegratedOptions();


    }

    private void SelectTool(AnnotationTool tool) {ClosePopups();ToolSelected?.Invoke(tool);}

    private void PenButton_Click(object sender, RoutedEventArgs e) => SelectTool(AnnotationTool.Pen);

    private void ShapeButton_Click(object sender, RoutedEventArgs e)
    {
        if (IsShapeControlsVisible)
        {
            ClosePopups(); SelectTool(_activeTool); e.Handled = true; return;
        }
        ColorPopup.IsOpen = false;
        StrokePopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = false;
        ShapePopup.IsOpen = !ShapePopup.IsOpen;
        e.Handled = true;
    }

    private void ShapeRectangleButton_Click(object sender, RoutedEventArgs e)
    {
        ShapePopup.IsOpen = false;
        SelectTool(AnnotationTool.Rectangle);
    }

    private void ShapeCircleButton_Click(object sender, RoutedEventArgs e)
    {
        ShapePopup.IsOpen = false;
        SelectTool(AnnotationTool.Circle);
    }

    private void ArrowButton_Click(object sender, RoutedEventArgs e)
    {
        ClosePopups();
        var menu = new ContextMenu { PlacementTarget = ArrowButton, Placement = System.Windows.Controls.Primitives.PlacementMode.Top };_toolMenu=menu;
        menu.Closed+=(_,_)=>{if(ReferenceEquals(_toolMenu,menu))_toolMenu=null;PopupClosed?.Invoke();};
        foreach (var style in Enum.GetValues<Clipxel.Models.LineStyle>())
        {
            var item = new MenuItem { Header = style switch { Clipxel.Models.LineStyle.Arrow => "箭頭", Clipxel.Models.LineStyle.Plain => "純直線", Clipxel.Models.LineStyle.Dashed => "虛線", _ => "圓端點" }, Icon = new Clipxel.Rendering.ToolGlyph { Glyph = style.ToString() } };
            item.Click += (_, _) => { LineStyleSelected?.Invoke(style); if (_activeTool != AnnotationTool.Arrow) SelectTool(AnnotationTool.Arrow); ArrowButton.ToolTip = item.Header; ArrowButton.Content = new Clipxel.Rendering.ToolGlyph { Glyph = style.ToString() }; };
            menu.Items.Add(item);
        }
        menu.IsOpen = true;
    }
    private void TextButton_Click(object sender, RoutedEventArgs e) => SelectTool(AnnotationTool.Text);
    private void UndoButton_Click(object sender, RoutedEventArgs e) => UndoRequested?.Invoke(this, EventArgs.Empty);
    private void RedoButton_Click(object sender, RoutedEventArgs e) => RedoRequested?.Invoke(this, EventArgs.Empty);
    private void PickButton_Click(object sender, RoutedEventArgs e) => PickRequested?.Invoke(this, EventArgs.Empty);
    private void CopyButton_Click(object sender, RoutedEventArgs e) => CopyRequested?.Invoke(this, EventArgs.Empty);
    private void SaveButton_Click(object sender, RoutedEventArgs e) => SaveRequested?.Invoke(this, EventArgs.Empty);
    private void ResetButton_Click(object sender, RoutedEventArgs e)
    {
        if (_selectionCaptureMode) ResetRequested?.Invoke(this, EventArgs.Empty);
        else SelectRequested?.Invoke(this, EventArgs.Empty);
    }
    private void ModeSwitchButton_Click(object sender, RoutedEventArgs e)
    {
        ClosePopups(); ModeSwitchRequested?.Invoke(this, EventArgs.Empty);
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e) => CloseRequested?.Invoke(this, EventArgs.Empty);

    private void ColorButton_Click(object sender, RoutedEventArgs e)
    {
        if(_toolMenu is not null)_toolMenu.IsOpen=false;
        if(TextButton.ContextMenu is not null)TextButton.ContextMenu.IsOpen=false;
        ShapePopup.IsOpen = false;
        StrokePopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = false;
        if(!ColorPopup.IsOpen)
        {
            if(_colorPicker is null)
            {
                _colorPicker=new Clipxel.Controls.ColorPicker(((SolidColorBrush)CurrentColorDot.Fill).Color);
                _colorPicker.ColorChanged+=color=>{SetAnnotationColor(color);AnnotationColorSelected?.Invoke(color);};
                _colorPicker.SamplingChanged+=sampling=>
                {
                    _samplingColor=sampling;
                    if(sampling)ColorPopup.IsOpen=false;
                    else {if(ColorButton.IsVisible)ColorPopup.IsOpen=true;PopupClosed?.Invoke();}
                };
                var shell=new Border {Style=(Style)Application.Current.FindResource("MistCard"),Padding=new Thickness(0),Child=new ScrollViewer {Content=_colorPicker,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled,MaxHeight=Clipxel.Controls.ColorPicker.AvailableHeight(Window.GetWindow(ColorButton)??this)},Background=(Brush)Application.Current.FindResource("DialogSurface"),CornerRadius=new CornerRadius(12)};
                ColorPopup.Child=shell;
                Clipxel.Services.MistBackdrop.Attach(shell,Window.GetWindow(ColorButton)??this);
            }
            _colorPicker.SourceOwner=Window.GetWindow(ColorButton)??this;
            _colorPicker.SetColor(((SolidColorBrush)CurrentColorDot.Fill).Color);
        }
        ColorPopup.IsOpen = !ColorPopup.IsOpen;
        e.Handled = true;
    }

    private void StrokeButton_Click(object sender, RoutedEventArgs e)
    {
        if(_toolMenu is not null)_toolMenu.IsOpen=false;
        if(TextButton.ContextMenu is not null)TextButton.ContextMenu.IsOpen=false;
        ShapePopup.IsOpen = false;
        ColorPopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = false;
        SyncIntegratedOptions();
        StrokePopup.IsOpen = !StrokePopup.IsOpen;
        e.Handled = true;
    }

    private void StrokeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_settingStrokeControl || StrokeValueInput is null) return;
        double value = Math.Round(e.NewValue);
        UpdateValueText(value);
        if (_fontSizeMode)
        {
            _fontSizeValue = Math.Clamp(value, 8, 120);
            FontSizeSelected?.Invoke(_fontSizeValue);
        }
        else
        {
            _strokeWidthValue = Math.Clamp(value, 1, 20);
            StrokeWidthSelected?.Invoke(_strokeWidthValue);
        }
    }

    private void CommitStrokeValueInput()
    {
        if (StrokeValueInput is null) return;
        if (!double.TryParse(StrokeValueInput.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out double value) &&
            !double.TryParse(StrokeValueInput.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
        {
            UpdateValueText(_fontSizeMode ? _fontSizeValue : _strokeWidthValue);
            return;
        }
        value = Math.Clamp(Math.Round(value), StrokeSlider.Minimum, StrokeSlider.Maximum);
        if (Math.Abs(StrokeSlider.Value - value) < .001)
        {
            UpdateValueText(value);
            if (_fontSizeMode) { _fontSizeValue = value; FontSizeSelected?.Invoke(value); }
            else { _strokeWidthValue = value; StrokeWidthSelected?.Invoke(value); }
            return;
        }
        StrokeSlider.Value = value;
    }

    private void StrokeValueInput_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter || e.Key == Key.Return)
        {
            CommitStrokeValueInput();
            Keyboard.ClearFocus();
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            UpdateValueText(_fontSizeMode ? _fontSizeValue : _strokeWidthValue);
            Keyboard.ClearFocus();
            e.Handled = true;
        }
    }

    private void StrokeValueInput_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) => CommitStrokeValueInput();
    private void StrokeValueInput_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) => StrokeValueInput.SelectAll();

    private void ShapeStrokeToggleButton_Click(object sender, RoutedEventArgs e)
    {
        if (_shapeStrokeEnabled && !_shapeFillEnabled) return; // Never make an invisible shape.
        _shapeStrokeEnabled = !_shapeStrokeEnabled;
        UpdateShapeControls();
        ShapeStrokeEnabledSelected?.Invoke(_shapeStrokeEnabled);
    }

    private void ShapeFillToggleButton_Click(object sender, RoutedEventArgs e)
    {
        if (_shapeFillEnabled && !_shapeStrokeEnabled) return;
        _shapeFillEnabled = !_shapeFillEnabled;
        UpdateShapeControls();
        ShapeFillEnabledSelected?.Invoke(_shapeFillEnabled);
    }

    private void ShapeStrokeOpacityButton_Click(object sender, RoutedEventArgs e)
    {
        if(_toolMenu is not null)_toolMenu.IsOpen=false;
        if(TextButton.ContextMenu is not null)TextButton.ContextMenu.IsOpen=false;
        ShapePopup.IsOpen = false;
        ColorPopup.IsOpen = false;
        StrokePopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = !ShapeStrokeOpacityPopup.IsOpen;
        e.Handled = true;
    }

    private void ShapeFillOpacityButton_Click(object sender, RoutedEventArgs e)
    {
        if(_toolMenu is not null)_toolMenu.IsOpen=false;
        if(TextButton.ContextMenu is not null)TextButton.ContextMenu.IsOpen=false;
        ShapePopup.IsOpen = false;
        ColorPopup.IsOpen = false;
        StrokePopup.IsOpen = false;
        ShapeStrokeOpacityPopup.IsOpen = false;
        ShapeFillOpacityPopup.IsOpen = !ShapeFillOpacityPopup.IsOpen;
        e.Handled = true;
    }

    private void ShapeStrokeOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_settingShapeStrokeOpacity || ShapeStrokeOpacityText is null || ShapeStrokeOpacityPopupText is null || ShapeStrokeOpacityPreview is null) return;
        double percent = Math.Clamp(Math.Round(e.NewValue / 5.0) * 5.0, 0, 100);
        _shapeStrokeOpacity = percent / 100.0;
        ShapeStrokeOpacityText.Text = $"{percent:0}%";

        ShapeStrokeOpacitySelected?.Invoke(_shapeStrokeOpacity);
    }

    private void ShapeFillOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_settingShapeFillOpacity || ShapeFillOpacityText is null || ShapeFillOpacityPopupText is null || ShapeFillOpacityPreview is null) return;
        double percent = Math.Clamp(Math.Round(e.NewValue / 5.0) * 5.0, 0, 100);
        _shapeFillOpacity = percent / 100.0;
        ShapeFillOpacityText.Text = $"{percent:0}%";

        ShapeFillOpacitySelected?.Invoke(_shapeFillOpacity);
        FillOpacitySelected?.Invoke(_shapeFillOpacity);
    }

    // Compatibility helpers for older code paths. They map the exclusive modes to
    // the new independent stroke/fill toggles.
    private void RectOutlineButton_Click(object sender, RoutedEventArgs e)
    {
        SetRectangleMode(RectangleAnnotationMode.Outline);
        RectangleModeSelected?.Invoke(RectangleAnnotationMode.Outline);
        ShapeStrokeEnabledSelected?.Invoke(true);
        ShapeFillEnabledSelected?.Invoke(false);
    }

    private void RectFillButton_Click(object sender, RoutedEventArgs e)
    {
        SetRectangleMode(RectangleAnnotationMode.Fill);
        RectangleModeSelected?.Invoke(RectangleAnnotationMode.Fill);
        ShapeStrokeEnabledSelected?.Invoke(false);
        ShapeFillEnabledSelected?.Invoke(true);
    }
}
