@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-win-x64.ps1"
if errorlevel 1 goto failed
echo.
echo Clipxel.exe build + self-test + digital signature completed.
echo Publisher / signer: danistwen
explorer "%~dp0publish\win-x64"
pause
exit /b 0
:failed
echo.
echo Build/sign failed. Read the error above.
pause
exit /b 1
