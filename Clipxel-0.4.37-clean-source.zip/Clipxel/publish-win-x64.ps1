$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "Clipxel.csproj"
$outDir = Join-Path $PSScriptRoot "publish\win-x64"
$command = Get-Command dotnet -ErrorAction SilentlyContinue
$dotnetExe = if ($command) { $command.Source } else { Join-Path $env:ProgramFiles "dotnet\dotnet.exe" }
if (-not (Test-Path $dotnetExe)) { throw "Install the .NET 10 SDK / Visual Studio .NET Desktop Development workload first." }
$sdks = & $dotnetExe --list-sdks
if (-not ($sdks | Where-Object { $_ -match '^10\.' })) { throw ".NET 10 SDK is required. Installed SDKs: $sdks" }

if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }
& $dotnetExe publish $project -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:DebugType=None -p:DebugSymbols=false -o $outDir
if ($LASTEXITCODE -ne 0) { throw "Build failed. See errors above. No successful build was produced." }
$exe = Join-Path $outDir "Clipxel.exe"
if (-not (Test-Path $exe)) { throw "Clipxel.exe was not produced." }

$report = Join-Path $outDir "self-test-report.txt"
$test = Start-Process -FilePath $exe -ArgumentList @('--self-test', ('"' + $report + '"')) -Wait -PassThru
if ($test.ExitCode -ne 0) { throw "Windows regression tests failed. Read $report" }

& (Join-Path $PSScriptRoot "sign-win-x64.ps1") -ExePath $exe
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Digital signing failed." }

Write-Host "Build, tests and digital signing passed:" -ForegroundColor Green
Write-Host $exe
