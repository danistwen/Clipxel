$ErrorActionPreference = "Stop"
dotnet run --project (Join-Path $PSScriptRoot "Clipxel.csproj") -c Debug
if ($LASTEXITCODE -ne 0) { throw "Clipxel exited with code $LASTEXITCODE" }
