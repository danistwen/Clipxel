$ErrorActionPreference = "Stop"
$subject = "CN=danistwen"
$friendlyName = "danistwen Clipxel Code Signing"
$signingDir = Join-Path $PSScriptRoot "signing"
$publicCert = Join-Path $signingDir "danistwen-code-signing.cer"
$thumbFile = Join-Path $signingDir "thumbprint.txt"

if (-not $IsWindows -and $PSVersionTable.PSEdition -eq 'Core') {
    throw "This signing setup must be run on Windows."
}

New-Item -ItemType Directory -Force -Path $signingDir | Out-Null

$cert = Get-ChildItem Cert:\CurrentUser\My |
    Where-Object { $_.Subject -eq $subject -and $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date).AddDays(30) } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

if (-not $cert) {
    Write-Host "Creating a self-signed code-signing certificate for danistwen..." -ForegroundColor Cyan
    $cert = New-SelfSignedCertificate `
        -Type CodeSigningCert `
        -Subject $subject `
        -FriendlyName $friendlyName `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -HashAlgorithm SHA256 `
        -KeyAlgorithm RSA `
        -KeyLength 3072 `
        -KeyExportPolicy Exportable `
        -NotAfter (Get-Date).AddYears(3)
}

Export-Certificate -Cert $cert -FilePath $publicCert -Force | Out-Null
Set-Content -Path $thumbFile -Value $cert.Thumbprint -Encoding ASCII

# Trust this development certificate for the current Windows user so local verification succeeds.
# This does NOT make other computers trust it; public distribution needs a CA-issued code-signing cert.
Import-Certificate -FilePath $publicCert -CertStoreLocation "Cert:\CurrentUser\Root" | Out-Null
Import-Certificate -FilePath $publicCert -CertStoreLocation "Cert:\CurrentUser\TrustedPublisher" | Out-Null

Write-Host "Self-signing certificate ready." -ForegroundColor Green
Write-Host "Subject: $($cert.Subject)"
Write-Host "Thumbprint: $($cert.Thumbprint)"
Write-Host "Public certificate: $publicCert"
