param(
    [string]$ExePath = (Join-Path $PSScriptRoot "publish\win-x64\Clipxel.exe")
)
$ErrorActionPreference = "Stop"
$subject = "CN=danistwen"
$thumbFile = Join-Path $PSScriptRoot "signing\thumbprint.txt"

if (-not (Test-Path $ExePath)) { throw "EXE not found: $ExePath" }

$cert = $null
if (Test-Path $thumbFile) {
    $thumb = (Get-Content $thumbFile -Raw).Trim()
    if ($thumb) { $cert = Get-Item "Cert:\CurrentUser\My\$thumb" -ErrorAction SilentlyContinue }
}
if (-not $cert) {
    $cert = Get-ChildItem Cert:\CurrentUser\My |
        Where-Object { $_.Subject -eq $subject -and $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date) } |
        Sort-Object NotAfter -Descending |
        Select-Object -First 1
}
if (-not $cert) {
    & (Join-Path $PSScriptRoot "setup-self-signing.ps1")
    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Signing certificate setup failed." }
    $thumb = (Get-Content $thumbFile -Raw).Trim()
    $cert = Get-Item "Cert:\CurrentUser\My\$thumb"
}

# Prefer Windows SDK signtool for RFC3161 SHA-256 timestamping.
$signTool = $null
$kitsRoot = Join-Path ${env:ProgramFiles(x86)} "Windows Kits\10\bin"
if (Test-Path $kitsRoot) {
    $signTool = Get-ChildItem $kitsRoot -Directory -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object { Join-Path $_.FullName "x64\signtool.exe" } |
        Where-Object { Test-Path $_ } |
        Select-Object -First 1
}

if ($signTool) {
    Write-Host "Signing with Windows SDK signtool..." -ForegroundColor Cyan
    & $signTool sign /fd SHA256 /tr "http://timestamp.digicert.com" /td SHA256 /sha1 $cert.Thumbprint $ExePath
    if ($LASTEXITCODE -ne 0) { throw "signtool sign failed with exit code $LASTEXITCODE" }
    & $signTool verify /pa /v $ExePath
    if ($LASTEXITCODE -ne 0) { throw "signtool verify failed with exit code $LASTEXITCODE" }
} else {
    Write-Host "Windows SDK signtool not found; using PowerShell Authenticode signing." -ForegroundColor Yellow
    $sig = Set-AuthenticodeSignature -FilePath $ExePath -Certificate $cert -HashAlgorithm SHA256 -TimestampServer "http://timestamp.digicert.com"
    if ($sig.Status -ne 'Valid') {
        throw "Authenticode signing verification failed: $($sig.Status) $($sig.StatusMessage)"
    }
}

$check = Get-AuthenticodeSignature -FilePath $ExePath
Write-Host "Signed Clipxel.exe" -ForegroundColor Green
Write-Host "Signer: $($check.SignerCertificate.Subject)"
Write-Host "Status: $($check.Status)"
