param([string]$ExePath = (Join-Path $PSScriptRoot "publish\win-x64\Clipxel.exe"))
if (-not (Test-Path $ExePath)) { throw "EXE not found: $ExePath" }
$sig = Get-AuthenticodeSignature -FilePath $ExePath
$sig | Format-List Status,StatusMessage,Path,@{Name='Signer';Expression={$_.SignerCertificate.Subject}},@{Name='Thumbprint';Expression={$_.SignerCertificate.Thumbprint}}
if ($sig.Status -ne 'Valid') { exit 1 }
