# 0.4.39 canvas1 變更清單

開發起點：使用者提供的 0.4.39 包中 Developers/Clipxel-0.4.39-macOS-source.zip。
設計／行為基準：使用者提供的 Windows 0.4.37 精簡包。
不變更套件版本、專案格式或既有 Core／Platform 共用模型。產品版本維持 0.4.39，以 canvas1 區分本輪工作包。

## 新增
- BoardWindow：無系統標題列的圖片畫布、上下列、浮動工具條；參照 Windows 既有層級與位置。
- BoardGlyph：沿用 Windows Rendering/ToolGlyph.cs 原始幾何路徑。
- BoardBrand：沿用 Windows Brand 三種原始 SVG 字標路径及色彩。
- BoardSurface：桌面介面層的圖片視圖狀態，使用原有 CapturedFrame、GroupLayout、HistoryTimeline。
- 圖片選取、Shift 多選、框選、整組拖曳、角落等比例縮放、Alt 非等比例縮放。
- 滾輪以游標為中心縮放；H 平移、中鍵平移、F 符合視窗。
- 排列只更動位置，不重設圖片尺寸。
- 刪除及復原／重做；整次拖曳／縮放為一次歷史操作。
- 三主題與當前主題勾選；使用中工具／置頂藍色及底色，Undo／Redo 無歷史時暗化。
- 主視窗「進入畫布」及釘圖「畫布」入口；返回或關閉畫布時保留圖片。
- 可多張匯入 PNG/JPEG；Tab 隱藏／顯示上下列與工具列，F8 單独切換工具列。
- 浮動工具列可由空白邊距拖曳。

## 本輪未變動
原生截圖服務、權限流程、裁切實作、既有圖片編碼、PNG釘圖儲存、Core與Platform模型，
以及全部 csproj 與 PackageReference，均未修改。
這不表示上述原生功能已在本輪通過 Mac 實測。

## 介面完成界線
沿用原版圖示、字標與主題色；目前面板為半透明色面，尚未接上 Windows 的文件取樣霧玻璃。
既有控制面板與釘圖工具列仍保留 0.4.39 起點樣式；這次沒有宣稱全部視窗視覺對等。
只顯示本輪有實作的畫布工具；沒有放入無作用的繪圖或存檔按鈕。
