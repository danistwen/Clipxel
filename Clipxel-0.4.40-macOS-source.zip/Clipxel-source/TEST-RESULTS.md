# 0.4.40 驗證結果

- .NET 10 Release 編譯成功，零警告／錯誤。
- 20 項 Core 測試通過。
- 91 項 Headless Desktop 測試通過，包含 Windows v1 專案讀寫、未知欄位保留、容量與非法數值檢查、標註選取拖移／復原、填色與線端樣式輸出、全尺寸框選放開即完成／Esc取消，以及既有 canvas2 回歸測試。
- osx-arm64 self-contained 交叉發布成功。
- UI 以 Linux Headless 渲染檢查；該環境無中文字型，預覽中的方框不能當作 Mac 實際中文字型結果。
- macOS 原生 GUI、ScreenCaptureKit、全域快捷鍵、剪貼簿、Spaces、混合DPI多螢幕、實際 Windows→Mac→Windows操作未在此環境驗證。

完整輸出在 validation/release-0.4.40。舊版 validation 子目錄僅為歷史紀錄。
