> 此文件為起點審閱紀錄；目前實作進度以 CHANGES-canvas2.md 與 UNFINISHED.md 為準。

# Windows 0.4.37 與 macOS 移植對照

審閱基準：本次提供的 Clipxel-0.4.37-clean-source.zip。
本次閱讀主要介面、繪圖、專案存讀與平台服務原始碼，未在Windows執行本包。

## 判斷

主要版面可以高度一致，主要編輯功能可移植；系統行為需要Mac實作與實機驗證。
目前Mac控制面板只是驗證入口，並不是最終UI，也不是macOS只能使用這種版面。
不能把能啟動.app視為完整移植成功，也不能把相同圖示視為功能對等。

| Windows項目 | 來源 | Mac對齊方式與界線 |
|---|---|---|
| 無外框畫布、上下列、浮動工具面板 | ReferenceBoardWindow.Chrome.cs / ToolOptions.cs | 以相同尺寸、層級、順序重建Avalonia控件與拖曳邊界 |
| 圖示、品牌配色、按鈕狀態 | Rendering/ToolGlyph.cs / App.xaml / ThemeService.cs | 沿用向量形狀與色票，移植樣式和狀態，不另換一套通用圖示 |
| 文件內容霧玻璃 | Services/MistBackdrop.cs / DocumentSurface.cs | 原版取樣的是文件繪圖，縮小後模糊再映射回面板；可跨平台重建，無需截取桌面 |
| 釘圖/畫布切換、選取、拖曳縮放 | PinWindow.* / ReferenceBoardWindow.* | 共享文件模型，移植互動狀態，不用扁平截圖代替可編輯物件 |
| 畫筆、形狀、線段、文字、吸色 | AnnotationRenderer.cs / Models/Annotation.cs / ColorLens.cs | 移植像素座標與樣式，處理IME、字型替代、DPI及文字排版差異 |
| Pie選單與手勢 | BoardPieWindow.cs / RadialGesture.cs / RadialLayout.cs | 八向布局與功能可保持一致，輸入事件需改用Avalonia指標事件 |
| 群組、自動排列、Undo/Redo | Workspace.cs / GroupOptions.cs / History.cs | 沿用0.4.37保持尺寸、固定錨點與群組排列語意，做等價測試 |
| .clipxel專案 | ReferenceBoardWindow.Project.cs | ZIP包含project.json與images/*.png。可設計雙向相容，需保持欄位、enum語意、標註、群組及版本，實際存讀比對後才能宣稱相容 |
| 螢幕截圖 | ScreenCaptureService.cs | 原版user32/gdi32需替換成ScreenCaptureKit；macOS授權不可由UI移植消除 |
| 全域快捷鍵/自動視窗偵測 | HotkeyHost.cs / WindowSnapService.cs | RegisterHotKey、EnumWindows、DWM等需原生Mac替代；視窗內部子區塊偵測不保證同等 |
| 常駐選單、置頂、系統對話框 | TrayService.cs / window services | 改用Mac選單列與原生視窗服務；Spaces、其他程式全螢幕須實機驗證 |

## 特別重要的實作事實

1. csproj為net10.0-windows，UseWPF及UseWindowsForms均為true。不是改成osx-arm64就能執行全部功能。
2. Annotation模型直接使用System.Windows.Point與Media.Color，文件/互動/呈現尚未完全分離；需要抽離跨平台資料模型。
3. MistBackdrop是文件內容取樣，不是系統桌面模糊。這讓無錄屏權限的Mac仍有條件驗證相同視覺。
4. 原版字型預設Segoe UI；Mac未必有相同字型。字型度量、抗鋸齒與IME是需對照的部分，不宜承諾逐像素相同。
5. .clipxel的群組AutoArrange、間距、樣式與浮動工具位置會序列化。不能只移植圖片匯入便宣稱檔案互通。

## 建議的下一個介面工作順序

- 以這份0.4.37為設計/行為基準，建立畫布框架、原版工具列、圖示與主題。
- 先接圖片匯入、排列、平移/縮放與釘圖切換；可在沒有錄屏權限的借用Mac測試。
- 再移植可編輯標註、群組、Undo/Redo及.clipxel雙向存讀。
- 最後集中驗證有系統依賴的截圖、全域快捷鍵、視窗偵測、常駐選單及Spaces。

本次0.4.39只補上無錄屏權限的圖片測試入口，尚未完成以上完整介面移植。
不估計沒有驗證依據的完成百分比。

參考：
https://docs.avaloniaui.net/docs/migration/wpf
https://developer.apple.com/documentation/screencapturekit/scscreenshotmanager
