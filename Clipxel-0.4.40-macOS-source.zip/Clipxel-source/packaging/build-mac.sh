#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
dotnet build tests/Clipxel.Core.Tests/Clipxel.Core.Tests.csproj -c Release -m:1
dotnet tests/Clipxel.Core.Tests/bin/Release/net10.0/Clipxel.Core.Tests.dll
dotnet build tests/Clipxel.Desktop.Tests/Clipxel.Desktop.Tests.csproj -c Release -m:1
dotnet tests/Clipxel.Desktop.Tests/bin/Release/net10.0/Clipxel.Desktop.Tests.dll
dotnet publish src/Clipxel.Desktop/Clipxel.Desktop.csproj -c Release -r osx-arm64 --self-contained true -p:UseAppHost=true -p:PublishTrimmed=false -p:DebugType=None -m:1 -o publish/osx-arm64
python3 packaging/bundle.py publish/osx-arm64 dist
