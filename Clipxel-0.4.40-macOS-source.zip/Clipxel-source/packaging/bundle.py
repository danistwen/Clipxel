from pathlib import Path
import shutil,plistlib,sys,zipfile
publish=Path(sys.argv[1]).resolve()
output=Path(sys.argv[2]).resolve()
app=output/'Clipxel.app'
if app.exists():raise SystemExit('Output app already exists; choose a fresh directory.')
for name in ['Clipxel.Desktop','Clipxel.Desktop.dll','libhostfxr.dylib','libcoreclr.dylib','libAvaloniaNative.dylib']:
 if not (publish/name).is_file():raise SystemExit('Missing publish file: '+name)
macos=app/'Contents/MacOS'
shutil.copytree(publish,macos)
(macos/'Clipxel.Desktop').chmod(0o755)
resources=app/'Contents/Resources';resources.mkdir()
shutil.copyfile(Path(__file__).parent/'Clipxel.icns',resources/'Clipxel.icns')
info={
'CFBundleExecutable':'Clipxel.Desktop','CFBundleName':'Clipxel',
'CFBundleDisplayName':'Clipxel','CFBundleIdentifier':'com.danistwen.clipxel.diagnostic',
'CFBundleVersion':'0.4.40','CFBundleShortVersionString':'0.4.40',
'CFBundlePackageType':'APPL','CFBundleInfoDictionaryVersion':'6.0',
'CFBundleIconFile':'Clipxel.icns','NSHighResolutionCapable':True,
'LSMinimumSystemVersion':'14.0'}
with (app/'Contents/Info.plist').open('wb') as f:plistlib.dump(info,f)
(app/'Contents/PkgInfo').write_bytes(b'APPL????')
print(app)
