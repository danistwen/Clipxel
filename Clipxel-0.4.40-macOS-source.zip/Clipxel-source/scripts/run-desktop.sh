#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
dotnet run --project src/Clipxel.Desktop/Clipxel.Desktop.csproj
