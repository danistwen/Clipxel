#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
dotnet run --project tests/Clipxel.Core.Tests/Clipxel.Core.Tests.csproj -c Release
