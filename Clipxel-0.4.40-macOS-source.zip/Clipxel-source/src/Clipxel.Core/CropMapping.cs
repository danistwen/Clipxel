namespace Clipxel.Core;

public readonly record struct ImageArea(double X, double Y, double Width, double Height);
public readonly record struct PixelCrop(int X, int Y, int Width, int Height);

public static class CropMapping
{
    public static ImageArea Fit(int pixelWidth, int pixelHeight, double viewWidth, double viewHeight)
    {
        if (pixelWidth <= 0 || pixelHeight <= 0 || !double.IsFinite(viewWidth) ||
            !double.IsFinite(viewHeight) || viewWidth <= 0 || viewHeight <= 0)
            throw new ArgumentOutOfRangeException();
        double scale = Math.Min(viewWidth / pixelWidth, viewHeight / pixelHeight);
        double w = pixelWidth * scale, h = pixelHeight * scale;
        return new((viewWidth - w) / 2, (viewHeight - h) / 2, w, h);
    }
    public static PixelCrop? Select(ImageArea area, int pixelWidth, int pixelHeight,
        double x1, double y1, double x2, double y2)
    {
        if (pixelWidth <= 0 || pixelHeight <= 0 || area.Width <= 0 || area.Height <= 0 ||
            new[] { area.X, area.Y, area.Width, area.Height, x1, y1, x2, y2 }.Any(v => !double.IsFinite(v)))
            throw new ArgumentOutOfRangeException();
        double left = Math.Clamp(Math.Min(x1, x2), area.X, area.X + area.Width);
        double right = Math.Clamp(Math.Max(x1, x2), area.X, area.X + area.Width);
        double top = Math.Clamp(Math.Min(y1, y2), area.Y, area.Y + area.Height);
        double bottom = Math.Clamp(Math.Max(y1, y2), area.Y, area.Y + area.Height);
        if (right - left < 3 || bottom - top < 3) return null;
        int x = Math.Clamp((int)Math.Floor((left - area.X) / area.Width * pixelWidth), 0, pixelWidth - 1);
        int y = Math.Clamp((int)Math.Floor((top - area.Y) / area.Height * pixelHeight), 0, pixelHeight - 1);
        int r = Math.Clamp((int)Math.Ceiling((right - area.X) / area.Width * pixelWidth), x + 1, pixelWidth);
        int b = Math.Clamp((int)Math.Ceiling((bottom - area.Y) / area.Height * pixelHeight), y + 1, pixelHeight);
        return new(x, y, r - x, b - y);
    }
}
