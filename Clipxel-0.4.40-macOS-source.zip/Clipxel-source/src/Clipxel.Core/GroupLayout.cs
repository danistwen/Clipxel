namespace Clipxel.Core;
public readonly record struct LayoutItem(string Id,double Width,double Height);
public readonly record struct Placement(string Id,double X,double Y,double Width,double Height);
public sealed record LayoutResult(Placement[] Items,double X,double Y,double Width,double Height);
public static class GroupLayout
{
    // Source: ReferenceBoardWindow.Workspace.ArrangeItemsInGroup, 0.4.37.
    // Pure layout: no WPF controls, image loading or window access.
    public static LayoutResult Arrange(IReadOnlyList<LayoutItem> items,double x,double y,
        double columnGap=24,double rowGap=24,double titleSize=16)
    {
        if(new[]{x,y,columnGap,rowGap,titleSize}.Any(v=>!double.IsFinite(v)) ||
            columnGap<0 || rowGap<0 || titleSize<=0)throw new ArgumentOutOfRangeException();
        if(items.Any(i=>!double.IsFinite(i.Width)||!double.IsFinite(i.Height)||i.Width<=0||i.Height<=0))
            throw new ArgumentOutOfRangeException(nameof(items));
        if(items.Select(i=>i.Id).Distinct().Count()!=items.Count)throw new ArgumentException("Duplicate IDs.");
        if(items.Count==0)return new LayoutResult([],x,y,100,70);
        int columns=(int)Math.Ceiling(Math.Sqrt(items.Count));
        double top=y+Math.Max(40,titleSize*1.5+16),right=x+16;
        var result=new List<Placement>();
        for(int start=0;start<items.Count;start+=columns)
        {
            double left=x+16,rowHeight=0;
            foreach(var item in items.Skip(start).Take(columns))
            {
                result.Add(new(item.Id,left,top,item.Width,item.Height));
                right=Math.Max(right,left+item.Width);rowHeight=Math.Max(rowHeight,item.Height);
                left+=item.Width+columnGap;
            }
            top+=rowHeight+rowGap;
        }
        return new(result.ToArray(),x,y,Math.Max(100,right-x+16),Math.Max(70,top-rowGap-y+16));
    }
    public static LayoutResult KeepAnchor(LayoutResult layout,string id,double x,double y)
    {
        if(!double.IsFinite(x)||!double.IsFinite(y))throw new ArgumentOutOfRangeException();
        var item=layout.Items.Single(i=>i.Id==id);
        double dx=x-item.X,dy=y-item.Y;
        return layout with {X=layout.X+dx,Y=layout.Y+dy,
            Items=layout.Items.Select(p=>p with {X=p.X+dx,Y=p.Y+dy}).ToArray()};
    }
}
