using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Threading;
using Clipxel.Platform;

namespace Clipxel.Desktop;

// Owns the persistent editing session independently of visible windows.
internal sealed class AppController
{
    private readonly IClassicDesktopStyleApplicationLifetime _desktop;
    private readonly IScreenCaptureService _capture;
    private readonly List<PinWindow> _pins=[];
    private readonly List<CropWindow> _overlays=[];
    private readonly CancellationTokenSource _lifetime=new();
    private readonly BoardWindow _board;
    private readonly TrayIcon _tray;
    private MacHotkeys? _hotkeys;
    private bool _busy,_quitting,_boardMode,_quitPending;
    private readonly Dictionary<int,(PinWindow Window,string Fingerprint)> _pinByItem=[];
    private readonly Dictionary<int,string> _dismissedPins=[];
    internal AppController(IClassicDesktopStyleApplicationLifetime desktop, IScreenCaptureService? capture=null)
    {
        _desktop=desktop;_capture=capture??new MacScreenCaptureService();
        _board=new BoardWindow([]);
        _board.CaptureRequested+=()=>_ = CaptureAsync();
        _board.PinsRequested+=ShowPins;
        _board.Closing+=(_,e)=>{if(!_quitting){e.Cancel=true;ShowPins();}};
        var menu=new NativeMenu();
        void Add(string title,Action action){var item=new NativeMenuItem(title);item.Click+=(_,_)=>action();menu.Items.Add(item);}
        Add("選取範圍並釘圖",()=>_ = CaptureAsync());Add("開啟畫布",ShowBoard);Add("顯示釘圖",()=>ShowPins(true));
        Add("螢幕錄製權限",()=>_ = PermissionFromMenuAsync());menu.Items.Add(new NativeMenuItemSeparator());Add("結束 Clipxel",()=>_ = QuitAsync());
        using var image=Avalonia.Platform.AssetLoader.Open(new Uri("avares://Clipxel.Desktop/Assets/Clipxel.png"));
        _tray=new TrayIcon{Icon=new WindowIcon(image),ToolTipText="Clipxel",Menu=menu,IsVisible=true};
        TrayIcon.SetIcons(Application.Current!,new TrayIcons{_tray});
        if(OperatingSystem.IsMacOS())
        {
            try{_hotkeys=new MacHotkeys(()=>Dispatcher.UIThread.Post(()=>_ = CaptureAsync()),()=>Dispatcher.UIThread.Post(ShowBoard));}
            catch(Exception ex){Dispatcher.UIThread.Post(()=>_ = Dialogs.MessageAsync("快捷鍵無法註冊",ex.Message+"。仍可使用選單列操作。"));}
        }
        if(Application.Current!.TryGetFeature(typeof(IActivatableLifetime)) is IActivatableLifetime activation)
            activation.Activated+=(_,e)=>{if(e.Kind==ActivationKind.Reopen)Dispatcher.UIThread.Post(()=>_ = CaptureAsync());};
        desktop.ShutdownRequested+=(_,e)=>{if(!_quitting){e.Cancel=true;_ = QuitAsync();}};
    }
    internal void Start()=>Dispatcher.UIThread.Post(()=>_ = CaptureAsync());
    private void ShowBoard()
    {
        if(_busy||_quitting||_quitPending)return;
        foreach(var pin in _pins)pin.Hide();_boardMode=true;_board.Show();_board.Activate();
    }
    private void ShowPins()=>SyncPins(false);
    private void ShowPins(bool revealDismissed)=>SyncPins(revealDismissed);
    private void SyncPins(bool revealDismissed)
    {
        if(_busy||_quitting||_quitPending)return;
        _board.Hide();_boardMode=false;
        if(revealDismissed)_dismissedPins.Clear();
        var items=_board.Surface.Items.ToArray();
        var frames=_board.Surface.RenderedFrames();
        var live=items.Select(i=>i.Id).ToHashSet();
        foreach(var id in _pinByItem.Keys.Where(id=>!live.Contains(id)).ToArray())
        {
            var old=_pinByItem[id].Window;_pinByItem.Remove(id);old.Close();
        }
        foreach(var id in _dismissedPins.Keys.Where(id=>!live.Contains(id)).ToArray())_dismissedPins.Remove(id);
        for(int i=0;i<items.Length;i++)
        {
            int id=items[i].Id;var frame=frames[i];
            string hash=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(frame.Png));
            if(_dismissedPins.TryGetValue(id,out var dismissed)&&dismissed==hash)continue;
            _dismissedPins.Remove(id);
            if(_pinByItem.TryGetValue(id,out var existing)&&existing.Fingerprint==hash)
            {existing.Window.Show();continue;}
            PixelPoint? position=null;double? width=null,height=null,opacity=null;bool topmost=true;
            if(existing.Window is not null)
            {
                position=existing.Window.Position;width=existing.Window.Width;height=existing.Window.Height;
                opacity=existing.Window.Opacity;topmost=existing.Window.Topmost;
                _pinByItem.Remove(id);existing.Window.Close();
            }
            var pin=new PinWindow(frame,_=>{},ShowBoard);_pins.Add(pin);_pinByItem[id]=(pin,hash);
            if(position is PixelPoint point){pin.Position=point;pin.Width=width!.Value;pin.Height=height!.Value;pin.Opacity=opacity!.Value;pin.Topmost=topmost;}
            pin.Closed+=(_,_)=>
            {
                _pins.Remove(pin);
                if(_pinByItem.TryGetValue(id,out var current)&&ReferenceEquals(current.Window,pin))
                {_pinByItem.Remove(id);_dismissedPins[id]=hash;}
            };
            pin.Show();
        }
    }
    internal async Task CaptureAsync()
    {
        if(_busy||_quitting||_quitPending)return;_busy=true;
        var visible=_pins.Where(p=>p.IsVisible).ToArray();bool restoreBoard=_board.IsVisible;bool captured=false;
        try
        {
            if(!_capture.HasPermission()){await PermissionAsync();return;}
            foreach(var p in visible)p.Hide();_board.Hide();
            await Task.Delay(250,_lifetime.Token);
            var displays=await _capture.GetDisplaysAsync(_lifetime.Token);
            if(displays.Count==0)throw new InvalidOperationException("找不到可擷取的螢幕。");
            var frames=new List<CapturedFrame>();
            foreach(var display in displays)frames.Add(await _capture.CaptureDisplayAsync(display,_lifetime.Token));
            var completion=new TaskCompletionSource<CapturedFrame?>(TaskCreationOptions.RunContinuationsAsynchronously);
            // Capture every monitor before displaying any overlay, avoiding recursive captures.
            for(int i=0;i<frames.Count;i++)
            {
                var overlay=new CropWindow(frames[i],true,displays[i].Id);_overlays.Add(overlay);
                overlay.Closed+=(_,_)=>completion.TrySetResult(overlay.Result);
                overlay.Show();
            }
            var result=await completion.Task;
            foreach(var overlay in _overlays.ToArray())overlay.Close();_overlays.Clear();
            if(result is not null){captured=true;_board.Surface.AddFrames(new[]{result});restoreBoard=false;_boardMode=false;}
        }
        catch(OperationCanceledException){}
        catch(Exception ex){await Dialogs.MessageAsync("無法擷取螢幕",ex.Message);}
        finally
        {
            foreach(var overlay in _overlays.ToArray())overlay.Close();_overlays.Clear();_busy=false;
            if(!_quitting)
            {
                if(restoreBoard)ShowBoard();
                else if(!_boardMode)
                {
                    if(captured)ShowPins();
                    else foreach(var pin in visible)if(_pins.Contains(pin))pin.Show();
                }
            }
        }
    }
    private async Task PermissionFromMenuAsync()
    {
        if(_busy||_quitting||_quitPending)return;
        _busy=true;
        try{await PermissionAsync();}
        finally{_busy=false;}
    }
    private async Task PermissionAsync()
    {
        bool request=await Dialogs.ConfirmAsync("允許 Clipxel 擷取螢幕","截圖需要 macOS 的螢幕錄製權限。你仍可開啟畫布匯入圖片、編輯及儲存。","設定權限","開啟畫布");
        if(request)
        {
            try{_capture.RequestPermission();_capture.OpenPermissionSettings();}
            catch(Exception ex){await Dialogs.MessageAsync("螢幕錄製權限",ex.Message);}
        }
        // Keep an actionable canvas available after the permission sheet closes.
        if(!_quitting){_boardMode=true;_board.Show();_board.Activate();}
    }
    private async Task QuitAsync()
    {
        if(_quitting||_quitPending)return;
        _quitPending=true;
        try
        {
            if(!await _board.ConfirmDiscardAsync())return;
            _quitting=true;_lifetime.Cancel();foreach(var o in _overlays.ToArray())o.Close();
        foreach(var pin in _pins.ToArray())pin.Close();_board.Close();_hotkeys?.Dispose();_tray.Dispose();_desktop.Shutdown();
        }
        finally{_quitPending=false;}
    }
}

internal static class Dialogs
{
    internal static Task<bool> ConfirmAsync(string title,string message,string accept="確定",string cancel="取消")
    {
        var done=new TaskCompletionSource<bool>();
        var window=new Window{Title=title,Width=460,SizeToContent=SizeToContent.Height,CanResize=false,WindowStartupLocation=WindowStartupLocation.CenterScreen};
        var buttons=new StackPanel{Orientation=Avalonia.Layout.Orientation.Horizontal,Spacing=12};
        buttons.Children.Add(Ui.Button(accept,()=>{done.TrySetResult(true);window.Close();},true));
        buttons.Children.Add(Ui.Button(cancel,()=>window.Close()));
        window.Content=new StackPanel{Margin=new Thickness(24),Spacing=20,Children={Ui.Text(message,14),buttons}};
        window.Closed+=(_,_)=>done.TrySetResult(false);window.Show();return done.Task;
    }
    internal static async Task MessageAsync(string title,string message)=>await ConfirmAsync(title,message,"關閉","關閉");
}
