using Clipxel.Core;
using Clipxel.Platform;
using Avalonia;
using Avalonia.Media;
using System.Globalization;
using System.Text.Json.Nodes;
using SkiaSharp;
namespace Clipxel.Desktop;
internal enum BoardTool { Select, Pen, Rectangle, Ellipse, Line, Arrow, Text }
internal sealed record BoardPoint(double X,double Y);
internal sealed record BoardAnnotation(int Id,BoardTool Tool,BoardPoint[] Points,string Color,double Width,string Text,double FontSize)
{
    public int? CardId {get;init;}
    public JsonObject? ProjectData {get;init;}
}
internal sealed record BoardGroup(int Id,string Name,int[] Members,bool AutoArrange,double Gap)
{
    public JsonObject? ProjectData {get;init;}
}
internal sealed partial class BoardSurface
{
    private readonly List<BoardAnnotation> _annotations=[];
    private JsonObject _drawingStyle=new();
    private readonly List<BoardGroup> _groups=[];
    private int _nextAnnotationId,_nextGroupId;
    private int? _selectedAnnotation;
    private BoardAnnotation? _draft,_annotationDrag;
    private BoardAnnotation[] _linkedBefore=[];
    private void TransformLinked(Item original,Item current)
    {
        foreach(var a in _linkedBefore.Where(a=>a.CardId==original.Id))
        {
            int n=_annotations.FindIndex(x=>x.Id==a.Id);if(n<0)continue;
            double sx=current.Width/original.Width,sy=current.Height/original.Height;
            _annotations[n]=a with {Points=a.Points.Select(p=>new BoardPoint(current.X+(p.X-original.X)*sx,current.Y+(p.Y-original.Y)*sy)).ToArray(),Width=a.Width*sx,FontSize=a.FontSize*sx};
        }
    }
    internal BoardTool Tool {get;set;}
    internal BoardTool ActiveTool {get=>Tool;set=>Tool=value;}
    internal string StrokeColor {get;set;}="#005DFF";
    internal double StrokeWidth {get;set;}=3;
    internal string TextValue {get;set;}="文字";
    internal double FontSize {get;set;}=24;
    internal IReadOnlyList<BoardAnnotation> Annotations=>_annotations;
    internal IReadOnlyList<BoardGroup> Groups=>_groups;

    internal CapturedFrame[] RenderedFrames()=>_items.Select(item=>
    {
        var annotations=_annotations.Where(a=>a.CardId==item.Id||a.CardId is null&&AnnotationBounds(a).Intersects(new Rect(item.X,item.Y,item.Width,item.Height))).ToArray();
        if(annotations.Length==0)return item.Frame;
        using var bitmap=SKBitmap.Decode(item.Frame.Png);
        using(var canvas=new SKCanvas(bitmap))
        {
            canvas.Scale((float)(bitmap.Width/item.Width),(float)(bitmap.Height/item.Height));
            canvas.Translate((float)-item.X,(float)-item.Y);
            foreach(var a in annotations)DrawAnnotationSkia(canvas,a);
        }
        using var image=SKImage.FromBitmap(bitmap);using var png=image.Encode(SKEncodedImageFormat.Png,100);
        return item.Frame with {Png=png.ToArray()};
    }).ToArray();
    internal void RestoreEditing(BoardAnnotation[] annotations,BoardGroup[] groups)
    {
        _annotations.Clear();_annotations.AddRange(annotations);_groups.Clear();_groups.AddRange(groups);
        _nextAnnotationId=annotations.Length==0?0:annotations.Max(a=>a.Id)+1;
        _nextGroupId=groups.Length==0?0:groups.Max(g=>g.Id)+1;
        _history.Reset(State());Notify();
    }
    internal void AddAnnotation(BoardAnnotation annotation)
    {
        EndGesture(false);
        if(annotation.Points.Length==0||annotation.Points.Any(p=>!double.IsFinite(p.X)||!double.IsFinite(p.Y))||!double.IsFinite(annotation.Width)||annotation.Width<=0||!double.IsFinite(annotation.FontSize)||annotation.FontSize<=0)throw new ArgumentException("無效標註");
        _=Color.Parse(annotation.Color);
        var item=annotation with {Id=_nextAnnotationId++};_annotations.Add(item);_selectedAnnotation=item.Id;_selected.Clear();Commit();
    }
    internal void SelectAnnotation(int id){EndGesture(false);_selectedAnnotation=_annotations.Any(a=>a.Id==id)?id:null;_selected.Clear();Notify();}
    internal void UpdateSelectedStyle(bool? fill=null,bool? stroke=null,double? opacity=null,string? font=null,double? fontSize=null,int? lineStyle=null)
    {
        int n=_annotations.FindIndex(a=>a.Id==_selectedAnnotation);
        JsonObject Apply(JsonObject source)
        {
            var data=source.DeepClone().AsObject();
            if(fill is bool f)data["Fill"]=f;if(stroke is bool st)data["Stroke"]=st;
            if(opacity is double o){data["StrokeOpacity"]=Math.Clamp(o,0,1);data["FillOpacity"]=Math.Clamp(o,0,1);}
            if(font is not null)data["FontFamily"]=font;if(lineStyle is int style)data["Style"]=Math.Clamp(style,0,3);
            return data;
        }
        _drawingStyle=Apply(_drawingStyle);
        if(fontSize is double fs)FontSize=Math.Clamp(fs,6,300);
        if(n<0)return;
        var a=_annotations[n];_annotations[n]=a with{ProjectData=Apply(a.ProjectData??new JsonObject()),FontSize=fontSize is not null?FontSize:a.FontSize};Commit();
    }

    internal void UpdateSelectedAnnotation(string? text=null,string? color=null,double? width=null)
    {
        int index=_annotations.FindIndex(a=>a.Id==_selectedAnnotation);if(index<0)return;
        var a=_annotations[index];_annotations[index]=a with {Text=text??a.Text,Color=color??a.Color,Width=width is double w?Math.Clamp(w,.2,100):a.Width};Commit();
    }
    internal void GroupSelected(string name="群組")
    {
        EndGesture(false);if(_selected.Count==0)return;
        _groups.RemoveAll(g=>g.Members.Any(_selected.Contains));
        _groups.Add(new BoardGroup(_nextGroupId++,name,_selected.ToArray(),true,24));Commit();
    }
    internal void UngroupSelected(){EndGesture(false);_groups.RemoveAll(g=>g.Members.Any(_selected.Contains));Commit();}
    private void ReflowGroup(int anchorId)
    {
        foreach(var group in _groups.Where(g=>g.AutoArrange&&g.Members.Contains(anchorId)))
        {
            var members=group.Members.Select(id=>_items.FirstOrDefault(i=>i.Id==id)).Where(i=>i is not null).Cast<Item>().ToArray();
            if(members.Length<2)continue;var anchor=members.First(i=>i.Id==anchorId);var b=GroupBounds(group);
            var layout=GroupLayout.KeepAnchor(GroupLayout.Arrange(members.Select(i=>new LayoutItem(i.Id.ToString(),i.Width,i.Height)).ToArray(),b.X,b.Y,group.Gap,group.Gap),anchorId.ToString(),anchor.X,anchor.Y);
            _linkedBefore=_annotations.Where(a=>a.CardId is not null).ToArray();
            foreach(var placement in layout.Items){int n=_items.FindIndex(i=>i.Id.ToString()==placement.Id);var old=_items[n];_items[n]=old with {X=placement.X,Y=placement.Y};TransformLinked(old,_items[n]);}
        }
    }
    internal void RenameSelectedGroup(string name)
    {
        int n=_groups.FindIndex(g=>g.Members.Any(_selected.Contains));if(n<0)return;_groups[n]=_groups[n] with{Name=name};Commit();
    }
    private bool BeginAnnotation(Point point)
    {
        if(Tool!=BoardTool.Select)
        {
            _selected.Clear();_selectedAnnotation=null;
            _draft=new BoardAnnotation(_nextAnnotationId++,Tool,[new(point.X,point.Y),new(point.X,point.Y)],StrokeColor,Math.Clamp(StrokeWidth,.2,100),TextValue,Math.Clamp(FontSize,6,300)){ProjectData=_drawingStyle.DeepClone().AsObject()};
            return true;
        }
        var hit=_annotations.LastOrDefault(a=>AnnotationBounds(a).Inflate(5/Zoom).Contains(point));
        _selectedAnnotation=hit?.Id;
        if(hit is null)return false;
        _selected.Clear();_annotationDrag=hit;return true;
    }
    private bool MoveAnnotation(Point point)
    {
        if(_draft is not null)
        {
            if(_draft.Tool==BoardTool.Pen)_draft=_draft with{Points=_draft.Points.Append(new BoardPoint(point.X,point.Y)).ToArray()};
            else if(_draft.Tool!=BoardTool.Text)_draft=_draft with{Points=[_draft.Points[0],new(point.X,point.Y)]};
            return true;
        }
        if(_annotationDrag is not null)
        {
            var d=point-_start;int n=_annotations.FindIndex(a=>a.Id==_annotationDrag.Id);
            if(n>=0)_annotations[n]=_annotationDrag with{Points=_annotationDrag.Points.Select(p=>new BoardPoint(p.X+d.X,p.Y+d.Y)).ToArray()};return true;
        }
        return false;
    }
    private bool FinishAnnotation(bool cancel)
    {
        bool changed=_draft is not null||_annotationDrag is not null;
        if(_draft is not null&&!cancel)
        {
            if(_draft.Tool==BoardTool.Text||_draft.Points.Length>2||Math.Abs(_draft.Points[1].X-_draft.Points[0].X)+Math.Abs(_draft.Points[1].Y-_draft.Points[0].Y)>1)
            {_annotations.Add(_draft);_selectedAnnotation=_draft.Id;}
        }
        if(cancel&&_annotationDrag is not null){int n=_annotations.FindIndex(a=>a.Id==_annotationDrag.Id);if(n>=0)_annotations[n]=_annotationDrag;}
        _draft=null;_annotationDrag=null;return changed;
    }
    private static Rect AnnotationBounds(BoardAnnotation a)
    {
        if(a.Points.Length==0)return new Rect(0,0,1,1);
        if(a.Tool==BoardTool.Text)return new Rect(a.Points[0].X,a.Points[0].Y,Math.Max(a.FontSize,a.Text.Length*a.FontSize),a.FontSize*1.5);
        return new Rect(new Point(a.Points.Min(p=>p.X),a.Points.Min(p=>p.Y)),new Point(a.Points.Max(p=>p.X),a.Points.Max(p=>p.Y))).Inflate(Math.Max(a.Width,1));
    }
    private Rect GroupBounds(BoardGroup g)
    {
        var items=_items.Where(i=>g.Members.Contains(i.Id)).ToArray();
        if(items.Length==0)return new Rect(Meta(g.ProjectData,"X",0),Meta(g.ProjectData,"Y",0),Math.Max(1,Meta(g.ProjectData,"Width",1)),Math.Max(1,Meta(g.ProjectData,"Height",1)));
        return new Rect(new Point(items.Min(i=>i.X)-16,items.Min(i=>i.Y)-40),new Point(items.Max(i=>i.X+i.Width)+16,items.Max(i=>i.Y+i.Height)+16));
    }
    private void DrawGroups(DrawingContext c)
    {
        foreach(var g in _groups)
        {
            var b=GroupBounds(g);var opacity=Math.Clamp(Meta(g.ProjectData,"Opacity",.15),0,1);
            var fill=new SolidColorBrush(Color.Parse(Str(g.ProjectData,"Fill","#FF005DFF")),opacity);
            var pen=new Pen(Brush.Parse(Str(g.ProjectData,"Border","#66005DFF")),1/Zoom,Flag(g.ProjectData,"Dashed",false)?DashStyle.Dash:null);
            c.DrawRectangle(fill,pen,b,8,8);
            c.DrawText(new FormattedText(g.Name,CultureInfo.CurrentCulture,FlowDirection.LeftToRight,Typeface.Default,Meta(g.ProjectData,"TitleSize",16),Brush.Parse(Str(g.ProjectData,"TitleColor","#FF20263F"))),new Point(b.X+12,b.Y+8));
        }
    }
    private void DrawGroupsSkia(SKCanvas c)
    {
        foreach(var g in _groups)
        {
            var b=GroupBounds(g);var color=SKColor.Parse(Str(g.ProjectData,"Fill","#FF005DFF"));
            using var p=new SKPaint{Color=color.WithAlpha((byte)(color.Alpha*Math.Clamp(Meta(g.ProjectData,"Opacity",.15),0,1))),IsAntialias=true};
            var r=new SKRect((float)b.Left,(float)b.Top,(float)b.Right,(float)b.Bottom);c.DrawRoundRect(r,8,8,p);
            p.Color=SKColor.Parse(Str(g.ProjectData,"Border","#66005DFF"));p.Style=SKPaintStyle.Stroke;p.StrokeWidth=1;
            using var dash=Flag(g.ProjectData,"Dashed",false)?SKPathEffect.CreateDash([4,2],0):null;p.PathEffect=dash;c.DrawRoundRect(r,8,8,p);
            using var face=SKFontManager.Default.MatchCharacter(g.Name.FirstOrDefault());
            using var text=new SKPaint{Color=SKColor.Parse(Str(g.ProjectData,"TitleColor","#FF20263F")),TextSize=(float)Meta(g.ProjectData,"TitleSize",16),Typeface=face,IsAntialias=true};c.DrawText(g.Name,(float)b.X+12,(float)b.Y+8-text.FontMetrics.Ascent,text);
        }
    }
    private static string Str(JsonObject? data,string name,string fallback)=>data?[name] is JsonValue value&&value.TryGetValue<string>(out var text)&&!string.IsNullOrWhiteSpace(text)?text:fallback;
    private static double Meta(JsonObject? data,string name,double fallback)=>data?[name] is JsonValue value&&double.TryParse(value.ToJsonString(),NumberStyles.Float,CultureInfo.InvariantCulture,out var number)&&double.IsFinite(number)?number:fallback;
    private static bool Flag(JsonObject? data,string name,bool fallback)=>data?[name] is JsonValue value&&value.TryGetValue<bool>(out var flag)?flag:fallback;
    private static Point P(BoardPoint p)=>new(p.X,p.Y);
    private void DrawAnnotation(DrawingContext c,BoardAnnotation a)
    {
        if(a.Points.Length==0)return;
        var brush=new SolidColorBrush(Color.Parse(a.Color),Math.Clamp(Meta(a.ProjectData,"StrokeOpacity",1),0,1));var pen=Flag(a.ProjectData,"Stroke",true)?new Pen(brush,a.Width,Meta(a.ProjectData,"Style",1)==2?DashStyle.Dash:null,PenLineCap.Round):null;
        IBrush? fill=Flag(a.ProjectData,"Fill",false)?new SolidColorBrush(Color.Parse(a.Color),Math.Clamp(Meta(a.ProjectData,"FillOpacity",.45),0,1)):null;var first=P(a.Points[0]);var last=P(a.Points[^1]);var box=new Rect(first,last).Normalize();
        switch(a.Tool)
        {
            case BoardTool.Text:c.DrawText(new FormattedText(a.Text,CultureInfo.CurrentCulture,FlowDirection.LeftToRight,new Typeface(Str(a.ProjectData,"FontFamily",FontFamily.Default.Name)),a.FontSize,brush),first);break;
            case BoardTool.Rectangle:c.DrawRectangle(fill,pen,box);break;
            case BoardTool.Ellipse:c.DrawEllipse(fill,pen,box);break;
            default:if(pen is null)break;for(int i=1;i<a.Points.Length;i++)c.DrawLine(pen,P(a.Points[i-1]),P(a.Points[i]));if(a.Tool==BoardTool.Arrow&&Meta(a.ProjectData,"Style",0)==0)
                {var ends=ArrowEnds(first,last,a.Width).ToArray();var geometry=new StreamGeometry();using(var path=geometry.Open()){path.BeginFigure(last,true);path.LineTo(ends[0]);path.LineTo(ends[1]);path.EndFigure(true);}c.DrawGeometry(brush,null,geometry);}
                if((a.Tool==BoardTool.Arrow||a.Tool==BoardTool.Line)&&Meta(a.ProjectData,"Style",1)==3){double radius=Math.Max(3,a.Width*1.6);c.DrawEllipse(brush,null,first,radius,radius);c.DrawEllipse(brush,null,last,radius,radius);}break;
        }
        if(a.Id==_selectedAnnotation)c.DrawRectangle(null,new Pen(Brush.Parse("#88005DFF"),1/Zoom),AnnotationBounds(a));
    }
    private static IEnumerable<Point> ArrowEnds(Point first,Point last,double width)
    {
        double dx=first.X-last.X,dy=first.Y-last.Y,length=Math.Sqrt(dx*dx+dy*dy);if(length<.01){yield return last;yield return last;yield break;}
        dx/=length;dy/=length;double head=Math.Min(length,Math.Max(8,width*4.5));
        yield return new Point(last.X+dx*head-dy*head*.43,last.Y+dy*head+dx*head*.43);
        yield return new Point(last.X+dx*head+dy*head*.43,last.Y+dy*head-dx*head*.43);
    }
    private static void DrawAnnotationSkia(SKCanvas c,BoardAnnotation a)
    {
        if(a.Points.Length==0)return;var first=P(a.Points[0]);var last=P(a.Points[^1]);var b=new Rect(first,last).Normalize();
        using var p=new SKPaint{Color=SKColor.Parse(a.Color),StrokeWidth=(float)a.Width,Style=SKPaintStyle.Stroke,IsAntialias=true,StrokeCap=SKStrokeCap.Round};
        var r=new SKRect((float)b.Left,(float)b.Top,(float)b.Right,(float)b.Bottom);
        using var dash=Meta(a.ProjectData,"Style",1)==2?SKPathEffect.CreateDash([(float)a.Width*2,(float)a.Width*2],0):null;p.PathEffect=dash;
        var baseColor=p.Color;
        if((a.Tool==BoardTool.Rectangle||a.Tool==BoardTool.Ellipse)&&Flag(a.ProjectData,"Fill",false))
        {
            p.Style=SKPaintStyle.Fill;p.Color=baseColor.WithAlpha((byte)(baseColor.Alpha*Math.Clamp(Meta(a.ProjectData,"FillOpacity",.45),0,1)));
            if(a.Tool==BoardTool.Rectangle)c.DrawRect(r,p);else c.DrawOval(r,p);p.Style=SKPaintStyle.Stroke;
        }
        if(!Flag(a.ProjectData,"Stroke",true)&&a.Tool!=BoardTool.Text)return;
        p.Color=baseColor.WithAlpha((byte)(baseColor.Alpha*Math.Clamp(Meta(a.ProjectData,"StrokeOpacity",1),0,1)));
        switch(a.Tool)
        {
            case BoardTool.Text:p.Style=SKPaintStyle.Fill;p.TextSize=(float)a.FontSize;using(var face=SKFontManager.Default.MatchFamily(Str(a.ProjectData,"FontFamily",FontFamily.Default.Name))??SKFontManager.Default.MatchCharacter(a.Text.FirstOrDefault())){p.Typeface=face;c.DrawText(a.Text,(float)first.X,(float)first.Y-p.FontMetrics.Ascent,p);}break;
            case BoardTool.Rectangle:c.DrawRect(r,p);break;
            case BoardTool.Ellipse:c.DrawOval(r,p);break;
            default:for(int i=1;i<a.Points.Length;i++)c.DrawLine((float)a.Points[i-1].X,(float)a.Points[i-1].Y,(float)a.Points[i].X,(float)a.Points[i].Y,p);if(a.Tool==BoardTool.Arrow&&Meta(a.ProjectData,"Style",0)==0){using var path=new SKPath();path.MoveTo((float)last.X,(float)last.Y);foreach(var end in ArrowEnds(first,last,a.Width))path.LineTo((float)end.X,(float)end.Y);path.Close();p.Style=SKPaintStyle.Fill;c.DrawPath(path,p);}
                if((a.Tool==BoardTool.Arrow||a.Tool==BoardTool.Line)&&Meta(a.ProjectData,"Style",1)==3){p.Style=SKPaintStyle.Fill;float radius=(float)Math.Max(3,a.Width*1.6);c.DrawCircle((float)first.X,(float)first.Y,radius,p);c.DrawCircle((float)last.X,(float)last.Y,radius,p);}break;
        }
    }
}
