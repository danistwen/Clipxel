using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Clipxel.Core;
using Clipxel.Platform;
using System.Text.Json;
namespace Clipxel.Desktop;

// View-local editing state; existing shared Core and Platform models remain unchanged.
internal sealed partial class BoardSurface : Control, IDisposable
{
    internal sealed record Item(int Id,CapturedFrame Frame,double X,double Y,double Width,double Height);
    private sealed record Snapshot(Item[] Items, BoardAnnotation[] Annotations, BoardGroup[] Groups);
    // Session-only copy storage, matching object copy/paste within this application.
    private static Item[] _copied=[];
    private static BoardAnnotation[] _copiedAnnotations=[];
    private int _pasteOffset;
    private static string _copyToken="";
    private readonly List<Item> _items=new();
    private readonly Dictionary<int,Bitmap> _images=new();
    private readonly HashSet<int> _selected=new();
    private readonly HistoryTimeline<Snapshot> _history=new(s=>JsonSerializer.Serialize(new {Items=s.Items.Select(i=>new {i.Id,i.X,i.Y,i.Width,i.Height}),s.Annotations,s.Groups}));
    private int _nextId;
    private Point _start,_originPan;
    private Dictionary<int,Item>? _drag;
    private Item? _resize;
    private int _corner;
    private Rect? _marquee;
    private IPointer? _pointer;
    private bool _panning,_disposed;
    internal double Zoom {get;private set;}=1;
    internal Vector Pan {get;private set;}=new(32,32);
    internal bool PanTool {get;set;}
    internal IReadOnlyList<Item> Items=>_items;
    internal IReadOnlyCollection<int> Selected=>_selected;
    internal bool CanUndo=>_history.CanUndo;
    internal bool CanRedo=>_history.CanRedo;
    internal event Action? Changed;
    public BoardSurface()
    {
        Focusable=true;ClipToBounds=true;
        _history.Reset(new Snapshot([],[],[]));
    }
    internal void AddFrames(IEnumerable<CapturedFrame> frames)
    {
        EndGesture(false);
        // Decode a whole batch before mutating history; invalid input cannot leave half an import.
        var staged=new List<(Item Item,Bitmap Bitmap)>();
        try
        {
            foreach(var f in frames)
            {
                var bitmap=new Bitmap(new MemoryStream(f.Png));
                if(f.PixelWidth<=0||f.PixelHeight<=0){bitmap.Dispose();throw new InvalidDataException("無效圖片尺寸");}
                double x=_items.Count==0&&staged.Count==0?0:_items.Concat(staged.Select(s=>s.Item)).Max(i=>i.X+i.Width)+24;
                staged.Add((new Item(_nextId++,f,x,0,f.PixelWidth,f.PixelHeight),bitmap));
            }
        }
        catch {foreach(var s in staged)s.Bitmap.Dispose();throw;}
        foreach(var s in staged){_items.Add(s.Item);_images.Add(s.Item.Id,s.Bitmap);}
        Commit();
    }
    internal string CopySelected()
    {
        EndGesture(false);
        _copied=_items.Where(i=>_selected.Contains(i.Id)).ToArray();_copiedAnnotations=_annotations.Where(a=>a.CardId is int id&&_selected.Contains(id)).ToArray();_pasteOffset=0;return _copyToken="Clipxel:objects:"+Guid.NewGuid().ToString("N");
    }
    internal bool PasteObjects(string? token)
    {
        if(_copied.Length==0||token!=_copyToken)return false;
        EndGesture(false);
        var added=new List<(Item Item,Bitmap Bitmap)>();
        try
        {
            double offset=24*(++_pasteOffset);
            foreach(var item in _copied)
                added.Add((item with {Id=_nextId++,X=item.X+offset,Y=item.Y+offset},
                    new Bitmap(new MemoryStream(item.Frame.Png))));
        }
        catch {foreach(var item in added)item.Bitmap.Dispose();throw;}
        _selected.Clear();
        foreach(var (item,bitmap) in added){_items.Add(item);_images.Add(item.Id,bitmap);_selected.Add(item.Id);}
        for(int k=0;k<added.Count;k++)foreach(var a in _copiedAnnotations.Where(a=>a.CardId==_copied[k].Id))
        {
            var old=_copied[k];var current=added[k].Item;
            _annotations.Add(a with {Id=_nextAnnotationId++,CardId=current.Id,Points=a.Points.Select(p=>new BoardPoint(p.X+current.X-old.X,p.Y+current.Y-old.Y)).ToArray()});
        }
        Commit();return true;
    }
    internal void RestoreSession(Item[] items,double zoom,Vector pan)
    {
        EndGesture(false);
        // Decode first, so a failed restore cannot destroy the existing canvas.
        var decoded=new Dictionary<int,Bitmap>();
        try{foreach(var item in items)decoded.Add(item.Id,new Bitmap(new MemoryStream(item.Frame.Png)));}
        catch {foreach(var bitmap in decoded.Values)bitmap.Dispose();throw;}
        foreach(var bitmap in _images.Values)bitmap.Dispose();_images.Clear();
        foreach(var pair in decoded)_images.Add(pair.Key,pair.Value);
        _items.Clear();_items.AddRange(items);_selected.Clear();_annotations.Clear();_groups.Clear();_selectedAnnotation=null;
        _nextId=items.Length==0?0:items.Max(i=>i.Id)+1;
        Zoom=zoom;Pan=pan;_history.Reset(State());Notify();
    }
    internal byte[] ExportImage(bool jpeg)
    {
        if(_items.Count==0&&_annotations.Count==0)throw new InvalidOperationException("畫布沒有圖片。");
        var extent=DocumentBounds();
        var bounds=new Rect(extent.X,extent.Y,extent.Width+4,extent.Height+4);
        double scale=Math.Min(1,Math.Min(8192/Math.Max(bounds.Width,bounds.Height),Math.Sqrt(32_000_000/(bounds.Width*bounds.Height))));
        int width=Math.Max(1,(int)Math.Ceiling(bounds.Width*scale)),height=Math.Max(1,(int)Math.Ceiling(bounds.Height*scale));
        using var bitmap=new SkiaSharp.SKBitmap(width,height,SkiaSharp.SKColorType.Bgra8888,SkiaSharp.SKAlphaType.Premul);
        using(var canvas=new SkiaSharp.SKCanvas(bitmap))
        {
            canvas.Clear(jpeg?SkiaSharp.SKColors.White:SkiaSharp.SKColors.Transparent);
            canvas.Scale((float)scale);
            canvas.Translate((float)(2-bounds.X),(float)(2-bounds.Y));
            DrawGroupsSkia(canvas);
            using var paint=new SkiaSharp.SKPaint{IsAntialias=true,FilterQuality=SkiaSharp.SKFilterQuality.High};
            foreach(var item in _items)
            {
                using var source=SkiaSharp.SKBitmap.Decode(item.Frame.Png);
                canvas.DrawBitmap(source,new SkiaSharp.SKRect((float)(item.X),(float)(item.Y),
                    (float)(item.X+item.Width),(float)(item.Y+item.Height)),paint);
            }
            foreach(var annotation in _annotations)DrawAnnotationSkia(canvas,annotation);
        }
        using var image=SkiaSharp.SKImage.FromBitmap(bitmap);
        using var data=image.Encode(jpeg?SkiaSharp.SKEncodedImageFormat.Jpeg:SkiaSharp.SKEncodedImageFormat.Png,95);
        return data.ToArray();
    }
    internal CapturedFrame[] Frames()=>_items.Select(i=>i.Frame).ToArray();
    internal void SelectAll(){_selected.UnionWith(_items.Select(i=>i.Id));Notify();}
    internal void DeleteSelected()
    {
        EndGesture(false);
        _annotations.RemoveAll(a=>a.CardId is int id&&_selected.Contains(id));
        _items.RemoveAll(i=>_selected.Contains(i.Id));
        if(_selectedAnnotation is int annotationId)_annotations.RemoveAll(a=>a.Id==annotationId);
        _selectedAnnotation=null;_groups.RemoveAll(g=>!g.Members.Any(id=>_items.Any(i=>i.Id==id)));_selected.Clear();Commit();
    }
    internal void Arrange()
    {
        EndGesture(false);
        var targets=_items.Where(i=>_selected.Count==0||_selected.Contains(i.Id)).ToArray();
        if(targets.Length==0)return;
        var result=GroupLayout.Arrange(targets.Select(i=>new LayoutItem(i.Id.ToString(),i.Width,i.Height)).ToArray(),
            targets.Min(i=>i.X)-16,targets.Min(i=>i.Y)-40);
        var byId=result.Items.ToDictionary(i=>int.Parse(i.Id));
        _linkedBefore=_annotations.Where(a=>a.CardId is not null).ToArray();
        for(int n=0;n<_items.Count;n++)if(byId.TryGetValue(_items[n].Id,out var p)){var old=_items[n];_items[n]=old with {X=p.X,Y=p.Y};TransformLinked(old,_items[n]);}
        Commit();
    }
    internal void History(bool redo)
    {
        EndGesture(false);
        if(_history.TryMove(redo,out var s)){_items.Clear();_items.AddRange(s.Items);_selected.IntersectWith(_items.Select(i=>i.Id));_annotations.Clear();_annotations.AddRange(s.Annotations);_groups.Clear();_groups.AddRange(s.Groups);_selectedAnnotation=null;}
        Notify();
    }
    internal void Fit()
    {
        if(_items.Count==0&&_annotations.Count==0)return;
        var b=DocumentBounds();double w=Math.Max(100,Bounds.Width-80),h=Math.Max(100,Bounds.Height-80);
        Zoom=Math.Clamp(Math.Min(w/b.Width,h/b.Height),.05,8);
        Pan=new Vector((Bounds.Width-b.Width*Zoom)/2-b.X*Zoom,(Bounds.Height-b.Height*Zoom)/2-b.Y*Zoom);Notify();
    }
    internal Rect DocumentBounds()
    {
        var rectangles=_items.Select(i=>new Rect(i.X,i.Y,i.Width,i.Height)).Concat(_annotations.Select(AnnotationBounds)).Concat(_groups.Select(GroupBounds)).ToArray();
        if(rectangles.Length==0)return new Rect(0,0,1,1);
        return rectangles.Aggregate((a,b)=>a.Union(b));
    }
    internal Point World(Point screen)=>new((screen.X-Pan.X)/Zoom,(screen.Y-Pan.Y)/Zoom);
    internal void ZoomAt(Point screen,double factor)
    {
        var world=World(screen);Zoom=Math.Clamp(Zoom*factor,.05,8);
        Pan=new Vector(screen.X-world.X*Zoom,screen.Y-world.Y*Zoom);Notify();
    }
    private static Point[] Corners(Item i)=>[new(i.X,i.Y),new(i.X+i.Width,i.Y),new(i.X+i.Width,i.Y+i.Height),new(i.X,i.Y+i.Height)];
    private int HitCorner(Point p,out Item? found)
    {
        foreach(var i in _items.Where(i=>_selected.Contains(i.Id)).Reverse())
        {
            var points=Corners(i);for(int n=0;n<4;n++)if(Math.Sqrt(Math.Pow(p.X-points[n].X,2)+Math.Pow(p.Y-points[n].Y,2))<=10/Zoom){found=i;return n;}
        }
        found=null;return -1;
    }
    internal static Item Resize(Item initial,int corner,Point point,bool free)
    {
        var anchor=Corners(initial)[(corner+2)%4];
        double w=Math.Max(8,Math.Abs(point.X-anchor.X)),h=Math.Max(8,Math.Abs(point.Y-anchor.Y));
        if(!free)
        {
            double scale=Math.Min(Math.Max(w/initial.Width,h/initial.Height),
                Math.Min(16000/initial.Width,16000/initial.Height));
            w=initial.Width*scale;h=initial.Height*scale;
        }
        w=Math.Min(16000,w);h=Math.Min(16000,h);
        return initial with {X=point.X<anchor.X?anchor.X-w:anchor.X,Y=point.Y<anchor.Y?anchor.Y-h:anchor.Y,Width=w,Height=h};
    }
    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);var props=e.GetCurrentPoint(this).Properties;
        if(props.IsRightButtonPressed){EndGesture(true);PanTool=false;Notify();e.Handled=true;return;}
        if(!props.IsLeftButtonPressed&&!props.IsMiddleButtonPressed)return;
        _linkedBefore=_annotations.Where(a=>a.CardId is not null).ToArray();
        Focus();_pointer=e.Pointer;_pointer.Capture(this);_start=World(e.GetPosition(this));
        _originPan=new Point(Pan.X,Pan.Y);
        if(!PanTool&&!props.IsMiddleButtonPressed&&BeginAnnotation(_start)){Notify();e.Handled=true;return;}
        if(PanTool||props.IsMiddleButtonPressed){_panning=true;_start=e.GetPosition(this);}
        else
        {
            _corner=HitCorner(_start,out _resize);
            if(_resize is null)
            {
                var hit=_items.LastOrDefault(i=>new Rect(i.X,i.Y,i.Width,i.Height).Contains(_start));
                if(hit is null)
                {
                    if(!e.KeyModifiers.HasFlag(KeyModifiers.Shift))_selected.Clear();
                    _marquee=new Rect(_start,_start);
                }
                else
                {
                    if(e.KeyModifiers.HasFlag(KeyModifiers.Shift))
                    {if(!_selected.Add(hit.Id))_selected.Remove(hit.Id);}
                    else if(!_selected.Contains(hit.Id)){_selected.Clear();_selected.Add(hit.Id);foreach(var group in _groups.Where(g=>g.Members.Contains(hit.Id)))_selected.UnionWith(group.Members);}
                    _drag=_items.Where(i=>_selected.Contains(i.Id)).ToDictionary(i=>i.Id);
                }
            }
        }
        Notify();e.Handled=true;
    }
    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);var screen=e.GetPosition(this);var point=World(screen);
        if(MoveAnnotation(point)){Notify();return;}
        if(_panning){var d=screen-_start;Pan=new Vector(_originPan.X+d.X,_originPan.Y+d.Y);}
        else if(_resize is not null)
        {
            var n=_items.FindIndex(i=>i.Id==_resize.Id);
            _items[n]=Resize(_resize,_corner,point,e.KeyModifiers.HasFlag(KeyModifiers.Alt));
            TransformLinked(_resize,_items[n]);
        }
        else if(_drag is not null)
        {
            var d=point-_start;for(int n=0;n<_items.Count;n++)if(_drag.TryGetValue(_items[n].Id,out var i)){_items[n]=i with {X=i.X+d.X,Y=i.Y+d.Y};TransformLinked(i,_items[n]);}
        }
        else if(_marquee is not null)_marquee=new Rect(_start,point).Normalize();
        else
        {
            int corner=HitCorner(point,out _);
            Cursor=new Cursor(corner<0?(PanTool?StandardCursorType.Hand:StandardCursorType.Arrow):
                corner%2==0?StandardCursorType.TopLeftCorner:StandardCursorType.TopRightCorner);
        }
        Notify();
    }
    protected override void OnPointerReleased(PointerReleasedEventArgs e)
    {
        base.OnPointerReleased(e);
        if(e.InitialPressMouseButton!=MouseButton.Left&&e.InitialPressMouseButton!=MouseButton.Middle)return;
        if(_marquee is Rect box)
            _selected.UnionWith(_items.Where(i=>box.Intersects(new Rect(i.X,i.Y,i.Width,i.Height))).Select(i=>i.Id));
        EndGesture(false);e.Handled=true;
    }
    protected override void OnPointerCaptureLost(PointerCaptureLostEventArgs e){base.OnPointerCaptureLost(e);EndGesture(false);}
    internal void EndGesture(bool cancel)
    {
        bool annotationChanged=FinishAnnotation(cancel);
        if(cancel)
        {
            if(_resize is not null){int n=_items.FindIndex(i=>i.Id==_resize.Id);if(n>=0)_items[n]=_resize;}
            if(_drag is not null)for(int n=0;n<_items.Count;n++)if(_drag.TryGetValue(_items[n].Id,out var i))_items[n]=i;
            if(_panning)Pan=new Vector(_originPan.X,_originPan.Y);
            foreach(var a in _linkedBefore){int n=_annotations.FindIndex(x=>x.Id==a.Id);if(n>=0)_annotations[n]=a;}
        }
        if(!cancel&&_resize is not null)ReflowGroup(_resize.Id);
        bool changed=annotationChanged||_resize is not null||_drag is not null;
        _resize=null;_drag=null;_marquee=null;_panning=false;
        var p=_pointer;_pointer=null;p?.Capture(null);
        if(changed&&!cancel)Commit();else Notify();
    }
    protected override void OnPointerWheelChanged(PointerWheelEventArgs e)
    {
        base.OnPointerWheelChanged(e);ZoomAt(e.GetPosition(this),Math.Pow(1.12,e.Delta.Y));e.Handled=true;
    }
    private Snapshot State()=>new(_items.ToArray(),_annotations.ToArray(),_groups.ToArray());
    private void Commit(){_history.Observe(State());Notify();}
    private void Notify(){InvalidateVisual();Changed?.Invoke();}
    public override void Render(DrawingContext c)
    {
        base.Render(c);c.FillRectangle(Brushes.Transparent,new Rect(Bounds.Size));
        using(c.PushTransform(new Matrix(Zoom,0,0,Zoom,Pan.X,Pan.Y)))
        {
            DrawGroups(c);
            foreach(var i in _items)
            {
                var b=new Rect(i.X,i.Y,i.Width,i.Height);
                c.DrawImage(_images[i.Id],new Rect(0,0,_images[i.Id].PixelSize.Width,_images[i.Id].PixelSize.Height),b);
                if(_selected.Contains(i.Id))
                {
                    c.DrawRectangle(null,new Pen(Brush.Parse("#005DFF"),1.5/Zoom),b);
                    foreach(var p in Corners(i))c.DrawRectangle(Brushes.White,new Pen(Brush.Parse("#005DFF"),1/Zoom),
                        new Rect(p.X-4/Zoom,p.Y-4/Zoom,8/Zoom,8/Zoom));
                }
            }
            foreach(var annotation in _annotations)DrawAnnotation(c,annotation);
            if(_draft is not null)DrawAnnotation(c,_draft);
            if(_marquee is Rect box)c.DrawRectangle(Brush.Parse("#22005DFF"),new Pen(Brush.Parse("#005DFF"),1/Zoom),box);
        }
    }
    public void Dispose()
    {
        if(_disposed)return;_disposed=true;EndGesture(true);
        foreach(var b in _images.Values)b.Dispose();_images.Clear();
    }
}
