using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
namespace Clipxel.Desktop;
public sealed partial class BoardWindow
{
    private void BuildEditingTools(StackPanel bar)
    {
        // Reflow keeps the floating palette usable on narrow windows.
        var palette=new WrapPanel{Orientation=Orientation.Horizontal,MaxWidth=620};
        foreach(var child in bar.Children.ToArray()){bar.Children.Remove(child);palette.Children.Add(child);}
        foreach(var (tool,glyph,label) in new[]{(BoardTool.Pen,"Pen","畫筆"),(BoardTool.Rectangle,"Rect","矩形"),(BoardTool.Ellipse,"Ellipse","橢圓"),(BoardTool.Line,"Plain","線段"),(BoardTool.Arrow,"Arrow","箭頭"),(BoardTool.Text,"Text","文字")})
            palette.Children.Add(Tool(glyph,label,null,()=>{Surface.PanTool=false;Surface.ActiveTool=tool;Refresh();}));
        palette.Children.Add(Tool("Group","建立分類群組",null,()=>Surface.GroupSelected()));
        palette.Children.Add(Tool("Disconnect","解除群組",null,Surface.UngroupSelected));
        var options=new StackPanel{Orientation=Orientation.Horizontal,Spacing=6,Margin=new Thickness(0,6,0,0)};
        var color=new TextBox{Text=Surface.StrokeColor,Width=100,Watermark="#RRGGBB"};
        ToolTip.SetTip(color,"線條／文字顏色");
        color.LostFocus+=(_,_)=>{if(Color.TryParse(color.Text,out _)){Surface.StrokeColor=color.Text!;Surface.UpdateSelectedAnnotation(color:color.Text);}else color.Text=Surface.StrokeColor;};
        var width=new NumericUpDown{Minimum=1,Maximum=100,Value=3,Width=90,FormatString="0"};
        ToolTip.SetTip(width,"線條寬度");width.ValueChanged+=(_,_)=>{Surface.StrokeWidth=(double)(width.Value??3);Surface.UpdateSelectedAnnotation(width:Surface.StrokeWidth);};
        var text=new TextBox{Text="文字",Watermark="文字內容",Width=180};
        text.TextChanged+=(_,_)=>Surface.TextValue=text.Text??"";
        options.Children.Add(color);options.Children.Add(width);options.Children.Add(text);
        options.Children.Add(Ui.Button("套用文字",()=>Surface.UpdateSelectedAnnotation(text:Surface.TextValue)));
        options.Children.Add(Ui.Button("命名群組",()=>Surface.RenameSelectedGroup(Surface.TextValue)));
        var styles=new WrapPanel{Orientation=Orientation.Horizontal};
        var fill=new CheckBox{Content="填色"};fill.IsCheckedChanged+=(_,_)=>Surface.UpdateSelectedStyle(fill:fill.IsChecked==true);
        var stroke=new CheckBox{Content="描邊",IsChecked=true};stroke.IsCheckedChanged+=(_,_)=>Surface.UpdateSelectedStyle(stroke:stroke.IsChecked==true);
        var opacity=new NumericUpDown{Minimum=0,Maximum=1,Increment=.1m,Value=1,Width=80};opacity.ValueChanged+=(_,_)=>Surface.UpdateSelectedStyle(opacity:(double)(opacity.Value??1));ToolTip.SetTip(opacity,"標註透明度");
        var size=new NumericUpDown{Minimum=6,Maximum=300,Value=24,Width=80};size.ValueChanged+=(_,_)=>{Surface.FontSize=(double)(size.Value??24);Surface.UpdateSelectedStyle(fontSize:Surface.FontSize);};ToolTip.SetTip(size,"文字大小");
        var font=new TextBox{Text="Arial",Width=110};font.LostFocus+=(_,_)=>Surface.UpdateSelectedStyle(font:font.Text??"Arial");ToolTip.SetTip(font,"字型名稱");
        var line=new ComboBox{ItemsSource=new[]{"箭頭","實線","虛線","圓端點"},SelectedIndex=1,Width=100};line.SelectionChanged+=(_,_)=>Surface.UpdateSelectedStyle(lineStyle:line.SelectedIndex);
        styles.Children.Add(fill);styles.Children.Add(stroke);styles.Children.Add(opacity);styles.Children.Add(size);styles.Children.Add(font);styles.Children.Add(line);
        _tools.Child=new StackPanel{Children={palette,options,styles}};
    }
    private async void DropFiles(object? sender,DragEventArgs e)
    {
        if(_busy||_closed)return;
        try
        {
#pragma warning disable CS0618
            var files=e.Data.GetFiles()?.ToArray();
#pragma warning restore CS0618
            if(files is null)return;
            var project=files.FirstOrDefault(f=>Path.GetExtension(f.Name).Equals(".clipxel",StringComparison.OrdinalIgnoreCase));
            if(project is not null){await OpenProjectAsync(project.TryGetLocalPath());return;}
            var frames=new List<Clipxel.Platform.CapturedFrame>();
            foreach(var file in files.OfType<IStorageFile>())
            {
                await using var stream=await file.OpenReadAsync();using var memory=new MemoryStream();
                byte[] buffer=new byte[81920];int n;
                while((n=await stream.ReadAsync(buffer))>0){if(memory.Length+n>64_000_000)throw new InvalidDataException("圖片超過 64 MB。");memory.Write(buffer,0,n);}
                frames.Add(ImageInputs.FromEncoded(memory.ToArray()));
            }
            Surface.AddFrames(frames);Surface.Fit();e.Handled=true;
        }
        catch(Exception ex){_status.Text="匯入失敗："+ex.Message;}
    }
}
