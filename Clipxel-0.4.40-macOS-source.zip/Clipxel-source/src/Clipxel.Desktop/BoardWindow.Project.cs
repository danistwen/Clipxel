using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using System.Text.Json;
namespace Clipxel.Desktop;
public sealed partial class BoardWindow
{
    private ProjectStore.Document? _project;
    private string? _projectPath;
    private string _savedState="";
    private string DocumentState()=>JsonSerializer.Serialize(new {Items=Surface.Items.Select(i=>new{i.Id,i.X,i.Y,i.Width,i.Height,Image=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(i.Frame.Png))}),Surface.Annotations,Surface.Groups,Background=Background?.ToString(),Topmost,_chrome,ToolsVisible=_tools.IsVisible});
    internal async Task<bool> ConfirmDiscardAsync()
    {
        if(_busy)return false;
        if((_savedState==""&&Surface.Items.Count==0&&Surface.Annotations.Count==0)||_savedState==DocumentState())return true;
        if(await Dialogs.ConfirmAsync("儲存變更","畫布有尚未儲存的變更。要先儲存專案嗎？","儲存","其他選擇"))return await SaveProjectAsync();
        return await Dialogs.ConfirmAsync("尚未儲存的變更","離開後將失去尚未儲存的編輯。","捨棄變更","繼續編輯");
    }
    private async Task<bool> SaveProjectAsync()
    {
        if(_busy||_closed)return false;_busy=true;Surface.IsEnabled=false;
        try
        {
            var file=await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions{Title="儲存 Clipxel 專案",SuggestedFileName=Path.GetFileName(_projectPath??"Reference.clipxel"),DefaultExtension="clipxel",FileTypeChoices=new[]{new FilePickerFileType("Clipxel 專案"){Patterns=new[]{"*.clipxel"}}}});
            if(file is null)return false;
            using(file)
            {
                var path=file.TryGetLocalPath()??throw new InvalidOperationException("請選擇本機檔案。");
                if(!path.EndsWith(".clipxel",StringComparison.OrdinalIgnoreCase))path+=".clipxel";
                Surface.EndGesture(false);
                var items=Surface.Items.ToArray();var annotations=Surface.Annotations.ToArray();var groups=Surface.Groups.ToArray();
                var zoom=Surface.Zoom;var pan=Surface.Pan;var state=DocumentState();
                var previous=_project??new ProjectStore.Document([],[],[],zoom,pan,new System.Text.Json.Nodes.JsonObject(),new Dictionary<int,System.Text.Json.Nodes.JsonObject>());
                var root=(System.Text.Json.Nodes.JsonObject)previous.Root.DeepClone();
                root["Background"]=Background is SolidColorBrush b?b.Color.ToString():"#FF27292E";
                root["Topmost"]=Topmost;root["ChromeVisible"]=_chrome;root["DrawingVisible"]=_tools.IsVisible;
                var snapshot=previous with{Root=root};
                await Task.Run(()=>ProjectStore.Save(path,items,zoom,pan,annotations,groups,snapshot));
                _projectPath=path;_savedState=state;_status.Text="專案已儲存："+Path.GetFileName(path);return true;
            }
        }
        catch(Exception ex){_status.Text="儲存失敗："+ex.Message;return false;}
        finally{_busy=false;Surface.IsEnabled=true;}
    }
    internal async Task OpenProjectAsync(string? path=null)
    {
        if(_busy||_closed||!await ConfirmDiscardAsync())return;_busy=true;Surface.IsEnabled=false;
        try
        {
            if(path is null)
            {
                var files=await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions{Title="開啟 Clipxel 專案",AllowMultiple=false,FileTypeFilter=new[]{new FilePickerFileType("Clipxel 專案"){Patterns=new[]{"*.clipxel","*.pinshot"}}}});
                if(files.Count==0)return;using var file=files[0];path=file.TryGetLocalPath()??throw new InvalidOperationException("請選擇本機檔案。");
            }
            var document=await Task.Run(()=>ProjectStore.Load(path));
            if(_closed)return;
            Surface.RestoreSession(document.Items,document.Zoom,document.Pan);Surface.RestoreEditing(document.Annotations,document.Groups);
            _project=document;_projectPath=path;
            if(document.Root["Topmost"] is not null)Topmost=document.Root["Topmost"]!.GetValue<bool>();
            if(document.Root["ChromeVisible"] is not null&&_chrome!=document.Root["ChromeVisible"]!.GetValue<bool>())ToggleChrome();
            if(document.Root["DrawingVisible"] is not null)_tools.IsVisible=_chrome&&document.Root["DrawingVisible"]!.GetValue<bool>();
            if(document.Root["Background"]?.GetValue<string>() is string color&&Color.TryParse(color,out var parsed))Background=new SolidColorBrush(parsed);
            _savedState=DocumentState();
            _status.Text="專案已開啟："+Path.GetFileName(path);
        }
        catch(Exception ex){_status.Text="開啟失敗："+ex.Message;}
        finally{_busy=false;Surface.IsEnabled=true;}
    }
}
