using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Clipxel.Platform;
namespace Clipxel.Desktop;

public sealed partial class BoardWindow : Window
{
    internal readonly BoardSurface Surface=new();
    private readonly Border _top=new(),_bottom=new(),_tools=new();
    private readonly TextBlock _status=new(){FontSize=11,VerticalAlignment=VerticalAlignment.Center};
    private readonly List<(Button Button,BoardGlyph Glyph,string Name)> _buttons=new();
    private readonly Button _undo,_redo,_pan,_select,_pin;
    private readonly Grid _root=new();
    private readonly Border _helpCard=new(){Name="CanvasHelpCard",IsVisible=false};
    private readonly Button _helpToggle=new(){Name="CanvasHelpToggle"};
    private Button? _drawingToggle;
    private readonly BoardBrand _brand=new(){VerticalAlignment=VerticalAlignment.Center};
    private Button? _restore;
    private Point? _toolDrag;
    private Thickness _toolStart;
    private string _theme="Dark";
    private bool _closed,_busy,_chrome=true;
    public bool ReturnToPins {get;private set;}
    internal event Action? CaptureRequested;
    internal event Action? PinsRequested;
    internal CapturedFrame[] Frames=>Surface.Frames();
    internal sealed record Session(BoardSurface.Item[] Items,double Zoom,Vector Pan,string Theme);
    internal Session SaveSession()=>new(Surface.Items.ToArray(),Surface.Zoom,Surface.Pan,_theme);
    internal void RestoreSession(Session session)
    {
        Surface.RestoreSession(session.Items,session.Zoom,session.Pan);ApplyTheme(session.Theme);
        _restored=true;
    }
    internal static Session ReconcileSession(Session previous,IReadOnlyList<CapturedFrame> frames)
    {
        var remaining=previous.Items.ToList();var items=new List<BoardSurface.Item>();
        int next=remaining.Count==0?0:remaining.Max(i=>i.Id)+1;
        double edge=remaining.Count==0?0:remaining.Max(i=>i.X+i.Width)+24;
        foreach(var frame in frames)
        {
            int n=remaining.FindIndex(i=>ReferenceEquals(i.Frame,frame));
            if(n>=0){items.Add(remaining[n]);remaining.RemoveAt(n);}
            else
            {
                items.Add(new BoardSurface.Item(next++,frame,edge,0,frame.PixelWidth,frame.PixelHeight));
                edge+=frame.PixelWidth+24;
            }
        }
        return previous with {Items=items.ToArray()};
    }
    private bool _restored;
    public BoardWindow(IEnumerable<CapturedFrame> frames)
    {
        Title="Clipxel — 畫布";Width=1100;Height=760;MinWidth=640;MinHeight=420;
        SystemDecorations=SystemDecorations.None;
        WindowStartupLocation=WindowStartupLocation.CenterScreen;
        _root.Children.Add(Surface);
        var top=new DockPanel{LastChildFill=true};
        var left=new StackPanel{Orientation=Orientation.Horizontal,Spacing=4,Margin=new Thickness(6)};
        left.Children.Add(Tool("OpenProject","開啟專案","⌘O",()=>_ = OpenProjectAsync()));
        left.Children.Add(Tool("SaveProject","儲存專案","⌘S",()=>_ = SaveProjectAsync()));
        left.Children.Add(Tool("Capture","選取範圍截圖","⌘N",()=>CaptureRequested?.Invoke()));
        left.Children.Add(Tool("Import","匯入圖片","⌘I",()=>_ = ImportAsync()));
        left.Children.Add(Tool("Paste","貼上","⌘V",()=>_ = PasteAsync()));
        left.Children.Add(Tool("BoardSettings","主題設定",null,ShowThemes));
        DockPanel.SetDock(left,Dock.Left);top.Children.Add(left);
        var right=new StackPanel{Orientation=Orientation.Horizontal,Spacing=4,Margin=new Thickness(6)};
        right.Children.Add(Tool("ToggleChrome","隱藏／顯示視窗","Tab",ToggleChrome));
        _pin=Tool("Topmost","視窗置頂",null,()=>{Topmost=!Topmost;Refresh();});right.Children.Add(_pin);
        right.Children.Add(Tool("Minimize","最小化",null,()=>WindowState=WindowState.Minimized));
        right.Children.Add(Tool("Close","關閉畫布",null,Close));
        DockPanel.SetDock(right,Dock.Right);top.Children.Add(right);
        var caption=new Border{Background=Brushes.Transparent,Child=_brand};
        caption.PointerPressed+=(_,e)=>
        {
            if(!e.GetCurrentPoint(caption).Properties.IsLeftButtonPressed)return;
            if(e.ClickCount==2)WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;
            else BeginMoveDrag(e);
        };
        top.Children.Add(caption);
        _top.Child=top;_top.VerticalAlignment=VerticalAlignment.Top;_root.Children.Add(_top);
        var bottom=new DockPanel();
        var back=Tool("Return","返回釘圖模式",null,()=>{ReturnToPins=true;if(PinsRequested is null)Close();else PinsRequested.Invoke();});
        DockPanel.SetDock(back,Dock.Right);bottom.Children.Add(back);
        _status.Margin=new Thickness(14,6);bottom.Children.Add(_status);
        _bottom.Child=bottom;_bottom.VerticalAlignment=VerticalAlignment.Bottom;_root.Children.Add(_bottom);
        var bar=new StackPanel{Orientation=Orientation.Horizontal,Spacing=4};
        _select=Tool("Select","選取","V",()=>{Surface.EndGesture(false);Surface.PanTool=false;Surface.ActiveTool=BoardTool.Select;Refresh();});
        _pan=Tool("Pan","平移","H",()=>{Surface.EndGesture(false);Surface.PanTool=true;Refresh();});
        bar.Children.Add(_select);bar.Children.Add(_pan);
        bar.Children.Add(Tool("Arrange","排列",null,Surface.Arrange));
        bar.Children.Add(Tool("Fit","符合畫布","F",Surface.Fit));
        _undo=Tool("Undo","復原","⌘Z",()=>Surface.History(false));
        _redo=Tool("Redo","重做","⌘⇧Z",()=>Surface.History(true));
        bar.Children.Add(_undo);bar.Children.Add(_redo);
        bar.Children.Add(Tool("Delete","刪除","Delete",Surface.DeleteSelected));
        bar.Children.Add(Tool("Export","匯出畫布",null,()=>_ = ExportAsync()));
        _tools.Child=bar;_tools.Padding=new Thickness(12,8);_tools.CornerRadius=new CornerRadius(14);
        _tools.HorizontalAlignment=HorizontalAlignment.Left;_tools.VerticalAlignment=VerticalAlignment.Bottom;
        _tools.Margin=new Thickness(24,0,0,60);_root.Children.Add(_tools);
        _tools.PointerPressed+=(_,e)=>
        {
            // Only empty padding starts panel movement; button clicks keep their meaning.
            if(e.Source!=_tools||!e.GetCurrentPoint(_tools).Properties.IsLeftButtonPressed)return;
            _toolDrag=e.GetPosition(_root);_toolStart=_tools.Margin;e.Pointer.Capture(_tools);e.Handled=true;
        };
        _tools.PointerMoved+=(_,e)=>
        {
            if(_toolDrag is not Point start)return;
            var d=e.GetPosition(_root)-start;
            _tools.Margin=new Thickness(Math.Clamp(_toolStart.Left+d.X,0,Math.Max(0,Bounds.Width-_tools.Bounds.Width)),0,0,
                Math.Clamp(_toolStart.Bottom-d.Y,40,Math.Max(40,Bounds.Height-_tools.Bounds.Height-52)));
        };
        _tools.PointerReleased+=(_,e)=>{_toolDrag=null;e.Pointer.Capture(null);};
        _tools.PointerCaptureLost+=(_,_)=>_toolDrag=null;
        _restore=Tool("ToggleChrome","隱藏／顯示視窗","Tab",ToggleChrome);
        _restore.HorizontalAlignment=HorizontalAlignment.Right;_restore.VerticalAlignment=VerticalAlignment.Top;
        _restore.Margin=new Thickness(0,6,6,0);_restore.IsVisible=false;_root.Children.Add(_restore);
        BuildHelp();
        BuildEditingTools(bar);
        Content=_root;
        DragDrop.SetAllowDrop(this,true);
        AddHandler(DragDrop.DropEvent,DropFiles);
        Surface.Changed+=Refresh;
        Surface.AddFrames(frames);
        Opened+=(_,_)=>{if(!_restored)Surface.Fit();};
        Closed+=(_,_)=>{_closed=true;Surface.Dispose();};
        AddHandler(KeyDownEvent,Keys,Avalonia.Interactivity.RoutingStrategies.Tunnel);
        ApplyTheme(Preferences.Theme);
    }
    private Button Tool(string name,string label,string? shortcut,Action action)
    {
        var glyph=new BoardGlyph(name);
        var b=new Button{Content=glyph,Width=34,Height=34,Padding=new Thickness(7),CornerRadius=new CornerRadius(7),
            Background=Brushes.Transparent,BorderThickness=new Thickness(0)};
        ToolTip.SetTip(b,shortcut is null?label:$"{label} ({shortcut})");
        b.Click+=(_,_)=>{Surface.EndGesture(false);action();};
        b.PointerEntered+=(_,_)=>{glyph.RenderTransform=new ScaleTransform(1.08,1.08);};
        b.PointerExited+=(_,_)=>glyph.RenderTransform=null;
        _buttons.Add((b,glyph,name));return b;
    }
    private void Keys(object? sender,KeyEventArgs e)
    {
        bool cmd=(e.KeyModifiers&(KeyModifiers.Meta|KeyModifiers.Control))!=0;
        if(e.Source is TextBox)return;
        if(cmd&&e.Key==Key.O){_ = OpenProjectAsync();}
        else if(cmd&&e.Key==Key.S){_ = SaveProjectAsync();}
        else if(cmd&&e.Key==Key.I){_ = ImportAsync();}
        else if(cmd&&e.Key==Key.N){CaptureRequested?.Invoke();}
        else if(cmd&&e.Key==Key.C){_ = CopyAsync();}
        else if(cmd&&e.Key==Key.V){_ = PasteAsync();}
        else if(cmd&&e.Key==Key.A)Surface.SelectAll();
        else if(cmd&&e.Key==Key.Z)Surface.History(e.KeyModifiers.HasFlag(KeyModifiers.Shift));
        else if(e.Key==Key.Delete||e.Key==Key.Back)Surface.DeleteSelected();
        else if(e.Key==Key.Tab)ToggleChrome();
        else if(e.Key==Key.F8)_tools.IsVisible=!_tools.IsVisible;
        else if(e.Key==Key.Escape){Surface.EndGesture(true);Surface.PanTool=false;Surface.ActiveTool=BoardTool.Select;Refresh();}
        else if(e.Key==Key.V){Surface.EndGesture(false);Surface.PanTool=false;Surface.ActiveTool=BoardTool.Select;Refresh();}
        else if(e.Key==Key.H){Surface.EndGesture(false);Surface.PanTool=true;Refresh();}
        else if(e.Key==Key.F)Surface.Fit();
        else return;
        e.Handled=true;
    }
    private void ToggleChrome()
    {
        _chrome=!_chrome;_top.IsVisible=_bottom.IsVisible=_tools.IsVisible=_chrome;
        if(_restore is not null)_restore.IsVisible=!_chrome;
        _helpToggle.IsVisible=_chrome;_helpCard.IsVisible=false;
        if(_drawingToggle is not null)_drawingToggle.IsVisible=_chrome;
    }
    private void BuildHelp()
    {
        _drawingToggle=Tool("ToggleDrawing","顯示／隱藏繪圖工具","F8",()=>_tools.IsVisible=!_tools.IsVisible);
        _drawingToggle.HorizontalAlignment=HorizontalAlignment.Right;_drawingToggle.VerticalAlignment=VerticalAlignment.Bottom;
        _drawingToggle.Margin=new Thickness(0,0,8,48);_root.Children.Add(_drawingToggle);
        _helpToggle.Width=_helpToggle.Height=14.4;_helpToggle.FontSize=8.4;_helpToggle.FontWeight=FontWeight.Bold;
        _helpToggle.Padding=new Thickness(0);_helpToggle.Content="!";_helpToggle.CornerRadius=new CornerRadius(7.2);
        _helpToggle.BorderThickness=new Thickness(1);_helpToggle.HorizontalAlignment=HorizontalAlignment.Left;
        _helpToggle.VerticalAlignment=VerticalAlignment.Bottom;_helpToggle.Margin=new Thickness(12,0,0,57.8);
        ToolTip.SetTip(_helpToggle,"顯示／隱藏操作說明");
        var text=new StackPanel{Spacing=8};
        foreach(var line in new[]{"畫布操作說明","瀏覽與選取","V 選取 · Shift 點選多選 · 空白處拖曳框選","H／中鍵拖曳平移 · 滾輪縮放 · F 顯示全部",
            "圖片操作","拖曳四角等比例縮放 · Alt 自由變形","⌘C／⌘V 複製／貼上 · Delete 刪除","⌘Z 復原 · ⌘⇧Z 重做","介面","Tab 隱藏／顯示視窗 · F8 工具列","⌘O 開啟專案 · ⌘S 儲存專案 · ⌘I 匯入"})
            text.Children.Add(new TextBlock{Text=line,FontSize=12,TextWrapping=TextWrapping.Wrap});
        var helpScroll=new ScrollViewer{Content=text,MaxHeight=400};
        _helpCard.Child=helpScroll;
        _root.SizeChanged+=(_,_)=>helpScroll.MaxHeight=Math.Max(80,_root.Bounds.Height-128);_helpCard.Padding=new Thickness(14);_helpCard.Width=350;_helpCard.CornerRadius=new CornerRadius(16);
        _helpCard.HorizontalAlignment=HorizontalAlignment.Left;_helpCard.VerticalAlignment=VerticalAlignment.Bottom;
        _helpCard.Margin=new Thickness(12,0,0,86);
        _helpToggle.Click+=(_,_)=>_helpCard.IsVisible=!_helpCard.IsVisible;
        _root.Children.Add(_helpCard);_root.Children.Add(_helpToggle);
        AddHandler(PointerPressedEvent,(_,e)=>
        {
            if(_helpCard.IsVisible&&!new Rect(_helpCard.Bounds.Size).Contains(e.GetPosition(_helpCard))&&
                !new Rect(_helpToggle.Bounds.Size).Contains(e.GetPosition(_helpToggle)))_helpCard.IsVisible=false;
        },Avalonia.Interactivity.RoutingStrategies.Tunnel);
        Deactivated+=(_,_)=>_helpCard.IsVisible=false;
    }
    private void ShowThemes()
    {
        var menu=new ContextMenu();
        foreach(var (key,label) in new[]{("Dark","深灰主題"),("Light","淺灰主題"),("White","白亮主題")})
        {
            var item=new MenuItem{Header=(_theme==key?"✓  ":"    ")+label};
            item.Click+=(_,_)=>ApplyTheme(key);menu.Items.Add(item);
        }
        menu.Open(_top);
    }
    internal void ApplyTheme(string key)
    {
        _theme=key;Preferences.SaveTheme(key);_brand.ThemeKey=key;_brand.InvalidateVisual();
        // Literal colors from Windows 0.4.37 ThemeService. No changes to shared models.
        Background=Brush.Parse(key=="Dark"?"#27292E":key=="Light"?"#7E899B":"#FFFFFF");
        var surface=Brush.Parse(key=="Dark"?"#E1383E47":key=="Light"?"#E1BDD5F5":"#E1F3F8FE");
        _top.Background=_bottom.Background=_tools.Background=surface;
        Foreground=key=="Dark"?Brushes.WhiteSmoke:Brush.Parse("#20263F");
        _status.Foreground=Foreground;
        _helpToggle.Foreground=Foreground;_helpToggle.BorderBrush=_theme=="Light"?Foreground:Brushes.Gray;
        _helpToggle.Background=_theme=="Light"?Brushes.Transparent:Background;
        _helpCard.Background=surface;
        if(_helpCard.Child is ScrollViewer {Content:StackPanel rows})foreach(var row in rows.Children.OfType<TextBlock>())row.Foreground=Foreground;
        Refresh();
    }
    private void Refresh()
    {
        if(_closed)return;
        foreach(var (button,glyph,name) in _buttons)
        {
            bool active=name=="Select"&&!Surface.PanTool&&Surface.ActiveTool==BoardTool.Select||name=="Pan"&&Surface.PanTool||name=="Topmost"&&Topmost;
            glyph.Ink=active?Brush.Parse(_theme=="Dark"?"#5489E8":"#005DFF"):_theme=="Dark"?Brushes.WhiteSmoke:Brush.Parse("#20263F");
            glyph.InvalidateVisual();
            button.Background=active?Brush.Parse(_theme=="Dark"?"#343B46":_theme=="White"?"#C8CFDA":"#32FFFFFF"):Brushes.Transparent;
        }
        if(_undo is not null){_undo.IsEnabled=Surface.CanUndo;_undo.Opacity=Surface.CanUndo?1:.35;}
        if(_redo is not null){_redo.IsEnabled=Surface.CanRedo;_redo.Opacity=Surface.CanRedo?1:.35;}
        _status.Text=$"{Surface.Items.Count} 張圖片 · 已選 {Surface.Selected.Count} 張 · {Surface.Zoom:P0}";
    }
    private async Task CopyAsync()
    {
        if(_busy||_closed||Surface.Selected.Count==0)return;
        try
        {
            if(Clipboard is null)throw new InvalidOperationException("無法取得剪貼簿。");
            var data=new DataObject();data.Set(DataFormats.Text,Surface.CopySelected());
            var selected=Surface.Selected.ToHashSet();
            var first=Surface.Items.Select((item,index)=>(item,index)).First(x=>selected.Contains(x.item.Id));
            var png=Surface.RenderedFrames()[first.index].Png;data.Set("public.png",png);data.Set("image/png",png);
            await Clipboard.SetDataObjectAsync(data);
            if(!_closed)_status.Text="已複製選取圖片。";
        }
        catch(Exception ex){if(!_closed)_status.Text="複製失敗："+ex.Message;}
    }
    private async Task PasteAsync()
    {
        if(_busy||_closed)return;
        try
        {
            string? token=Clipboard is null?null:await Clipboard.GetTextAsync();
            if(_closed||Surface.PasteObjects(token))return;
            if(Clipboard is not null)
            {
                foreach(var format in new[]{"public.png","image/png","public.jpeg","image/jpeg","public.tiff"})
                {
                    if(await Clipboard.GetDataAsync(format) is byte[] bytes)
                    {Surface.AddFrames(new[]{ImageInputs.FromEncoded(bytes)});Surface.Fit();return;}
                }
            }
            _status.Text="剪貼簿沒有支援的圖片；也可拖入圖片檔案。";
        }
        catch(Exception ex){if(!_closed)_status.Text="貼上失敗："+ex.Message;}
    }
    private async Task ExportAsync()
    {
        if(_busy||_closed||(Surface.Items.Count==0&&Surface.Annotations.Count==0))return;_busy=true;
        string? temporary=null;
        try
        {
            var file=await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title="匯出畫布",SuggestedFileName="Clipxel-reference-board.png",DefaultExtension="png",
                FileTypeChoices=new[]{new FilePickerFileType("PNG"){Patterns=new[]{"*.png"}},
                    new FilePickerFileType("JPEG"){Patterns=new[]{"*.jpg","*.jpeg"}}}
            });
            if(file is null||_closed)return;
            using(file)
            {
                var path=file.TryGetLocalPath()??throw new InvalidOperationException("請選擇本機儲存位置。");
                var extension=Path.GetExtension(path).ToLowerInvariant();
                if(extension is not (".png" or ".jpg" or ".jpeg"))throw new InvalidOperationException("請使用 PNG 或 JPEG 副檔名。");
                var data=Surface.ExportImage(extension!=".png");
                temporary=Path.Combine(Path.GetDirectoryName(path)!,".clipxel-"+Guid.NewGuid().ToString("N")+".tmp");
                await File.WriteAllBytesAsync(temporary,data);
                File.Move(temporary,path,true);temporary=null;
                if(!_closed)_status.Text="畫布已匯出，不含選取框與工具列。";
            }
        }
        catch(Exception ex){if(!_closed)_status.Text="匯出失敗："+ex.Message;}
        finally
        {
            if(temporary is not null)try{File.Delete(temporary);}catch(IOException){}
            _busy=false;
        }
    }
    private async Task ImportAsync()
    {
        if(_busy||_closed)return;_busy=true;
        try
        {
            var files=await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions{Title="匯入圖片",AllowMultiple=true,
                FileTypeFilter=new[]{new FilePickerFileType("PNG／JPEG"){Patterns=new[]{"*.png","*.jpg","*.jpeg"}}}});
            var frames=new List<CapturedFrame>();
            foreach(var file in files)
            {
                using(file)
                await using(var stream=await file.OpenReadAsync())
                {
                    using var bytes=new MemoryStream();var buffer=new byte[81920];int n;
                    while((n=await stream.ReadAsync(buffer))>0)
                    {if(bytes.Length+n>64_000_000)throw new InvalidDataException("圖片超過 64 MB 上限");bytes.Write(buffer,0,n);}
                    frames.Add(ImageInputs.FromEncoded(bytes.ToArray()));
                }
            }
            if(!_closed){Surface.AddFrames(frames);Surface.Fit();}
        }
        catch(Exception ex){if(!_closed)_status.Text="匯入失敗："+ex.Message;}
        finally{_busy=false;}
    }
}
