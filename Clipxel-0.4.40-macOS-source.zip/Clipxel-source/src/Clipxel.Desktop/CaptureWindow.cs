using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Clipxel.Platform;

namespace Clipxel.Desktop;
public sealed class CaptureWindow : Window
{
    private readonly MacScreenCaptureService _capture = new();
    private readonly CancellationTokenSource _lifetime = new();
    private readonly ComboBox _displays = new() { MinWidth = 400, HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Stretch };
    private readonly TextBlock _permission = Ui.Text("正在檢查螢幕錄製授權…");
    private readonly TextBlock _status = Ui.Text("選擇螢幕後即可擷取。圖片只保留在本機，儲存位置由你選擇。", 13);
    private readonly WrapPanel _actions = new() { Orientation = Avalonia.Layout.Orientation.Horizontal };
    private readonly WrapPanel _localActions = new();
    private readonly List<PinWindow> _pins = new();
    internal int PinCount => _pins.Count;
    private readonly List<string> _log = new();
    private bool _busy, _closing;
    private CropWindow? _crop;
    private BoardWindow? _board;
    internal BoardWindow? ActiveBoard=>_board;
    private BoardWindow.Session? _boardSession;
    public CaptureWindow()
    {
        Title = "Clipxel — Mac 截圖與釘圖測試版";
        Width = 760; Height = 660; MinWidth = 620; MinHeight = 570;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = Brush.Parse("#F3F6FC");
        var local = new StackPanel { Spacing = 12 };
        local.Children.Add(Ui.Text("圖片操作 · 不需螢幕錄製權限", 17));
        local.Children.Add(Ui.Text("可使用內建圖片或自己選擇的 PNG／JPEG，測試釘圖、縮放、裁切與儲存。", 13));
        _localActions.Children.Add(Ui.Button("開啟測試圖", () => _ = LocalImageAsync(true, false), true));
        _localActions.Children.Add(Ui.Button("框選測試圖", () => _ = LocalImageAsync(true, true)));
        _localActions.Children.Add(Ui.Button("匯入圖片", () => _ = LocalImageAsync(false, false)));
        _localActions.Children.Add(Ui.Button("匯入並框選", () => _ = LocalImageAsync(false, true)));
        local.Children.Add(_localActions);
        var permissions = new StackPanel { Spacing = 12 };
        permissions.Children.Add(Ui.Text("01  螢幕錄製授權", 17));
        permissions.Children.Add(_permission);
        var permissionButtons = new WrapPanel();
        permissionButtons.Children.Add(Ui.Button("請求授權", RequestPermission));
        permissionButtons.Children.Add(Ui.Button("開啟系統授權設定", OpenSettings));
        permissions.Children.Add(permissionButtons);
        var capture = new StackPanel { Spacing = 14 };
        capture.Children.Add(Ui.Text("02  選擇螢幕", 17));
        capture.Children.Add(_displays);
        capture.Children.Add(Ui.Button("更新螢幕清單", () => _ = RefreshAsync()));
        _actions.Children.Add(Ui.Button("擷取整個螢幕", () => _ = CaptureAsync(false, false), true));
        _actions.Children.Add(Ui.Button("框選截圖區域", () => _ = CaptureAsync(true, false)));
        _actions.Children.Add(Ui.Button("擷取所有螢幕", () => _ = CaptureAsync(false, true)));
        _actions.IsEnabled = false;
        capture.Children.Add(_actions);
        capture.Children.Add(Ui.Text("框選會開啟擷取畫面的預覽。拖曳框選，再確認產生釘圖；Esc 取消。", 12));
        var footer = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 10 };
        footer.Children.Add(Ui.Button("顯示全部釘圖", ShowPins));
        footer.Children.Add(Ui.Button("進入畫布", OpenBoard));
        footer.Children.Add(Ui.Button("匯出診斷紀錄", () => _ = ExportLogAsync()));
        Content = new ScrollViewer
        {
            Content = new StackPanel
            {
                Margin = new Thickness(28), Spacing = 18,
                Children = { Ui.Text("Clipxel", 32), Ui.Text("截取畫面，放在眼前。", 15),
                    Ui.Panel(local), Ui.Panel(permissions), Ui.Panel(capture), _status, footer,
                    Ui.Text("0.4.39 · Mac 第二階段測試版 · 關閉此視窗會結束程式與釘圖", 11) }
            }
        };
        Opened += async (_, _) => await RefreshAsync();
        Activated += (_, _) => { if (!_busy && !_closing) CheckPermission(); };
        Closing += (_, _) =>
        {
            _closing = true; _lifetime.Cancel(); _crop?.Close(); _board?.Close();
            foreach (var pin in _pins.ToArray()) pin.Close();
        };
        KeyDown += (_, e) =>
        {
            if ((e.KeyModifiers & KeyModifiers.Meta) != 0 && e.Key == Key.N)
            { e.Handled = true; _ = CaptureAsync(false, false); }
        };
        Log($"Started {Environment.OSVersion}; process {System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture}");
    }
    private void Log(string message)
    { _log.Add($"{DateTimeOffset.Now:O} {message}"); if (_log.Count > 300) _log.RemoveAt(0); }
    private void Status(string text) { _status.Text = text; Log(text); }
    private bool CheckPermission()
    {
        try
        {
            bool granted = _capture.HasPermission();
            _permission.Text = granted ? "已允許螢幕錄製。" : "尚未允許。請授權後，回來按「更新螢幕清單」；若仍無法擷取，請結束並重開 Clipxel。";
            _actions.IsEnabled = granted && !_busy && _displays.ItemCount > 0;
            return granted;
        }
        catch (Exception ex) { _permission.Text = ex.Message; _actions.IsEnabled = false; Log(ex.ToString()); return false; }
    }
    private void RequestPermission()
    {
        if (_busy || _closing) return;
        try
        {
            _capture.RequestPermission();
            if (CheckPermission()) _ = RefreshAsync();
            else Status("請在系統設定允許 Clipxel 錄製螢幕，然後更新螢幕清單。必要時結束並重開程式。");
        }
        catch (Exception ex) { Status(ex.Message); Log(ex.ToString()); }
    }
    private void OpenSettings()
    {
        if (_closing) return;
        try { _capture.OpenPermissionSettings(); } catch (Exception ex) { Status(ex.Message); }
    }
    private async Task RefreshAsync()
    {
        if (_busy || _closing || !CheckPermission()) return;
        SetBusy(true);
        try
        {
            var prior = (_displays.SelectedItem as CaptureDisplay)?.Id;
            Status("正在讀取螢幕清單…");
            var displays = await _capture.GetDisplaysAsync(_lifetime.Token);
            if (_closing) return;
            _displays.ItemsSource = displays;
            _displays.SelectedItem = displays.FirstOrDefault(d => d.Id == prior) ?? displays.FirstOrDefault();
            Status(displays.Count == 0 ? "沒有可擷取的螢幕。請檢查授權與螢幕連接。" : $"找到 {displays.Count} 個螢幕。");
        }
        catch (OperationCanceledException) { if (!_closing) Status("讀取螢幕清單逾時。請確認系統授權，再重新嘗試。"); }
        catch (Exception ex) { if (!_closing) Status(ex.Message); Log(ex.ToString()); }
        finally { SetBusy(false); }
    }
    private void SetBusy(bool value)
    { _busy = value; _displays.IsEnabled = !value; _localActions.IsEnabled = !value; if (!_closing) CheckPermission(); }
    private async Task LocalImageAsync(bool sample, bool region)
    {
        if (_busy || _closing) return;
        SetBusy(true);
        PinWindow[] hidden = Array.Empty<PinWindow>();
        try
        {
            CapturedFrame frame;
            if (sample) frame = ImageInputs.Sample();
            else
            {
                var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
                {
                    Title = "選擇圖片", AllowMultiple = false,
                    FileTypeFilter = new[] { new FilePickerFileType("PNG／JPEG 圖片")
                    { Patterns = new[] { "*.png", "*.jpg", "*.jpeg" }, AppleUniformTypeIdentifiers = new[] { "public.png", "public.jpeg" } } }
                });
                if (files.Count == 0) return;
                using var file = files[0];
                await using var input = await file.OpenReadAsync();
                using var bytes = new MemoryStream();
                var buffer = new byte[81920]; int count;
                while ((count = await input.ReadAsync(buffer, _lifetime.Token)) != 0)
                {
                    if (bytes.Length + count > 64_000_000) throw new InvalidDataException("圖片檔案超過 64 MB 上限。");
                    await bytes.WriteAsync(buffer.AsMemory(0, count), _lifetime.Token);
                }
                frame = await Task.Run(() => ImageInputs.FromEncoded(bytes.ToArray()), _lifetime.Token);
            }
            if (_closing) return;
            if (region)
            {
                hidden = _pins.Where(p => p.IsVisible).ToArray();
                foreach (var pin in hidden) pin.Hide();
                var cropWindow = new CropWindow(frame); _crop = cropWindow;
                var completion = new TaskCompletionSource<CapturedFrame?>(TaskCreationOptions.RunContinuationsAsynchronously);
                cropWindow.Closed += (_, _) => completion.TrySetResult(cropWindow.Result);
                cropWindow.Show();
                var result = await completion.Task; _crop = null;
                if (_closing) return;
                foreach (var pin in hidden) if (_pins.Contains(pin)) pin.Show();
                if (result is null) { Status("已取消圖片框選。"); return; }
                frame = result;
            }
            AddPin(frame);
            Status(sample ? "已開啟內建測試圖，可測試拖曳、置頂、縮放及儲存。未擷取螢幕。" : "圖片已匯入。此操作不需要螢幕錄製權限。");
        }
        catch (OperationCanceledException) { if (!_closing) Status("已取消圖片操作。"); }
        catch (Exception ex) { if (!_closing) Status("無法開啟圖片：" + ex.Message); Log(ex.ToString()); }
        finally
        {
            if (!_closing) foreach (var pin in hidden) if (_pins.Contains(pin) && !pin.IsVisible) pin.Show();
            SetBusy(false);
        }
    }
    private async Task CaptureAsync(bool region, bool all)
    {
        if (_busy || _closing || !CheckPermission()) return;
        if (_displays.SelectedItem is not CaptureDisplay selected) { Status("請先更新並選擇螢幕。"); return; }
        SetBusy(true);
        var visible = _pins.Where(p => p.IsVisible).ToArray();
        var frames = new List<CapturedFrame>();
        try
        {
            foreach (var pin in visible) pin.Hide();
            Hide();
            await Task.Delay(350, _lifetime.Token);
            var targets = all ? (_displays.ItemsSource as IReadOnlyList<CaptureDisplay>) ?? new[] { selected } : new[] { selected };
            foreach (var display in targets) frames.Add(await _capture.CaptureDisplayAsync(display, _lifetime.Token));
            if (_closing) return;
            if (region)
            {
                var cropWindow = new CropWindow(frames[0]); _crop = cropWindow;
                var completion = new TaskCompletionSource<CapturedFrame?>(TaskCreationOptions.RunContinuationsAsynchronously);
                cropWindow.Closed += (_, _) => completion.TrySetResult(cropWindow.Result);
                cropWindow.Show();
                var cropped = await completion.Task;
                _crop = null; frames.Clear();
                if (cropped is not null) frames.Add(cropped);
            }
            if (!_closing)
            {
                Status(frames.Count == 0 ? "已取消框選。" : $"已建立 {frames.Count} 張釘圖。拖曳圖片可移動；使用 + / − 縮放，PNG 保留原始像素。");
            }
        }
        catch (OperationCanceledException) { if (!_closing) Status("擷取逾時或已取消。請確認授權後重試。"); }
        catch (Exception ex)
        {
            if (!_closing) Status($"擷取未全部完成：{ex.Message}（已保留 {frames.Count} 張成功的截圖）");
            Log(ex.ToString());
        }
        finally
        {
            if (!_closing)
            {
                Show();
                foreach (var pin in visible) if (_pins.Contains(pin)) pin.Show();
                foreach (var frame in frames)
                {
                    try { AddPin(frame); }
                    catch (Exception ex) { Status("建立釘圖失敗：" + ex.Message); Log(ex.ToString()); }
                }
            }
            SetBusy(false);
        }
    }
    private void AddPin(CapturedFrame frame)
    {
        var pin = new PinWindow(frame, Status, OpenBoard);
        _pins.Add(pin); pin.Closed += (_, _) => _pins.Remove(pin); pin.Show();
        pin.Position = new PixelPoint(Position.X + 50 + ((_pins.Count - 1) % 7) * 26,
            Position.Y + 70 + ((_pins.Count - 1) % 7) * 26);
    }
    private void OpenBoard()
    {
        if(_busy||_closing)return;
        if(_board is not null){_board.Activate();return;}
        var framesNow=_pins.Select(p=>p.Frame).ToArray();
        var board=new BoardWindow(_boardSession is null?framesNow:Array.Empty<CapturedFrame>());_board=board;
        if(_boardSession is not null)
            board.RestoreSession(BoardWindow.ReconcileSession(_boardSession,framesNow));
        board.Closed+=(_,_)=>
        {
            _board=null;
            if(_closing)return;
            _boardSession=board.SaveSession();
            var frames=board.Frames;
            foreach(var p in _pins.ToArray())p.Close();
            foreach(var f in frames)AddPin(f);
            if(!board.ReturnToPins)foreach(var p in _pins)p.Hide();
            Show();Activate();
            Status("畫布圖片與本次布局已保留；本階段尚未提供專案存檔。");
        };
        foreach(var p in _pins)p.Hide();
        Hide();board.Show();
    }
    private void ShowPins()
    {
        if (_busy) return;
        foreach (var pin in _pins) { pin.Show(); pin.Activate(); }
        Status($"目前有 {_pins.Count} 張釘圖。");
    }
    private async Task ExportLogAsync()
    {
        try
        {
            var file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            { Title = "儲存診斷紀錄", SuggestedFileName = "Clipxel-diagnostics.txt", DefaultExtension = "txt" });
            if (file is null) return;
            using (file)
            await using (var stream = await file.OpenWriteAsync())
            {
                stream.SetLength(0); await using var writer = new StreamWriter(stream);
                await writer.WriteAsync(string.Join(Environment.NewLine, _log));
            }
            Status("診斷紀錄已儲存，內容不包含截圖圖片。");
        }
        catch (Exception ex) { Status("無法儲存診斷紀錄：" + ex.Message); }
    }
}
