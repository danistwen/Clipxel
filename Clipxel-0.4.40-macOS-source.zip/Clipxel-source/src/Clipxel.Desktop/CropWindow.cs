using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Clipxel.Core;
using Clipxel.Platform;
namespace Clipxel.Desktop;

public sealed class CropWindow : Window
{
    private readonly CapturedFrame _frame;
    private readonly Bitmap _bitmap;
    private readonly CropSurface _surface;
    private readonly TextBlock _status = Ui.Text("在圖片內按住滑鼠拖曳框選；Enter 確認，Esc 取消。", 13);
    public CapturedFrame? Result { get; private set; }
    public CropWindow(CapturedFrame frame, bool desktopOverlay = false, uint? displayId = null)
    {
        _frame = frame;
        using (var stream = new MemoryStream(frame.Png)) _bitmap = new Bitmap(stream);
        Title = "Clipxel — 選取截圖範圍";
        Width = 1120; Height = 790; MinWidth = 600; MinHeight = 420;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = Brush.Parse("#F3F6FC");
        _surface = new CropSurface(_bitmap);
        _surface.SelectionChanged += crop => _status.Text = crop is null
            ? "請拖曳選取範圍；Enter 確認，Esc 取消。"
            : $"選取 {crop.Value.Width} × {crop.Value.Height} 像素；可重新拖曳框選。";
        var bar = new DockPanel { Margin = new Thickness(16) };
        var buttons = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 10, Margin = new Thickness(0, 0, 15, 0) };
        buttons.Children.Add(Ui.Button("建立釘圖", Confirm, true));
        buttons.Children.Add(Ui.Button("取消", Close));
        DockPanel.SetDock(buttons, Dock.Left); bar.Children.Add(buttons); bar.Children.Add(_status);
        var root = new DockPanel(); DockPanel.SetDock(bar, Dock.Bottom);
        root.Children.Add(bar); root.Children.Add(_surface); Content = root;
        if (desktopOverlay)
        {
            SystemDecorations=SystemDecorations.None;CanResize=false;Topmost=true;ShowInTaskbar=false;
            WindowStartupLocation=WindowStartupLocation.Manual;MinWidth=1;MinHeight=1;
            Width=frame.LogicalWidth;Height=frame.LogicalHeight;root.Children.Remove(_surface);Content=_surface;
            // Avalonia.Native 11.3 exposes the same CGDirectDisplayID as ScreenCaptureKit.
            // Match identity, not mixed-DPI desktop coordinates.
            var screen = displayId is uint id ? Screens.All.FirstOrDefault(s =>
                s.TryGetPlatformHandle() is { HandleDescriptor: "CGDirectDisplayID" } h &&
                h.Handle.ToInt64() == id) : null;
            if (displayId is not null && screen is null)
            {
                _bitmap.Dispose();
                throw new InvalidOperationException("螢幕配置已變更，請重新截圖。");
            }
            Position = screen?.Bounds.Position ?? new PixelPoint((int)frame.LogicalX, (int)frame.LogicalY);
            if (screen is not null)
            {
                Width = screen.Bounds.Width / screen.Scaling;
                Height = screen.Bounds.Height / screen.Scaling;
            }
            _surface.SelectionCompleted+=Confirm;
        }
        KeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) { e.Handled = true; Close(); }
            if (e.Key == Key.Enter) { e.Handled = true; Confirm(); }
        };
        Closed += (_, _) => _bitmap.Dispose();
    }
    private void Confirm()
    {
        if (_surface.Selection is not PixelCrop crop) { _status.Text = "請先拖曳框選一個範圍。"; return; }
        try
        {
            byte[] png = CropImage(_bitmap, crop);
            Result = new CapturedFrame(png,
                _frame.LogicalX + crop.X * _frame.LogicalWidth / _frame.PixelWidth,
                _frame.LogicalY + crop.Y * _frame.LogicalHeight / _frame.PixelHeight,
                crop.Width * _frame.LogicalWidth / _frame.PixelWidth,
                crop.Height * _frame.LogicalHeight / _frame.PixelHeight, crop.Width, crop.Height);
            Close();
        }
        catch (Exception ex) { _status.Text = "裁切失敗：" + ex.Message; }
    }
    internal static byte[] CropImage(Bitmap bitmap, PixelCrop crop)
    {
        using var target = new RenderTargetBitmap(new PixelSize(crop.Width, crop.Height), new Vector(96, 96));
        // Bitmap source rectangles are raster pixels. Applying its DPI here
        // would shift a Retina crop into a different part of the image.
        using (var context = target.CreateDrawingContext())
            context.DrawImage(bitmap, new Rect(crop.X, crop.Y, crop.Width, crop.Height),
                new Rect(0, 0, crop.Width, crop.Height));
        using var stream = new MemoryStream(); target.Save(stream); return stream.ToArray();
    }
    private sealed class CropSurface : Control
    {
        private readonly Bitmap _image;
        private Point _start, _end;
        private bool _dragging;
        private IPointer? _pointer;
        public PixelCrop? Selection { get; private set; }
        public event Action<PixelCrop?>? SelectionChanged;
        public event Action? SelectionCompleted;
        public CropSurface(Bitmap image)
        {
            _image = image; ClipToBounds = true; Cursor = new Cursor(StandardCursorType.Cross);
            SizeChanged += (_, _) => { Selection = null; _dragging = false; _pointer?.Capture(null); _pointer = null; SelectionChanged?.Invoke(null); InvalidateVisual(); };
        }
        private ImageArea Area => CropMapping.Fit(_image.PixelSize.Width, _image.PixelSize.Height, Bounds.Width, Bounds.Height);
        public override void Render(DrawingContext context)
        {
            context.FillRectangle(Brush.Parse("#20263F"), new Rect(Bounds.Size));
            if (Bounds.Width <= 0 || Bounds.Height <= 0) return;
            var a = Area; context.DrawImage(_image, new Rect(a.X, a.Y, a.Width, a.Height));
            if (Selection is PixelCrop c)
            {
                var rect = new Rect(a.X + c.X * a.Width / _image.PixelSize.Width,
                    a.Y + c.Y * a.Height / _image.PixelSize.Height,
                    c.Width * a.Width / _image.PixelSize.Width, c.Height * a.Height / _image.PixelSize.Height);
                context.DrawRectangle(Brush.Parse("#18005DFF"), new Pen(Ui.Blue, 2), rect);
            }
        }
        protected override void OnPointerPressed(PointerPressedEventArgs e)
        {
            if (!e.GetCurrentPoint(this).Properties.IsLeftButtonPressed || Bounds.Width <= 0 || Bounds.Height <= 0) return;
            var p = e.GetPosition(this); var a = Area;
            if (p.X < a.X || p.X > a.X + a.Width || p.Y < a.Y || p.Y > a.Y + a.Height) return;
            _start = _end = p; _dragging = true; _pointer = e.Pointer; e.Pointer.Capture(this);
            Selection = null; SelectionChanged?.Invoke(null); InvalidateVisual(); e.Handled = true;
        }
        protected override void OnPointerMoved(PointerEventArgs e)
        {
            if (!_dragging) return;
            _end = e.GetPosition(this); UpdateSelection(); e.Handled = true;
        }
        protected override void OnPointerReleased(PointerReleasedEventArgs e)
        {
            if (!_dragging) return;
            _end = e.GetPosition(this); UpdateSelection(); _dragging = false; e.Pointer.Capture(null); _pointer = null; e.Handled = true;
            if(Selection is not null)SelectionCompleted?.Invoke();
        }
        protected override void OnPointerCaptureLost(PointerCaptureLostEventArgs e)
        { _dragging = false; _pointer = null; base.OnPointerCaptureLost(e); }
        private void UpdateSelection()
        {
            Selection = CropMapping.Select(Area, _image.PixelSize.Width, _image.PixelSize.Height, _start.X, _start.Y, _end.X, _end.Y);
            SelectionChanged?.Invoke(Selection); InvalidateVisual();
        }
    }
}
