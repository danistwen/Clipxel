using Clipxel.Platform;
using SkiaSharp;
namespace Clipxel.Desktop;

internal static class ImageInputs
{
    public static CapturedFrame FromEncoded(byte[] bytes)
    {
        if (bytes.Length > 64_000_000) throw new InvalidDataException("圖片檔案超過本測試版的 64 MB 上限。");
        using var data = SKData.CreateCopy(bytes);
        using var codec = SKCodec.Create(data) ?? throw new InvalidDataException("無法讀取圖片，請使用 PNG 或 JPEG。");
        int w = codec.Info.Width, h = codec.Info.Height;
        if (w <= 0 || h <= 0 || (long)w * h > 64_000_000) throw new InvalidDataException("圖片超過 6400 萬像素上限。");
        using var decoded = SKBitmap.Decode(codec) ?? throw new InvalidDataException("圖片解碼失敗。");
        bool rotated = (int)codec.EncodedOrigin >= 5;
        using var normalized = new SKBitmap(rotated ? h : w, rotated ? w : h, SKColorType.Bgra8888, SKAlphaType.Premul);
        using (var canvas = new SKCanvas(normalized))
        {
            canvas.Clear(SKColors.Transparent);
            switch (codec.EncodedOrigin)
            {
                case SKEncodedOrigin.TopRight: canvas.Translate(w, 0); canvas.Scale(-1, 1); break;
                case SKEncodedOrigin.BottomRight: canvas.Translate(w, h); canvas.RotateDegrees(180); break;
                case SKEncodedOrigin.BottomLeft: canvas.Translate(0, h); canvas.Scale(1, -1); break;
                case SKEncodedOrigin.LeftTop: canvas.RotateDegrees(90); canvas.Scale(1, -1); break;
                case SKEncodedOrigin.RightTop: canvas.Translate(h, 0); canvas.RotateDegrees(90); break;
                case SKEncodedOrigin.RightBottom: canvas.Translate(h, w); canvas.RotateDegrees(90); canvas.Scale(-1, 1); break;
                case SKEncodedOrigin.LeftBottom: canvas.Translate(0, w); canvas.RotateDegrees(270); break;
            }
            canvas.DrawBitmap(decoded, 0, 0);
        }
        return Frame(normalized);
    }
    private static CapturedFrame Frame(SKBitmap image)
    {
        using var encoded = image.Encode(SKEncodedImageFormat.Png, 100);
        return new(encoded.ToArray(), 0, 0, image.Width, image.Height, image.Width, image.Height);
    }
    public static CapturedFrame Sample()
    {
        using var image = new SKBitmap(960, 600);
        using (var canvas = new SKCanvas(image))
        using (var paint = new SKPaint { IsAntialias = true })
        {
            canvas.Clear(SKColor.Parse("#F3F8FE"));
            paint.Color = SKColor.Parse("#005DFF"); canvas.DrawRect(0, 0, 480, 300, paint);
            paint.Color = SKColor.Parse("#20263F"); canvas.DrawRect(480, 0, 480, 300, paint);
            paint.Color = SKColor.Parse("#FFD74A"); canvas.DrawRect(0, 300, 480, 300, paint);
            paint.Color = SKColor.Parse("#BDD5F5"); canvas.DrawRect(480, 300, 480, 300, paint);
            paint.Color = SKColors.White; paint.TextSize = 48;
            canvas.DrawText("Clipxel", 40, 90, paint);
            paint.TextSize = 23; canvas.DrawText("LOCAL IMAGE TEST", 40, 134, paint);
            canvas.DrawCircle(720, 150, 85, paint);
            paint.Color = SKColor.Parse("#20263F"); paint.TextSize = 25;
            canvas.DrawText("960 x 600 pixels", 40, 360, paint);
            canvas.DrawText("Drag / Pin / Zoom / Crop / Save", 40, 405, paint);
            paint.Color = SKColor.Parse("#005DFF"); paint.StrokeWidth = 2;
            for (int i = 0; i <= 8; i++) canvas.DrawLine(530 + i * 44, 340, 530 + i * 44, 560, paint);
            for (int i = 0; i <= 5; i++) canvas.DrawLine(530, 340 + i * 44, 882, 340 + i * 44, paint);
        }
        return Frame(image);
    }
}
