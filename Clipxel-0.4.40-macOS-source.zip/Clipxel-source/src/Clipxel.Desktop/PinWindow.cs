using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using Clipxel.Platform;
namespace Clipxel.Desktop;

public sealed class PinWindow : Window
{
    private readonly CapturedFrame _frame;
    internal CapturedFrame Frame => _frame;
    private readonly Bitmap _bitmap;
    private readonly Action<string> _report;
    private readonly TextBlock _size;
    private bool _saving, _closed;
    private readonly Image _image;
    private bool _flipped;
    public PinWindow(CapturedFrame frame, Action<string> report, Action? openBoard = null)
    {
        _frame = frame; _report = report;
        using (var stream = new MemoryStream(frame.Png)) _bitmap = new Bitmap(stream);
        Title = $"Clipxel 釘圖 — {frame.PixelWidth} × {frame.PixelHeight}";
        SystemDecorations = SystemDecorations.None; CanResize = true;
        Topmost = true; ShowInTaskbar = false; MinWidth = 360; MinHeight = 150;
        Background = Brushes.White;
        Width = Math.Clamp(frame.LogicalWidth, 360, 680);
        Height = Math.Clamp((Width - 2) * frame.PixelHeight / frame.PixelWidth + 76, 150, 780);
        var image = _image = new Image { Source = _bitmap, Stretch = Stretch.Uniform, RenderTransformOrigin = RelativePoint.Center };
        image.PointerPressed += (_, e) =>
        {
            if (e.GetCurrentPoint(image).Properties.IsLeftButtonPressed) { BeginMoveDrag(e); e.Handled = true; }
        };
        Button Icon(string glyph, string tip, Action action)
        {
            var button = new Button { Content = new BoardGlyph(glyph) { Ink = Brush.Parse("#20263F") },
                Width = 30, Height = 30, Padding = new Thickness(5), Background = Brushes.Transparent,
                BorderThickness = new Thickness(0), CornerRadius = new CornerRadius(6) };
            ToolTip.SetTip(button, tip); button.Click += (_, _) => action(); return button;
        }
        var bar = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 2, Margin = new Thickness(6, 4) };
        if (openBoard is not null) bar.Children.Add(Icon("Return", "開啟畫布", openBoard));
        var pin = Icon("Topmost", "切換置頂", () => Topmost = !Topmost);
        bar.Children.Add(pin);
        bar.Children.Add(Icon("ZoomOut", "縮小（−）", () => ResizeBy(1 / 1.2)));
        bar.Children.Add(Icon("ZoomIn", "放大（+）", () => ResizeBy(1.2)));
        bar.Children.Add(Icon("Paste", "複製原始圖片（⌘C）", () => _ = CopyAsync()));
        bar.Children.Add(Icon("Export", "儲存原始 PNG（⌘S）", () => _ = SaveAsync()));
        bar.Children.Add(Icon("Close", "關閉釘圖（Esc）", Close));
        _size = Ui.Text($"{frame.PixelWidth} × {frame.PixelHeight} px", 10);
        _size.Margin = new Thickness(8, 2, 8, 5);
        ToolTip.SetTip(_size, "F：水平翻轉預覽 · [ / ]：調整透明度 · 0：還原透明度與翻轉；儲存與複製保留原圖");
        var header = new StackPanel { Children = { bar, _size }, Background = Brush.Parse("#F3F6FC") };
        var root = new DockPanel(); DockPanel.SetDock(header, Dock.Top); root.Children.Add(header); root.Children.Add(image);
        Content = new Border { BorderBrush = Brush.Parse("#CBD3E4"), BorderThickness = new Thickness(1), Child = root };
        KeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) { e.Handled = true; Close(); }
            else if (e.Key == Key.C && (e.KeyModifiers & KeyModifiers.Meta) != 0) { e.Handled = true; _ = CopyAsync(); }
            else if (e.Key == Key.F && e.KeyModifiers == KeyModifiers.None) { _flipped = !_flipped; _image.RenderTransform = new ScaleTransform(_flipped ? -1 : 1, 1); e.Handled = true; }
            else if (e.Key == Key.OemOpenBrackets) { Opacity = Math.Max(0.2, Opacity - 0.1); e.Handled = true; }
            else if (e.Key == Key.OemCloseBrackets) { Opacity = Math.Min(1, Opacity + 0.1); e.Handled = true; }
            else if (e.Key == Key.D0) { Opacity = 1; _flipped = false; _image.RenderTransform = null; e.Handled = true; }
            else if (e.Key is Key.OemPlus or Key.Add) { ResizeBy(1.2); e.Handled = true; }
            else if (e.Key is Key.OemMinus or Key.Subtract) { ResizeBy(1 / 1.2); e.Handled = true; }
            else if (e.Key == Key.S && (e.KeyModifiers & KeyModifiers.Meta) != 0) { e.Handled = true; _ = SaveAsync(); }
        };
        Closed += (_, _) => { _closed = true; _bitmap.Dispose(); };
    }
    private void ResizeBy(double factor)
    {
        var working = Screens.ScreenFromWindow(this)?.WorkingArea;
        double maxWidth = working is null ? 1400 : working.Value.Width / RenderScaling;
        double maxHeight = working is null ? 1000 : working.Value.Height / RenderScaling;
        double proposed = Math.Clamp(Width * factor, MinWidth, Math.Max(MinWidth, maxWidth));
        Width = proposed;
        Height = Math.Clamp((proposed - 2) * _frame.PixelHeight / _frame.PixelWidth + 76, MinHeight, Math.Max(MinHeight, maxHeight));
    }
    private async Task CopyAsync()
    {
        if (_closed) return;
        try
        {
            if (Clipboard is null) throw new InvalidOperationException("無法取得剪貼簿。");
            // Avalonia.Native 11.3 passes byte[] and custom UTI formats to NSPasteboard.setData.
            var data = new DataObject();
            data.Set("public.png", _frame.Png);
            data.Set("image/png", _frame.Png);
            await Clipboard.SetDataObjectAsync(data);
            if (!_closed) _size.Text = "已複製原始圖片";
            _report("已複製 PNG 圖片，可貼至支援圖片的應用程式。");
        }
        catch (Exception ex) { if (!_closed) _size.Text = "複製失敗：" + ex.Message; _report("複製失敗：" + ex.Message); }
    }
    private async Task SaveAsync()
    {
        if (_saving || _closed) return;
        _saving = true;
        try
        {
            var file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "儲存釘圖 PNG", SuggestedFileName = $"Clipxel-{DateTime.Now:yyyyMMdd-HHmmss}.png",
                DefaultExtension = "png", FileTypeChoices = new[] { new FilePickerFileType("PNG 圖片") { Patterns = new[] { "*.png" } } }
            });
            if (file is null) return;
            using (file)
            await using (var stream = await file.OpenWriteAsync())
            {
                stream.SetLength(0); await stream.WriteAsync(_frame.Png); await stream.FlushAsync();
            }
            if (!_closed) _size.Text = $"已儲存 · {_frame.PixelWidth} × {_frame.PixelHeight} px";
            _report("釘圖 PNG 已儲存，保留原始像素尺寸。");
        }
        catch (Exception ex) { if (!_closed) _size.Text = "儲存失敗：" + ex.Message; _report("儲存失敗：" + ex.Message); }
        finally { _saving = false; }
    }
}
