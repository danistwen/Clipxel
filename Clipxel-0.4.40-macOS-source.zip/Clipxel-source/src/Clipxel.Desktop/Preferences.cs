using System.Text.Json;
namespace Clipxel.Desktop;
internal static class Preferences
{
    private static string PathName=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Clipxel","preferences.json");
    internal static string Theme
    {
        get{try{var value=JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(PathName));return value?.GetValueOrDefault("Theme") is "Light" or "White" ? value["Theme"]:"Dark";}catch{return "Dark";}}
    }
    internal static void SaveTheme(string theme)
    {
        try{Directory.CreateDirectory(Path.GetDirectoryName(PathName)!);var tmp=PathName+".tmp";File.WriteAllText(tmp,JsonSerializer.Serialize(new {Theme=theme}));File.Move(tmp,PathName,true);}catch(IOException){}catch(UnauthorizedAccessException){}
    }
}
