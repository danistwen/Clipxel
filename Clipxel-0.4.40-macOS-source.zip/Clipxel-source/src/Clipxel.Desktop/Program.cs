using Avalonia;
namespace Clipxel.Desktop;
internal static class Program
{
    [STAThread] public static void Main(string[] args)=>AppBuilder.Configure<MigrationApp>().UsePlatformDetect().StartWithClassicDesktopLifetime(args);
}
