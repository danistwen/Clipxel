using System.IO.Compression;
using System.Text.Json;
using System.Text.Json.Nodes;
using Avalonia;
using Avalonia.Media;
using Clipxel.Platform;
using SkiaSharp;

namespace Clipxel.Desktop;

// Windows v1 ZIP format. Unknown JSON properties survive a read/edit/write cycle.
internal static class ProjectStore
{
    internal sealed record Document(BoardSurface.Item[] Items, BoardAnnotation[] Annotations,
        BoardGroup[] Groups, double Zoom, Vector Pan, JsonObject Root,
        IReadOnlyDictionary<int,JsonObject> Cards);
    private const long MaxJson=64_000_000, MaxImage=256_000_000, MaxTotal=512_000_000;
    private static readonly JsonSerializerOptions JsonOptions=new(){WriteIndented=true};
    internal static Document Load(string path)
    {
        using var file=File.OpenRead(path); return Load(file);
    }
    internal static Document Load(Stream input)
    {
        using var zip=new ZipArchive(input,ZipArchiveMode.Read,true);
        if(zip.Entries.Count>12000)throw Bad("專案項目過多。");
        var entries=new Dictionary<string,ZipArchiveEntry>(StringComparer.Ordinal);
        long total=0;
        foreach(var entry in zip.Entries)
        {
            if(!entries.TryAdd(entry.FullName,entry))throw Bad("專案包含重複項目。");
            total=checked(total+entry.Length);if(total>MaxTotal)throw Bad("專案解壓縮容量超過 512 MB。");
        }
        if(!entries.TryGetValue("project.json",out var json))throw Bad("找不到 project.json。");
        var root=JsonNode.Parse(ReadEntry(json,MaxJson),documentOptions:new JsonDocumentOptions{MaxDepth=64}) as JsonObject ?? throw Bad("無效專案內容。");
        Validate(root);
        var cards=Array(root,"Cards");var items=new List<BoardSurface.Item>();var metadata=new Dictionary<int,JsonObject>();
        var annotations=new List<BoardAnnotation>();long pixels=0;
        for(int n=0;n<cards.Count;n++)
        {
            var card=Object(cards[n]);
            if(!entries.TryGetValue($"images/{n}.png",out var image))throw Bad("專案缺少圖片。");
            var bytes=ReadEntry(image,MaxImage);
            using var data=SKData.CreateCopy(bytes);using var codec=SKCodec.Create(data)??throw Bad("圖片無法解碼。");
            int w=codec.Info.Width,h=codec.Info.Height;
            pixels=checked(pixels+(long)w*h);
            if(w<=0||h<=0||pixels>128_000_000)throw Bad("專案總像素超過 1 億 2800 萬。");
            if(codec.EncodedFormat!=SKEncodedImageFormat.Png)throw Bad("專案圖片必須是 PNG。");
            using var bitmap=SKBitmap.Decode(codec)??throw Bad("圖片資料不完整。");
            var frame=new CapturedFrame(bytes,0,0,w,h,w,h);
            var item=new BoardSurface.Item(n,frame,Number(card,"X"),Number(card,"Y"),Number(card,"Width"),Number(card,"Height"));
            items.Add(item);metadata.Add(n,(JsonObject)card.DeepClone());
            foreach(var ink in Array(card,"Ink"))annotations.Add(ReadInk(Object(ink),annotations.Count,item));
        }
        foreach(var ink in Array(root,"Ink"))annotations.Add(ReadInk(Object(ink),annotations.Count,null));
        var groupNodes=Array(root,"Groups").Select(Object).ToArray();
        var groups=groupNodes.Select((g,index)=>new BoardGroup(index,Text(g,"Name"),
            items.Where(i=>groupNodes.Where(x=>Contains(x,i)).OrderBy(x=>Number(x,"Width")*Number(x,"Height")).FirstOrDefault()==g).Select(i=>i.Id).ToArray(),
            Bool(g,"AutoArrange"),Number(g,"ColumnGap",24)){ProjectData=(JsonObject)g.DeepClone()}).ToArray();
        // Convert legacy links exactly once, retaining their original style metadata as ordinary ink.
        foreach(var node in Array(root,"Links"))
        {
            var link=Object(node);var from=groupNodes.Single(g=>Text(g,"Id")==Text(link,"From"));var to=groupNodes.Single(g=>Text(g,"Id")==Text(link,"To"));
            var a=Port(from,Integer(link,"FromSide",1));var b=Port(to,Integer(link,"ToSide"));
            var ink=new JsonObject{["Tool"]=4,["Style"]=Integer(link,"Style"),["X"]=a.X,["Y"]=a.Y,["X2"]=b.X,["Y2"]=b.Y,["Color"]=Text(link,"Color","#FF465CFF"),["Width"]=Number(link,"Width",3)};
            annotations.Add(ReadInk(ink,annotations.Count,null));
        }
        root["Links"]=new JsonArray();
        return new(items.OrderBy(i=>Integer(metadata[i.Id],"Z")).ToArray(),annotations.ToArray(),groups,
            Number(root,"Zoom",1),new Vector(Number(root,"PanX"),Number(root,"PanY")),root,metadata);
    }
    internal static void Save(string path,IReadOnlyList<BoardSurface.Item> items,double zoom,Vector pan,
        IReadOnlyList<BoardAnnotation> annotations,IReadOnlyList<BoardGroup> groups,Document? previous=null)
    {
        string temp=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(path))!,".clipxel-"+Guid.NewGuid().ToString("N")+".tmp");
        try
        {
            using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))
            { Write(stream,items,zoom,pan,annotations,groups,previous);stream.Flush(true); }
            File.Move(temp,path,true);
        }
        finally{if(File.Exists(temp))File.Delete(temp);}
    }
    internal static void Write(Stream output,IReadOnlyList<BoardSurface.Item> items,double zoom,Vector pan,
        IReadOnlyList<BoardAnnotation> annotations,IReadOnlyList<BoardGroup> groups,Document? previous=null)
    {
        var root=previous is null?new JsonObject(): (JsonObject)previous.Root.DeepClone();
        root["Version"]=1;root["Zoom"]=zoom;root["PanX"]=pan.X;root["PanY"]=pan.Y;
        root["Background"]??="#FF27292E";root["FloatingX"]??=16;root["FloatingY"]??=60;
        root["FloatingWidth"]??=620;root["FloatingHeight"]??=120;root["DrawingVisible"]??=true;
        root["Snap"]??=true;root["ChromeVisible"]??=true;root["Topmost"]??=true;
        var cards=new JsonArray();var ink=new JsonArray();
        for(int index=0;index<items.Count;index++)
        {
            var item=items[index];var card=previous is not null&&previous.Cards.TryGetValue(item.Id,out var old)?(JsonObject)old.DeepClone():new JsonObject();
            card["X"]=item.X;card["Y"]=item.Y;card["Width"]=item.Width;card["Height"]=item.Height;card["Z"]=previous is not null&&previous.Items.Select(i=>i.Id).SequenceEqual(items.Select(i=>i.Id))&&previous.Cards.TryGetValue(item.Id,out var original)?Integer(original,"Z"):index;
            card["Ink"]=new JsonArray(annotations.Where(a=>a.CardId==item.Id).Select(a=>(JsonNode)WriteInk(a,item)).ToArray());cards.Add(card);
        }
        foreach(var annotation in annotations.Where(a=>a.CardId is null))ink.Add(WriteInk(annotation,null));
        root["Cards"]=cards;root["Ink"]=ink;root["Links"]=new JsonArray();
        root["Groups"]=new JsonArray(groups.Select(g=>(JsonNode)WriteGroup(g,items,previous)).ToArray());
        Validate(root);
        var json=JsonSerializer.SerializeToUtf8Bytes(root,JsonOptions);if(json.LongLength>MaxJson)throw Bad("專案內容過大。");
        long total=json.LongLength,pixels=0;
        foreach(var i in items){total=checked(total+i.Frame.Png.LongLength);pixels=checked(pixels+(long)i.Frame.PixelWidth*i.Frame.PixelHeight);if(i.Frame.Png.LongLength>MaxImage||total>MaxTotal||pixels>128_000_000)throw Bad("專案超過容量上限。");}
        using var zip=new ZipArchive(output,ZipArchiveMode.Create,true);
        using(var stream=zip.CreateEntry("project.json",CompressionLevel.Optimal).Open())stream.Write(json);
        for(int n=0;n<items.Count;n++){using var stream=zip.CreateEntry($"images/{n}.png",CompressionLevel.NoCompression).Open();stream.Write(items[n].Frame.Png);}
    }
    private static BoardAnnotation ReadInk(JsonObject ink,int id,BoardSurface.Item? item)
    {
        BoardPoint Convert(double x,double y)=>item is null?new(x,y):new(item.X+x*item.Width/item.Frame.PixelWidth,item.Y+y*item.Height/item.Frame.PixelHeight);
        int tool=Integer(ink,"Tool"),style=Integer(ink,"Style");
        var mapped=tool switch{1=>BoardTool.Pen,2=>BoardTool.Rectangle,3=>BoardTool.Ellipse,4=>style==0?BoardTool.Arrow:BoardTool.Line,5=>BoardTool.Text,_=>BoardTool.Select};
        var points=tool==1?Array(ink,"Points").Select(p=>{var a=(JsonArray)p!;return Convert(a[0]!.GetValue<double>(),a[1]!.GetValue<double>());}).ToArray():new[]{Convert(Number(ink,"X"),Number(ink,"Y")),Convert(Number(ink,"X2"),Number(ink,"Y2"))};
        double scale=item is null?1:item.Width/item.Frame.PixelWidth;
        return new BoardAnnotation(id,mapped,points,Text(ink,"Color","#FFFFFFFF"),Number(ink,"Width",3)*scale,Text(ink,"Text"),Number(ink,"Font",22)*scale){CardId=item?.Id,ProjectData=(JsonObject)ink.DeepClone()};
    }
    private static JsonObject WriteInk(BoardAnnotation a,BoardSurface.Item? item)
    {
        var ink=a.ProjectData is null?new JsonObject():(JsonObject)a.ProjectData.DeepClone();
        BoardPoint Convert(BoardPoint p)=>item is null?p:new((p.X-item.X)*item.Frame.PixelWidth/item.Width,(p.Y-item.Y)*item.Frame.PixelHeight/item.Height);
        var p=a.Points.Select(Convert).ToArray();var start=p.FirstOrDefault()??new BoardPoint(0,0);var end=p.LastOrDefault()??start;
        ink["Tool"]=a.Tool switch{BoardTool.Pen=>1,BoardTool.Rectangle=>2,BoardTool.Ellipse=>3,BoardTool.Arrow or BoardTool.Line=>4,BoardTool.Text=>5,_=>0};
        ink["Style"]??=a.Tool==BoardTool.Line?1:0;
        if(a.Tool!=BoardTool.Pen||a.ProjectData is null){ink["X"]=start.X;ink["Y"]=start.Y;ink["X2"]=end.X;ink["Y2"]=end.Y;}
        double scale=item is null?1:item.Frame.PixelWidth/item.Width;
        ink["Width"]=a.Width*scale;ink["Font"]=a.FontSize*scale;ink["Color"]=a.Color;ink["Text"]=a.Text;
        ink["FontFamily"]??="Segoe UI";ink["Stroke"]??=true;ink["Fill"]??=false;ink["StrokeOpacity"]??=1;ink["FillOpacity"]??=.45;ink["RectangleMode"]??=0;
        ink["Points"]=a.Tool==BoardTool.Pen?new JsonArray(p.Select(x=>(JsonNode)new JsonArray(x.X,x.Y)).ToArray()):new JsonArray();return ink;
    }
    private static JsonObject WriteGroup(BoardGroup g,IReadOnlyList<BoardSurface.Item> items,Document? previous)
    {
        var data=g.ProjectData is null?new JsonObject():(JsonObject)g.ProjectData.DeepClone();
        data["Id"]??=Guid.NewGuid().ToString("N");data["Name"]=g.Name;data["AutoArrange"]=g.AutoArrange;data["ColumnGap"]=g.Gap;
        data["RowGap"]??=g.Gap;data["Fill"]??="#FF465CFF";data["Border"]??="#FF465CFF";data["Opacity"]??=.15;
        data["TitleSize"]??=16;data["TitleColor"]??="#FFF5F5F5";data["Dashed"]??=false;
        var members=items.Where(i=>g.Members.Contains(i.Id)).ToArray();
        bool moved=previous is null||members.Any(i=>!previous.Items.Any(old=>old.Id==i.Id&&old.X==i.X&&old.Y==i.Y&&old.Width==i.Width&&old.Height==i.Height));
        if(g.ProjectData is null||(members.Length>0&&moved))
        {
            double x=members.Length==0?0:members.Min(i=>i.X)-16,y=members.Length==0?0:members.Min(i=>i.Y)-40;
            data["X"]=x;data["Y"]=y;data["Width"]=members.Length==0?240:members.Max(i=>i.X+i.Width)+16-x;data["Height"]=members.Length==0?160:members.Max(i=>i.Y+i.Height)+16-y;
        }
        return data;
    }
    private static byte[] ReadEntry(ZipArchiveEntry entry,long limit)
    {
        if(entry.Length>limit)throw Bad("專案項目超過容量上限。");using var stream=entry.Open();using var output=new MemoryStream();var buffer=new byte[81920];int read;
        while((read=stream.Read(buffer))>0){if(output.Length+read>limit)throw Bad("專案解壓縮資料過大。");output.Write(buffer,0,read);}return output.ToArray();
    }
    private static void Validate(JsonObject root)
    {
        if(Integer(root,"Version",1)!=1)throw Bad("不支援此專案版本。");
        ColorValue(root,"Background","#FF1E2128");foreach(var key in new[]{"Zoom","PanX","PanY","FloatingX","FloatingY","FloatingWidth","FloatingHeight"})Number(root,key,key=="Zoom"?1:0);
        Range(Number(root,"Zoom",1),.02,16);foreach(var key in new[]{"DrawingVisible","Snap","ChromeVisible","Topmost"})Bool(root,key,true);
        var cards=Array(root,"Cards");var groups=Array(root,"Groups");var ink=Array(root,"Ink");var links=Array(root,"Links");
        if(cards.Count>1000||groups.Count>10000||ink.Count>100000||links.Count>10000)throw Bad("專案項目過多。");
        long strokes=ink.Count;foreach(var c in cards){var card=Object(c);Rect(card);Integer(card,"Z");var ci=Array(card,"Ink");strokes+=ci.Count;if(strokes>100000)throw Bad("標註過多。");foreach(var a in ci)ValidateInk(Object(a));}
        foreach(var a in ink)ValidateInk(Object(a));
        var ids=new HashSet<string>();
        foreach(var g in groups)
        {
            var group=Object(g);Rect(group);var id=Text(group,"Id");if(string.IsNullOrWhiteSpace(id)||!ids.Add(id))throw Bad("區塊識別碼無效或重複。");
            if(Text(group,"Name").Length>10000)throw Bad("區塊名稱過長。");ColorValue(group,"Fill");ColorValue(group,"Border");ColorValue(group,"TitleColor","#FFF5F5F5");
            Range(Number(group,"Opacity"),0,1);Range(Number(group,"ColumnGap",24),0,200);Range(Number(group,"RowGap",24),0,200);Range(Number(group,"TitleSize",16),10,96);Bool(group,"AutoArrange");Bool(group,"Dashed");
        }
        foreach(var l in links){var link=Object(l);if(!ids.Contains(Text(link,"From"))||!ids.Contains(Text(link,"To"))||Text(link,"From")==Text(link,"To"))throw Bad("無效連接線。");Range(Integer(link,"FromSide",1),0,3);Range(Integer(link,"ToSide"),0,3);Range(Integer(link,"Style"),0,3);Range(Number(link,"Width",3),1,24);ColorValue(link,"Color","#FF465CFF");}
    }
    private static void ValidateInk(JsonObject a)
    {
        Range(Integer(a,"Tool"),0,5);Range(Integer(a,"Style"),0,3);Range(Integer(a,"RectangleMode"),0,1);
        foreach(var k in new[]{"X","Y","X2","Y2"})Number(a,k);
        Range(Number(a,"Width",3),double.Epsilon,10000);Range(Number(a,"Font",22),double.Epsilon,10000);Range(Number(a,"StrokeOpacity",1),0,1);Range(Number(a,"FillOpacity",.45),0,1);
        ColorValue(a,"Color","#FFFFFFFF");if(Text(a,"Text").Length>1000000)throw Bad("文字過長。");var font=Text(a,"FontFamily","Segoe UI");if(string.IsNullOrWhiteSpace(font)||font.Length>500)throw Bad("字型名稱無效。");
        foreach(var key in new[]{"Independent","Stroke","Fill"})Bool(a,key,key=="Stroke");
        var points=Array(a,"Points");if(points.Count>1000000)throw Bad("筆畫過長。");foreach(var p in points){if(p is not JsonArray point||point.Count!=2)throw Bad("無效筆畫座標。");foreach(var n in point)Finite(n?.GetValue<double>()??double.NaN);}
    }
    private static JsonObject Object(JsonNode? n)=>n as JsonObject??throw Bad("無效專案物件。");
    private static JsonArray Array(JsonObject o,string k)=>o[k] is null&&!o.ContainsKey(k)?new JsonArray():o[k] as JsonArray??throw Bad("無效專案陣列："+k);
    private static string Text(JsonObject o,string k,string fallback="")=>o.ContainsKey(k)?o[k]?.GetValue<string>()??throw Bad("無效文字："+k):fallback;
    private static double Number(JsonObject o,string k,double fallback=0){double n=o.ContainsKey(k)?o[k]?.Deserialize<double>()??double.NaN:fallback;Finite(n);return n;}
    private static int Integer(JsonObject o,string k,int fallback=0)=>o.ContainsKey(k)?o[k]?.GetValue<int>()??throw Bad("無效整數："+k):fallback;
    private static bool Bool(JsonObject o,string k,bool fallback=false)=>o.ContainsKey(k)?o[k]?.GetValue<bool>()??throw Bad("無效布林值："+k):fallback;
    private static void ColorValue(JsonObject o,string k,string fallback=""){if(!Color.TryParse(Text(o,k,fallback),out _))throw Bad("無效顏色："+k);}
    private static void Finite(double n){if(!double.IsFinite(n)||Math.Abs(n)>10000000)throw Bad("無效座標或尺寸。");}
    private static void Range(double n,double low,double high){Finite(n);if(n<low||n>high)throw Bad("專案數值超出範圍。");}
    private static void Rect(JsonObject o){foreach(var k in new[]{"X","Y","Width","Height"})Number(o,k);if(Number(o,"Width")<=0||Number(o,"Height")<=0)throw Bad("專案尺寸必須大於零。");}
    private static bool Contains(JsonObject g,BoardSurface.Item i)=>i.X+i.Width/2>=Number(g,"X")&&i.X+i.Width/2<=Number(g,"X")+Number(g,"Width")&&i.Y+i.Height/2>=Number(g,"Y")&&i.Y+i.Height/2<=Number(g,"Y")+Number(g,"Height");
    private static BoardPoint Port(JsonObject g,int side){double x=Number(g,"X"),y=Number(g,"Y"),w=Number(g,"Width"),h=Number(g,"Height");return side switch{0=>new(x,y+h/2),1=>new(x+w,y+h/2),2=>new(x+w/2,y),_=>new(x+w/2,y+h)};}
    private static InvalidDataException Bad(string message)=>new(message);
}
