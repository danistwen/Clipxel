using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Clipxel.Desktop.Tests")]
