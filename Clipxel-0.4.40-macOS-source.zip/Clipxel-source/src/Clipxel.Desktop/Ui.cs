using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
namespace Clipxel.Desktop;
internal static class Ui
{
    public static readonly IBrush Blue = Brush.Parse("#005DFF");
    public static readonly IBrush Ink = Brush.Parse("#20263F");
    public static TextBlock Text(string text, double size = 14) => new()
    { Text = text, FontSize = size, Foreground = Ink, TextWrapping = TextWrapping.Wrap };
    public static Button Button(string text, Action action, bool primary = false)
    {
        var button = new Button { Content = text, Padding = new Thickness(14, 9), CornerRadius = new CornerRadius(7) };
        if (primary) { button.Background = Blue; button.Foreground = Brushes.White; }
        button.Click += (_, _) => action();
        return button;
    }
    public static Border Panel(Control content) => new()
    { Background = Brushes.White, Padding = new Thickness(20), CornerRadius = new CornerRadius(12), Child = content };
}
