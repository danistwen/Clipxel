using System.Runtime.InteropServices;

namespace Clipxel.Platform;

/// <summary>Carbon registered hotkeys; create and dispose on the macOS UI thread.
/// Callbacks run from the application event loop. No event tap or accessibility permission is used.</summary>
public sealed class MacHotkeys : IDisposable
{
    private const string Carbon = "/System/Library/Frameworks/Carbon.framework/Carbon";
    private const uint Signature = 0x436C7078; // 'Clpx'
    private readonly Action _capture, _board;
    private readonly EventHandlerProc _callback;
    private IntPtr _handler, _captureRef, _boardRef;
    private bool _disposed;
    public MacHotkeys(Action capture, Action board)
    {
        ArgumentNullException.ThrowIfNull(capture); ArgumentNullException.ThrowIfNull(board);
        _capture = capture; _board = board; _callback = Handle;
        if (!OperatingSystem.IsMacOS()) throw new PlatformNotSupportedException("全域快捷鍵僅適用於 macOS。");
        try
        {
            var type = new EventType { Class = 0x6B657962, Kind = 5 }; // 'keyb', kEventHotKeyPressed
            Check(InstallEventHandler(GetApplicationEventTarget(), _callback, 1, ref type, IntPtr.Zero, out _handler), "安裝快捷鍵處理程序");
            const uint modifiers = (1u << 8) | (1u << 9); // cmdKey | shiftKey
            Check(RegisterEventHotKey(19, modifiers, new HotkeyId { Signature = Signature, Id = 1 }, GetApplicationEventTarget(), 0, out _captureRef), "註冊 ⌘⇧2 截圖");
            Check(RegisterEventHotKey(18, modifiers, new HotkeyId { Signature = Signature, Id = 2 }, GetApplicationEventTarget(), 0, out _boardRef), "註冊 ⌘⇧1 畫布");
        }
        catch { Dispose(); throw; }
    }
    private int Handle(IntPtr next, IntPtr evt, IntPtr data)
    {
        if (_disposed) return -9874; // eventNotHandledErr
        int status = GetEventParameter(evt, 0x2D2D2D2D, 0x686B6964, IntPtr.Zero, 8, IntPtr.Zero, out var id); // '----', 'hkid'
        if (status != 0 || id.Signature != Signature || (id.Id != 1 && id.Id != 2)) return -9874;
        // Managed exceptions must never cross the native callback boundary.
        try { if (id.Id == 1) _capture(); else _board(); }
        catch (Exception ex) { System.Diagnostics.Trace.TraceError("Clipxel hotkey callback: {0}", ex); }
        return 0;
    }
    private static void Check(int status, string action)
    {
        if (status != 0) throw new InvalidOperationException($"{action}失敗（macOS {status}）；快捷鍵可能已被其他程式使用。");
    }
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        if (_captureRef != IntPtr.Zero) { UnregisterEventHotKey(_captureRef); _captureRef = IntPtr.Zero; }
        if (_boardRef != IntPtr.Zero) { UnregisterEventHotKey(_boardRef); _boardRef = IntPtr.Zero; }
        if (_handler != IntPtr.Zero) { RemoveEventHandler(_handler); _handler = IntPtr.Zero; }
        GC.KeepAlive(_callback);
    }
    [StructLayout(LayoutKind.Sequential)] private struct EventType { public uint Class, Kind; }
    [StructLayout(LayoutKind.Sequential)] private struct HotkeyId { public uint Signature, Id; }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] private delegate int EventHandlerProc(IntPtr next, IntPtr evt, IntPtr data);
    [DllImport(Carbon)] private static extern IntPtr GetApplicationEventTarget();
    [DllImport(Carbon)] private static extern int InstallEventHandler(IntPtr target, EventHandlerProc handler, nuint count, ref EventType type, IntPtr data, out IntPtr reference);
    [DllImport(Carbon)] private static extern int RemoveEventHandler(IntPtr handler);
    [DllImport(Carbon)] private static extern int RegisterEventHotKey(uint key, uint modifiers, HotkeyId id, IntPtr target, uint options, out IntPtr reference);
    [DllImport(Carbon)] private static extern int UnregisterEventHotKey(IntPtr reference);
    [DllImport(Carbon)] private static extern int GetEventParameter(IntPtr evt, uint name, uint type, IntPtr actualType, nuint size, IntPtr actualSize, out HotkeyId id);
}
