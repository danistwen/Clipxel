using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Clipxel.Platform;

public sealed record CaptureDisplay(uint Id, double X, double Y, double Width, double Height,
    int PixelWidth, int PixelHeight, bool Primary)
{
    public override string ToString() => $"{(Primary ? "主螢幕" : "螢幕")} · {PixelWidth} × {PixelHeight} · ID {Id}";
}

// macOS 14+ ScreenCaptureKit still-image API; no shell screenshot process,
// no microphone capture and no private API. Objective-C ABI is ARM64 only.
public sealed class MacScreenCaptureService : IScreenCaptureService
{
    private const string ObjC = "/usr/lib/libobjc.A.dylib";
    private const string CG = "/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics";
    private const string CF = "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation";
    private const string IO = "/System/Library/Frameworks/ImageIO.framework/ImageIO";
    private static readonly Lazy<IntPtr> Framework = new(() =>
        NativeLibrary.Load("/System/Library/Frameworks/ScreenCaptureKit.framework/ScreenCaptureKit"));
    [StructLayout(LayoutKind.Sequential)]
    private struct Rect { public double X, Y, Width, Height; }
    [DllImport(ObjC)] private static extern IntPtr objc_getClass(string name);
    [DllImport(ObjC)] private static extern IntPtr sel_registerName(string name);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern IntPtr Send(IntPtr receiver, IntPtr selector);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern IntPtr Send1(IntPtr receiver, IntPtr selector, IntPtr value);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern IntPtr Send2(IntPtr receiver, IntPtr selector, IntPtr a, IntPtr b);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern void Send3(IntPtr receiver, IntPtr selector, IntPtr a, IntPtr b, IntPtr c);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern void SetBool(IntPtr receiver, IntPtr selector, [MarshalAs(UnmanagedType.I1)] bool value);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern void SetSize(IntPtr receiver, IntPtr selector, nuint value);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern nuint GetSize(IntPtr receiver, IntPtr selector);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern IntPtr At(IntPtr receiver, IntPtr selector, nuint index);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern uint GetId(IntPtr receiver, IntPtr selector);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern float GetFloat(IntPtr receiver, IntPtr selector);
    [DllImport(ObjC, EntryPoint = "objc_msgSend")] private static extern Rect GetRect(IntPtr receiver, IntPtr selector);
    [DllImport(CG)] [return: MarshalAs(UnmanagedType.I1)] private static extern bool CGPreflightScreenCaptureAccess();
    [DllImport(CG)] [return: MarshalAs(UnmanagedType.I1)] private static extern bool CGRequestScreenCaptureAccess();
    [DllImport(CG)] private static extern uint CGMainDisplayID();
    [DllImport(CG)] private static extern Rect CGDisplayBounds(uint display);
    [DllImport(CG)] private static extern nuint CGImageGetWidth(IntPtr image);
    [DllImport(CG)] private static extern nuint CGImageGetHeight(IntPtr image);
    [DllImport(CF)] private static extern IntPtr CFDataCreateMutable(IntPtr allocator, nint capacity);
    [DllImport(CF)] private static extern nint CFDataGetLength(IntPtr data);
    [DllImport(CF)] private static extern IntPtr CFDataGetBytePtr(IntPtr data);
    [DllImport(CF)] private static extern void CFRelease(IntPtr value);
    [DllImport(CF)] private static extern IntPtr CFStringCreateWithCString(IntPtr allocator, string text, uint encoding);
    [DllImport(IO)] private static extern IntPtr CGImageDestinationCreateWithData(IntPtr data, IntPtr type, nuint count, IntPtr options);
    [DllImport(IO)] private static extern void CGImageDestinationAddImage(IntPtr destination, IntPtr image, IntPtr properties);
    [DllImport(IO)] [return: MarshalAs(UnmanagedType.I1)] private static extern bool CGImageDestinationFinalize(IntPtr destination);
    private static IntPtr Sel(string selector) => sel_registerName(selector);
    private static (int Width, int Height) Dimensions(IntPtr filter)
    {
        var rect = GetRect(filter, Sel("contentRect"));
        double scale = GetFloat(filter, Sel("pointPixelScale"));
        double width = Math.Round(rect.Width * scale), height = Math.Round(rect.Height * scale);
        if (!double.IsFinite(width) || !double.IsFinite(height) || width <= 0 || height <= 0 || width * height > 100_000_000)
            throw new InvalidOperationException("螢幕尺寸無效，或超過本測試版的 1 億像素上限。");
        return (checked((int)width), checked((int)height));
    }
    private static IntPtr Pool() => Send(Send(objc_getClass("NSAutoreleasePool"), Sel("alloc")), Sel("init"));
    private static void Release(IntPtr value) { if (value != IntPtr.Zero) Send(value, Sel("release")); }
    private static void EnsureSupported()
    {
        if (!OperatingSystem.IsMacOSVersionAtLeast(14) || RuntimeInformation.ProcessArchitecture != Architecture.Arm64)
            throw new PlatformNotSupportedException("截圖功能需要 Apple Silicon 與 macOS 14 或更新版本。");
        _ = Framework.Value;
        if (objc_getClass("SCScreenshotManager") == IntPtr.Zero)
            throw new PlatformNotSupportedException("此系統沒有可用的 ScreenCaptureKit 截圖 API。");
        NativeBlock.VerifyRuntime();
    }
    public bool HasPermission() { EnsureSupported(); return CGPreflightScreenCaptureAccess(); }
    public bool RequestPermission() { EnsureSupported(); return CGRequestScreenCaptureAccess(); }
    public void OpenPermissionSettings() => Process.Start(new ProcessStartInfo
    {
        FileName = "/usr/bin/open",
        ArgumentList = { "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture" },
        UseShellExecute = false
    });
    private static string ErrorText(IntPtr error)
    {
        if (error == IntPtr.Zero) return "macOS 未回傳截圖資料。";
        var description = Send(error, Sel("localizedDescription"));
        return Marshal.PtrToStringUTF8(Send(description, Sel("UTF8String"))) ?? "ScreenCaptureKit 發生錯誤。";
    }
    private static async Task<IntPtr> GetContentAsync(CancellationToken token)
    {
        var tcs = new TaskCompletionSource<IntPtr>(TaskCreationOptions.RunContinuationsAsynchronously);
        using var registration = token.Register(() => tcs.TrySetCanceled(token));
        using (var block = new NativeBlock((value, error) =>
        {
            try
            {
                if (error != IntPtr.Zero || value == IntPtr.Zero) throw new InvalidOperationException(ErrorText(error));
                Send(value, Sel("retain"));
                if (!tcs.TrySetResult(value)) Release(value); // Late result after cancellation.
            }
            catch (Exception ex) { tcs.TrySetException(ex); }
        }))
        {
            token.ThrowIfCancellationRequested();
            Send1(objc_getClass("SCShareableContent"), Sel("getShareableContentWithCompletionHandler:"), block.Pointer);
        }
        return await tcs.Task.ConfigureAwait(false);
    }
    public async Task<IReadOnlyList<CaptureDisplay>> GetDisplaysAsync(CancellationToken token)
    {
        EnsureSupported();
        if (!HasPermission()) throw new UnauthorizedAccessException("請先允許 Clipxel 錄製螢幕，再更新螢幕清單。");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromSeconds(30));
        var content = await GetContentAsync(timeout.Token).ConfigureAwait(false);
        var pool = Pool();
        try
        {
            var displays = Send(content, Sel("displays"));
            var result = new List<CaptureDisplay>();
            for (nuint i = 0; i < GetSize(displays, Sel("count")); i++)
            {
                var id = GetId(At(displays, Sel("objectAtIndex:"), i), Sel("displayID"));
                var bounds = CGDisplayBounds(id);
                if (bounds.Width <= 0 || bounds.Height <= 0) continue;
                var filter = Send2(Send(objc_getClass("SCContentFilter"), Sel("alloc")), Sel("initWithDisplay:excludingWindows:"),
                    At(displays, Sel("objectAtIndex:"), i), Send(objc_getClass("NSArray"), Sel("array")));
                try
                {
                    if (filter == IntPtr.Zero) throw new InvalidOperationException("無法讀取螢幕解析度。");
                    var size = Dimensions(filter);
                    result.Add(new(id, bounds.X, bounds.Y, bounds.Width, bounds.Height, size.Width, size.Height, id == CGMainDisplayID()));
                }
                finally { Release(filter); }
            }
            return result.OrderByDescending(d => d.Primary).ThenBy(d => d.X).ThenBy(d => d.Y).ToArray();
        }
        finally { Release(content); Release(pool); }
    }
    public async Task<CapturedFrame> CaptureDisplayAsync(CaptureDisplay display, CancellationToken token)
    {
        EnsureSupported();
        if (!HasPermission()) throw new UnauthorizedAccessException("螢幕錄製授權尚未開啟，或已被撤銷。");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
        timeout.CancelAfter(TimeSpan.FromSeconds(30));
        var content = await GetContentAsync(timeout.Token).ConfigureAwait(false);
        IntPtr filter = IntPtr.Zero, config = IntPtr.Zero;
        var pool = Pool();
        try
        {
            var displays = Send(content, Sel("displays"));
            IntPtr nativeDisplay = IntPtr.Zero;
            for (nuint i = 0; i < GetSize(displays, Sel("count")); i++)
            {
                var item = At(displays, Sel("objectAtIndex:"), i);
                if (GetId(item, Sel("displayID")) == display.Id) { nativeDisplay = item; break; }
            }
            if (nativeDisplay == IntPtr.Zero) throw new InvalidOperationException("螢幕已移除，請更新螢幕清單。");
            var bounds = CGDisplayBounds(display.Id);
            filter = Send2(Send(objc_getClass("SCContentFilter"), Sel("alloc")), Sel("initWithDisplay:excludingWindows:"),
                nativeDisplay, Send(objc_getClass("NSArray"), Sel("array")));
            config = Send(Send(objc_getClass("SCStreamConfiguration"), Sel("alloc")), Sel("init"));
            if (filter == IntPtr.Zero || config == IntPtr.Zero) throw new InvalidOperationException("無法建立螢幕擷取設定。");
            var size = Dimensions(filter);
            SetSize(config, Sel("setWidth:"), (nuint)size.Width); SetSize(config, Sel("setHeight:"), (nuint)size.Height);
            SetBool(config, Sel("setShowsCursor:"), false);
            SetBool(config, Sel("setScalesToFit:"), true);
            var tcs = new TaskCompletionSource<CapturedFrame>(TaskCreationOptions.RunContinuationsAsynchronously);
            using var registration = timeout.Token.Register(() => tcs.TrySetCanceled(timeout.Token));
            using (var block = new NativeBlock((image, error) =>
            {
                try
                {
                    if (tcs.Task.IsCompleted) return;
                    if (error != IntPtr.Zero || image == IntPtr.Zero) throw new InvalidOperationException(ErrorText(error));
                    var png = EncodePng(image);
                    tcs.TrySetResult(new(png, bounds.X, bounds.Y, bounds.Width, bounds.Height,
                        checked((int)CGImageGetWidth(image)), checked((int)CGImageGetHeight(image))));
                }
                catch (Exception ex) { tcs.TrySetException(ex); }
            }))
            {
                timeout.Token.ThrowIfCancellationRequested();
                Send3(objc_getClass("SCScreenshotManager"), Sel("captureImageWithFilter:configuration:completionHandler:"),
                    filter, config, block.Pointer);
            }
            // Autorelease pools must be drained on their creation thread, before awaiting.
            Release(pool); pool = IntPtr.Zero;
            return await tcs.Task.ConfigureAwait(false);
        }
        finally { Release(config); Release(filter); Release(content); Release(pool); }
    }
    private static byte[] EncodePng(IntPtr image)
    {
        var data = CFDataCreateMutable(IntPtr.Zero, 0);
        var type = CFStringCreateWithCString(IntPtr.Zero, "public.png", 0x08000100);
        IntPtr destination = IntPtr.Zero;
        try
        {
            if (data == IntPtr.Zero || type == IntPtr.Zero) throw new OutOfMemoryException();
            destination = CGImageDestinationCreateWithData(data, type, 1, IntPtr.Zero);
            if (destination == IntPtr.Zero) throw new InvalidOperationException("無法建立 PNG 編碼器。");
            CGImageDestinationAddImage(destination, image, IntPtr.Zero);
            if (!CGImageDestinationFinalize(destination)) throw new InvalidOperationException("PNG 編碼失敗。");
            var bytes = new byte[checked((int)CFDataGetLength(data))];
            Marshal.Copy(CFDataGetBytePtr(data), bytes, 0, bytes.Length);
            return bytes;
        }
        finally
        {
            if (destination != IntPtr.Zero) CFRelease(destination);
            if (type != IntPtr.Zero) CFRelease(type);
            if (data != IntPtr.Zero) CFRelease(data);
        }
    }
}
