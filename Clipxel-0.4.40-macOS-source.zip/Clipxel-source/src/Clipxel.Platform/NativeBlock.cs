using System.Runtime.InteropServices;

namespace Clipxel.Platform;

// Apple Blocks ABI. The native copy owns a reference to the GCHandle until
// its dispose helper runs, including when a request times out in managed code.
internal sealed class NativeBlock : IDisposable
{
    [StructLayout(LayoutKind.Sequential)]
    private struct Literal
    {
        public IntPtr Isa;
        public int Flags, Reserved;
        public IntPtr Invoke, Descriptor, Context;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct Descriptor
    {
        public nuint Reserved, Size;
        public IntPtr Copy, Dispose, Signature;
    }
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate void InvokeDelegate(IntPtr block, IntPtr value, IntPtr error);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate void CopyDelegate(IntPtr destination, IntPtr source);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate void DisposeDelegate(IntPtr block);
    private sealed class State(Action<IntPtr, IntPtr> callback)
    {
        public int References = 1;
        public readonly Action<IntPtr, IntPtr> Callback = callback;
        public GCHandle Handle;
    }
    private static readonly InvokeDelegate InvokeRoot = Invoke;
    private static readonly CopyDelegate CopyRoot = Copy;
    private static readonly DisposeDelegate DisposeRoot = Release;
    private static readonly IntPtr DescriptorPointer = CreateDescriptor();
    private static readonly Lazy<bool> RuntimeCheck = new(CheckRuntime);
    [DllImport("/usr/lib/libSystem.B.dylib", EntryPoint = "_Block_copy")]
    private static extern IntPtr CopyNative(IntPtr block);
    [DllImport("/usr/lib/libSystem.B.dylib", EntryPoint = "_Block_release")]
    private static extern void ReleaseNative(IntPtr block);
    public IntPtr Pointer { get; private set; }

    public static void VerifyRuntime() { _ = RuntimeCheck.Value; }
    private static bool CheckRuntime()
    {
        if (Marshal.SizeOf<Literal>() != 40 || Marshal.OffsetOf<Literal>(nameof(Literal.Context)).ToInt32() != 32)
            throw new PlatformNotSupportedException("原生回呼的記憶體配置不相容。");
        int calls = 0;
        IntPtr copy;
        using (var original = new NativeBlock((value, error) =>
        { if (value == new IntPtr(17) && error == IntPtr.Zero) calls++; }))
            copy = CopyNative(original.Pointer);
        if (copy == IntPtr.Zero) throw new InvalidOperationException("無法建立原生回呼。");
        try
        {
            var invoke = Marshal.GetDelegateForFunctionPointer<InvokeDelegate>(Marshal.PtrToStructure<Literal>(copy).Invoke);
            invoke(copy, new IntPtr(17), IntPtr.Zero);
            if (calls != 1) throw new InvalidOperationException("原生回呼生命週期檢查失敗。");
        }
        finally { ReleaseNative(copy); }
        return true;
    }

    public NativeBlock(Action<IntPtr, IntPtr> callback)
    {
        if (!OperatingSystem.IsMacOS() || RuntimeInformation.ProcessArchitecture != Architecture.Arm64)
            throw new PlatformNotSupportedException("此建置僅支援 Apple Silicon macOS。");
        var state = new State(callback);
        state.Handle = GCHandle.Alloc(state);
        try
        {
            var system = NativeLibrary.Load("/usr/lib/libSystem.B.dylib");
            Pointer = Marshal.AllocHGlobal(Marshal.SizeOf<Literal>());
            Marshal.StructureToPtr(new Literal
            {
                Isa = NativeLibrary.GetExport(system, "_NSConcreteStackBlock"),
                Flags = (1 << 25) | (1 << 30),
                Invoke = Marshal.GetFunctionPointerForDelegate(InvokeRoot),
                Descriptor = DescriptorPointer,
                Context = GCHandle.ToIntPtr(state.Handle)
            }, Pointer, false);
            NativeLibrary.Free(system);
        }
        catch
        {
            if (Pointer != IntPtr.Zero) Marshal.FreeHGlobal(Pointer);
            Pointer = IntPtr.Zero;
            state.Handle.Free();
            throw;
        }
    }
    private static IntPtr CreateDescriptor()
    {
        var result = Marshal.AllocHGlobal(Marshal.SizeOf<Descriptor>());
        Marshal.StructureToPtr(new Descriptor
        {
            Size = (nuint)Marshal.SizeOf<Literal>(),
            Copy = Marshal.GetFunctionPointerForDelegate(CopyRoot),
            Dispose = Marshal.GetFunctionPointerForDelegate(DisposeRoot),
            Signature = Marshal.StringToHGlobalAnsi("v24@?0^v8@16")
        }, result, false);
        return result; // Process-lifetime ABI descriptor and rooted delegates.
    }
    private static State GetState(IntPtr block) =>
        (State)GCHandle.FromIntPtr(Marshal.PtrToStructure<Literal>(block).Context).Target!;
    private static void Copy(IntPtr destination, IntPtr source) =>
        Interlocked.Increment(ref GetState(source).References);
    private static void Release(IntPtr block)
    {
        var state = GetState(block);
        if (Interlocked.Decrement(ref state.References) == 0) state.Handle.Free();
    }
    private static void Invoke(IntPtr block, IntPtr value, IntPtr error)
    {
        // Callbacks supplied by MacScreenCaptureService catch all exceptions.
        // Never propagate a managed exception across the Objective-C ABI.
        try { GetState(block).Callback(value, error); }
        catch (Exception ex) { System.Diagnostics.Trace.WriteLine(ex); }
    }
    public void Dispose()
    {
        if (Pointer == IntPtr.Zero) return;
        Release(Pointer);
        Marshal.FreeHGlobal(Pointer);
        Pointer = IntPtr.Zero;
    }
}
