namespace Clipxel.Platform;
public enum CapturePermission { Unknown, Granted, Denied, Restricted }
public sealed record CaptureRegion(double X,double Y,double Width,double Height);
public sealed record CapturedFrame(byte[] Png,double LogicalX,double LogicalY,
    double LogicalWidth,double LogicalHeight,int PixelWidth,int PixelHeight);
// Screen points and raster pixels remain separate for mixed Retina displays.
// Phase 2 implements this service with ScreenCaptureKit on Apple Silicon.
public interface IScreenCaptureService
{
    bool HasPermission();
    bool RequestPermission();
    void OpenPermissionSettings();
    Task<IReadOnlyList<CaptureDisplay>> GetDisplaysAsync(CancellationToken cancellationToken);
    Task<CapturedFrame> CaptureDisplayAsync(CaptureDisplay display, CancellationToken cancellationToken);
}
