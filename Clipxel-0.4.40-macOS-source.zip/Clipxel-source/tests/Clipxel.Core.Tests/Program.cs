using Clipxel.Core;
static void Check(bool condition,string name){if(!condition)throw new Exception(name);Console.WriteLine("PASS "+name);}
var input=new[]{new LayoutItem("a",410,320),new LayoutItem("b",130,90),new LayoutItem("c",270,180)};
var layout=GroupLayout.Arrange(input,0,0,37,51);
Check(layout.Items.Select(p=>(p.Width,p.Height)).SequenceEqual(input.Select(p=>(p.Width,p.Height))),"sizes preserved");
Check(layout.Items[1].X-layout.Items[0].X-410==37,"horizontal gap");
Check(layout.Items[2].Y-layout.Items[0].Y-320==51,"vertical gap");
input[0]=input[0] with {Width=600,Height=460};
var reflow=GroupLayout.KeepAnchor(GroupLayout.Arrange(input,0,0,37,51),"a",-20,-10);
Check(reflow.Items[0].X==-20&&reflow.Items[0].Y==-10,"resize anchor");
Check(reflow.Items[1].X==617&&reflow.Items[2].Y==501,"other images move");
Check(reflow.Items[1].Width==130,"neighbor size unchanged");
var h=new HistoryTimeline<string>(s=>s,2);h.Reset("a");
Check(!h.CanUndo&&!h.CanRedo,"empty history");
h.Observe("b");h.Observe("c");
Check(h.TryMove(false,out var b)&&b=="b","undo");
Check(!h.Observe("b")&&h.CanRedo,"unchanged observation retains redo");
Check(h.TryMove(true,out var c)&&c=="c","redo");
h.TryMove(false,out _);h.Observe("d");Check(!h.CanRedo,"branch clears redo");
Console.WriteLine("All core checks passed.");
var fitted = CropMapping.Fit(3840,2160,960,640);
Check(fitted == new ImageArea(0,50,960,540),"Retina preview letterboxing");
Check(CropMapping.Select(fitted,3840,2160,0,50,960,590)==new PixelCrop(0,0,3840,2160),"full selection preserves all pixels");
Check(CropMapping.Select(fitted,3840,2160,300,250,100,150)==new PixelCrop(400,400,800,400),"reverse drag maps to native pixels");
Check(CropMapping.Select(fitted,3840,2160,-200,-200,1200,900)==new PixelCrop(0,0,3840,2160),"out of bounds selection clips safely");
Check(CropMapping.Select(fitted,3840,2160,100,100,100,100)==null,"click does not create crop");
Check(CropMapping.Select(fitted,3840,2160,0,0,300,40)==null,"letterbox only selection rejected");
var portrait=CropMapping.Fit(1200,1920,1000,800);
Check(portrait==new ImageArea(250,0,500,800),"portrait display fit");
Check(CropMapping.Select(portrait,1200,1920,250,0,750,800)==new PixelCrop(0,0,1200,1920),"portrait native pixel bounds");
try { CropMapping.Fit(1920,1080,double.NaN,500);throw new Exception("NaN was accepted"); }
catch(ArgumentOutOfRangeException){Check(true,"invalid view dimensions rejected");}
Console.WriteLine("All 20 core checks passed.");
