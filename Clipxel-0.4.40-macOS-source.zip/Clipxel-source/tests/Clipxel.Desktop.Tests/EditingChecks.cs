using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Input;
using Clipxel.Desktop;
using SkiaSharp;
internal static class EditingChecks
{
    internal static void Run(Action<bool,string> check)
    {
        using var board=new BoardSurface();
        var frame=ImageInputs.Sample();board.AddFrames([frame,frame]);
        int card=board.Items[0].Id;
        var annotation=new BoardAnnotation(0,BoardTool.Line,[new(10,10),new(200,10)],"#FFFF0000",8,"",24){CardId=card};
        board.AddAnnotation(annotation);
        check(board.Annotations.Count==1,"annotation creation enters document");
        board.History(false);check(board.Annotations.Count==0&&board.Items.Count==2,"annotation undo preserves images");
        board.History(true);check(board.Annotations.Count==1,"annotation redo restores editable state");
        board.SelectAnnotation(board.Annotations[0].Id);board.UpdateSelectedAnnotation(color:"#FF00FF00");
        using(var image=SKBitmap.Decode(board.RenderedFrames()[0].Png))check(image.GetPixel(50,10).Green>240&&image.GetPixel(50,10).Red<10,"pin export composites editable annotation");
        using(var original=SKBitmap.Decode(board.Frames()[0].Png))check(original.GetPixel(50,10)!=SKColors.Lime,"pin export does not flatten original source");
        var saved=board.Annotations.ToArray();board.RestoreSession(board.Items.ToArray(),1,new Vector(32,32));board.RestoreEditing(saved,[]);
        board.SelectAnnotation(saved[0].Id);board.UpdateSelectedAnnotation(color:"#FFFF0000");
        check(board.Annotations[0].Color=="#FFFF0000"&&board.CanUndo,"restored annotations remain editable with history");
        board.History(false);check(board.Annotations[0].Color=="#FF00FF00","restored annotation edit undo exact");
        board.SelectAll();board.GroupSelected("範例");check(board.Groups.Count==1&&board.Groups[0].Members.Length==2,"group stores stable image members");
        board.DeleteSelected();check(board.Items.Count==0&&board.Groups.Count==0&&board.Annotations.Count==0,"deleting group members removes linked annotation and empty group");
        board.History(false);check(board.Items.Count==2&&board.Groups.Count==1&&board.Annotations.Count==1,"undo restores images groups annotations together");
        var host=new Window{Width=900,Height=700,Content=board};host.Show();Avalonia.Threading.Dispatcher.UIThread.RunJobs();
        board.SelectAnnotation(board.Annotations[0].Id);board.ActiveTool=BoardTool.Select;
        host.MouseDown(new Point(82,42),MouseButton.Left);host.MouseMove(new Point(102,62));host.MouseUp(new Point(102,62),MouseButton.Left);
        check(Math.Abs(board.Annotations[0].Points[0].X-30)<.01,"loaded annotation pointer drag updates world coordinates");
        board.History(false);check(Math.Abs(board.Annotations[0].Points[0].X-10)<.01,"annotation drag is one undo operation");
        host.Close();
        using var styled=new BoardSurface();styled.AddFrames([frame]);
        styled.AddAnnotation(new BoardAnnotation(0,BoardTool.Rectangle,[new(20,20),new(120,120)],"#FFFF0000",4,"",24){CardId=styled.Items[0].Id});
        styled.UpdateSelectedStyle(fill:true,stroke:false,opacity:1,font:"Arial",fontSize:32,lineStyle:2);
        using(var image=SKBitmap.Decode(styled.RenderedFrames()[0].Png))check(image.GetPixel(70,70)==SKColors.Red,"shape fill style is included in pixel export");
        styled.History(false);
        using(var image=SKBitmap.Decode(styled.RenderedFrames()[0].Png))check(image.GetPixel(70,70)!=SKColors.Red,"style undo restores unfilled shape without mutated metadata");
        styled.UpdateSelectedStyle(fill:false,stroke:true,opacity:1,lineStyle:3);
        styled.AddAnnotation(new BoardAnnotation(0,BoardTool.Line,[new(200,100),new(300,100)],"#FFFF0000",6,"",24){CardId=styled.Items[0].Id,ProjectData=new System.Text.Json.Nodes.JsonObject{["Style"]=3}});
        using(var image=SKBitmap.Decode(styled.RenderedFrames()[0].Png))check(image.GetPixel(200,107).Red>240,"round endpoint style renders endpoint disks");
        var renderHost=new Window{Width=1000,Height=700,Content=styled};renderHost.Show();Avalonia.Threading.Dispatcher.UIThread.RunJobs();
        using(var preview=new Avalonia.Media.Imaging.RenderTargetBitmap(new PixelSize(1000,700),new Vector(96,96)))
        {
            preview.Render(styled);using var stream=new MemoryStream();preview.Save(stream);using var image=SKBitmap.Decode(stream.ToArray());
            check(image.GetPixel(232,139).Red>240,"preview includes matching endpoint style");
        }
        renderHost.Close();
    }
}
