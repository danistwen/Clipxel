using Avalonia;
using Avalonia.Input;
using Avalonia.Controls;
using Avalonia.LogicalTree;
using Avalonia.Interactivity;
using Avalonia.Headless;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Clipxel.Desktop;
using Clipxel.Core;
using Clipxel.Platform;
using System.Runtime.InteropServices;

int checks=0;
void Check(bool condition,string name){checks++;if(!condition)throw new Exception(name);Console.WriteLine("PASS "+name);}
AppBuilder.Configure<MigrationApp>()
 .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing=false })
 .UseSkia().SetupWithoutStarting();
ProjectStoreTests.Run(Check);
EditingChecks.Run(Check);
using var source=new RenderTargetBitmap(new PixelSize(20,10),new Vector(192,192));
using(var context=source.CreateDrawingContext())
{
 context.FillRectangle(Brushes.Red,new Rect(0,0,5,5));
 context.FillRectangle(Brushes.Blue,new Rect(5,0,5,5));
}
var png=CropWindow.CropImage(source,new PixelCrop(10,0,10,10));
using var decoded=new Bitmap(new MemoryStream(png));
Check(decoded.PixelSize==new PixelSize(10,10),"crop retains selected pixel dimensions at 192 DPI");
var memory=Marshal.AllocHGlobal(400);
try
{
 decoded.CopyPixels(new PixelRect(0,0,10,10),memory,400,40);
 var bytes=new byte[400];Marshal.Copy(memory,bytes,0,400);
 Check(bytes.Where((b,i)=>i%4==3).All(b=>b==255),"crop stays opaque, no empty border");
 Check(Enumerable.Range(0,100).All(i=>bytes.AsSpan(i*4,4).SequenceEqual(bytes.AsSpan(0,4))),"crop has no neighboring red pixels");
 using var exact = SkiaSharp.SKBitmap.Decode(png);
 Check(Enumerable.Range(0,100).All(i=>exact.GetPixel(i%10,i/10)==new SkiaSharp.SKColor(0,0,255,255)),"crop preserves exact blue pixels");
}
finally{Marshal.FreeHGlobal(memory);}
var frame=new CapturedFrame(png,-1920,0,10,10,10,10);
var pin=new PinWindow(frame,_=>{});pin.Show();
Check(pin.Topmost && pin.IsVisible,"pin starts visible and topmost");
pin.Hide();Check(!pin.IsVisible,"pin can hide before capture");
pin.Show();Check(pin.IsVisible,"pin restores after capture");
pin.Close();
var cropWindow=new CropWindow(frame);cropWindow.Show();cropWindow.Close();
Check(cropWindow.Result is null,"closing selection does not create a crop");
var overlayTest=new CropWindow(ImageInputs.Sample(),true);overlayTest.Show();
Avalonia.Threading.Dispatcher.UIThread.RunJobs();
overlayTest.MouseDown(new Point(100,100),MouseButton.Left);overlayTest.MouseMove(new Point(300,250));overlayTest.MouseUp(new Point(300,250),MouseButton.Left);
Check(overlayTest.Result is not null&&!overlayTest.IsVisible,"desktop overlay release crops immediately without preview panel");
var cancelledOverlay=new CropWindow(ImageInputs.Sample(),true);cancelledOverlay.Show();cancelledOverlay.KeyPress(Key.Escape,RawInputModifiers.None);
Check(cancelledOverlay.Result is null&&!cancelledOverlay.IsVisible,"desktop overlay Escape cancels without a pin");
var main=new CaptureWindow();main.Show();
Check(main.IsVisible,"capture control window opens in headless UI");
if(args.Length>0)
{
 Avalonia.Threading.Dispatcher.UIThread.RunJobs();
 using var preview=new RenderTargetBitmap(new PixelSize(760,660),new Vector(96,96));
 preview.Render(main);preview.Save(args[0]);
}
var sampleButton=main.GetLogicalDescendants().OfType<Button>().First(b=>b.Content?.ToString()=="開啟測試圖");
Check(sampleButton.IsEnabled,"local image entry enabled when native capture is unavailable");
sampleButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
Check(main.PinCount==1,"local image button creates a pin without screen permission");
var boardEntry=main.GetLogicalDescendants().OfType<Button>().First(b=>b.Content?.ToString()=="進入畫布");
boardEntry.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
Check(main.ActiveBoard?.Surface.Items.Count==1,"mode switch transfers existing pin");
Check(!main.IsVisible&&main.ActiveBoard!.IsVisible,"canvas mode hides control window");
main.ActiveBoard!.Close();
Check(main.ActiveBoard is null&&main.IsVisible&&main.PinCount==1,"closing canvas preserves images and restores control window");
main.Close();
var local=ImageInputs.Sample();
Check(local.PixelWidth==960&&local.PixelHeight==600,"built-in sample available without screen capture");
var imported=ImageInputs.FromEncoded(local.Png);
Check(imported.PixelWidth==960&&imported.PixelHeight==600,"PNG import preserves dimensions");
using(var localDecoded=SkiaSharp.SKBitmap.Decode(imported.Png))
 Check(localDecoded.GetPixel(10,10)==SkiaSharp.SKColor.Parse("#005DFF"),"PNG import preserves test color");
try { ImageInputs.FromEncoded(new byte[]{1,2,3});throw new Exception("Invalid image accepted"); }
catch(InvalidDataException){Check(true,"invalid image rejected");}

var board=new BoardWindow(new[]{local,local});board.Show();
Avalonia.Threading.Dispatcher.UIThread.RunJobs();
var canvas=board.Surface;
Check(canvas.Items.Count==2,"canvas receives pin images");
var originalSizes=canvas.Items.Select(i=>(i.Width,i.Height)).ToArray();
canvas.Arrange();
Check(canvas.Items.Select(i=>(i.Width,i.Height)).SequenceEqual(originalSizes),"canvas arrangement preserves dimensions");
var before=canvas.Items.ToArray();
canvas.SelectAll();
Point Screen(double x,double y)=>new(x*canvas.Zoom+canvas.Pan.X,y*canvas.Zoom+canvas.Pan.Y);
var start=Screen(before[0].X+100,before[0].Y+100);
board.MouseDown(start,MouseButton.Left);
board.MouseMove(start+new Vector(40,30));
board.MouseUp(start+new Vector(40,30),MouseButton.Left);
Check(Math.Abs(canvas.Items[0].X-before[0].X-40/canvas.Zoom)<.001,"pointer drag moves selected image");
Check(Math.Abs(canvas.Items[1].X-before[1].X-40/canvas.Zoom)<.001,"pointer drag moves selection together");
canvas.History(false);
Check(canvas.Items.SequenceEqual(before),"single undo restores whole drag");
canvas.History(true);
Check(canvas.Items[0].X!=before[0].X,"redo restores drag");
var zoomPoint=new Point(410,220);var world=canvas.World(zoomPoint);canvas.ZoomAt(zoomPoint,1.2);
Check(Math.Abs(canvas.World(zoomPoint).X-world.X)+Math.Abs(canvas.World(zoomPoint).Y-world.Y)<.001,"zoom preserves pointer anchor");
var sourceItem=canvas.Items[0];
var proportional=BoardSurface.Resize(sourceItem,2,new Point(sourceItem.X+sourceItem.Width*2,sourceItem.Y+sourceItem.Height*1.4),false);
Check(Math.Abs(proportional.Width/proportional.Height-sourceItem.Width/sourceItem.Height)<.0001,"corner resize preserves aspect ratio");
var free=BoardSurface.Resize(sourceItem,2,new Point(sourceItem.X+120,sourceItem.Y+450),true);
Check(Math.Abs(free.Width-120)<.001&&Math.Abs(free.Height-450)<.001,"Alt resize allows independent dimensions");
canvas.DeleteSelected();Check(canvas.Items.Count==0,"delete removes selected images");
canvas.History(false);Check(canvas.Items.Count==2,"undo restores deleted images and frames");
foreach(var theme in new[]{"Dark","Light","White"})board.ApplyTheme(theme);
Check(((ISolidColorBrush)board.Background!).Color==Colors.White,"theme switch reaches white without exception");
Check(canvas.Items.Count==2,"theme switching preserves document");
Check(board.Frames.Length==2&&board.Frames[0].Png.SequenceEqual(local.Png),"return frames preserve source pixels");
canvas.Arrange();canvas.Fit();
var box=canvas.DocumentBounds();
var a=Screen(box.Left,box.Top)-new Vector(12,12);
var z=Screen(box.Right,box.Bottom)+new Vector(12,12);
board.MouseDown(a,MouseButton.Left);board.MouseMove(z);board.MouseUp(z,MouseButton.Left);
Check(canvas.Selected.Count==2,"marquee pointer gesture selects both images");
var resizeItem=canvas.Items[0];
var edge=Screen(resizeItem.X+resizeItem.Width,resizeItem.Y+resizeItem.Height);
board.MouseDown(edge,MouseButton.Left);board.MouseMove(edge+new Vector(25,35));board.MouseUp(edge+new Vector(25,35),MouseButton.Left);
Check(canvas.Items[0].Width>resizeItem.Width&&Math.Abs(canvas.Items[0].Width/canvas.Items[0].Height-resizeItem.Width/resizeItem.Height)<.001,"pointer corner gesture resizes proportionally");
canvas.History(false);
Check(canvas.Items[0]==resizeItem,"undo restores corner gesture");
canvas.PanTool=true;var oldPan=canvas.Pan;
board.MouseDown(new Point(300,130),MouseButton.Left);board.MouseMove(new Point(330,150));board.MouseUp(new Point(330,150),MouseButton.Left);
Check(canvas.Pan==oldPan+new Vector(30,20),"pan pointer gesture translates viewport");
canvas.PanTool=false;canvas.Fit();
Avalonia.Threading.Dispatcher.UIThread.RunJobs();
if(args.Length>1)
{
 using var preview=new RenderTargetBitmap(new PixelSize(1100,760),new Vector(96,96));
 preview.Render(board);preview.Save(args[1]);
}
var helpToggle=board.GetLogicalDescendants().OfType<Button>().Single(b=>b.Name=="CanvasHelpToggle");
var helpCard=board.GetLogicalDescendants().OfType<Border>().Single(b=>b.Name=="CanvasHelpCard");
helpToggle.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
Check(helpCard.IsVisible,"help toggle opens readable panel");
board.MouseDown(new Point(400,100),MouseButton.Left);board.MouseUp(new Point(400,100),MouseButton.Left);
Check(!helpCard.IsVisible,"outside click dismisses help");
board.RaiseEvent(new KeyEventArgs{RoutedEvent=InputElement.KeyDownEvent,Key=Key.Tab});
Check(!helpToggle.IsVisible,"Tab hides help toggle with chrome");
board.RaiseEvent(new KeyEventArgs{RoutedEvent=InputElement.KeyDownEvent,Key=Key.Tab});
board.Close();
Check(!board.IsVisible,"canvas closes cleanly");
Check(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(BoardGlyph.ReturnMaskBytes)).ToLowerInvariant()=="1b332bfbff96c5c6dde2299ec4b0254bfee8a354d44fd4dfefb96db1714df214","return icon uses exact Windows mask bytes");
using var exportSurface=new BoardSurface();
exportSurface.AddFrames(new[]{frame});exportSurface.SelectAll();
using(var pngExport=SkiaSharp.SKBitmap.Decode(exportSurface.ExportImage(false)))
{
 Check(pngExport.Width==14&&pngExport.Height==14,"export follows Windows image extent plus four pixels");
 Check(pngExport.GetPixel(0,0).Alpha==0,"PNG export has transparent padding and no selection border");
 Check(pngExport.GetPixel(5,5)==new SkiaSharp.SKColor(0,0,255,255),"PNG export preserves source blue");
}
using(var jpegExport=SkiaSharp.SKBitmap.Decode(exportSurface.ExportImage(true)))
{
 Check(jpegExport.GetPixel(0,0).Alpha==255,"JPEG export flattens transparency");
}
var token=exportSurface.CopySelected();
Check(!exportSurface.PasteObjects("external text"),"paste rejects stale object clipboard");
Check(exportSurface.PasteObjects(token)&&exportSurface.Items.Count==2,"object paste creates image copy");
Check(exportSurface.Items[1].Width==10&&exportSurface.Items[1].X==24,"object paste preserves size and offsets position");
exportSurface.History(false);Check(exportSurface.Items.Count==1,"object paste undoes in one step");
exportSurface.History(true);Check(exportSurface.Items.Count==2,"object paste redoes in one step");
var sessionBoard=new BoardWindow(new[]{local});sessionBoard.Show();
sessionBoard.Surface.ZoomAt(new Point(300,200),1.7);sessionBoard.ApplyTheme("Light");
var session=sessionBoard.SaveSession();sessionBoard.Close();
var restored=new BoardWindow(Array.Empty<CapturedFrame>());restored.RestoreSession(session);restored.Show();
Check(restored.Surface.Items.SequenceEqual(session.Items),"canvas session retains image layout");
Check(restored.Surface.Zoom==session.Zoom&&restored.Surface.Pan==session.Pan,"canvas session retains zoom and pan after opening");
Check(((ISolidColorBrush)restored.Background!).Color==Color.Parse("#7E899B"),"canvas session retains theme");
restored.Close();
var logoFit=BoardBrand.FitTransform(new Size(52,15));
Check(logoFit.M11==logoFit.M22,"brand logo keeps uniform scale");
Check(Math.Abs(logoFit.M22*175-15)<.00001&&logoFit.M31>0,"brand logo fits height and centers without flattening");
var expanded=BoardWindow.ReconcileSession(session,new[]{local,frame});
Check(expanded.Items[0]==session.Items[0],"adding pin preserves prior canvas placement");
Check(expanded.Items.Length==2&&expanded.Items[1].Id!=expanded.Items[0].Id,"new pin receives unique canvas item");
Console.WriteLine($"All {checks} desktop checks passed (headless Linux, not native macOS).");

