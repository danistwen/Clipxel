using System.IO.Compression;
using System.Text.Json.Nodes;
using Clipxel.Desktop;
using Avalonia;

internal static class ProjectStoreTests
{
    internal static void Run(Action<bool,string> check)
    {
        var png=ImageInputs.Sample().Png;
        JsonObject Fixture()=>JsonNode.Parse("""
        {"Version":1,"Background":"#FF1E2128","Zoom":0.5,"PanX":-25,"PanY":12,"FloatingX":99,"FloatingY":45,"FloatingWidth":620,"FloatingHeight":120,"Topmost":false,"UnknownFuture":{"value":17},
         "Cards":[{"X":100,"Y":50,"Width":480,"Height":300,"Z":9,"ExtraCard":"keep","Ink":[{"Tool":4,"Style":2,"X":20,"Y":40,"X2":100,"Y2":200,"Width":6,"Font":22,"Color":"#FF123456","Text":"","FontFamily":"Segoe UI","Independent":true,"Stroke":true,"Fill":false,"StrokeOpacity":0.7,"FillOpacity":0.45,"RectangleMode":0,"Points":[],"FutureInk":42}]}],
         "Groups":[{"Id":"original-group","Name":"參考圖","X":70,"Y":10,"Width":550,"Height":400,"Fill":"#FF465CFF","Border":"#FFFFFFFF","Opacity":0.2,"ColumnGap":24,"RowGap":38,"AutoArrange":true,"TitleSize":18,"TitleColor":"#FFFFD74A","Dashed":true,"FutureGroup":"retained"}],
         "Ink":[{"Tool":5,"Style":0,"X":-100,"Y":-50,"X2":100,"Y2":0,"Width":3,"Font":22,"Color":"#FFFFFFFF","Text":"中文文字","FontFamily":"PingFang TC","Points":[]}],"Links":[]}
        """)!.AsObject();
        MemoryStream Zip(JsonObject root,bool includeImage=true,bool duplicate=false)
        {
            var stream=new MemoryStream();using(var zip=new ZipArchive(stream,ZipArchiveMode.Create,true))
            {
                using(var writer=new StreamWriter(zip.CreateEntry("project.json").Open()))writer.Write(root.ToJsonString());
                if(includeImage){using var image=zip.CreateEntry("images/0.png").Open();image.Write(png);}
                if(duplicate){using var writer=new StreamWriter(zip.CreateEntry("project.json").Open());writer.Write("{}");}
            }
            stream.Position=0;return stream;
        }
        using var source=Zip(Fixture());var doc=ProjectStore.Load(source);
        check(doc.Items.Length==1&&doc.Items[0].Frame.Png.SequenceEqual(png),"Windows project preserves original PNG bytes");
        check(doc.Annotations[0].CardId==0&&doc.Annotations[0].Points[0]==new BoardPoint(110,70)&&doc.Annotations[0].Width==3,"Windows card ink converts source pixels to world coordinates");
        check(doc.Groups[0].Members.SequenceEqual(new[]{0})&&doc.Groups[0].AutoArrange,"Windows group membership and automatic layout restored");
        using var saved=new MemoryStream();ProjectStore.Write(saved,doc.Items,doc.Zoom,doc.Pan,doc.Annotations,doc.Groups,doc);saved.Position=0;
        using(var zip=new ZipArchive(saved,ZipArchiveMode.Read,true))
        using(var stream=zip.GetEntry("project.json")!.Open())
        {
            var root=JsonNode.Parse(stream)!;
            check(root["Cards"]![0]!["Z"]!.GetValue<int>()==9&&root["Cards"]![0]!["Ink"]![0]!["X"]!.GetValue<double>()==20,"Windows card Z and original annotation coordinates round trip");
            check(root["UnknownFuture"]!["value"]!.GetValue<int>()==17&&root["Cards"]![0]!["ExtraCard"]!.GetValue<string>()=="keep"&&root["Cards"]![0]!["Ink"]![0]!["FutureInk"]!.GetValue<int>()==42,"Unknown root, card and ink metadata survive save");
            check(root["Groups"]![0]!["Id"]!.GetValue<string>()=="original-group"&&root["Groups"]![0]!["RowGap"]!.GetValue<int>()==38&&root["Groups"]![0]!["FutureGroup"]!.GetValue<string>()=="retained","Windows group identity, row gap and metadata survive save");
        }
        saved.Position=0;var reloaded=ProjectStore.Load(saved);
        check(reloaded.Annotations[1].Text=="中文文字"&&reloaded.Annotations[1].ProjectData!["FontFamily"]!.GetValue<string>()=="PingFang TC","Project Unicode text and font preserved");
        bool Reject(JsonObject root,bool image=true,bool duplicate=false){try{using var stream=Zip(root,image,duplicate);ProjectStore.Load(stream);return false;}catch(InvalidDataException){return true;}}
        var invalid=Fixture();invalid["Version"]=2;check(Reject(invalid),"Unsupported project versions rejected");
        check(Reject(Fixture(),false),"Missing project image rejected before document replacement");
        check(Reject(Fixture(),true,true),"Duplicate ZIP entry names rejected");
        invalid=Fixture();invalid["Groups"]![0]!["Opacity"]=-.1;check(Reject(invalid),"Invalid group opacity rejected");
        invalid=Fixture();invalid["Cards"]![0]!["Width"]=-1;check(Reject(invalid),"Invalid project geometry rejected");
        invalid=Fixture();invalid["Cards"]![0]!["Ink"]![0]!["StrokeOpacity"]=2;check(Reject(invalid),"Invalid annotation opacity rejected");
        using var deleted=new MemoryStream();ProjectStore.Write(deleted,doc.Items,doc.Zoom,doc.Pan,[],[],doc);deleted.Position=0;var emptyEditing=ProjectStore.Load(deleted);
        check(emptyEditing.Annotations.Length==0&&emptyEditing.Groups.Length==0,"Deleted imported annotations and groups do not return on save");
        using var empty=new MemoryStream();ProjectStore.Write(empty,[],1,new Vector(),[],[]);empty.Position=0;
        var emptyDoc=ProjectStore.Load(empty);check(emptyDoc.Items.Length==0&&emptyDoc.Annotations.Length==0&&emptyDoc.Groups.Length==0,"Empty Windows v1 project supported");
        using var fresh=new MemoryStream();ProjectStore.Write(fresh,doc.Items,1,new Vector(),[],[]);fresh.Position=0;
        check(ProjectStore.Load(fresh).Items.Length==1,"New Mac project writes Windows v1 compatible structure");
    }
}
